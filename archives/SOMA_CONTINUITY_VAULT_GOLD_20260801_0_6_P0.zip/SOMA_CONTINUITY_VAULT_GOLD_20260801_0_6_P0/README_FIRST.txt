SOMA CONTINUITY VAULT — GOLD 20260801 / SOMA-CELL 0.6-P0
================================================================
現在の凍結基準: SOMA-CELL 0.6-P0.0
身体ポート契約: 0.6-P0.2
次のマイルストーン: SOMA-CELL 0.6-P1

このVaultの目的
----------------
会話コンテキスト、sandboxリンク、一時添付に依存せず、P0の検証済み
化学身体ポートとSOMA-0〜0.5の系譜を復元し、P1の1物質神経細胞を
正しい身体境界上で実装できる状態を保存する。

新しい会話で再開するとき
------------------------
1. このZIP全体を添付する。
2. governance/00_MANDATORY_STARTUP_GATE_JA.mdを最初に読む。
3. governance/PROJECT_STATE.json、docs/SOMA_CONTEXT_HANDOFF_JA.md、
   docs/SOMA_CELL_0_6_INTEGRATION_CONTRACT.md、
   docs/SOMA_CELL_0_6_P0_BODY_PORT_CONTRACT.mdを正本として扱う。
4. SHA256SUMS.txtを照合する。
5. P1実装前にP0本体・22項目検証・15試行レポートを再読し、
   最新Git HEADで新しいプリフライト証跡を発行する。

凍結ルール
----------
- P0は情報処理神経を含まない。適応利益を主張しない。
- P1組織はChemicalBodyPortの公開API以外から身体へアクセスしない。
- ATP・材料・信号・損傷・死体化学・eDNA・HGTを無料化しない。
- 未接続／Null時の0.5ロックステップとP0 22/22検証を回帰試験として維持する。
- 旧SOMA-5〜7（Rなし）は統合元にしない。

重要
----
ChatGPTの会話コンテキストやsandboxは永久保管を保証しない。このZIPを
ユーザー自身のGoogle Drive、iCloud Drive、Filesアプリ、PC等にも保存する。
