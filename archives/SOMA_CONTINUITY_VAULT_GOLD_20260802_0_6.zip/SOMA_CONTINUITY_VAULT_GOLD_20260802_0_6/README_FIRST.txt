SOMA Continuity Vault — SOMA-CELL 0.6.0

Current baseline: SOMA-CELL 0.6.0 (engineering PASS, science PASS_WITH_LIMITS)
Next milestone: SOMA-CELL 0.6.1
First read governance/00_MANDATORY_STARTUP_GATE_JA.md, governance/PROJECT_STATE.json, docs/SOMA_CONTEXT_HANDOFF_JA.md and docs/SOMA_CELL_0_6_FORMAL_CONTRACT.md.
