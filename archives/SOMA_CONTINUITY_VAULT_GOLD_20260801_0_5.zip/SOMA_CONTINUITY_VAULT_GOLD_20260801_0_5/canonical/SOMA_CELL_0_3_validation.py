# coding: utf-8
"""Deterministic mechanism validation for SOMA-CELL 0.3.

The suite tests material damage conversion, paid repair, evolvable fidelity,
asymmetric damage inheritance, structural death, physical division, material
accounting, selection in the controlled life-history assay, and exact
save/restore continuation.  It intentionally separates mechanistic tests from
claims about biological life or open-ended evolution.
"""
from __future__ import division

import csv
import math
import os
import tempfile

import numpy as np

import SOMA_CELL_0_3_pythonista as soma

BASE_DIR = os.path.dirname(__file__)
CSV_PATH = os.path.join(BASE_DIR, 'soma_cell_0_3_validation.csv')
TXT_PATH = os.path.join(BASE_DIR, 'SOMA_CELL_0_3_VALIDATION_RESULTS.txt')


def _fmt(value):
    if isinstance(value, (float, np.floating)):
        return '{:.12g}'.format(float(value))
    return str(value)


def _record(rows, name, passed, observed, criterion):
    rows.append({
        'test': name,
        'pass': 'PASS' if bool(passed) else 'FAIL',
        'observed': _fmt(observed),
        'criterion': str(criterion),
    })


def _state_equal(a, b):
    if isinstance(a, np.ndarray) or isinstance(b, np.ndarray):
        try:
            return np.array_equal(np.asarray(a), np.asarray(b))
        except Exception:
            return False
    if isinstance(a, dict) and isinstance(b, dict):
        return set(a) == set(b) and all(_state_equal(a[key], b[key]) for key in a)
    if isinstance(a, (list, tuple)) and isinstance(b, (list, tuple)):
        return len(a) == len(b) and all(_state_equal(x, y) for x, y in zip(a, b))
    if isinstance(a, (float, np.floating)) or isinstance(b, (float, np.floating)):
        return float(a) == float(b)
    return a == b


def _remove_repair_kind(cell, kind):
    for fingerprint in list(cell.proteins):
        spec = cell.gene_specs.get(fingerprint)
        if (
            spec is not None
            and spec['role'] == soma.ROLE_REGULATOR
            and int(spec['parameter']) % 8 == int(kind)
        ):
            del cell.proteins[fingerprint]
    cell._sync_protein_pool()


def _injured_cell(seed=11):
    world = soma.DamageWorld(
        seed=seed,
        initial_cells=1,
        config=soma.LifeHistoryConfig(stress_mode='stable'),
    )
    cell = world.cells[0]
    cell._damage_active_proteins(0.15)
    cell._aggregate_damaged_proteins(0.05)
    cell.pools[soma.POOL_REACTIVE] += 0.08
    cell.genome_lesions = [0.70 for _ in cell.genomes]
    cell.membrane_oxidation[:] = 0.55
    cell.pools[soma.POOL_ATP] = 1.50
    cell.pools[soma.POOL_FUEL] = max(cell.pools[soma.POOL_FUEL], 0.80)
    cell.pools[soma.POOL_MEM_PRECURSOR] = max(
        cell.pools[soma.POOL_MEM_PRECURSOR], 0.40
    )
    cell._sync_damage_pool()
    return world, cell


def _division_probe(symmetric):
    config = soma.LifeHistoryConfig(
        stress_mode='stable',
        damage_segregation=True,
        forced_symmetric_damage=bool(symmetric),
    )
    world = soma.DamageWorld(seed=9, initial_cells=1, config=config)
    cell = world.cells[0]
    cell.genomes.append(cell.genomes[0].copy())
    cell.genome_lesions = [0.80, 0.80]
    cell._refresh_gene_cache()
    cell._damage_active_proteins(0.18)
    cell._aggregate_damaged_proteins(0.08)
    cell.pools[soma.POOL_REACTIVE] = 0.12
    cell.membrane_oxidation[:] = 0.60
    cell.pools[soma.POOL_ATP] = 1.00
    cell.division_progress = 1.0
    cell.septum_mass = 0.12
    parent_damage = cell.damage_burden()
    daughters = cell.split(world)
    pair = tuple(d.damage_burden() for d in daughters)
    return world, parent_damage, daughters, pair


def run_validation():
    rows = []

    # 1. Chronological age alone is not a death condition.
    old_world = soma.DamageWorld(
        seed=3,
        initial_cells=1,
        config=soma.LifeHistoryConfig(
            stress_mode='stable',
            endogenous_damage=False,
            environmental_damage=False,
            division=False,
        ),
    )
    old = old_world.cells[0]
    old.age = 1.0e7
    old.pools[soma.POOL_ATP] = 1.2
    old.pools[soma.POOL_REACTIVE] = 0.0
    old.genome_lesions = [0.0]
    old.membrane_oxidation[:] = 0.0
    for _ in range(100):
        old.update_viability(0.1)
    _record(
        rows,
        'chronological_age_alone_does_not_kill',
        old.alive,
        'alive={}, age={:.1f}'.format(old.alive, old.age),
        'a structurally healthy cell remains viable even at a very large assigned age',
    )

    # 2. Damage conversion changes molecular state without creating/destroying matter.
    world = soma.DamageWorld(seed=5, initial_cells=1)
    cell = world.cells[0]
    before = cell.material_mass()
    moved = cell._damage_active_proteins(0.11)
    aggregated = cell._aggregate_damaged_proteins(0.045)
    after = cell.material_mass()
    _record(
        rows,
        'protein_damage_state_changes_conserve_material',
        moved > 0.09 and aggregated > 0.035 and abs(after - before) < 1e-12,
        'moved={:.6g}, aggregated={:.6g}, residual={:.3e}'.format(
            moved, aggregated, before - after
        ),
        'active→damaged→aggregate transitions preserve total material to roundoff',
    )

    # 3. More flux/stress produces more endogenous damage from the same starting state.
    template_world = soma.DamageWorld(seed=7, initial_cells=1)
    state = template_world.cells[0].state_dict()
    low_world = soma.DamageWorld(seed=17, initial_cells=0)
    high_world = soma.DamageWorld(seed=17, initial_cells=0)
    low = soma.DamageProtoCell.from_state(low_world.rng, state)
    high = soma.DamageProtoCell.from_state(high_world.rng, state)
    low.last_catalysis = 0.0
    low.last_translation = 0.0
    low.current_stress = 0.0
    high.last_catalysis = 5.0
    high.last_translation = 2.0
    high.current_stress = 0.85
    low._decay_information_and_proteins(low_world, 5.0)
    high._decay_information_and_proteins(high_world, 5.0)
    _record(
        rows,
        'damage_generation_tracks_flux_and_stress',
        high.last_damage_generated > low.last_damage_generated * 2.0,
        'low={:.8g}, high={:.8g}'.format(
            low.last_damage_generated, high.last_damage_generated
        ),
        'the high-flux/high-stress cell generates at least twice as much damage',
    )

    # 4. Full repair reduces damage and pays ATP.
    repair_world, repaired = _injured_cell(seed=11)
    repair_before = repaired.damage_burden()
    atp_before = repaired.pools[soma.POOL_ATP]
    for _ in range(20):
        repaired._repair_damage(repair_world, 0.5, repair_world.config)
    repair_after = repaired.damage_burden()
    atp_after = repaired.pools[soma.POOL_ATP]
    _record(
        rows,
        'repair_is_paid_and_reduces_damage',
        repair_after < repair_before * 0.82 and atp_after < atp_before - 0.05,
        'damage {:.6f}->{:.6f}, ATP {:.6f}->{:.6f}'.format(
            repair_before, repair_after, atp_before, atp_after
        ),
        'repair lowers burden by >18% while consuming >0.05 ATP',
    )

    # 5. Turning repair functions off prevents the same recovery.
    ablation_config = soma.LifeHistoryConfig(
        stress_mode='stable',
        protein_repair=False,
        genome_repair=False,
        membrane_repair=False,
    )
    ablation_world, unrepairable = _injured_cell(seed=11)
    ablation_world.config = ablation_config
    ablation_before = unrepairable.damage_burden()
    atp_ablation_before = unrepairable.pools[soma.POOL_ATP]
    for _ in range(20):
        unrepairable._repair_damage(ablation_world, 0.5, ablation_config)
    ablation_after = unrepairable.damage_burden()
    _record(
        rows,
        'repair_ablation_blocks_recovery',
        abs(ablation_after - ablation_before) < 1e-10
        and abs(unrepairable.pools[soma.POOL_ATP] - atp_ablation_before) < 1e-10,
        'damage {:.6f}->{:.6f}, ATP delta={:.3e}'.format(
            ablation_before, ablation_after,
            unrepairable.pools[soma.POOL_ATP] - atp_ablation_before,
        ),
        'with all repair channels disabled, damage and repair ATP remain unchanged',
    )

    # 6. Proofreading lowers effective error and slows/costs copying.
    def proofreading_probe(enabled):
        cfg = soma.LifeHistoryConfig(
            gene_expression=False,
            proofreading=enabled,
            mutation=True,
            variable_length=False,
            gene_duplication=False,
            structural_rate=0.0,
            mutation_rate=0.020,
            stress_mode='stable',
        )
        probe_world = soma.DamageWorld(seed=77, initial_cells=1, config=cfg)
        probe = probe_world.cells[0]
        probe.pools[soma.POOL_ATP] = 1.50
        probe.pools[soma.POOL_NUCLEOTIDE] = 1.00
        probe.genome_lesions = [1.20]
        probe.pools[soma.POOL_REACTIVE] = 0.15
        for _ in range(300):
            probe._replicate_genome(probe_world, 0.05, cfg)
        return (
            probe.last_effective_error_rate,
            probe.cumulative_proofreading_atp,
            len(probe.replication_copy),
        )

    proof_on = proofreading_probe(True)
    proof_off = proofreading_probe(False)
    _record(
        rows,
        'proofreading_trades_speed_and_atp_for_fidelity',
        proof_on[0] < proof_off[0] * 0.75
        and proof_on[1] > 0.0
        and proof_on[2] < proof_off[2],
        'error on/off={:.6g}/{:.6g}, ATP={:.6g}, copied={}/{}'.format(
            proof_on[0], proof_off[0], proof_on[1], proof_on[2], proof_off[2]
        ),
        'proofreading lowers error by >25%, consumes ATP, and copies fewer symbols in fixed time',
    )

    # 7. Genome repair specifically removes lesions at a chemical cost.
    genome_world, genome_cell = _injured_cell(seed=19)
    for kind in (
        soma.REPAIR_ANTIOXIDANT,
        soma.REPAIR_CHAPERONE,
        soma.REPAIR_PROTEASE,
        soma.REPAIR_MEMBRANE,
    ):
        _remove_repair_kind(genome_cell, kind)
    lesion_before = genome_cell.mean_genome_lesion()
    atp_before = genome_cell.pools[soma.POOL_ATP]
    for _ in range(20):
        genome_cell._repair_damage(genome_world, 0.5, genome_world.config)
    lesion_after = genome_cell.mean_genome_lesion()
    _record(
        rows,
        'genome_lesions_are_repairable_but_not_free',
        lesion_after < lesion_before and genome_cell.pools[soma.POOL_ATP] < atp_before,
        'lesion {:.6f}->{:.6f}, ATP spent={:.6f}'.format(
            lesion_before, lesion_after, atp_before - genome_cell.pools[soma.POOL_ATP]
        ),
        'genome-repair proteins lower lesion load and consume ATP',
    )

    # 8–9. Damage segregation creates a clean/dirty pair; symmetric ablation does not.
    asym_world, parent_damage, asym_daughters, asym_pair = _division_probe(False)
    sym_world, _, sym_daughters, sym_pair = _division_probe(True)
    asym_gap = abs(asym_pair[0] - asym_pair[1])
    sym_gap = abs(sym_pair[0] - sym_pair[1])
    _record(
        rows,
        'damage_segregation_rejuvenates_one_daughter',
        min(asym_pair) < parent_damage - 0.05
        and asym_gap > 0.10
        and sorted(d.pole_age for d in asym_daughters) == [0, 1],
        'parent={:.6f}, daughters=({:.6f},{:.6f}), gap={:.6f}'.format(
            parent_damage, asym_pair[0], asym_pair[1], asym_gap
        ),
        'one daughter is >0.05 cleaner than the parent and the pair differs by >0.10',
    )
    _record(
        rows,
        'symmetric_partition_ablation_removes_large_damage_gap',
        sym_gap < 0.03 and asym_gap > sym_gap * 4.0,
        'asymmetric gap={:.6f}, symmetric gap={:.6f}'.format(asym_gap, sym_gap),
        'forced symmetry keeps daughter burdens close and removes the large asymmetric gap',
    )
    _record(
        rows,
        'damage_partition_preserves_total_material',
        abs(asym_world.division_residual) < 1e-10
        and abs(sym_world.division_residual) < 1e-10,
        'asym={:.3e}, sym={:.3e}'.format(
            asym_world.division_residual, sym_world.division_residual
        ),
        'both division modes conserve total material to numerical roundoff',
    )

    # 10–11. The full spatial chemistry reaches an internally supported division.
    physical = soma.DamageWorld(seed=101, initial_cells=1)
    dt = 1.0 / soma.SIM_HZ
    first_division = None
    max_abs_ledger = 0.0
    for _ in range(int(260 * soma.SIM_HZ)):
        physical.step(dt)
        max_abs_ledger = max(max_abs_ledger, abs(physical.matter_ledger_residual()))
        if physical.divisions:
            first_division = physical.age
            break
        if not physical.living_cells():
            break
    living = physical.living_cells()
    _record(
        rows,
        'full_material_damage_loop_reaches_division',
        physical.divisions >= 1
        and len(living) == 2
        and all(cell.generation == 1 and len(cell.genomes) >= 1 for cell in living),
        'age={}, cells={}, divisions={}, generations={}, genomes={}'.format(
            _fmt(first_division), len(living), physical.divisions,
            [cell.generation for cell in living], [len(cell.genomes) for cell in living],
        ),
        'one parent becomes two G1 daughters, each retaining a material genome',
    )
    _record(
        rows,
        'physical_division_and_run_keep_material_ledger',
        physical.finite()
        and abs(physical.division_residual) < 1e-10
        and max_abs_ledger < 5e-5,
        'finite={}, division={:.3e}, max ledger={:.3e}'.format(
            physical.finite(), physical.division_residual, max_abs_ledger
        ),
        'all states finite, division residual <1e-10, run ledger residual <5e-5',
    )

    # 12. Under chronic stress, paid repair prevents the collapse seen in the ablation.
    full_chronic = soma.DamageWorld(
        seed=101, initial_cells=1,
        config=soma.LifeHistoryConfig(stress_mode='chronic'),
    )
    no_repair = soma.DamageWorld(
        seed=101, initial_cells=1,
        config=soma.LifeHistoryConfig(
            stress_mode='chronic',
            protein_repair=False,
            genome_repair=False,
            membrane_repair=False,
        ),
    )
    for _ in range(int(320 * soma.SIM_HZ)):
        if full_chronic.living_cells():
            full_chronic.step(dt)
        if no_repair.living_cells():
            no_repair.step(dt)
    full_summary = full_chronic.summary()
    ablated_summary = no_repair.summary()
    _record(
        rows,
        'repair_prevents_chronic_damage_collapse',
        full_summary['cells'] >= 1
        and full_summary['repair_atp_total'] > 0.2
        and ablated_summary['cells'] == 0
        and ablated_summary['deaths'] >= 1,
        'full cells={}, repair ATP={:.4f}; ablated cells={}, deaths={}'.format(
            full_summary['cells'], full_summary['repair_atp_total'],
            ablated_summary['cells'], ablated_summary['deaths'],
        ),
        'the repaired lineage persists to 320 s while the same no-repair lineage collapses',
    )

    # 13. Heritable mutation plus selection improves the pulsed-stress assay.
    evolved = soma.run_life_history_assay(
        seed=101, generations=30, population=48,
        environment='pulsed', mutation=True,
    )
    frozen = soma.run_life_history_assay(
        seed=101, generations=30, population=48,
        environment='pulsed', mutation=False,
    )
    _record(
        rows,
        'heritable_variation_improves_pulsed_assay_fitness',
        evolved['final_mean_fitness'] > frozen['final_mean_fitness'] * 2.0
        and evolved['final_best_fitness'] > frozen['final_best_fitness'] * 3.0,
        'mean {:.6f}/{:.6f}, best {:.6f}/{:.6f}'.format(
            evolved['final_mean_fitness'], frozen['final_mean_fitness'],
            evolved['final_best_fitness'], frozen['final_best_fitness'],
        ),
        'mutation+selection more than doubles mean and triples best pulsed-stress fitness',
    )

    # 14. Save/restore must resume the exact same physical future.
    original = soma.DamageWorld(seed=404, initial_cells=1)
    for _ in range(420):
        original.step(dt)
    with tempfile.TemporaryDirectory() as folder:
        path = os.path.join(folder, 'state.pkl')
        original.save(path)
        restored = soma.DamageWorld.load(path)
        for _ in range(240):
            original.step(dt)
            restored.step(dt)
        exact = _state_equal(original.state_dict(), restored.state_dict())
    _record(
        rows,
        'save_restore_continues_bit_exact_future',
        exact,
        'exact={}'.format(exact),
        'after disk save/load, the next 240 steps match exactly',
    )

    # 15. Serialization state itself must remain finite.
    finite = physical.finite() and full_chronic.finite() and no_repair.finite()
    _record(
        rows,
        'all_validation_worlds_remain_numerically_finite',
        finite,
        'finite={}'.format(finite),
        'all checked arrays, pools, lesions, and repair states are finite',
    )

    with open(CSV_PATH, 'w', newline='', encoding='utf-8') as handle:
        writer = csv.DictWriter(handle, fieldnames=('test', 'pass', 'observed', 'criterion'))
        writer.writeheader()
        writer.writerows(rows)

    passed = sum(row['pass'] == 'PASS' for row in rows)
    lines = [
        'SOMA-CELL 0.3 VALIDATION',
        'Build: {}'.format(soma.BUILD),
        'Result: {}/{} PASS'.format(passed, len(rows)),
        '',
    ]
    for index, row in enumerate(rows, 1):
        lines.append('{:02d}. [{}] {}'.format(index, row['pass'], row['test']))
        lines.append('    observed: {}'.format(row['observed']))
        lines.append('    criterion: {}'.format(row['criterion']))
    lines.extend([
        '',
        'Scope note:',
        'These tests establish the implemented mechanisms under declared controls.',
        'They do not establish biological life, universal aging, or open-ended evolution.',
    ])
    with open(TXT_PATH, 'w', encoding='utf-8') as handle:
        handle.write('\n'.join(lines) + '\n')
    return rows


if __name__ == '__main__':
    result = run_validation()
    passed = sum(row['pass'] == 'PASS' for row in result)
    print('SOMA-CELL 0.3 validation: {}/{} PASS'.format(passed, len(result)))
    for row in result:
        print('[{}] {} :: {}'.format(row['pass'], row['test'], row['observed']))
