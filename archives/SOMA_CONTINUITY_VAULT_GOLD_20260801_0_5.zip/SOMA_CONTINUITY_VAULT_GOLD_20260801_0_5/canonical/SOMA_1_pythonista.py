# coding: utf-8
"""
SOMA-1 — Causal Trophic Tissue / 因果栄養組織
Pythonista 3向け・単体人工生命の第2段階

SOMA-0からの主な変更
---------------------
1. 単一の報酬値を使わない。
   身体のエネルギー・体温・損傷・疲労を、4種類の独立した
   「栄養通貨（trophic currencies）」として神経細胞へ返す。

2. 神経細胞を、固定された計算ユニットではなく小さな生態系として扱う。
   各細胞は栄養を消費し、結線を介して交換し、低活性ではなく
   「身体維持への因果的寄与」が乏しいと入れ替わる。

3. 誤差逆伝播を使わない。
   各細胞へ微小な独立ゆらぎを注入し、その後の身体変化との相関から
   局所的な因果勾配を推定する。これは観察相関だけでなく、個体内部で
   小規模な無作為介入を常時行う仕組みである。

4. 各細胞は、自分の受容野が次にどう変わるかだけを予測する。
   中央の世界モデルはなく、局所予測器の集合として内部モデルが生じる。

5. 成熟した細胞は可塑性が下がり、栄養不足になると再び可塑的になる。
   記憶を固定する専用フェーズではなく、身体状態に依存する可逆的成熟を使う。

注意
----
- これは研究仮説を動く形にした実験モデルであり、意識や本物の生命を
  実装したという主張ではありません。
- 「学術的に完全に未発表」と保証するものではありません。既知の
  homeostasis、node perturbation、structural plasticity、neural Darwinism等を
  踏まえつつ、因果的な多通貨配分と神経内代謝交換を統合した提案です。

操作
----
- 画面タップ: 最寄りの黄色い栄養体をタップ位置へ移す
- 死亡後にタップ: 獲得した神経組織を保ったまま身体だけ再生
- 完全な新生個体: soma1_life.npz を削除
"""

import json
import math
import os
import sys
import time

import numpy as np

try:
    import ui
    from scene import (
        Scene,
        ShapeNode,
        SpriteNode,
        LabelNode,
        run,
        LANDSCAPE,
    )
    IN_PYTHONISTA = True
except ImportError:
    # Core simulation can be smoke-tested on ordinary CPython.
    IN_PYTHONISTA = False
    ui = None
    Scene = object
    ShapeNode = SpriteNode = LabelNode = None
    LANDSCAPE = None


# =============================================================================
# Configuration
# =============================================================================

SAVE_FILE = os.path.join(os.path.dirname(__file__), 'soma1_life.npz')
SAVE_VERSION = 1

CELL_COUNT = 48
SENSOR_COUNT = 24
ACTION_COUNT = 2
TROPHIC_COUNT = 4

NUTRIENT_COUNT = 9
TOXIN_COUNT = 7
SHELTER_COUNT = 3

# Normalized world geometry. The simulation itself is screen-independent.
BODY_RADIUS = 0.022
NUTRIENT_RADIUS = 0.015
TOXIN_RADIUS = 0.013
SHELTER_RADIUS = 0.070
MAX_SPEED = 0.18

HUD_HEIGHT = 88.0
ARENA_BOTTOM = 7.0

TROPHIC_NAMES = ('energy', 'thermal', 'integrity', 'fatigue')


# =============================================================================
# Utilities
# =============================================================================

def clamp(value, low, high):
    return low if value < low else high if value > high else value


def wrapped_delta(source, target):
    """Shortest displacement on a unit torus, from source to target."""
    delta = np.asarray(target, dtype=float) - np.asarray(source, dtype=float)
    return (delta + 0.5) % 1.0 - 0.5


def stable_softmax(values, temperature=1.0):
    values = np.asarray(values, dtype=float)
    temperature = max(1e-6, float(temperature))
    shifted = (values - float(np.max(values))) / temperature
    weights = np.exp(np.clip(shifted, -35.0, 0.0))
    total = float(np.sum(weights))
    if total <= 0.0 or not np.isfinite(total):
        return np.full(values.shape, 1.0 / max(1, values.size))
    return weights / total


def encode_rng_state(rng):
    return np.array(json.dumps(rng.bit_generator.state))


def restore_rng_state(rng, encoded):
    text = str(np.asarray(encoded).item())
    rng.bit_generator.state = json.loads(text)


# =============================================================================
# Causal trophic tissue
# =============================================================================

class CausalTrophicTissue:
    """
    A non-backpropagating, metabolically selected recurrent tissue.

    It remains a numerical dynamical system, but it does not use the usual
    fixed-layer / global-loss / train-then-infer abstraction.

    Each cell has:
    - a sensory receptor vector
    - sparse recurrent inputs
    - a motor vote
    - four trophic stores
    - a metabolic demand profile
    - local prediction machinery
    - a maturity/plasticity state

    Learning uses randomized micro-interventions. Independent fluctuations are
    injected into cells. Eligibility traces remember which receptors, recurrent
    inputs, and motor votes were associated with those fluctuations. Later body
    changes convert the traces into local changes. No gradient is propagated
    through other cells.
    """

    def __init__(
        self,
        seed=None,
        learning_enabled=True,
        scalarize_trophic=False,
        diffusion_enabled=True,
        turnover_enabled=True,
    ):
        if seed is None:
            seed = int(time.time() * 1000.0) & 0xFFFFFFFF
        self.rng = np.random.default_rng(seed)

        self.n_cell = CELL_COUNT
        self.n_sensor = SENSOR_COUNT
        self.n_action = ACTION_COUNT
        self.n_trophic = TROPHIC_COUNT

        self.learning_enabled = bool(learning_enabled)
        self.scalarize_trophic = bool(scalarize_trophic)
        self.diffusion_enabled = bool(diffusion_enabled)
        self.turnover_enabled = bool(turnover_enabled)

        n = self.n_cell
        s = self.n_sensor
        a = self.n_action
        k = self.n_trophic

        # Receptors are not arranged in layers. Every cell samples the body/world.
        self.w_sensor = self.rng.normal(0.0, 0.30, (n, s))

        # Sparse recurrent tissue. Row = receiving cell, column = source cell.
        self.rec_mask = self.rng.random((n, n)) < 0.13
        np.fill_diagonal(self.rec_mask, False)
        self.w_rec = self.rng.normal(0.0, 0.13, (n, n)) * self.rec_mask
        self._limit_recurrent_rows(0.95)

        # No dedicated output layer: every cell owns a two-dimensional motor vote.
        self.motor = self.rng.normal(0.0, 0.38, (n, a))

        self.bias = self.rng.normal(0.0, 0.04, n)
        self.gain = np.ones(n, dtype=float)
        # Multiple intrinsic timescales create a small temporal ecology.
        self.tau = np.exp(
            self.rng.uniform(math.log(0.10), math.log(1.20), n)
        )

        self.hidden = np.zeros(n, dtype=float)
        self.prev_hidden = np.zeros(n, dtype=float)

        # Ornstein-Uhlenbeck-like probes: coherent enough to move the body,
        # independent enough to estimate causal contribution over time.
        self.probe_state = np.zeros(n, dtype=float)
        self.motor_probe = np.zeros((n, a), dtype=float)
        self.last_probe_scale = np.full(n, 0.10, dtype=float)
        self.last_motor_sigma = np.full(n, 0.10, dtype=float)

        # Eligibility traces bridge action and delayed bodily consequences.
        self.elig_bias = np.zeros(n, dtype=float)
        self.elig_sensor = np.zeros((n, s), dtype=float)
        self.elig_rec = np.zeros((n, n), dtype=float)
        self.elig_motor = np.zeros((n, a), dtype=float)

        # Four separate stores. They are deliberately not collapsed to one reward.
        self.trophic_store = np.clip(
            self.rng.normal(0.36, 0.035, (n, k)), 0.24, 0.48
        )
        # Different cells have different metabolic enzyme profiles.
        self.metabolic_profile = self.rng.dirichlet(
            np.full(k, 0.70), size=n
        )

        self.maturity = np.full(n, 0.10, dtype=float)
        self.cell_age = np.zeros(n, dtype=float)
        self.generation = np.zeros(n, dtype=np.int64)
        self.lineage = np.arange(n, dtype=np.int64)
        self.next_lineage = n

        # Estimated causal contribution, one value per cell and body currency.
        self.causal_estimate = np.zeros((n, k), dtype=float)
        self.trophic_baseline = np.zeros(k, dtype=float)

        # Homeostatic firing regulation.
        self.activity_mean = np.zeros(n, dtype=float)
        self.activity_square = np.zeros(n, dtype=float)

        # Each cell predicts only its own next receptor drive.
        # Features: own state, action x, action y, tonic input.
        self.predict_w = self.rng.normal(0.0, 0.05, (n, 4))
        self.prediction = np.zeros(n, dtype=float)
        self.prediction_error = np.full(n, 0.50, dtype=float)
        self.last_predict_feature = np.zeros((n, 4), dtype=float)

        self.edge_correlation = np.zeros((n, n), dtype=float)

        self.last_sensor = np.zeros(s, dtype=float)
        self.last_debt = np.ones(k, dtype=float)
        self.last_action = np.zeros(a, dtype=float)
        self.last_trophic_pulse = np.zeros(k, dtype=float)
        self.last_trophic_advantage = np.zeros(k, dtype=float)
        self.last_mean_flow = 0.0

        self.step_count = 0
        self.birth_count = 0
        self.death_count = 0
        self.rewire_count = 0

        self.vitality = self._cell_vitality()

    # ------------------------------------------------------------------
    # Dynamics
    # ------------------------------------------------------------------

    def act(self, sensor, body_debt, dt):
        sensor = np.clip(np.asarray(sensor, dtype=float), -1.0, 1.0)
        body_debt = np.clip(np.asarray(body_debt, dtype=float), 0.0, 1.0)
        dt = clamp(float(dt), 1.0 / 240.0, 0.10)

        if sensor.shape != (self.n_sensor,):
            raise ValueError('sensor shape must be ({},)'.format(self.n_sensor))
        if body_debt.shape != (self.n_trophic,):
            raise ValueError(
                'body_debt shape must be ({},)'.format(self.n_trophic)
            )

        self.last_sensor = sensor.copy()
        self.last_debt = body_debt.copy()
        self.prev_hidden = self.hidden.copy()

        rho = math.exp(-dt / 0.28)
        fresh_scale = math.sqrt(max(0.0, 1.0 - rho * rho))
        self.probe_state = (
            rho * self.probe_state
            + fresh_scale * self.rng.normal(0.0, 1.0, self.n_cell)
        )
        self.motor_probe = (
            rho * self.motor_probe
            + fresh_scale
            * self.rng.normal(0.0, 1.0, (self.n_cell, self.n_action))
        )

        # Mature, well-predicted cells are quieter; distressed cells reopen.
        plasticity = np.clip(
            0.10
            + 0.70 * (1.0 - self.maturity)
            + 0.35 * self.prediction_error,
            0.10,
            1.0,
        )
        tissue_stress = float(np.mean(body_debt))
        probe_scale = 0.025 + 0.055 * plasticity + 0.025 * tissue_stress
        motor_sigma = 0.035 + 0.090 * plasticity + 0.030 * tissue_stress
        self.last_probe_scale = probe_scale
        self.last_motor_sigma = motor_sigma

        sensory_drive = (self.w_sensor @ sensor) / math.sqrt(
            self.n_sensor * 0.60
        )
        recurrent_drive = self.w_rec @ self.prev_hidden
        drive = sensory_drive + recurrent_drive + probe_scale * self.probe_state

        target = np.tanh(self.gain * drive + self.bias)
        leak = 1.0 - np.exp(-dt / self.tau)
        self.hidden = self.prev_hidden + leak * (target - self.prev_hidden)

        self.vitality = self._cell_vitality()
        influence = 0.45 + 0.55 * np.sqrt(self.vitality)
        effective_motor = self.motor + motor_sigma[:, None] * self.motor_probe

        raw_action = np.sum(
            influence[:, None] * self.hidden[:, None] * effective_motor,
            axis=0,
        ) / math.sqrt(self.n_cell)
        action = np.tanh(3.8 * raw_action)
        self.last_action = action.copy()

        # Local perturbation eligibility. Dividing by probe amplitude estimates
        # sensitivity rather than merely recording raw noise magnitude.
        eligibility_decay = math.exp(-dt / 3.5)
        normalized_probe = self.probe_state / np.maximum(probe_scale, 0.02)
        normalized_motor_probe = self.motor_probe / np.maximum(
            motor_sigma[:, None], 0.02
        )

        self.elig_bias = (
            eligibility_decay * self.elig_bias + normalized_probe * dt
        )
        self.elig_sensor = (
            eligibility_decay * self.elig_sensor
            + normalized_probe[:, None] * sensor[None, :] * dt
        )
        self.elig_rec = (
            eligibility_decay * self.elig_rec
            + normalized_probe[:, None]
            * self.prev_hidden[None, :]
            * self.rec_mask
            * dt
        )
        self.elig_motor = (
            eligibility_decay * self.elig_motor
            + normalized_motor_probe * np.abs(self.hidden)[:, None] * dt
        )

        np.clip(self.elig_bias, -14.0, 14.0, out=self.elig_bias)
        np.clip(self.elig_sensor, -14.0, 14.0, out=self.elig_sensor)
        np.clip(self.elig_rec, -9.0, 9.0, out=self.elig_rec)
        np.clip(self.elig_motor, -11.0, 11.0, out=self.elig_motor)

        self.last_predict_feature = np.column_stack((
            self.hidden,
            np.full(self.n_cell, action[0]),
            np.full(self.n_cell, action[1]),
            np.ones(self.n_cell),
        ))
        self.prediction = np.tanh(
            np.sum(self.predict_w * self.last_predict_feature, axis=1)
        )

        return action

    def learn(self, next_sensor, next_debt, dt):
        next_sensor = np.clip(
            np.asarray(next_sensor, dtype=float), -1.0, 1.0
        )
        next_debt = np.clip(np.asarray(next_debt, dtype=float), 0.0, 1.0)
        dt = clamp(float(dt), 1.0 / 240.0, 0.10)

        # --------------------------------------------------------------
        # Local next-receptor prediction
        # --------------------------------------------------------------
        receptor_target = np.tanh(
            (self.w_sensor @ next_sensor) / math.sqrt(self.n_sensor * 0.60)
        )
        prediction_delta = receptor_target - self.prediction
        self.prediction_error = (
            0.985 * self.prediction_error
            + 0.015 * np.abs(prediction_delta)
        )

        if self.learning_enabled:
            local_predict_delta = (
                prediction_delta * (1.0 - self.prediction ** 2)
            )
            self.predict_w += (
                0.018
                * dt
                * local_predict_delta[:, None]
                * self.last_predict_feature
            )
            np.clip(self.predict_w, -2.0, 2.0, out=self.predict_w)

        # --------------------------------------------------------------
        # Four-dimensional bodily consequence
        # --------------------------------------------------------------
        improvement = self.last_debt - next_debt
        normalization = np.array([4.0, 3.5, 4.0, 2.5], dtype=float)
        pulse = np.clip(improvement * normalization, -0.35, 0.35)

        if self.scalarize_trophic:
            # Ablation mode only: collapse the vector into one repeated signal.
            scalar = float(np.mean(pulse))
            pulse[:] = scalar

        advantage = pulse - self.trophic_baseline
        self.trophic_baseline = (
            0.998 * self.trophic_baseline + 0.002 * pulse
        )
        self.last_trophic_pulse = pulse
        self.last_trophic_advantage = advantage

        required = self._required_trophic()
        shortage = required / (self.trophic_store + 0.03)

        # A cell's own starvation portfolio determines how it interprets the
        # vector pulse. Current body debt only biases urgency; it never turns the
        # four channels into one fixed global objective.
        body_priority = 0.30 + 0.70 * np.clip(
            self.last_debt + 0.15, 0.0, 1.0
        )
        local_need = shortage * body_priority[None, :]
        local_need /= np.maximum(
            np.sum(local_need, axis=1, keepdims=True), 1e-9
        )
        # Tiny frame-to-frame fluctuations are still used by the metabolic
        # economy, but are too weak to justify changing sensorimotor structure.
        # This evidence floor prevents slow numerical/weather drift from
        # masquerading as causal knowledge.
        learning_advantage = advantage.copy()
        learning_advantage[np.abs(learning_advantage) < 0.006] = 0.0
        local_advantage = local_need @ learning_advantage

        plasticity = np.clip(
            0.10
            + 0.75 * (1.0 - self.maturity)
            + 0.30 * self.prediction_error,
            0.10,
            1.0,
        )

        if self.learning_enabled:
            factor = np.clip(local_advantage, -0.35, 0.35) * plasticity

            # No chain rule through the tissue. Each row changes only from its
            # own perturbation trace and the later bodily vector.
            self.w_sensor += 0.018 * factor[:, None] * self.elig_sensor
            self.w_rec += (
                0.0015
                * factor[:, None]
                * self.elig_rec
                * self.rec_mask
            )
            self.bias += 0.0030 * factor * self.elig_bias
            self.motor += 0.030 * factor[:, None] * self.elig_motor

            np.clip(self.w_sensor, -1.70, 1.70, out=self.w_sensor)
            np.clip(self.w_rec, -0.90, 0.90, out=self.w_rec)
            np.clip(self.motor, -1.50, 1.50, out=self.motor)
            np.clip(self.bias, -1.20, 1.20, out=self.bias)
            self.w_rec *= self.rec_mask
            self._limit_recurrent_rows(1.15)

        # This vector is the tissue's empirical causal audit. A positive value
        # means that increasing the cell's recent activity tended to improve the
        # corresponding bodily dimension relative to baseline.
        causal_sample = np.clip(
            self.elig_bias[:, None] * learning_advantage[None, :], -2.0, 2.0
        )
        self.causal_estimate = (
            0.994 * self.causal_estimate + 0.006 * causal_sample
        )

        self._update_trophic_economy(
            next_debt=next_debt,
            advantage=advantage,
            local_need=local_need,
            dt=dt,
        )

        # --------------------------------------------------------------
        # Maturity and neuronal homeostasis
        # --------------------------------------------------------------
        competence = np.sum(
            local_need * np.maximum(self.causal_estimate, 0.0), axis=1
        )
        self.maturity += dt * (
            0.014 * competence
            + 0.0015 * (self.prediction_error < 0.20)
            - 0.018 * np.maximum(0.42 - self.vitality, 0.0)
        )
        np.clip(self.maturity, 0.0, 1.0, out=self.maturity)

        activity_rate = 1.0 - math.exp(-dt / 2.5)
        self.activity_mean = (
            (1.0 - activity_rate) * self.activity_mean
            + activity_rate * self.hidden
        )
        self.activity_square = (
            (1.0 - activity_rate) * self.activity_square
            + activity_rate * self.hidden ** 2
        )
        self.bias -= dt * 0.010 * self.activity_mean
        self.gain += dt * 0.007 * (0.16 - self.activity_square)
        np.clip(self.bias, -1.20, 1.20, out=self.bias)
        np.clip(self.gain, 0.50, 2.00, out=self.gain)

        if self.learning_enabled:
            very_slow_decay = math.exp(-dt * 1e-5)
            self.w_sensor *= very_slow_decay
            self.motor *= very_slow_decay

        self.edge_correlation = (
            0.997 * self.edge_correlation
            + 0.003 * np.outer(self.hidden, self.prev_hidden)
        )

        self.cell_age += dt
        self.step_count += 1

        if self.learning_enabled and self.step_count % 300 == 0:
            self._rewire_weak_edges()
        if (
            self.learning_enabled
            and self.turnover_enabled
            and self.step_count % 900 == 0
        ):
            self._turnover_one_cell()

    # ------------------------------------------------------------------
    # Trophic economy
    # ------------------------------------------------------------------

    def _required_trophic(self):
        # Every cell needs all four currencies, but in different proportions.
        return 0.34 + 0.26 * self.metabolic_profile

    def _cell_vitality(self):
        required = self._required_trophic()
        ratio = np.clip(self.trophic_store / required, 0.01, 1.0)
        geometric = np.exp(np.mean(np.log(ratio), axis=1))
        bottleneck = np.min(ratio, axis=1)
        return np.clip(0.65 * geometric + 0.35 * bottleneck, 0.0, 1.0)

    def _update_trophic_economy(
        self,
        next_debt,
        advantage,
        local_need,
        dt,
    ):
        health = 1.0 - next_debt

        # A viable body supplies a limited basal flux to the whole tissue.
        # This is not performance credit; it is the cost of keeping neural
        # matter alive while the body itself remains viable.
        self.trophic_store += dt * 0.00078 * health[None, :]

        # Improvement creates a finite currency pool. It is distributed toward
        # cells with the strongest accumulated causal evidence. Damage taxes the
        # cells whose audit most strongly implicates them in that dimension.
        for currency in range(self.n_trophic):
            value = float(advantage[currency])
            if value > 1e-10:
                allocation = stable_softmax(
                    self.causal_estimate[:, currency], temperature=0.045
                )
                pool = 0.38 * value
                self.trophic_store[:, currency] += pool * allocation
            elif value < -1e-10:
                liability = stable_softmax(
                    -self.causal_estimate[:, currency], temperature=0.060
                )
                pool = 0.060 * (-value)
                self.trophic_store[:, currency] -= pool * liability

        incoming_degree = np.count_nonzero(self.rec_mask, axis=1)
        cell_load = (
            0.00070
            + 0.00100 * self.hidden ** 2
            + 0.000006 * incoming_degree
        )
        consumption_mix = 0.50 + 1.35 * self.metabolic_profile
        self.trophic_store -= dt * cell_load[:, None] * consumption_mix

        if self.diffusion_enabled and self.step_count % 3 == 0:
            # Symmetrizing only the resource conduit preserves total currency
            # during exchange even though signal transmission remains directed.
            conduit = np.abs(self.w_rec) * self.rec_mask
            conduit = 0.5 * (conduit + conduit.T)
            degree = np.sum(conduit, axis=1)
            flow = (
                conduit @ self.trophic_store
                - degree[:, None] * self.trophic_store
            )
            change = dt * 0.045 * flow
            self.trophic_store += change
            self.last_mean_flow = float(np.mean(np.abs(change))) / max(dt, 1e-9)
        else:
            self.last_mean_flow *= 0.98

        np.clip(self.trophic_store, 0.0, 1.0, out=self.trophic_store)
        self.vitality = self._cell_vitality()

    # ------------------------------------------------------------------
    # Structural adaptation
    # ------------------------------------------------------------------

    def _limit_recurrent_rows(self, max_l1):
        row_l1 = np.sum(np.abs(self.w_rec), axis=1)
        scale = np.maximum(1.0, row_l1 / float(max_l1))
        self.w_rec /= scale[:, None]

    def _rewire_weak_edges(self):
        n = self.n_cell
        allowed = ~np.eye(n, dtype=bool)
        active_flat = np.flatnonzero(self.rec_mask & allowed)
        inactive_flat = np.flatnonzero((~self.rec_mask) & allowed)
        if active_flat.size == 0 or inactive_flat.size == 0:
            return

        amount = max(1, int(active_flat.size * 0.008))
        amount = min(amount, inactive_flat.size)

        edge_importance = (
            np.abs(self.w_rec) * (0.20 + np.abs(self.edge_correlation))
        ).ravel()[active_flat]
        prune_flat = active_flat[np.argsort(edge_importance)[:amount]]

        grow_flat = []
        required = self._required_trophic()
        deficit = np.maximum(required - self.trophic_store, 0.0)
        surplus = np.maximum(self.trophic_store - required, 0.0)

        for _ in range(amount):
            sample_size = min(220, inactive_flat.size)
            candidates = self.rng.choice(
                inactive_flat, size=sample_size, replace=False
            )
            targets = candidates // n
            sources = candidates % n

            metabolic_complement = np.sum(
                deficit[targets] * surplus[sources], axis=1
            )
            dynamic_fit = np.abs(
                self.edge_correlation[targets, sources]
            )
            score = (
                metabolic_complement
                + 0.05 * dynamic_fit
                + 0.01 * self.rng.random(sample_size)
            )
            grow_flat.append(int(candidates[int(np.argmax(score))]))

        grow_flat = np.asarray(grow_flat, dtype=np.int64)
        mask_flat = self.rec_mask.ravel()
        weight_flat = self.w_rec.ravel()
        trace_flat = self.elig_rec.ravel()

        mask_flat[prune_flat] = False
        weight_flat[prune_flat] = 0.0
        trace_flat[prune_flat] = 0.0

        mask_flat[grow_flat] = True
        weight_flat[grow_flat] = self.rng.normal(
            0.0, 0.045, grow_flat.size
        )
        trace_flat[grow_flat] = 0.0

        self.rewire_count += int(grow_flat.size)
        self._limit_recurrent_rows(1.10)

    def _turnover_one_cell(self):
        self.vitality = self._cell_vitality()
        eligible = np.flatnonzero(self.cell_age > 20.0)
        if eligible.size == 0:
            return

        causal_benefit = np.mean(
            np.maximum(self.causal_estimate, 0.0), axis=1
        )
        fitness = (
            0.60 * self.vitality
            + 0.25 * self.maturity
            + 0.15 * np.clip(causal_benefit * 8.0, 0.0, 1.0)
        )

        victim = int(eligible[int(np.argmin(fitness[eligible]))])
        # No obligatory churn when the tissue is uniformly healthy.
        if fitness[victim] > 0.56 and self.vitality[victim] > 0.46:
            return

        parent_score = (
            self.vitality
            * (0.25 + 0.75 * self.maturity)
            * (1.0 + 0.50 * causal_benefit)
        )
        parent_score[victim] = 0.0
        total = float(np.sum(parent_score))
        if total <= 0.0 or not np.isfinite(total):
            parent = int(self.rng.integers(self.n_cell))
        else:
            parent = int(
                self.rng.choice(self.n_cell, p=parent_score / total)
            )

        self._replace_cell(victim, parent)

    def _replace_cell(self, victim, parent):
        n = self.n_cell

        self.w_sensor[victim] = (
            self.w_sensor[parent]
            + self.rng.normal(0.0, 0.10, self.n_sensor)
        )
        self.motor[victim] = (
            self.motor[parent]
            + self.rng.normal(0.0, 0.09, self.n_action)
        )
        self.bias[victim] = self.bias[parent] + self.rng.normal(0.0, 0.05)
        self.gain[victim] = clamp(
            self.gain[parent] + self.rng.normal(0.0, 0.08), 0.60, 1.80
        )
        self.tau[victim] = clamp(
            self.tau[parent] * math.exp(self.rng.normal(0.0, 0.18)),
            0.08,
            1.50,
        )

        profile = self.metabolic_profile[parent] * np.exp(
            self.rng.normal(0.0, 0.22, self.n_trophic)
        )
        profile = np.maximum(profile, 0.03)
        self.metabolic_profile[victim] = profile / float(np.sum(profile))

        self.predict_w[victim] = (
            self.predict_w[parent] + self.rng.normal(0.0, 0.05, 4)
        )

        # Budding has a real cost to the parent.
        inherited_store = self.trophic_store[parent].copy()
        self.trophic_store[parent] *= 0.84
        self.trophic_store[victim] = np.clip(
            0.15 + 0.32 * inherited_store, 0.12, 0.42
        )

        self.maturity[victim] = 0.04
        self.cell_age[victim] = 0.0
        self.generation[victim] = self.generation[parent] + 1
        self.lineage[victim] = self.next_lineage
        self.next_lineage += 1

        self.hidden[victim] = 0.0
        self.prev_hidden[victim] = 0.0
        self.probe_state[victim] = 0.0
        self.motor_probe[victim] = 0.0
        self.causal_estimate[victim] = 0.0
        self.prediction_error[victim] = 0.50
        self.activity_mean[victim] = 0.0
        self.activity_square[victim] = 0.0
        self.elig_bias[victim] = 0.0
        self.elig_sensor[victim] = 0.0
        self.elig_rec[victim] = 0.0
        self.elig_rec[:, victim] = 0.0
        self.elig_motor[victim] = 0.0

        # Daughter inherits a noisy subset of the parent's relational niche.
        incoming = self.rec_mask[parent].copy()
        outgoing = self.rec_mask[:, parent].copy()
        incoming &= self.rng.random(n) > 0.15
        outgoing &= self.rng.random(n) > 0.15
        incoming[victim] = False
        outgoing[victim] = False

        self.rec_mask[victim, :] = incoming
        self.rec_mask[:, victim] = outgoing
        self.rec_mask[victim, victim] = False

        self.w_rec[victim, :] = (
            self.w_rec[parent, :] + self.rng.normal(0.0, 0.04, n)
        )
        self.w_rec[:, victim] = (
            self.w_rec[:, parent] + self.rng.normal(0.0, 0.04, n)
        )
        self.w_rec *= self.rec_mask

        for _ in range(3):
            source = int(self.rng.integers(n))
            if source != victim:
                self.rec_mask[victim, source] = True
                self.w_rec[victim, source] = self.rng.normal(0.0, 0.05)

        self.birth_count += 1
        self.death_count += 1
        self._limit_recurrent_rows(1.10)
        self.vitality = self._cell_vitality()

    # ------------------------------------------------------------------
    # Diagnostics and persistence
    # ------------------------------------------------------------------

    def neural_cost(self):
        activity = float(np.mean(self.hidden ** 2))
        connection_fraction = (
            float(np.count_nonzero(self.rec_mask))
            / float(self.n_cell * self.n_cell)
        )
        probe_cost = 0.05 * float(np.mean(self.last_probe_scale ** 2))
        return activity + 0.12 * connection_fraction + probe_cost

    def diagnostics(self):
        causal_strength = float(
            np.mean(np.abs(self.causal_estimate))
        )
        return {
            'mean_vitality': float(np.mean(self.vitality)),
            'min_vitality': float(np.min(self.vitality)),
            'mean_maturity': float(np.mean(self.maturity)),
            'prediction_error': float(np.mean(self.prediction_error)),
            'causal_strength': causal_strength,
            'mean_flow': float(self.last_mean_flow),
            'edges': int(np.count_nonzero(self.rec_mask)),
            'births': int(self.birth_count),
            'deaths': int(self.death_count),
            'rewires': int(self.rewire_count),
        }

    def state_dict(self):
        return {
            'brain_rng_state': encode_rng_state(self.rng),
            'brain_w_sensor': self.w_sensor,
            'brain_rec_mask': self.rec_mask.astype(np.uint8),
            'brain_w_rec': self.w_rec,
            'brain_motor': self.motor,
            'brain_bias': self.bias,
            'brain_gain': self.gain,
            'brain_tau': self.tau,
            'brain_hidden': self.hidden,
            'brain_prev_hidden': self.prev_hidden,
            'brain_probe_state': self.probe_state,
            'brain_motor_probe': self.motor_probe,
            'brain_elig_bias': self.elig_bias,
            'brain_elig_sensor': self.elig_sensor,
            'brain_elig_rec': self.elig_rec,
            'brain_elig_motor': self.elig_motor,
            'brain_trophic_store': self.trophic_store,
            'brain_metabolic_profile': self.metabolic_profile,
            'brain_maturity': self.maturity,
            'brain_cell_age': self.cell_age,
            'brain_generation': self.generation,
            'brain_lineage': self.lineage,
            'brain_next_lineage': np.array(
                self.next_lineage, dtype=np.int64
            ),
            'brain_causal_estimate': self.causal_estimate,
            'brain_trophic_baseline': self.trophic_baseline,
            'brain_activity_mean': self.activity_mean,
            'brain_activity_square': self.activity_square,
            'brain_predict_w': self.predict_w,
            'brain_prediction_error': self.prediction_error,
            'brain_edge_correlation': self.edge_correlation,
            'brain_step_count': np.array(self.step_count, dtype=np.int64),
            'brain_birth_count': np.array(self.birth_count, dtype=np.int64),
            'brain_death_count': np.array(self.death_count, dtype=np.int64),
            'brain_rewire_count': np.array(self.rewire_count, dtype=np.int64),
        }

    def load_state(self, data):
        arrays = {
            'brain_w_sensor': self.w_sensor,
            'brain_rec_mask': self.rec_mask,
            'brain_w_rec': self.w_rec,
            'brain_motor': self.motor,
            'brain_bias': self.bias,
            'brain_gain': self.gain,
            'brain_tau': self.tau,
            'brain_hidden': self.hidden,
            'brain_prev_hidden': self.prev_hidden,
            'brain_probe_state': self.probe_state,
            'brain_motor_probe': self.motor_probe,
            'brain_elig_bias': self.elig_bias,
            'brain_elig_sensor': self.elig_sensor,
            'brain_elig_rec': self.elig_rec,
            'brain_elig_motor': self.elig_motor,
            'brain_trophic_store': self.trophic_store,
            'brain_metabolic_profile': self.metabolic_profile,
            'brain_maturity': self.maturity,
            'brain_cell_age': self.cell_age,
            'brain_generation': self.generation,
            'brain_lineage': self.lineage,
            'brain_causal_estimate': self.causal_estimate,
            'brain_trophic_baseline': self.trophic_baseline,
            'brain_activity_mean': self.activity_mean,
            'brain_activity_square': self.activity_square,
            'brain_predict_w': self.predict_w,
            'brain_prediction_error': self.prediction_error,
            'brain_edge_correlation': self.edge_correlation,
        }
        for key, current in arrays.items():
            if key not in data or tuple(data[key].shape) != tuple(current.shape):
                raise ValueError('incompatible brain save: ' + key)

        self.w_sensor = np.array(data['brain_w_sensor'], dtype=float)
        self.rec_mask = np.array(data['brain_rec_mask'], dtype=bool)
        self.w_rec = np.array(data['brain_w_rec'], dtype=float)
        self.motor = np.array(data['brain_motor'], dtype=float)
        self.bias = np.array(data['brain_bias'], dtype=float)
        self.gain = np.array(data['brain_gain'], dtype=float)
        self.tau = np.array(data['brain_tau'], dtype=float)
        self.hidden = np.array(data['brain_hidden'], dtype=float)
        self.prev_hidden = np.array(data['brain_prev_hidden'], dtype=float)
        self.probe_state = np.array(data['brain_probe_state'], dtype=float)
        self.motor_probe = np.array(data['brain_motor_probe'], dtype=float)
        self.elig_bias = np.array(data['brain_elig_bias'], dtype=float)
        self.elig_sensor = np.array(data['brain_elig_sensor'], dtype=float)
        self.elig_rec = np.array(data['brain_elig_rec'], dtype=float)
        self.elig_motor = np.array(data['brain_elig_motor'], dtype=float)
        self.trophic_store = np.array(
            data['brain_trophic_store'], dtype=float
        )
        self.metabolic_profile = np.array(
            data['brain_metabolic_profile'], dtype=float
        )
        self.maturity = np.array(data['brain_maturity'], dtype=float)
        self.cell_age = np.array(data['brain_cell_age'], dtype=float)
        self.generation = np.array(data['brain_generation'], dtype=np.int64)
        self.lineage = np.array(data['brain_lineage'], dtype=np.int64)
        self.next_lineage = int(data['brain_next_lineage'])
        self.causal_estimate = np.array(
            data['brain_causal_estimate'], dtype=float
        )
        self.trophic_baseline = np.array(
            data['brain_trophic_baseline'], dtype=float
        )
        self.activity_mean = np.array(
            data['brain_activity_mean'], dtype=float
        )
        self.activity_square = np.array(
            data['brain_activity_square'], dtype=float
        )
        self.predict_w = np.array(data['brain_predict_w'], dtype=float)
        self.prediction_error = np.array(
            data['brain_prediction_error'], dtype=float
        )
        self.edge_correlation = np.array(
            data['brain_edge_correlation'], dtype=float
        )

        self.step_count = int(data['brain_step_count'])
        self.birth_count = int(data['brain_birth_count'])
        self.death_count = int(data['brain_death_count'])
        self.rewire_count = int(data['brain_rewire_count'])

        restore_rng_state(self.rng, data['brain_rng_state'])
        self.w_rec *= self.rec_mask
        self._limit_recurrent_rows(1.15)
        self.vitality = self._cell_vitality()


# =============================================================================
# Embodied world core — independent of Pythonista rendering
# =============================================================================

class SomaOneCore:
    def __init__(
        self,
        seed=None,
        learning_enabled=True,
        scalarize_trophic=False,
        diffusion_enabled=True,
        turnover_enabled=True,
    ):
        if seed is None:
            seed = int(time.time() * 1000.0) & 0xFFFFFFFF
        self.seed = int(seed)
        self.rng = np.random.default_rng(self.seed ^ 0xA5A5A5A5)
        self.brain = CausalTrophicTissue(
            seed=self.seed,
            learning_enabled=learning_enabled,
            scalarize_trophic=scalarize_trophic,
            diffusion_enabled=diffusion_enabled,
            turnover_enabled=turnover_enabled,
        )

        self.pos = self.rng.random(2)
        self.vel = np.zeros(2, dtype=float)
        self.last_action = np.zeros(2, dtype=float)

        self.energy = 0.78
        self.temperature = 0.50
        self.integrity = 0.95
        self.fatigue = 0.18
        self.pain = 0.0

        self.age = 0.0
        self.alive = True
        self.eaten = 0
        self.poisoned = 0
        self.regenerations = 0

        self.nutrient_positions = self.rng.random((NUTRIENT_COUNT, 2))
        self.toxin_positions = self.rng.random((TOXIN_COUNT, 2))
        self.shelter_positions = self.rng.random((SHELTER_COUNT, 2))

        self.distance_travelled = 0.0
        self.viability_integral = 0.0
        self.last_ambient = 0.50
        self.last_shelter = 0.0
        self.last_body_debt = self.body_debt()

    # ------------------------------------------------------------------
    # Environment fields and sensors
    # ------------------------------------------------------------------

    def temperature_field(self, position=None, at_time=None):
        if position is None:
            position = self.pos
        if at_time is None:
            at_time = self.age

        x = float(position[0])
        y = float(position[1])
        phase = 0.06 * math.sin(float(at_time) * 0.012)
        ax = 2.0 * math.pi * (x + phase)
        by = 2.0 * math.pi * (y - 0.70 * phase)

        value = (
            0.50
            + 0.26 * math.sin(ax)
            + 0.13 * math.cos(by)
            + 0.06 * math.sin(ax + by)
        )
        value = clamp(value, 0.04, 0.96)

        gx = (
            0.26 * 2.0 * math.pi * math.cos(ax)
            + 0.06 * 2.0 * math.pi * math.cos(ax + by)
        )
        gy = (
            -0.13 * 2.0 * math.pi * math.sin(by)
            + 0.06 * 2.0 * math.pi * math.cos(ax + by)
        )
        gradient = np.array([gx / 2.30, gy / 2.30], dtype=float)
        return value, np.clip(gradient, -1.0, 1.0)

    def _chemical_field(self, positions, scale):
        vector = np.zeros(2, dtype=float)
        concentration_sum = 0.0
        for source in positions:
            delta = wrapped_delta(self.pos, source)
            distance = float(np.linalg.norm(delta))
            concentration = math.exp(-distance / float(scale))
            vector += delta / (distance + 0.03) * concentration
            concentration_sum += concentration

        if concentration_sum > 1e-10:
            vector /= concentration_sum
        concentration = 1.0 - math.exp(-0.65 * concentration_sum)
        return np.clip(vector, -1.0, 1.0), clamp(concentration, 0.0, 1.0)

    def shelter_level(self):
        level = 0.0
        for shelter in self.shelter_positions:
            distance = float(np.linalg.norm(wrapped_delta(self.pos, shelter)))
            level = max(level, math.exp(-((distance / SHELTER_RADIUS) ** 2)))
        return clamp(level, 0.0, 1.0)

    def body_debt(self):
        return np.array([
            clamp((0.56 - self.energy) / 0.56, 0.0, 1.0),
            clamp(abs(self.temperature - 0.50) / 0.43, 0.0, 1.0),
            clamp(1.0 - self.integrity, 0.0, 1.0),
            clamp(self.fatigue, 0.0, 1.0),
        ], dtype=float)

    def make_sensor(self):
        nutrient_gradient, nutrient_concentration = self._chemical_field(
            self.nutrient_positions, 0.17
        )
        toxin_gradient, toxin_concentration = self._chemical_field(
            self.toxin_positions, 0.15
        )
        shelter_gradient, shelter_concentration = self._chemical_field(
            self.shelter_positions, 0.20
        )
        ambient, thermal_gradient = self.temperature_field()

        tissue_distress = 1.0 - float(np.mean(self.brain.vitality))
        prediction_uncertainty = float(
            np.mean(self.brain.prediction_error)
        )

        sensor = np.array([
            nutrient_gradient[0],                  # 0 chemical A gradient x
            nutrient_gradient[1],                  # 1 chemical A gradient y
            nutrient_concentration * 2.0 - 1.0,   # 2 chemical A density
            toxin_gradient[0],                     # 3 chemical B gradient x
            toxin_gradient[1],                     # 4 chemical B gradient y
            toxin_concentration * 2.0 - 1.0,      # 5 chemical B density
            shelter_gradient[0],                   # 6 chemical C gradient x
            shelter_gradient[1],                   # 7 chemical C gradient y
            shelter_concentration * 2.0 - 1.0,    # 8 chemical C density
            ambient * 2.0 - 1.0,                  # 9 local ambient temperature
            thermal_gradient[0],                   # 10 thermal gradient x
            thermal_gradient[1],                   # 11 thermal gradient y
            self.energy * 2.0 - 1.0,              # 12 interoceptive energy
            (self.temperature - 0.50) * 2.0,      # 13 signed temperature
            self.integrity * 2.0 - 1.0,           # 14 tissue integrity
            self.fatigue * 2.0 - 1.0,             # 15 fatigue
            self.vel[0] / MAX_SPEED,              # 16 self velocity x
            self.vel[1] / MAX_SPEED,              # 17 self velocity y
            self.last_action[0],                   # 18 prior motor x
            self.last_action[1],                   # 19 prior motor y
            self.pain * 2.0 - 1.0,                # 20 nociception
            tissue_distress * 2.0 - 1.0,          # 21 neural tissue distress
            clamp(prediction_uncertainty, 0.0, 1.0) * 2.0 - 1.0,
                                                     # 22 local-model uncertainty
            1.0,                                    # 23 tonic receptor
        ], dtype=float)
        return np.clip(sensor, -1.0, 1.0)

    # ------------------------------------------------------------------
    # Life cycle
    # ------------------------------------------------------------------

    def step(self, dt=1.0 / 30.0):
        dt = clamp(float(dt), 1.0 / 240.0, 0.10)
        if not self.alive:
            return

        sensor = self.make_sensor()
        debt_before = self.body_debt()
        action = self.brain.act(sensor, debt_before, dt)

        self._apply_body_and_world(action, dt)

        next_sensor = self.make_sensor()
        debt_after = self.body_debt()
        self.brain.learn(next_sensor, debt_after, dt)

        self.last_action = np.array(action, dtype=float)
        self.age += dt
        self.last_body_debt = debt_after
        self.viability_integral += dt * (1.0 - float(np.mean(debt_after)))

        if self.energy <= 0.0 or self.integrity <= 0.0:
            self.energy = max(0.0, self.energy)
            self.integrity = max(0.0, self.integrity)
            self.vel[:] = 0.0
            self.alive = False

    def _apply_body_and_world(self, action, dt):
        action = np.clip(np.asarray(action, dtype=float), -1.0, 1.0)
        target_velocity = action * MAX_SPEED
        response = 1.0 - math.exp(-4.0 * dt)
        self.vel += (target_velocity - self.vel) * response

        displacement = self.vel * dt
        self.pos = (self.pos + displacement) % 1.0
        self.distance_travelled += float(np.linalg.norm(displacement))

        movement = float(np.dot(action, action))
        neural = self.brain.neural_cost()
        shelter = self.shelter_level()
        ambient, _ = self.temperature_field()
        self.last_ambient = ambient
        self.last_shelter = shelter

        thermal_coupling = 0.16 + 0.95 * shelter
        self.temperature += (
            (ambient - self.temperature) * thermal_coupling * dt
            + 0.022 * movement * dt
        )
        self.temperature = clamp(self.temperature, 0.0, 1.0)

        thermal_stress = clamp(
            abs(self.temperature - 0.50) / 0.42, 0.0, 1.0
        )

        self.fatigue += (0.075 * movement + 0.020 * neural) * dt
        rest_fraction = max(0.0, 1.0 - math.sqrt(min(1.0, movement)))
        recovery = (0.008 + 0.160 * shelter) * rest_fraction
        self.fatigue -= recovery * dt
        self.fatigue = clamp(self.fatigue, 0.0, 1.0)

        energy_cost = (
            0.0019
            + 0.0026 * movement
            + 0.0010 * neural
            + 0.0014 * thermal_stress
            + 0.0010 * self.fatigue
        ) * dt
        self.energy -= energy_cost

        if thermal_stress > 0.70:
            damage = (
                0.010
                * (thermal_stress - 0.70)
                / 0.30
                * dt
            )
            self.integrity -= damage
            self.pain = min(1.0, self.pain + damage * 20.0)

        if self.fatigue > 0.90:
            damage = 0.006 * (self.fatigue - 0.90) / 0.10 * dt
            self.integrity -= damage
            self.pain = min(1.0, self.pain + damage * 20.0)

        # Healing is an embodied tradeoff: it consumes energy and needs rest.
        if (
            self.energy > 0.52
            and self.fatigue < 0.58
            and thermal_stress < 0.55
        ):
            heal_rate = (
                0.0018
                * (self.energy - 0.52)
                / 0.48
                * (1.0 - self.fatigue)
            )
            healing = min(heal_rate * dt, 1.0 - self.integrity)
            self.integrity += healing
            self.energy -= healing * 0.35

        for index, nutrient in enumerate(self.nutrient_positions):
            if float(np.linalg.norm(wrapped_delta(self.pos, nutrient))) < (
                BODY_RADIUS + NUTRIENT_RADIUS
            ):
                self.energy = min(1.0, self.energy + 0.17)
                self.eaten += 1
                self.nutrient_positions[index] = self.rng.random(2)

        for index, toxin in enumerate(self.toxin_positions):
            if float(np.linalg.norm(wrapped_delta(self.pos, toxin))) < (
                BODY_RADIUS + TOXIN_RADIUS
            ):
                self.integrity = max(0.0, self.integrity - 0.16)
                self.energy = max(0.0, self.energy - 0.035)
                self.pain = 1.0
                self.poisoned += 1
                self.toxin_positions[index] = self.rng.random(2)

        self.pain *= math.exp(-2.3 * dt)
        self.energy = clamp(self.energy, 0.0, 1.0)
        self.integrity = clamp(self.integrity, 0.0, 1.0)

    def relocate_nearest_nutrient(self, normalized_position):
        target = np.asarray(normalized_position, dtype=float) % 1.0
        distances = np.array([
            np.linalg.norm(wrapped_delta(target, nutrient))
            for nutrient in self.nutrient_positions
        ])
        index = int(np.argmin(distances))
        self.nutrient_positions[index] = target

    def regenerate_body(self, normalized_position=None):
        if normalized_position is not None:
            self.pos = np.asarray(normalized_position, dtype=float) % 1.0
        self.energy = 0.42
        self.temperature = 0.50
        self.integrity = 0.62
        self.fatigue = 0.24
        self.pain = 0.0
        self.vel[:] = 0.0
        self.last_action[:] = 0.0
        self.alive = True
        self.regenerations += 1

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def state_dict(self):
        state = self.brain.state_dict()
        state.update({
            'save_version': np.array(SAVE_VERSION, dtype=np.int64),
            'world_rng_state': encode_rng_state(self.rng),
            'life_seed': np.array(self.seed, dtype=np.int64),
            'life_pos': self.pos,
            'life_vel': self.vel,
            'life_last_action': self.last_action,
            'life_energy': np.array(self.energy),
            'life_temperature': np.array(self.temperature),
            'life_integrity': np.array(self.integrity),
            'life_fatigue': np.array(self.fatigue),
            'life_pain': np.array(self.pain),
            'life_age': np.array(self.age),
            'life_alive': np.array(1 if self.alive else 0, dtype=np.uint8),
            'life_eaten': np.array(self.eaten, dtype=np.int64),
            'life_poisoned': np.array(self.poisoned, dtype=np.int64),
            'life_regenerations': np.array(
                self.regenerations, dtype=np.int64
            ),
            'life_nutrients': self.nutrient_positions,
            'life_toxins': self.toxin_positions,
            'life_shelters': self.shelter_positions,
            'life_distance': np.array(self.distance_travelled),
            'life_viability_integral': np.array(self.viability_integral),
        })
        return state

    def load_state(self, data):
        if int(data['save_version']) != SAVE_VERSION:
            raise ValueError('unsupported SOMA-1 save version')

        expected = {
            'life_pos': (2,),
            'life_vel': (2,),
            'life_last_action': (2,),
            'life_nutrients': (NUTRIENT_COUNT, 2),
            'life_toxins': (TOXIN_COUNT, 2),
            'life_shelters': (SHELTER_COUNT, 2),
        }
        for key, shape in expected.items():
            if key not in data or tuple(data[key].shape) != shape:
                raise ValueError('incompatible life save: ' + key)

        self.brain.load_state(data)
        restore_rng_state(self.rng, data['world_rng_state'])

        self.seed = int(data['life_seed'])
        self.pos = np.array(data['life_pos'], dtype=float) % 1.0
        self.vel = np.array(data['life_vel'], dtype=float)
        self.last_action = np.array(data['life_last_action'], dtype=float)
        self.energy = clamp(float(data['life_energy']), 0.0, 1.0)
        self.temperature = clamp(float(data['life_temperature']), 0.0, 1.0)
        self.integrity = clamp(float(data['life_integrity']), 0.0, 1.0)
        self.fatigue = clamp(float(data['life_fatigue']), 0.0, 1.0)
        self.pain = clamp(float(data['life_pain']), 0.0, 1.0)
        self.age = max(0.0, float(data['life_age']))
        self.alive = bool(int(data['life_alive']))
        self.eaten = max(0, int(data['life_eaten']))
        self.poisoned = max(0, int(data['life_poisoned']))
        self.regenerations = max(0, int(data['life_regenerations']))
        self.nutrient_positions = np.array(
            data['life_nutrients'], dtype=float
        ) % 1.0
        self.toxin_positions = np.array(
            data['life_toxins'], dtype=float
        ) % 1.0
        self.shelter_positions = np.array(
            data['life_shelters'], dtype=float
        ) % 1.0
        self.distance_travelled = max(0.0, float(data['life_distance']))
        self.viability_integral = max(
            0.0, float(data['life_viability_integral'])
        )
        self.last_body_debt = self.body_debt()


# =============================================================================
# Pythonista scene
# =============================================================================

if IN_PYTHONISTA:

    def circle_node(radius, fill_color, stroke_color='clear', parent=None):
        path = ui.Path.oval(-radius, -radius, radius * 2.0, radius * 2.0)
        path.line_width = 1.0
        return ShapeNode(
            path=path,
            fill_color=fill_color,
            stroke_color=stroke_color,
            parent=parent,
        )


    def diamond_node(radius, fill_color, stroke_color='clear', parent=None):
        path = ui.Path()
        path.move_to(0.0, radius)
        path.line_to(radius, 0.0)
        path.line_to(0.0, -radius)
        path.line_to(-radius, 0.0)
        path.close()
        path.line_width = 1.0
        return ShapeNode(
            path=path,
            fill_color=fill_color,
            stroke_color=stroke_color,
            parent=parent,
        )


    def temperature_color(value):
        value = clamp(float(value), 0.0, 1.0)
        if value < 0.5:
            t = value / 0.5
            r = int(18 + 20 * t)
            g = int(42 + 22 * t)
            b = int(67 + 5 * t)
        else:
            t = (value - 0.5) / 0.5
            r = int(38 + 57 * t)
            g = int(64 - 22 * t)
            b = int(72 - 40 * t)
        return '#{:02X}{:02X}{:02X}'.format(r, g, b)


    class SomaOneScene(Scene):

        def setup(self):
            self.background_color = '#071014'
            self.core = SomaOneCore()

            self.temperature_tiles = []
            self.tile_columns = 12
            self.tile_rows = 6
            for _ in range(self.tile_columns * self.tile_rows):
                tile = SpriteNode(
                    texture=None,
                    color='#162A3A',
                    size=(10.0, 10.0),
                    parent=self,
                )
                tile.alpha = 0.62
                tile.z_position = -20
                self.temperature_tiles.append(tile)

            self.shelter_nodes = []
            for _ in range(SHELTER_COUNT):
                node = circle_node(20.0, '#355D76', '#73A6C4', parent=self)
                node.alpha = 0.34
                node.z_position = -5
                self.shelter_nodes.append(node)

            self.nutrient_nodes = []
            for _ in range(NUTRIENT_COUNT):
                node = circle_node(8.0, '#FFD15A', '#FFF1B0', parent=self)
                self.nutrient_nodes.append(node)

            self.toxin_nodes = []
            for _ in range(TOXIN_COUNT):
                node = diamond_node(8.5, '#E45B68', '#FFC0C6', parent=self)
                self.toxin_nodes.append(node)

            self.body = circle_node(18.0, '#54E3BD', '#C5FFF1', parent=self)
            self.body.z_position = 10
            self.core_node = circle_node(6.2, '#F2FFFB', 'clear', parent=self.body)

            self.cell_nodes = []
            visible_cells = 20
            for index in range(visible_cells):
                angle = 2.0 * math.pi * index / visible_cells
                node = circle_node(1.65, '#DFFFF7', 'clear', parent=self.body)
                node.position = (
                    10.2 * math.cos(angle),
                    10.2 * math.sin(angle),
                )
                self.cell_nodes.append(node)

            self.bar_backgrounds = []
            self.bar_foregrounds = []
            bar_colors = ('#FFD15A', '#7CC8FF', '#69E5BE', '#C9A7FF')
            for color in bar_colors:
                bg = SpriteNode(
                    texture=None,
                    color='#26383E',
                    size=(116.0, 7.0),
                    parent=self,
                )
                fg = SpriteNode(
                    texture=None,
                    color=color,
                    size=(116.0, 7.0),
                    parent=self,
                )
                bg.anchor_point = (0.0, 0.5)
                fg.anchor_point = (0.0, 0.5)
                self.bar_backgrounds.append(bg)
                self.bar_foregrounds.append(fg)

            self.info_label = LabelNode('', font=('Menlo', 10), parent=self)
            self.info_label.anchor_point = (0.0, 1.0)
            self.info_label.color = '#DCEAEC'

            self.help_label = LabelNode(
                'tap: relocate nutrient   autosave: 20 s',
                font=('Menlo', 9),
                parent=self,
            )
            self.help_label.anchor_point = (1.0, 1.0)
            self.help_label.color = '#7F9AA1'

            self.death_label = LabelNode(
                'DORMANT — tap to regenerate the body',
                font=('Menlo-Bold', 15),
                parent=self,
            )
            self.death_label.color = '#FF8D96'
            self.death_label.alpha = 0.0
            self.death_label.z_position = 30

            self.last_save_time = 0.0
            self.last_tile_update = -100.0
            self._layout()
            self._load_life_if_possible()
            self._sync_nodes(force_tiles=True)

        @property
        def arena_top(self):
            return max(ARENA_BOTTOM + 90.0, float(self.size.h) - HUD_HEIGHT)

        @property
        def play_height(self):
            return self.arena_top - ARENA_BOTTOM

        def did_change_size(self):
            if hasattr(self, 'info_label'):
                self._layout()
                self._sync_nodes(force_tiles=True)

        def _layout(self):
            width = float(self.size.w)
            height = float(self.size.h)
            top = height - 7.0
            self.info_label.position = (9.0, top)
            self.help_label.position = (width - 9.0, top)
            self.death_label.position = (
                width * 0.5,
                ARENA_BOTTOM + self.play_height * 0.5,
            )

            bar_y = height - 66.0
            for index, (bg, fg) in enumerate(zip(
                self.bar_backgrounds, self.bar_foregrounds
            )):
                x = 9.0 + index * 126.0
                bg.position = (x, bar_y)
                fg.position = (x, bar_y)

            tile_width = width / self.tile_columns
            tile_height = self.play_height / self.tile_rows
            for row in range(self.tile_rows):
                for column in range(self.tile_columns):
                    index = row * self.tile_columns + column
                    tile = self.temperature_tiles[index]
                    tile.size = (tile_width + 1.0, tile_height + 1.0)
                    tile.position = (
                        (column + 0.5) * tile_width,
                        ARENA_BOTTOM + (row + 0.5) * tile_height,
                    )

            body_radius_pixels = max(
                15.0,
                BODY_RADIUS * min(width, self.play_height),
            )
            scale = body_radius_pixels / 18.0
            self.body.scale = scale

            shelter_radius_pixels = SHELTER_RADIUS * min(
                width, self.play_height
            )
            for node in self.shelter_nodes:
                node.scale = shelter_radius_pixels / 20.0

        def update(self):
            dt = clamp(float(self.dt), 1.0 / 120.0, 1.0 / 15.0)
            self.core.step(dt)
            self._sync_nodes(force_tiles=False)

            if self.t - self.last_save_time >= 20.0:
                self._save_life()
                self.last_save_time = self.t

        def _screen_position(self, normalized):
            return (
                float(normalized[0]) * float(self.size.w),
                ARENA_BOTTOM + float(normalized[1]) * self.play_height,
            )

        def _sync_nodes(self, force_tiles=False):
            if force_tiles or self.t - self.last_tile_update >= 1.0:
                for row in range(self.tile_rows):
                    for column in range(self.tile_columns):
                        index = row * self.tile_columns + column
                        normalized = np.array([
                            (column + 0.5) / self.tile_columns,
                            (row + 0.5) / self.tile_rows,
                        ])
                        value, _ = self.core.temperature_field(normalized)
                        self.temperature_tiles[index].color = temperature_color(value)
                self.last_tile_update = self.t

            for node, position in zip(
                self.nutrient_nodes, self.core.nutrient_positions
            ):
                node.position = self._screen_position(position)

            for node, position in zip(
                self.toxin_nodes, self.core.toxin_positions
            ):
                node.position = self._screen_position(position)

            for node, position in zip(
                self.shelter_nodes, self.core.shelter_positions
            ):
                node.position = self._screen_position(position)

            self.body.position = self._screen_position(self.core.pos)
            self.body.alpha = 1.0 if self.core.alive else 0.25
            self.core_node.alpha = (
                0.18
                + 0.42 * self.core.energy
                + 0.40 * self.core.integrity
            )
            self.death_label.alpha = 0.0 if self.core.alive else 1.0

            for index, node in enumerate(self.cell_nodes):
                activity = abs(float(self.core.brain.hidden[index]))
                vitality = float(self.core.brain.vitality[index])
                node.alpha = 0.12 + 0.50 * activity + 0.38 * vitality
                node.scale = 0.68 + 0.42 * activity + 0.22 * vitality

            values = (
                self.core.energy,
                1.0 - abs(self.core.temperature - 0.50) / 0.50,
                self.core.integrity,
                1.0 - self.core.fatigue,
            )
            for foreground, value in zip(self.bar_foregrounds, values):
                foreground.size = (
                    max(1.0, 116.0 * clamp(value, 0.0, 1.0)),
                    7.0,
                )

            diagnostic = self.core.brain.diagnostics()
            debt = self.core.body_debt()
            pulse = self.core.brain.last_trophic_pulse
            self.info_label.text = (
                'SOMA-1  age {:6.1f}s  E {:.3f}  T {:.3f}  I {:.3f}  F {:.3f}  food {}  toxin {}\n'
                'debt [{:.2f} {:.2f} {:.2f} {:.2f}]  pulse [{:+.3f} {:+.3f} {:+.3f} {:+.3f}]\n'
                'tissue V {:.3f}/{:.3f}  pred {:.3f}  causal {:.4f}  flow {:.5f}  edges {}  born {}  rewired {}'
            ).format(
                self.core.age,
                self.core.energy,
                self.core.temperature,
                self.core.integrity,
                self.core.fatigue,
                self.core.eaten,
                self.core.poisoned,
                debt[0], debt[1], debt[2], debt[3],
                pulse[0], pulse[1], pulse[2], pulse[3],
                diagnostic['mean_vitality'],
                diagnostic['min_vitality'],
                diagnostic['prediction_error'],
                diagnostic['causal_strength'],
                diagnostic['mean_flow'],
                diagnostic['edges'],
                diagnostic['births'],
                diagnostic['rewires'],
            )

        def touch_began(self, touch):
            x = clamp(float(touch.location.x), 0.0, float(self.size.w))
            y = clamp(
                float(touch.location.y), ARENA_BOTTOM, self.arena_top
            )
            normalized = np.array([
                x / max(1.0, float(self.size.w)),
                (y - ARENA_BOTTOM) / max(1.0, self.play_height),
            ])

            if self.core.alive:
                self.core.relocate_nearest_nutrient(normalized)
            else:
                self.core.regenerate_body(normalized)
            self._save_life()

        def _save_life(self):
            try:
                np.savez(SAVE_FILE, **self.core.state_dict())
            except Exception as exc:
                print('SOMA-1 save failed:', exc)

        def _load_life_if_possible(self):
            if not os.path.exists(SAVE_FILE):
                return
            try:
                with np.load(SAVE_FILE, allow_pickle=False) as data:
                    self.core.load_state(data)
            except Exception as exc:
                print('SOMA-1 load ignored:', exc)

        def pause(self):
            self._save_life()

        def stop(self):
            self._save_life()


# =============================================================================
# Headless experimental helpers
# =============================================================================

def run_headless_trial(
    seed=0,
    seconds=120.0,
    learning_enabled=True,
    scalarize_trophic=False,
    diffusion_enabled=True,
    turnover_enabled=True,
    dt=1.0 / 30.0,
):
    core = SomaOneCore(
        seed=seed,
        learning_enabled=learning_enabled,
        scalarize_trophic=scalarize_trophic,
        diffusion_enabled=diffusion_enabled,
        turnover_enabled=turnover_enabled,
    )
    maximum_steps = int(max(0.0, float(seconds)) / float(dt))
    for _ in range(maximum_steps):
        core.step(dt)
        if not core.alive:
            break

    diagnostic = core.brain.diagnostics()
    lived = max(core.age, 1e-9)
    return {
        'seed': int(seed),
        'age': float(core.age),
        'survived': bool(core.alive),
        'food': int(core.eaten),
        'toxin': int(core.poisoned),
        'energy': float(core.energy),
        'temperature': float(core.temperature),
        'integrity': float(core.integrity),
        'fatigue': float(core.fatigue),
        'mean_health': float(core.viability_integral / lived),
        'distance': float(core.distance_travelled),
        'tissue_vitality': diagnostic['mean_vitality'],
        'prediction_error': diagnostic['prediction_error'],
        'births': diagnostic['births'],
        'rewires': diagnostic['rewires'],
    }


def _print_smoke_test():
    result = run_headless_trial(seed=7, seconds=20.0)
    print('SOMA-1 headless smoke test')
    for key in sorted(result):
        print('{:>18}: {}'.format(key, result[key]))


if __name__ == '__main__':
    if IN_PYTHONISTA:
        run(
            SomaOneScene(),
            orientation=LANDSCAPE,
            frame_interval=2,
            anti_alias=True,
            show_fps=False,
            multi_touch=True,
        )
    else:
        _print_smoke_test()
