# coding: utf-8
"""Small ablation matrix for SOMA-CELL 0.1.

This is a mechanism check, not a population-level statistical claim.  The same
three random seeds are reused across conditions.
"""

from __future__ import print_function

import csv
import math
import os

import numpy as np

import SOMA_CELL_0_1_pythonista as cellmod


SEEDS = (101, 202, 303)
RESULTS_FILE = os.path.join(os.path.dirname(__file__), 'soma_cell_0_1_experiment_results.csv')
SUMMARY_FILE = os.path.join(os.path.dirname(__file__), 'soma_cell_0_1_experiment_summary.csv')
DT = 1.0 / cellmod.SIM_HZ
RESUME_COMPLETED = True


CONDITIONS = (
    ('full', 360.0, cellmod.CellConfig(environmental_damage=False), False),
    ('full_repeated_damage', 420.0, cellmod.CellConfig(environmental_damage=False), True),
    ('no_membrane_synthesis_damage', 420.0, cellmod.CellConfig(
        membrane_synthesis=False, environmental_damage=False
    ), True),
    ('no_transport', 360.0, cellmod.CellConfig(
        transport=False, environmental_damage=False
    ), False),
    ('no_catalyst_replication', 360.0, cellmod.CellConfig(
        catalyst_synthesis=False, environmental_damage=False
    ), False),
    ('no_waste_export', 430.0, cellmod.CellConfig(
        waste_export=False, environmental_damage=False
    ), False),
)


def run_condition(name, seconds, config, periodic_damage, seed):
    world = cellmod.SomaCellWorld(seed=seed, initial_cells=1, config=config)
    first_division_age = float('nan')
    steps = int(round(seconds * cellmod.SIM_HZ))
    for step in range(steps):
        if (
            periodic_damage
            and step > 0
            and step % int(30 * cellmod.SIM_HZ) == 0
            and world.living_cells()
        ):
            target = world.living_cells()[0]
            removed = target.puncture((step / 137.0) % (2.0 * math.pi), 0.80)
            world.field.add_particle(
                cellmod.PARTICLE_WASTE,
                target.pos,
                removed,
                count_as_injection=False,
            )
        world.step(DT)
        if world.divisions and not np.isfinite(first_division_age):
            first_division_age = world.age
        if not world.living_cells():
            break
    summary = world.summary()
    return {
        'condition': name,
        'seed': seed,
        'planned_seconds': seconds,
        'age': summary['age'],
        'cells': summary['cells'],
        'births': summary['births'],
        'divisions': summary['divisions'],
        'deaths': summary['deaths'],
        'max_generation': summary['max_generation'],
        'first_division_age': first_division_age,
        'mean_closure': summary['mean_closure'],
        'mean_atp': summary['mean_atp'],
        'mean_catalyst': summary['mean_catalyst'],
        'mean_loop': summary['mean_loop'],
        'mean_membrane': summary['mean_membrane'],
        'external_fuel': summary['external_fuel'],
        'external_mineral': summary['external_mineral'],
        'external_waste': summary['external_waste'],
        'cell_material': summary['cell_material'],
        'total_material': summary['total_material'],
        'matter_residual': summary['matter_residual'],
        'division_residual': summary['division_residual'],
        'extinct': int(summary['cells'] == 0),
    }


def aggregate(rows):
    output = []
    names = []
    for row in rows:
        if row['condition'] not in names:
            names.append(row['condition'])
    numeric = [
        'age', 'cells', 'births', 'divisions', 'deaths', 'max_generation',
        'first_division_age', 'mean_closure', 'mean_atp', 'mean_catalyst',
        'mean_loop', 'mean_membrane', 'external_fuel', 'external_mineral',
        'external_waste', 'cell_material', 'total_material',
        'matter_residual', 'division_residual', 'extinct',
    ]
    for name in names:
        group = [row for row in rows if row['condition'] == name]
        item = {'condition': name, 'n': len(group)}
        for key in numeric:
            values = np.asarray([float(row[key]) for row in group], dtype=float)
            finite = values[np.isfinite(values)]
            item[key + '_mean'] = float(np.mean(finite)) if finite.size else float('nan')
            item[key + '_min'] = float(np.min(finite)) if finite.size else float('nan')
            item[key + '_max'] = float(np.max(finite)) if finite.size else float('nan')
        output.append(item)
    return output


def _write_results(rows):
    if not rows:
        return
    fields = list(rows[0].keys())
    with open(RESULTS_FILE, 'w', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def _load_results():
    if not RESUME_COMPLETED or not os.path.exists(RESULTS_FILE):
        return []
    rows = []
    with open(RESULTS_FILE, 'r', newline='') as handle:
        for row in csv.DictReader(handle):
            converted = dict(row)
            for key, value in list(converted.items()):
                if key == 'condition':
                    continue
                try:
                    converted[key] = float(value)
                except Exception:
                    converted[key] = value
            converted['seed'] = int(converted['seed'])
            for key in ('cells', 'births', 'divisions', 'deaths', 'max_generation', 'extinct'):
                converted[key] = int(float(converted[key]))
            rows.append(converted)
    return rows


def main():
    rows = _load_results()
    completed = {(row['condition'], int(row['seed'])) for row in rows}
    for name, seconds, config, periodic_damage in CONDITIONS:
        for seed in SEEDS:
            if (name, int(seed)) in completed:
                continue
            row = run_condition(name, seconds, config, periodic_damage, seed)
            rows.append(row)
            completed.add((name, int(seed)))
            _write_results(rows)  # Persist every completed life.
            print(
                '{:<31} seed={} cells={} divisions={} deaths={} loop={:.3f}'.format(
                    name, seed, row['cells'], row['divisions'],
                    row['deaths'], row['mean_loop']
                ),
                flush=True,
            )
    rows.sort(key=lambda row: (
        [item[0] for item in CONDITIONS].index(row['condition']),
        int(row['seed']),
    ))
    _write_results(rows)
    summary = aggregate(rows)
    if summary:
        summary_fields = list(summary[0].keys())
        with open(SUMMARY_FILE, 'w', newline='') as handle:
            writer = csv.DictWriter(handle, fieldnames=summary_fields)
            writer.writeheader()
            writer.writerows(summary)
    return rows, summary


if __name__ == '__main__':
    main()
