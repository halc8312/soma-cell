# coding: utf-8
"""
SOMA-2.1 — Revocable Causal Leases / 可撤回因果リース
Pythonista 3向け・単体人工生命の監査校正版

必要ファイル（同じフォルダ）
--------------------------------
- SOMA_1_pythonista.py
- SOMA_2_pythonista.py
- SOMA_2_1_pythonista.py（このファイル）

SOMA-2の弱点を二つ修正します。

1. 反転対称・汚染認識型の神経監査
   claim/sham各群を ABBA または BAAB の対称順序で測定し、線形な時間変化
   と順序効果を抑えます。食物・毒への接触が測定窓へ入った場合は、その窓を
   汚染済みとして再試行します。身体・環境文脈が揃わない比較は低品質証拠に
   格下げします。

2. 永久器官を廃止した「因果リース」
   採択済みの形態変化は永久所有物ではありません。一定時間または身体文脈の
   変化後に、その変化だけを一時的に撤去する交差試験を行います。効果が再現
   すればリースを更新し、反証が続けば形態変化を取り消して材料を一部回収します。

普通のニューラルネットワークとの違い
------------------------------------
- 学習済み重みや器官を「真実」とせず、期限付きの因果主張として扱う。
- 同じ生涯の中で、内部機能と身体構造を実際に止めて再検証する。
- 世界や身体が変われば、過去の正しい知識も失効しうる。
- 試験中は高速なシナプス学習を凍結し、介入と学習の同時変化を分離する。

研究仮説を動く形にしたモデルであり、意識・生命・学術的新規性を証明する
ものではありません。
"""

import math
import os
import time

import numpy as np

import SOMA_2_pythonista as soma2
from SOMA_1_pythonista import (
    CELL_COUNT,
    TROPHIC_COUNT,
    MAX_SPEED,
    LANDSCAPE,
    clamp,
)
from SOMA_2_pythonista import (
    AuditedCausalTissue,
    CausalAuditor,
    EscrowMorphology,
    SomaTwoCore,
    MORPH_SLOT_COUNT,
    MORPH_MODALITY_COUNT,
    MORPH_SENSOR,
    MORPH_FIN,
    MORPH_SHELL,
    MORPH_KIND_NAMES,
    MORPH_MODALITY_NAMES,
    TRIAL_EPOCH_COUNT,
    scalar_array,
    bool_array,
)


SAVE_FILE = os.path.join(os.path.dirname(__file__), 'soma2_1_life.npz')
SAVE_VERSION = 4

# Discrete events that can dominate a short causal window.
EVENT_NUTRIENT = 1
EVENT_TOXIN = 2
EVENT_SHELTER_EDGE = 4
EVENT_THERMAL_SHIFT = 8
HARD_EVENT_MASK = EVENT_NUTRIENT | EVENT_TOXIN

AUDIT_CONTEXT_DIM = 9
AUDIT_CONTEXT_SCALE = np.array(
    [0.22, 0.22, 0.18, 0.24, 0.35, 0.22, 0.35, 0.25, 0.22],
    dtype=float,
)

LEASE_MODE_PROPOSAL = 0
LEASE_MODE_REVIEW = 1
MAX_CAUSAL_LEASES = 48


# =============================================================================
# Counterbalanced neuronal causal audit
# =============================================================================


class CounterbalancedCausalAuditor(CausalAuditor):
    """Within-life N-of-1 audit with symmetric order and evidence expiry.

    Each of the two cell groups (claim and matched sham) receives four short
    periods. The condition sequence is either ABBA or BAAB, where A is intact
    output and B is efferent knockout. This symmetry cancels a first-order time
    trend within each arm. Claim/sham arm order is independently randomized.

    A nutrient or toxin contact can dwarf metabolic slopes, so contaminated
    periods are retried when possible. Context mismatch and residual noise do
    not erase evidence, but reduce its weight. Evidence coverage decays when it
    has not been re-audited: causal knowledge is a lease, not a permanent fact.
    """

    STAGE_MEASURE = 0
    STAGE_WASHOUT = 1

    def __init__(
        self,
        seed=0,
        enabled=True,
        group_size=5,
        symmetric_order=True,
        exclude_hard_events=True,
        evidence_decay=True,
        evidence_half_life=95.0,
        max_period_retries=2,
    ):
        super().__init__(seed=seed, enabled=enabled, group_size=group_size)
        self.symmetric_order = bool(symmetric_order)
        self.exclude_hard_events = bool(exclude_hard_events)
        self.evidence_decay = bool(evidence_decay)
        self.evidence_half_life = float(evidence_half_life)
        self.max_period_retries = int(max_period_retries)

        self.measure_duration = 1.20
        self.washout_duration = 0.45
        self.stage = self.STAGE_MEASURE
        self.stage_duration = self.measure_duration

        self.period_sequence = np.zeros((2, 4), dtype=np.int8)
        self.period_index = 0
        self.period_slope = np.zeros((2, 4, TROPHIC_COUNT), dtype=float)
        self.period_context = np.zeros(
            (2, 4, AUDIT_CONTEXT_DIM), dtype=float
        )
        self.period_event_mask = np.zeros((2, 4), dtype=np.int16)
        self.period_retry_count = np.zeros((2, 4), dtype=np.int8)
        self.period_complete = np.zeros((2, 4), dtype=bool)
        self.pending_retry = False

        self.segment_start_debt = np.zeros(TROPHIC_COUNT, dtype=float)
        self.segment_context_sum = np.zeros(AUDIT_CONTEXT_DIM, dtype=float)
        self.segment_context_weight = 0.0
        self.segment_event_mask = 0

        shape = (CELL_COUNT, TROPHIC_COUNT)
        self.effect_variance = np.zeros(shape, dtype=float)
        self.effect_weight = np.zeros(shape, dtype=float)
        self.effect_last_age = np.full(shape, -1e9, dtype=float)
        self.current_age = 0.0

        self.last_quality = 0.0
        self.last_context_mismatch = 0.0
        self.last_noise = 0.0
        self.quality_sum = 0.0
        self.contaminated_segments = 0
        self.retried_segments = 0
        self.forced_contaminated_segments = 0
        self.soft_event_segments = 0
        self.aborted = 0
        self.last_event_mask = 0

    # ------------------------------------------------------------------
    # Time-limited evidence
    # ------------------------------------------------------------------

    def _decayed_weight(self):
        weight = np.asarray(self.effect_weight, dtype=float)
        if not self.evidence_decay:
            return weight
        age_delta = np.maximum(0.0, self.current_age - self.effect_last_age)
        decay = np.exp(
            -math.log(2.0) * age_delta / max(self.evidence_half_life, 1e-6)
        )
        return weight * decay

    def gate(self):
        effective_weight = self._decayed_weight()
        standard_error = np.sqrt(np.maximum(self.effect_variance, 0.0)) / np.sqrt(
            np.maximum(effective_weight, 0.20)
        )
        signal = self.effect_mean / (0.00042 + standard_error)
        confidence = 0.5 + 0.5 * np.tanh(signal)
        coverage = 1.0 - np.exp(-effective_weight / 2.2)
        gate = coverage * confidence
        gate[self.effect_mean < -0.00025] *= 0.08
        return np.clip(gate, 0.0, 1.0)

    def mean_quality(self):
        return self.quality_sum / max(1, self.completed)

    # ------------------------------------------------------------------
    # Audit state machine
    # ------------------------------------------------------------------

    @property
    def busy(self):
        return bool(self.active)

    def _make_sequence(self):
        if self.symmetric_order:
            template_a = np.array([0, 1, 1, 0], dtype=np.int8)
            template_b = np.array([1, 0, 0, 1], dtype=np.int8)
            return template_a if self.rng.random() < 0.5 else template_b
        # Deliberately order-confounded ablation with equal sample count.
        return (
            np.array([0, 0, 1, 1], dtype=np.int8)
            if self.rng.random() < 0.5
            else np.array([1, 1, 0, 0], dtype=np.int8)
        )

    def _current_arm(self):
        return int(self.arm_order[self.arm_index])

    def _current_condition(self):
        arm = self._current_arm()
        return int(self.period_sequence[arm, self.period_index])

    def _begin_measure(self, debt):
        self.stage = self.STAGE_MEASURE
        self.stage_duration = self.measure_duration
        self.stage_elapsed = 0.0
        self.segment_start_debt = np.asarray(debt, dtype=float).copy()
        self.stage_start_debt = self.segment_start_debt.copy()
        self.segment_context_sum[:] = 0.0
        self.segment_context_weight = 0.0
        self.segment_event_mask = 0

    def _begin_washout(self, debt):
        self.stage = self.STAGE_WASHOUT
        self.stage_duration = self.washout_duration
        self.stage_elapsed = 0.0
        self.stage_start_debt = np.asarray(debt, dtype=float).copy()

    def maybe_start(self, age, debt, brain, morphology_busy=False, force=False):
        if not self.enabled or self.active or morphology_busy:
            return False
        if not force:
            if self.cooldown > 0.0 or age < 18.0:
                return False
            if float(np.max(debt)) > 0.78:
                return False

        self.currency = self._choose_currency(brain, debt)
        (
            self.claimed_mask,
            self.sham_mask,
            self.last_claim_strength,
        ) = self._select_groups(brain, self.currency)
        if not np.any(self.claimed_mask) or not np.any(self.sham_mask):
            self.cooldown = 4.0
            return False

        self.arm_order = self.rng.permutation(np.array([0, 1], dtype=np.int8))
        self.period_sequence[0] = self._make_sequence()
        self.period_sequence[1] = self._make_sequence()
        self.arm_index = 0
        self.period_index = 0
        self.period_slope[:] = 0.0
        self.period_context[:] = 0.0
        self.period_event_mask[:] = 0
        self.period_retry_count[:] = 0
        self.period_complete[:] = False
        self.pending_retry = False
        self.active = True
        self.current_age = float(age)
        self.last_started_age = float(age)
        self.last_status = 'running'
        self._begin_measure(debt)
        return True

    def current_knockout_mask(self):
        if not self.active or self.stage != self.STAGE_MEASURE:
            return None
        if self._current_condition() == 0:
            return None
        return self.claimed_mask if self._current_arm() == 0 else self.sham_mask

    def tick_cooldown(self, dt):
        if not self.active:
            self.cooldown = max(0.0, self.cooldown - float(dt))

    def _advance_period(self, debt_after, age):
        self.period_index += 1
        if self.period_index < 4:
            self._begin_washout(debt_after)
            return False

        self.arm_index += 1
        self.period_index = 0
        if self.arm_index < 2:
            self._begin_washout(debt_after)
            return False

        self._finish_counterbalanced(age)
        return True

    def observe(
        self,
        debt_after,
        dt,
        age,
        event_mask=0,
        context=None,
    ):
        self.current_age = float(age)
        if not self.active:
            self.tick_cooldown(dt)
            return False

        dt = float(dt)
        debt_after = np.asarray(debt_after, dtype=float)
        if context is None:
            context = np.zeros(AUDIT_CONTEXT_DIM, dtype=float)
        context = np.asarray(context, dtype=float)
        if context.shape != (AUDIT_CONTEXT_DIM,):
            raise ValueError('audit context has incompatible shape')

        if self.stage == self.STAGE_MEASURE:
            self.segment_context_sum += context * dt
            self.segment_context_weight += dt
            self.segment_event_mask |= int(event_mask)

        self.stage_elapsed += dt
        if self.stage_elapsed + 1e-12 < self.stage_duration:
            return False

        if self.stage == self.STAGE_WASHOUT:
            if self.pending_retry:
                self.pending_retry = False
                self._begin_measure(debt_after)
                return False
            self._begin_measure(debt_after)
            return False

        arm = self._current_arm()
        period = int(self.period_index)
        slope = (debt_after - self.segment_start_debt) / max(
            self.stage_elapsed, 1e-9
        )
        hard_contaminated = bool(self.segment_event_mask & HARD_EVENT_MASK)

        if hard_contaminated and self.exclude_hard_events:
            self.contaminated_segments += 1
            retries = int(self.period_retry_count[arm, period])
            if retries < self.max_period_retries:
                self.period_retry_count[arm, period] = retries + 1
                self.retried_segments += 1
                self.pending_retry = True
                self._begin_washout(debt_after)
                return False
            self.forced_contaminated_segments += 1

        if self.segment_event_mask & ~HARD_EVENT_MASK:
            self.soft_event_segments += 1

        self.period_slope[arm, period] = slope
        self.period_context[arm, period] = (
            self.segment_context_sum / max(self.segment_context_weight, 1e-9)
        )
        self.period_event_mask[arm, period] = int(self.segment_event_mask)
        self.period_complete[arm, period] = True
        self.last_event_mask = int(self.segment_event_mask)
        return self._advance_period(debt_after, age)

    # ------------------------------------------------------------------
    # Estimation and evidence update
    # ------------------------------------------------------------------

    def _context_mismatch(self):
        mismatches = []
        for arm in (0, 1):
            sequence = self.period_sequence[arm]
            intact = np.mean(self.period_context[arm, sequence == 0], axis=0)
            knockout = np.mean(self.period_context[arm, sequence == 1], axis=0)
            scaled = (knockout - intact) / AUDIT_CONTEXT_SCALE
            mismatches.append(float(np.sqrt(np.mean(scaled * scaled))))

        claim_context = np.mean(self.period_context[0], axis=0)
        sham_context = np.mean(self.period_context[1], axis=0)
        cross = (claim_context - sham_context) / AUDIT_CONTEXT_SCALE
        cross_mismatch = float(np.sqrt(np.mean(cross * cross)))
        return 0.70 * float(np.mean(mismatches)) + 0.30 * cross_mismatch

    def _slope_noise(self):
        dispersions = []
        for arm in (0, 1):
            sequence = self.period_sequence[arm]
            for condition in (0, 1):
                values = self.period_slope[arm, sequence == condition]
                center = np.median(values, axis=0)
                dispersions.append(np.median(np.abs(values - center), axis=0))
        return float(np.median(np.asarray(dispersions)))

    def _update_cell_evidence(self, index, currency, effect, quality, age):
        old_weight = float(self.effect_weight[index, currency])
        old_age = float(self.effect_last_age[index, currency])
        if self.evidence_decay and old_age > -1e8:
            old_weight *= math.exp(
                -math.log(2.0)
                * max(0.0, float(age) - old_age)
                / max(self.evidence_half_life, 1e-6)
            )

        added = max(0.02, float(quality))
        total = old_weight + added
        old_mean = float(self.effect_mean[index, currency])
        delta = float(effect) - old_mean
        alpha = added / max(total, 1e-9)
        new_mean = old_mean + alpha * delta
        old_var = float(self.effect_variance[index, currency])
        new_var = (1.0 - alpha) * (
            old_var + alpha * delta * delta
        )

        self.effect_mean[index, currency] = new_mean
        self.effect_variance[index, currency] = max(0.0, new_var)
        self.effect_weight[index, currency] = total
        self.effect_last_age[index, currency] = float(age)
        self.effect_count[index, currency] += 1
        self.effect_m2[index, currency] = (
            self.effect_variance[index, currency] * max(total - 1.0, 1.0)
        )

    def _finish_counterbalanced(self, age):
        if not bool(np.all(self.period_complete)):
            self.aborted += 1
            self.active = False
            self.cooldown = 5.0
            self.last_status = 'aborted'
            return

        arm_effect = np.zeros((2, TROPHIC_COUNT), dtype=float)
        for arm in (0, 1):
            sequence = self.period_sequence[arm]
            knockout = np.median(
                self.period_slope[arm, sequence == 1], axis=0
            )
            intact = np.median(
                self.period_slope[arm, sequence == 0], axis=0
            )
            arm_effect[arm] = knockout - intact

        effect = arm_effect[0] - arm_effect[1]
        self.last_effect = effect.copy()
        target_effect = float(effect[self.currency])
        self.last_target_effect = target_effect

        context_mismatch = self._context_mismatch()
        noise = self._slope_noise()
        context_quality = math.exp(-0.24 * context_mismatch)
        noise_quality = 1.0 / (1.0 + noise / 0.0035)
        forced = int(np.sum(
            (self.period_event_mask & HARD_EVENT_MASK) != 0
        ))
        hard_quality = 0.42 ** forced
        soft = int(np.sum(
            (self.period_event_mask & ~HARD_EVENT_MASK) != 0
        ))
        soft_quality = 0.94 ** soft
        quality = clamp(
            context_quality * noise_quality * hard_quality * soft_quality,
            0.02,
            1.0,
        )

        self.last_context_mismatch = context_mismatch
        self.last_noise = noise
        self.last_quality = quality
        self.quality_sum += quality

        for index in np.flatnonzero(self.claimed_mask):
            self._update_cell_evidence(
                int(index), self.currency, target_effect, quality, age
            )

        # Fill legacy diagnostics with arm-level values for easier inspection.
        self.baseline_slope[0] = np.median(
            self.period_slope[0, self.period_sequence[0] == 0], axis=0
        )
        self.knockout_slope[0] = np.median(
            self.period_slope[0, self.period_sequence[0] == 1], axis=0
        )
        self.baseline_slope[1] = np.median(
            self.period_slope[1, self.period_sequence[1] == 0], axis=0
        )
        self.knockout_slope[1] = np.median(
            self.period_slope[1, self.period_sequence[1] == 1], axis=0
        )

        self.completed += 1
        if quality >= 0.18 and target_effect > 0.00020:
            self.passed += 1
            self.last_status = 'supported'
        elif quality >= 0.18 and target_effect < -0.00020:
            self.failed += 1
            self.last_status = 'contradicted'
        else:
            self.last_status = 'inconclusive'

        self.active = False
        self.stage = self.STAGE_MEASURE
        self.stage_duration = self.measure_duration
        self.cooldown = 8.0
        self.last_finished_age = float(age)

    def cancel_active(self, reason='cancelled'):
        if self.active:
            self.active = False
            self.aborted += 1
            self.cooldown = 4.0
            self.last_status = str(reason)

    def status_text(self):
        if not self.enabled:
            return 'audit off'
        if not self.active:
            return '{} q{:.2f}'.format(self.last_status, self.last_quality)
        if self.stage == self.STAGE_WASHOUT:
            return 'wash k{} retry{}'.format(
                self.currency,
                int(self.period_retry_count[
                    self._current_arm(), self.period_index
                ]),
            )
        arm_name = 'claim' if self._current_arm() == 0 else 'sham'
        condition = 'KO' if self._current_condition() else 'intact'
        return '{}-{} {}/4 k{}'.format(
            arm_name, condition, self.period_index + 1, self.currency
        )

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def state_dict(self):
        state = super().state_dict()
        state.update({
            'audit21_symmetric_order': bool_array(self.symmetric_order),
            'audit21_exclude_hard_events': bool_array(
                self.exclude_hard_events
            ),
            'audit21_evidence_decay': bool_array(self.evidence_decay),
            'audit21_evidence_half_life': scalar_array(
                self.evidence_half_life
            ),
            'audit21_max_period_retries': scalar_array(
                self.max_period_retries, np.int64
            ),
            'audit21_measure_duration': scalar_array(self.measure_duration),
            'audit21_washout_duration': scalar_array(self.washout_duration),
            'audit21_period_sequence': self.period_sequence,
            'audit21_period_index': scalar_array(self.period_index, np.int64),
            'audit21_period_slope': self.period_slope,
            'audit21_period_context': self.period_context,
            'audit21_period_event_mask': self.period_event_mask,
            'audit21_period_retry_count': self.period_retry_count,
            'audit21_period_complete': self.period_complete.astype(np.uint8),
            'audit21_pending_retry': bool_array(self.pending_retry),
            'audit21_segment_start_debt': self.segment_start_debt,
            'audit21_segment_context_sum': self.segment_context_sum,
            'audit21_segment_context_weight': scalar_array(
                self.segment_context_weight
            ),
            'audit21_segment_event_mask': scalar_array(
                self.segment_event_mask, np.int64
            ),
            'audit21_effect_variance': self.effect_variance,
            'audit21_effect_weight': self.effect_weight,
            'audit21_effect_last_age': self.effect_last_age,
            'audit21_current_age': scalar_array(self.current_age),
            'audit21_last_quality': scalar_array(self.last_quality),
            'audit21_last_context_mismatch': scalar_array(
                self.last_context_mismatch
            ),
            'audit21_last_noise': scalar_array(self.last_noise),
            'audit21_quality_sum': scalar_array(self.quality_sum),
            'audit21_contaminated_segments': scalar_array(
                self.contaminated_segments, np.int64
            ),
            'audit21_retried_segments': scalar_array(
                self.retried_segments, np.int64
            ),
            'audit21_forced_contaminated_segments': scalar_array(
                self.forced_contaminated_segments, np.int64
            ),
            'audit21_soft_event_segments': scalar_array(
                self.soft_event_segments, np.int64
            ),
            'audit21_aborted': scalar_array(self.aborted, np.int64),
            'audit21_last_event_mask': scalar_array(
                self.last_event_mask, np.int64
            ),
        })
        return state

    def load_state(self, data):
        super().load_state(data)
        self.symmetric_order = bool(int(data['audit21_symmetric_order']))
        self.exclude_hard_events = bool(
            int(data['audit21_exclude_hard_events'])
        )
        self.evidence_decay = bool(int(data['audit21_evidence_decay']))
        self.evidence_half_life = float(data['audit21_evidence_half_life'])
        self.max_period_retries = int(data['audit21_max_period_retries'])
        self.measure_duration = float(data['audit21_measure_duration'])
        self.washout_duration = float(data['audit21_washout_duration'])
        self.period_sequence = np.array(
            data['audit21_period_sequence'], dtype=np.int8
        )
        self.period_index = int(data['audit21_period_index'])
        self.period_slope = np.array(data['audit21_period_slope'], dtype=float)
        self.period_context = np.array(
            data['audit21_period_context'], dtype=float
        )
        self.period_event_mask = np.array(
            data['audit21_period_event_mask'], dtype=np.int16
        )
        self.period_retry_count = np.array(
            data['audit21_period_retry_count'], dtype=np.int8
        )
        self.period_complete = np.array(
            data['audit21_period_complete'], dtype=bool
        )
        self.pending_retry = bool(int(data['audit21_pending_retry']))
        self.segment_start_debt = np.array(
            data['audit21_segment_start_debt'], dtype=float
        )
        self.segment_context_sum = np.array(
            data['audit21_segment_context_sum'], dtype=float
        )
        self.segment_context_weight = float(
            data['audit21_segment_context_weight']
        )
        self.segment_event_mask = int(data['audit21_segment_event_mask'])
        self.effect_variance = np.array(
            data['audit21_effect_variance'], dtype=float
        )
        self.effect_weight = np.array(
            data['audit21_effect_weight'], dtype=float
        )
        self.effect_last_age = np.array(
            data['audit21_effect_last_age'], dtype=float
        )
        self.current_age = float(data['audit21_current_age'])
        self.last_quality = float(data['audit21_last_quality'])
        self.last_context_mismatch = float(
            data['audit21_last_context_mismatch']
        )
        self.last_noise = float(data['audit21_last_noise'])
        self.quality_sum = float(data['audit21_quality_sum'])
        self.contaminated_segments = int(
            data['audit21_contaminated_segments']
        )
        self.retried_segments = int(data['audit21_retried_segments'])
        self.forced_contaminated_segments = int(
            data['audit21_forced_contaminated_segments']
        )
        self.soft_event_segments = int(data['audit21_soft_event_segments'])
        self.aborted = int(data['audit21_aborted'])
        self.last_event_mask = int(data['audit21_last_event_mask'])


# =============================================================================
# Revocable morphology: every accepted change receives a causal lease
# =============================================================================


class CausalLeaseMorphology(EscrowMorphology):
    """Escrow morphology whose committed changes remain falsifiable.

    The permanent arrays still contain accepted changes, but each change is
    recorded separately. During a lease review, exactly that delta is removed
    in the OFF periods. A supported effect renews the lease. Contradictory or
    repeatedly inconclusive evidence revokes the delta and recycles material.
    """

    def __init__(
        self,
        *args,
        lease_review_enabled=True,
        context_sensitive_leases=True,
        lease_evidence_decay=True,
        **kwargs
    ):
        super().__init__(*args, **kwargs)
        self.lease_review_enabled = bool(lease_review_enabled)
        self.context_sensitive_leases = bool(context_sensitive_leases)
        self.lease_evidence_decay = bool(lease_evidence_decay)
        self.lease_half_life = 85.0
        self.mode = LEASE_MODE_PROPOSAL
        self.current_age = 0.0
        self.review_index = -1

        n = MAX_CAUSAL_LEASES
        self.lease_active = np.zeros(n, dtype=bool)
        self.lease_kind = np.zeros(n, dtype=np.int8)
        self.lease_slot = np.zeros(n, dtype=np.int8)
        self.lease_modality = np.zeros(n, dtype=np.int8)
        self.lease_delta = np.zeros(n, dtype=float)
        self.lease_target_currency = np.zeros(n, dtype=np.int8)
        self.lease_birth_age = np.zeros(n, dtype=float)
        self.lease_last_review_age = np.zeros(n, dtype=float)
        self.lease_next_review_age = np.full(n, 1e9, dtype=float)
        self.lease_trust = np.zeros(n, dtype=float)
        self.lease_review_count = np.zeros(n, dtype=np.int16)
        self.lease_support_count = np.zeros(n, dtype=np.int16)
        self.lease_failure_count = np.zeros(n, dtype=np.int16)
        self.lease_dormant_count = np.zeros(n, dtype=np.int16)
        self.lease_context = np.zeros((n, TROPHIC_COUNT), dtype=float)
        self.lease_effect_mean = np.zeros((n, TROPHIC_COUNT), dtype=float)
        self.lease_effect_m2 = np.zeros((n, TROPHIC_COUNT), dtype=float)

        self.leases_created = 0
        self.reviews_started = 0
        self.reviews_completed = 0
        self.leases_renewed = 0
        self.leases_revoked = 0
        self.reviews_deferred = 0
        self.last_review_effect = np.zeros(TROPHIC_COUNT, dtype=float)
        self.last_review_trust = 0.0
        self.last_review_status = 'none'

    # ------------------------------------------------------------------
    # Effective phenotype
    # ------------------------------------------------------------------

    @property
    def treatment_on(self):
        if self.mode == LEASE_MODE_REVIEW:
            return bool(
                self.active
                and 0 <= self.epoch_index < TRIAL_EPOCH_COUNT
                and self.sequence[self.epoch_index] == 1
            )
        return bool(EscrowMorphology.treatment_on.fget(self))

    def _apply_delta_to_arrays(
        self, sensor, fin, shell, kind, slot, modality, delta
    ):
        if kind == MORPH_SENSOR:
            sensor = sensor.copy()
            sensor[slot, modality] = clamp(
                sensor[slot, modality] + delta, 0.0, 1.0
            )
        elif kind == MORPH_FIN:
            fin = fin.copy()
            fin[slot] = clamp(fin[slot] + delta, 0.0, 1.0)
        else:
            shell = shell.copy()
            shell[slot] = clamp(shell[slot] + delta, 0.0, 1.0)
        return sensor, fin, shell

    def effective_arrays(self):
        if self.mode != LEASE_MODE_REVIEW:
            return super().effective_arrays()

        sensor, fin, shell = self.sensor, self.fin, self.shell
        if not self.active or self.treatment_on or self.review_index < 0:
            return sensor, fin, shell

        index = int(self.review_index)
        # OFF means undo exactly this accepted change, leaving all others intact.
        return self._apply_delta_to_arrays(
            sensor,
            fin,
            shell,
            int(self.lease_kind[index]),
            int(self.lease_slot[index]),
            int(self.lease_modality[index]),
            -float(self.lease_delta[index]),
        )

    def construction_and_maintenance_cost(self):
        sensor, fin, shell = self.effective_arrays()
        sensor_cost = 0.00010 * float(np.sum(sensor))
        fin_cost = 0.00016 * float(np.sum(fin))
        shell_cost = 0.00013 * float(np.sum(shell))
        prototype = (
            0.00030
            if self.mode == LEASE_MODE_PROPOSAL and self.treatment_on
            else 0.0
        )
        review_cost = 0.00006 if self.mode == LEASE_MODE_REVIEW else 0.0
        return sensor_cost + fin_cost + shell_cost + prototype + review_cost

    # ------------------------------------------------------------------
    # Lease bookkeeping
    # ------------------------------------------------------------------

    def active_lease_indices(self):
        return np.flatnonzero(self.lease_active)

    def active_lease_count(self):
        return int(np.count_nonzero(self.lease_active))

    def _context_distance(self, index, debt):
        delta = (
            np.asarray(debt, dtype=float) - self.lease_context[index]
        ) / np.array([0.22, 0.22, 0.18, 0.24], dtype=float)
        return float(np.sqrt(np.mean(delta * delta)))

    def effective_lease_trust(self, index, age, debt):
        trust = float(self.lease_trust[index])
        if self.lease_evidence_decay:
            elapsed = max(
                0.0, float(age) - float(self.lease_last_review_age[index])
            )
            trust *= math.exp(
                -math.log(2.0) * elapsed / max(self.lease_half_life, 1e-6)
            )
        if self.context_sensitive_leases:
            trust *= math.exp(-0.30 * self._context_distance(index, debt))
        return clamp(trust, 0.0, 1.0)

    def _due_indices(self, age, debt):
        due = []
        for index in self.active_lease_indices():
            index = int(index)
            effective = self.effective_lease_trust(index, age, debt)
            context_shift = self._context_distance(index, debt)
            if (
                float(age) >= float(self.lease_next_review_age[index])
                or effective < 0.24
                or (
                    self.context_sensitive_leases
                    and context_shift > 1.35
                    and float(age) - float(self.lease_last_review_age[index]) > 8.0
                )
            ):
                due.append(index)
        return due

    def review_due(self, age, debt):
        return bool(
            self.enabled
            and self.lease_review_enabled
            and not self.active
            and self._due_indices(age, debt)
        )

    def _choose_due_lease(self, age, debt):
        due = self._due_indices(age, debt)
        if not due:
            return -1
        scores = []
        for index in due:
            overdue = max(
                0.0,
                float(age) - float(self.lease_next_review_age[index]),
            )
            context = self._context_distance(index, debt)
            trust = self.effective_lease_trust(index, age, debt)
            scores.append(
                0.04 * overdue + 0.70 * context + 1.20 * (1.0 - trust)
                + 0.02 * self.rng.random()
            )
        return int(due[int(np.argmax(scores))])

    def _allocate_lease_slot(self):
        free = np.flatnonzero(~self.lease_active)
        if free.size:
            return int(free[0])
        # This should be rare; revoke the least trusted old lease rather than
        # silently losing accountability for a new change.
        debt = np.mean(self.lease_context, axis=0)
        active = self.active_lease_indices()
        trust = np.array([
            self.effective_lease_trust(int(i), self.current_age, debt)
            for i in active
        ])
        index = int(active[int(np.argmin(trust))])
        self._revoke_lease(index, reason='registry pressure')
        return index

    def _initial_trust(self, immediate=False):
        if immediate:
            return 0.22
        positive = self.last_z[self.last_votes > 0]
        score = float(np.max(positive)) if positive.size else 0.0
        return clamp(0.50 + 0.14 * math.tanh(score), 0.38, 0.82)

    def _register_current_change(self, age, context, immediate=False):
        if abs(float(self.delta)) < 1e-9:
            return -1
        index = self._allocate_lease_slot()
        self.lease_active[index] = True
        self.lease_kind[index] = int(self.kind)
        self.lease_slot[index] = int(self.slot)
        self.lease_modality[index] = int(self.modality)
        self.lease_delta[index] = float(self.delta)
        self.lease_target_currency[index] = int(self.target_currency)
        self.lease_birth_age[index] = float(age)
        self.lease_last_review_age[index] = float(age)
        trust = self._initial_trust(immediate=immediate)
        self.lease_trust[index] = trust
        self.lease_next_review_age[index] = float(age) + 20.0 + 18.0 * trust
        self.lease_review_count[index] = 0
        self.lease_support_count[index] = 0
        self.lease_failure_count[index] = 0
        self.lease_dormant_count[index] = 0
        self.lease_context[index] = np.asarray(context, dtype=float)
        self.lease_effect_mean[index] = self.last_effect
        self.lease_effect_m2[index] = 0.0
        self.leases_created += 1
        return index

    def _apply_permanent_delta(self, kind, slot, modality, delta):
        if kind == MORPH_SENSOR:
            self.sensor[slot, modality] = clamp(
                self.sensor[slot, modality] + delta, 0.0, 1.0
            )
        elif kind == MORPH_FIN:
            self.fin[slot] = clamp(self.fin[slot] + delta, 0.0, 1.0)
        else:
            self.shell[slot] = clamp(self.shell[slot] + delta, 0.0, 1.0)

    def _revoke_lease(self, index, reason='revoked'):
        if index < 0 or not self.lease_active[index]:
            return
        self._apply_permanent_delta(
            int(self.lease_kind[index]),
            int(self.lease_slot[index]),
            int(self.lease_modality[index]),
            -float(self.lease_delta[index]),
        )
        refund = 0.25 * (0.030 + 0.080 * abs(float(self.lease_delta[index])))
        self.add_material(refund)
        self.lease_active[index] = False
        self.lease_next_review_age[index] = 1e9
        self.leases_revoked += 1
        self.last_review_status = str(reason)

    # ------------------------------------------------------------------
    # Scheduling proposals and withdrawal reviews
    # ------------------------------------------------------------------

    def _start_review(self, index, age, debt):
        self.mode = LEASE_MODE_REVIEW
        self.review_index = int(index)
        self.kind = int(self.lease_kind[index])
        self.slot = int(self.lease_slot[index])
        self.modality = int(self.lease_modality[index])
        self.delta = float(self.lease_delta[index])
        self.target_currency = int(self.lease_target_currency[index])
        self.reserve = 0.0

        template_a = np.array([1, 0, 0, 1, 0, 1, 1, 0], dtype=np.int8)
        template_b = 1 - template_a
        self.sequence = template_a if self.rng.random() < 0.5 else template_b
        self.epoch_index = 0
        self.epoch_elapsed = 0.0
        self.epoch_duration = 2.20
        self.epoch_improvement[:] = 0.0
        self.epoch_rates[:] = 0.0
        self.epoch_complete[:] = False
        self.trial_need_sum[:] = 0.0
        self.trial_elapsed = 0.0
        self.active = True
        self.current_age = float(age)
        self.reviews_started += 1
        self.last_status = 'lease withdrawal trial'
        self.last_proposal = self.description()
        return True

    def maybe_start(
        self, age, debt, brain, auditor, audit_busy=False, force=False
    ):
        self.current_age = float(age)
        if not self.enabled or self.active or audit_busy:
            return False

        if self.lease_review_enabled:
            index = self._choose_due_lease(age, debt)
            if index >= 0 and (force or float(np.max(debt)) <= 0.84):
                return self._start_review(index, age, debt)

        self.mode = LEASE_MODE_PROPOSAL
        self.review_index = -1
        self.epoch_duration = 3.0
        accepted_before = self.accepted
        started = super().maybe_start(
            age, debt, brain, auditor, audit_busy=audit_busy, force=force
        )
        if self.accepted > accepted_before:
            # Immediate-commit ablation: no trial evidence exists, so the lease
            # starts weak and will be reviewed soon.
            self._register_current_change(age, debt, immediate=True)
        return started

    # ------------------------------------------------------------------
    # Trial completion
    # ------------------------------------------------------------------

    def observe(self, debt_before, debt_after, dt, age=None):
        if age is not None:
            self.current_age = float(age)
        return super().observe(debt_before, debt_after, dt)

    def _evaluate_trial(self):
        treatment = self.epoch_rates[(self.sequence == 1) & self.epoch_complete]
        control = self.epoch_rates[(self.sequence == 0) & self.epoch_complete]
        treatment_median, treatment_mad = self._median_and_mad(treatment)
        control_median, control_mad = self._median_and_mad(control)
        effect = treatment_median - control_median
        standard_error = (
            treatment_mad / math.sqrt(max(1, treatment.shape[0]))
            + control_mad / math.sqrt(max(1, control.shape[0]))
            + 0.00020
        )
        z = effect / standard_error
        need = self.trial_need_sum / max(self.trial_elapsed, 1e-9)
        yes = (need > 0.10) & (effect > 0.00012) & (z > 0.20)
        veto = (effect < -0.00035) & (z < -0.35)
        votes = np.zeros(TROPHIC_COUNT, dtype=np.int8)
        votes[yes] = 1
        votes[veto] = -1
        if self.pareto_veto_enabled:
            accepted = bool(np.any(yes) and not np.any(veto))
        else:
            weights = 0.05 + need
            scalar_effect = float(np.sum(weights * effect) / np.sum(weights))
            scalar_z = float(np.sum(weights * z) / np.sum(weights))
            accepted = scalar_effect > 0.00008 and scalar_z > 0.10
        return effect, z, need, votes, accepted

    def _finish_trial(self):
        if self.mode == LEASE_MODE_PROPOSAL:
            context = self.trial_need_sum / max(self.trial_elapsed, 1e-9)
            accepted_before = self.accepted
            super()._finish_trial()
            if self.accepted > accepted_before:
                self._register_current_change(
                    self.current_age, context, immediate=False
                )
            return
        self._finish_review()

    def _finish_review(self):
        if not bool(np.all(self.epoch_complete)):
            raise RuntimeError('lease review finished with incomplete epochs')
        index = int(self.review_index)
        effect, z, need, votes, supported = self._evaluate_trial()
        self.last_effect = effect.copy()
        self.last_z = z.copy()
        self.last_votes = votes.copy()
        self.last_review_effect = effect.copy()
        self.reviews_completed += 1

        count = int(self.lease_review_count[index]) + 1
        old_mean = self.lease_effect_mean[index].copy()
        delta = effect - old_mean
        new_mean = old_mean + delta / (count + 1.0)
        self.lease_effect_mean[index] = new_mean
        self.lease_effect_m2[index] += delta * (effect - new_mean)
        self.lease_review_count[index] = count

        target = int(self.lease_target_currency[index])
        target_need = float(need[target])
        target_effect = float(effect[target])
        target_z = float(z[target])
        positive = z[votes > 0]
        best_z = float(np.max(positive)) if positive.size else target_z
        evidence = clamp(
            0.48 + 0.18 * math.tanh(best_z) + 90.0 * max(target_effect, 0.0),
            0.0,
            1.0,
        )

        strong_contradiction = bool(
            np.any(votes < 0)
            or (target_effect < -0.00025 and target_z < -0.20)
        )
        low_need = target_need < 0.075 and float(np.max(need)) < 0.13

        if supported:
            self.lease_support_count[index] += 1
            self.lease_failure_count[index] = max(
                0, int(self.lease_failure_count[index]) - 1
            )
            self.lease_dormant_count[index] = 0
            self.lease_trust[index] = clamp(
                0.62 * float(self.lease_trust[index])
                + 0.38 * max(0.56, evidence),
                0.0,
                1.0,
            )
            self.lease_context[index] = (
                0.72 * self.lease_context[index] + 0.28 * need
            )
            self.lease_last_review_age[index] = self.current_age
            self.lease_next_review_age[index] = (
                self.current_age
                + 27.0
                + 25.0 * float(self.lease_trust[index])
            )
            self.leases_renewed += 1
            self.last_review_status = 'lease renewed'
            self.last_status = 'lease renewed'
        elif low_need and not strong_contradiction:
            # Absence of current need is not evidence of harm. The lease becomes
            # dormant and is challenged again sooner, while trust slowly fades.
            self.lease_dormant_count[index] += 1
            self.lease_trust[index] *= 0.92
            self.lease_last_review_age[index] = self.current_age
            self.lease_next_review_age[index] = self.current_age + 14.0
            self.reviews_deferred += 1
            self.last_review_status = 'review deferred: low need'
            self.last_status = 'lease dormant'
            if (
                int(self.lease_dormant_count[index]) >= 3
                and float(self.lease_trust[index]) < 0.22
            ):
                self._revoke_lease(index, reason='revoked: prolonged dormancy')
                self.last_status = self.last_review_status
        else:
            self.lease_failure_count[index] += 1
            factor = 0.42 if strong_contradiction else 0.68
            self.lease_trust[index] *= factor
            self.lease_last_review_age[index] = self.current_age
            self.lease_next_review_age[index] = (
                self.current_age + 9.0 + 8.0 * float(self.lease_trust[index])
            )
            if (
                strong_contradiction
                or int(self.lease_failure_count[index]) >= 2
                or float(self.lease_trust[index]) < 0.16
            ):
                self._revoke_lease(index, reason='lease revoked')
                self.last_status = self.last_review_status
            else:
                self.last_review_status = 'lease probation'
                self.last_status = 'lease probation'

        self.last_review_trust = (
            float(self.lease_trust[index])
            if self.lease_active[index]
            else 0.0
        )
        self.active = False
        self.review_index = -1
        self.mode = LEASE_MODE_PROPOSAL
        self.epoch_duration = 3.0
        self.cooldown = 8.0

    def cancel_active(self, reason='cancelled'):
        if not self.active:
            return
        if self.mode == LEASE_MODE_PROPOSAL and self.reserve > 0.0:
            self.add_material(0.25 * self.reserve)
            self.reserve = 0.0
        self.active = False
        self.review_index = -1
        self.mode = LEASE_MODE_PROPOSAL
        self.epoch_duration = 3.0
        self.cooldown = 4.0
        self.last_status = str(reason)

    def description(self):
        text = super().description()
        if self.mode == LEASE_MODE_REVIEW:
            return 'review ' + text
        return text

    def status_text(self):
        if not self.enabled:
            return 'fixed body'
        if not self.active:
            return self.last_status
        if self.mode == LEASE_MODE_REVIEW:
            arm = 'PRESENT' if self.treatment_on else 'WITHDRAWN'
            return '{} {}/{} {}'.format(
                arm,
                self.epoch_index + 1,
                TRIAL_EPOCH_COUNT,
                self.description(),
            )
        return super().status_text()

    def lease_summary(self, age, debt):
        active = self.active_lease_indices()
        if active.size:
            trust = np.array([
                self.effective_lease_trust(int(i), age, debt)
                for i in active
            ])
            overdue = sum(
                1 for i in active
                if float(age) >= float(self.lease_next_review_age[int(i)])
            )
            mean_trust = float(np.mean(trust))
        else:
            overdue = 0
            mean_trust = 0.0
        return {
            'active': int(active.size),
            'mean_trust': mean_trust,
            'overdue': int(overdue),
            'created': int(self.leases_created),
            'reviews': int(self.reviews_completed),
            'renewed': int(self.leases_renewed),
            'revoked': int(self.leases_revoked),
            'deferred': int(self.reviews_deferred),
        }

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def state_dict(self):
        state = super().state_dict()
        state.update({
            'lease_review_enabled': bool_array(self.lease_review_enabled),
            'lease_context_sensitive': bool_array(
                self.context_sensitive_leases
            ),
            'lease_evidence_decay': bool_array(self.lease_evidence_decay),
            'lease_half_life': scalar_array(self.lease_half_life),
            'lease_mode': scalar_array(self.mode, np.int64),
            'lease_current_age': scalar_array(self.current_age),
            'lease_review_index': scalar_array(self.review_index, np.int64),
            'lease_active': self.lease_active.astype(np.uint8),
            'lease_kind': self.lease_kind,
            'lease_slot': self.lease_slot,
            'lease_modality': self.lease_modality,
            'lease_delta': self.lease_delta,
            'lease_target_currency': self.lease_target_currency,
            'lease_birth_age': self.lease_birth_age,
            'lease_last_review_age': self.lease_last_review_age,
            'lease_next_review_age': self.lease_next_review_age,
            'lease_trust': self.lease_trust,
            'lease_review_count': self.lease_review_count,
            'lease_support_count': self.lease_support_count,
            'lease_failure_count': self.lease_failure_count,
            'lease_dormant_count': self.lease_dormant_count,
            'lease_context': self.lease_context,
            'lease_effect_mean': self.lease_effect_mean,
            'lease_effect_m2': self.lease_effect_m2,
            'lease_created_count': scalar_array(self.leases_created, np.int64),
            'lease_reviews_started': scalar_array(
                self.reviews_started, np.int64
            ),
            'lease_reviews_completed': scalar_array(
                self.reviews_completed, np.int64
            ),
            'lease_renewed_count': scalar_array(
                self.leases_renewed, np.int64
            ),
            'lease_revoked_count': scalar_array(
                self.leases_revoked, np.int64
            ),
            'lease_reviews_deferred': scalar_array(
                self.reviews_deferred, np.int64
            ),
            'lease_last_review_effect': self.last_review_effect,
            'lease_last_review_trust': scalar_array(self.last_review_trust),
            'lease_last_review_status': np.array(self.last_review_status),
        })
        return state

    def load_state(self, data):
        super().load_state(data)
        self.lease_review_enabled = bool(int(data['lease_review_enabled']))
        self.context_sensitive_leases = bool(
            int(data['lease_context_sensitive'])
        )
        self.lease_evidence_decay = bool(int(data['lease_evidence_decay']))
        self.lease_half_life = float(data['lease_half_life'])
        self.mode = int(data['lease_mode'])
        self.current_age = float(data['lease_current_age'])
        self.review_index = int(data['lease_review_index'])
        self.lease_active = np.array(data['lease_active'], dtype=bool)
        self.lease_kind = np.array(data['lease_kind'], dtype=np.int8)
        self.lease_slot = np.array(data['lease_slot'], dtype=np.int8)
        self.lease_modality = np.array(data['lease_modality'], dtype=np.int8)
        self.lease_delta = np.array(data['lease_delta'], dtype=float)
        self.lease_target_currency = np.array(
            data['lease_target_currency'], dtype=np.int8
        )
        self.lease_birth_age = np.array(data['lease_birth_age'], dtype=float)
        self.lease_last_review_age = np.array(
            data['lease_last_review_age'], dtype=float
        )
        self.lease_next_review_age = np.array(
            data['lease_next_review_age'], dtype=float
        )
        self.lease_trust = np.array(data['lease_trust'], dtype=float)
        self.lease_review_count = np.array(
            data['lease_review_count'], dtype=np.int16
        )
        self.lease_support_count = np.array(
            data['lease_support_count'], dtype=np.int16
        )
        self.lease_failure_count = np.array(
            data['lease_failure_count'], dtype=np.int16
        )
        self.lease_dormant_count = np.array(
            data['lease_dormant_count'], dtype=np.int16
        )
        self.lease_context = np.array(data['lease_context'], dtype=float)
        self.lease_effect_mean = np.array(
            data['lease_effect_mean'], dtype=float
        )
        self.lease_effect_m2 = np.array(data['lease_effect_m2'], dtype=float)
        self.leases_created = int(data['lease_created_count'])
        self.reviews_started = int(data['lease_reviews_started'])
        self.reviews_completed = int(data['lease_reviews_completed'])
        self.leases_renewed = int(data['lease_renewed_count'])
        self.leases_revoked = int(data['lease_revoked_count'])
        self.reviews_deferred = int(data['lease_reviews_deferred'])
        self.last_review_effect = np.array(
            data['lease_last_review_effect'], dtype=float
        )
        self.last_review_trust = float(data['lease_last_review_trust'])
        self.last_review_status = str(
            np.asarray(data['lease_last_review_status']).item()
        )


# =============================================================================
# Embodied SOMA-2.1 core
# =============================================================================


class SomaTwoOneCore(SomaTwoCore):
    def __init__(
        self,
        seed=None,
        learning_enabled=True,
        scalarize_trophic=False,
        diffusion_enabled=True,
        turnover_enabled=True,
        audit_enabled=True,
        morphogenesis_enabled=True,
        require_audit=True,
        escrow_enabled=True,
        pareto_veto_enabled=True,
        symmetric_audit=True,
        exclude_contact_events=True,
        audit_evidence_decay=True,
        lease_review_enabled=True,
        context_sensitive_leases=True,
        lease_evidence_decay=True,
        freeze_learning_during_trials=True,
    ):
        super().__init__(
            seed=seed,
            learning_enabled=learning_enabled,
            scalarize_trophic=scalarize_trophic,
            diffusion_enabled=diffusion_enabled,
            turnover_enabled=turnover_enabled,
            audit_enabled=audit_enabled,
            morphogenesis_enabled=morphogenesis_enabled,
            require_audit=require_audit,
            escrow_enabled=escrow_enabled,
            pareto_veto_enabled=pareto_veto_enabled,
        )
        self.auditor = CounterbalancedCausalAuditor(
            seed=self.seed,
            enabled=audit_enabled,
            group_size=5,
            symmetric_order=symmetric_audit,
            exclude_hard_events=exclude_contact_events,
            evidence_decay=audit_evidence_decay,
        )
        self.morphology = CausalLeaseMorphology(
            seed=self.seed,
            enabled=morphogenesis_enabled,
            require_audit=require_audit,
            escrow_enabled=escrow_enabled,
            pareto_veto_enabled=pareto_veto_enabled,
            lease_review_enabled=lease_review_enabled,
            context_sensitive_leases=context_sensitive_leases,
            lease_evidence_decay=lease_evidence_decay,
        )
        self.freeze_learning_during_trials = bool(
            freeze_learning_during_trials
        )
        self.trial_frozen_time = 0.0
        self.last_body_debt = self.body_debt()

    def _audit_context(self, debt):
        ambient, _ = self.temperature_field()
        shelter = self.shelter_level()
        speed = float(np.linalg.norm(self.vel)) / max(MAX_SPEED, 1e-9)
        return np.array([
            float(debt[0]),
            float(debt[1]),
            float(debt[2]),
            float(debt[3]),
            clamp(speed, 0.0, 1.5),
            float(ambient),
            float(shelter),
            1.0 - float(np.mean(self.brain.vitality)),
            clamp(float(np.mean(self.brain.prediction_error)), 0.0, 1.0),
        ], dtype=float)

    def _event_mask(
        self,
        eaten_before,
        poisoned_before,
        shelter_before,
        ambient_before,
    ):
        mask = 0
        if self.eaten > eaten_before:
            mask |= EVENT_NUTRIENT
        if self.poisoned > poisoned_before:
            mask |= EVENT_TOXIN
        shelter_after = self.shelter_level()
        if (
            (shelter_before < 0.42 <= shelter_after)
            or (shelter_after < 0.42 <= shelter_before)
        ):
            mask |= EVENT_SHELTER_EDGE
        ambient_after, _ = self.temperature_field()
        if abs(float(ambient_after) - float(ambient_before)) > 0.055:
            mask |= EVENT_THERMAL_SHIFT
        return mask

    def step(self, dt=1.0 / 30.0):
        dt = clamp(float(dt), 1.0 / 240.0, 0.10)
        if not self.alive:
            return

        debt_before = self.body_debt()

        # Overdue morphology claims are reviewed before creating new claims.
        if not self.auditor.busy and not self.morphology.busy:
            started = False
            if self.morphology.review_due(self.age, debt_before):
                started = self.morphology.maybe_start(
                    self.age,
                    debt_before,
                    self.brain,
                    self.auditor,
                    audit_busy=False,
                )

            priority_audit = (
                self.auditor.enabled
                and (
                    self.auditor.completed < 2
                    or (
                        self.auditor.cooldown <= 0.0
                        and self.morphology.cooldown > 3.0
                    )
                )
            )
            if not started and priority_audit:
                started = self.auditor.maybe_start(
                    self.age,
                    debt_before,
                    self.brain,
                    morphology_busy=False,
                )
            if not started:
                started = self.morphology.maybe_start(
                    self.age,
                    debt_before,
                    self.brain,
                    self.auditor,
                    audit_busy=False,
                )
            if not started and self.auditor.enabled:
                self.auditor.maybe_start(
                    self.age,
                    debt_before,
                    self.brain,
                    morphology_busy=False,
                )

        self.brain.set_audit_gate(
            self.auditor.gate()
            if self.auditor.enabled
            else np.ones((CELL_COUNT, TROPHIC_COUNT), dtype=float)
        )
        self.brain.set_efferent_knockout(
            self.auditor.current_knockout_mask()
        )

        sensor = self.make_sensor()
        action = self.brain.act(sensor, debt_before, dt)
        eaten_before = self.eaten
        poisoned_before = self.poisoned
        shelter_before = self.shelter_level()
        ambient_before, _ = self.temperature_field()

        self._apply_body_and_world(action, dt)
        if self.eaten > eaten_before:
            self.morphology.add_material(
                0.070 * (self.eaten - eaten_before)
            )

        next_sensor = self.make_sensor()
        debt_after = self.body_debt()
        event_mask = self._event_mask(
            eaten_before,
            poisoned_before,
            shelter_before,
            ambient_before,
        )
        context = self._audit_context(debt_after)

        was_learning = self.brain.learning_enabled
        causal_snapshot = None
        freeze = self.auditor.busy or (
            self.freeze_learning_during_trials and self.morphology.busy
        )
        if freeze:
            self.brain.learning_enabled = False
            self.trial_frozen_time += dt
        if self.auditor.busy:
            causal_snapshot = self.brain.causal_estimate.copy()

        self.brain.learn(next_sensor, debt_after, dt)
        if causal_snapshot is not None:
            self.brain.causal_estimate = causal_snapshot
        self.brain.learning_enabled = was_learning
        self.brain.set_efferent_knockout(None)

        self.auditor.observe(
            debt_after,
            dt,
            self.age + dt,
            event_mask=event_mask,
            context=context,
        )
        self.morphology.observe(
            debt_before,
            debt_after,
            dt,
            age=self.age + dt,
        )

        self.last_action = np.array(action, dtype=float)
        self.age += dt
        self.last_body_debt = debt_after
        self.viability_integral += dt * (1.0 - float(np.mean(debt_after)))

        if self.energy <= 0.0 or self.integrity <= 0.0:
            self.energy = max(0.0, self.energy)
            self.integrity = max(0.0, self.integrity)
            self.vel[:] = 0.0
            self.alive = False

    def regenerate_body(self, normalized_position=None):
        # A causal trial cannot continue across bodily death as though no reset
        # happened. Cancel it explicitly before regenerating the body.
        self.auditor.cancel_active('cancelled by regeneration')
        self.morphology.cancel_active('cancelled by regeneration')
        super().regenerate_body(normalized_position)

    def state_dict(self):
        state = super().state_dict()
        state['save_version'] = scalar_array(SAVE_VERSION, np.int64)
        state.update({
            'soma21_freeze_learning_during_trials': bool_array(
                self.freeze_learning_during_trials
            ),
            'soma21_trial_frozen_time': scalar_array(self.trial_frozen_time),
        })
        return state

    def load_state(self, data):
        if int(data['save_version']) != SAVE_VERSION:
            raise ValueError('unsupported SOMA-2.1 save version')
        keys = list(data.files) if hasattr(data, 'files') else list(data.keys())
        base = {key: data[key] for key in keys}
        base['save_version'] = scalar_array(3, np.int64)
        super().load_state(base)
        self.freeze_learning_during_trials = bool(
            int(data['soma21_freeze_learning_during_trials'])
        )
        self.trial_frozen_time = float(data['soma21_trial_frozen_time'])
        self.brain.set_audit_gate(
            self.auditor.gate()
            if self.auditor.enabled
            else np.ones((CELL_COUNT, TROPHIC_COUNT), dtype=float)
        )
        self.brain.set_efferent_knockout(None)


# =============================================================================
# Pythonista scene (reuse SOMA-2 drawing, replace core and diagnostics)
# =============================================================================


if soma2.IN_PYTHONISTA:

    class SomaTwoOneScene(soma2.SomaTwoScene):
        def setup(self):
            # Prevent the inherited setup from loading a SOMA-2.1 save into its
            # temporary SOMA-2 core.
            self._building_base_scene = True
            super().setup()
            self._building_base_scene = False
            self.core = SomaTwoOneCore()
            self.help_label.text = (
                'tap: relocate nutrient   causal leases autosave: 20 s'
            )
            self._load_life_if_possible()
            self._sync_nodes(force_tiles=True)

        def _save_life(self):
            if getattr(self, '_building_base_scene', False):
                return
            try:
                np.savez(SAVE_FILE, **self.core.state_dict())
            except Exception as exc:
                print('SOMA-2.1 save failed:', exc)

        def _load_life_if_possible(self):
            if getattr(self, '_building_base_scene', False):
                return
            if not os.path.exists(SAVE_FILE):
                return
            try:
                with np.load(SAVE_FILE, allow_pickle=False) as data:
                    self.core.load_state(data)
            except Exception as exc:
                print('SOMA-2.1 load ignored:', exc)

        def _sync_nodes(self, force_tiles=False):
            super()._sync_nodes(force_tiles=force_tiles)
            if getattr(self, '_building_base_scene', False):
                return
            diagnostic = self.core.brain.diagnostics()
            audit = self.core.auditor
            morph = self.core.morphology
            lease = morph.lease_summary(
                self.core.age, self.core.body_debt()
            )
            organ_means = morph.organ_means()
            vote_text = ''.join(
                '+' if vote > 0 else '-' if vote < 0 else '0'
                for vote in morph.last_votes
            )
            self.info_label.text = (
                'SOMA-2.1 age {:6.1f}s E {:.3f} T {:.3f} I {:.3f} F {:.3f} food {} toxin {} material {:.2f}\n'
                'AUDIT {:22s} n {} pass/fail {}/{} q {:.2f} dirty/retry {}/{} verified {:.4f}\n'
                'MORPH {:31s} P/A/R {}/{}/{} votes {} S/F/H {:.2f}/{:.2f}/{:.2f}\n'
                'LEASE active {} trust {:.2f} overdue {} reviews {} renew/revoke {}/{} frozen {:.1f}s\n'
                'tissue V {:.3f} pred {:.3f} causal {:.4f} born {} rewired {}'
            ).format(
                self.core.age,
                self.core.energy,
                self.core.temperature,
                self.core.integrity,
                self.core.fatigue,
                self.core.eaten,
                self.core.poisoned,
                morph.material,
                audit.status_text(),
                audit.completed,
                audit.passed,
                audit.failed,
                audit.last_quality,
                audit.contaminated_segments,
                audit.retried_segments,
                diagnostic['verified_strength'],
                morph.status_text(),
                morph.proposals,
                morph.accepted,
                morph.rejected,
                vote_text,
                organ_means[0],
                organ_means[1],
                organ_means[2],
                lease['active'],
                lease['mean_trust'],
                lease['overdue'],
                lease['reviews'],
                lease['renewed'],
                lease['revoked'],
                self.core.trial_frozen_time,
                diagnostic['mean_vitality'],
                diagnostic['prediction_error'],
                diagnostic['causal_strength'],
                diagnostic['births'],
                diagnostic['rewires'],
            )


# =============================================================================
# Headless helper
# =============================================================================


def run_headless_trial(
    seed=0,
    seconds=300.0,
    learning_enabled=True,
    scalarize_trophic=False,
    diffusion_enabled=True,
    turnover_enabled=True,
    audit_enabled=True,
    morphogenesis_enabled=True,
    require_audit=True,
    escrow_enabled=True,
    pareto_veto_enabled=True,
    symmetric_audit=True,
    exclude_contact_events=True,
    audit_evidence_decay=True,
    lease_review_enabled=True,
    context_sensitive_leases=True,
    lease_evidence_decay=True,
    freeze_learning_during_trials=True,
    dt=1.0 / 30.0,
):
    core = SomaTwoOneCore(
        seed=seed,
        learning_enabled=learning_enabled,
        scalarize_trophic=scalarize_trophic,
        diffusion_enabled=diffusion_enabled,
        turnover_enabled=turnover_enabled,
        audit_enabled=audit_enabled,
        morphogenesis_enabled=morphogenesis_enabled,
        require_audit=require_audit,
        escrow_enabled=escrow_enabled,
        pareto_veto_enabled=pareto_veto_enabled,
        symmetric_audit=symmetric_audit,
        exclude_contact_events=exclude_contact_events,
        audit_evidence_decay=audit_evidence_decay,
        lease_review_enabled=lease_review_enabled,
        context_sensitive_leases=context_sensitive_leases,
        lease_evidence_decay=lease_evidence_decay,
        freeze_learning_during_trials=freeze_learning_during_trials,
    )
    maximum_steps = int(max(0.0, float(seconds)) / float(dt))
    for _ in range(maximum_steps):
        core.step(dt)
        if not core.alive:
            break

    diagnostic = core.brain.diagnostics()
    lived = max(core.age, 1e-9)
    sensor_mean, fin_mean, shell_mean = core.morphology.organ_means()
    audit_rate = (
        core.auditor.passed / core.auditor.completed
        if core.auditor.completed else 0.0
    )
    lease = core.morphology.lease_summary(core.age, core.body_debt())
    review_support_rate = (
        core.morphology.leases_renewed / core.morphology.reviews_completed
        if core.morphology.reviews_completed else 0.0
    )
    return {
        'seed': int(seed),
        'age': float(core.age),
        'survived': bool(core.alive),
        'food': int(core.eaten),
        'toxin': int(core.poisoned),
        'energy': float(core.energy),
        'temperature': float(core.temperature),
        'integrity': float(core.integrity),
        'fatigue': float(core.fatigue),
        'mean_health': float(core.viability_integral / lived),
        'distance': float(core.distance_travelled),
        'tissue_vitality': diagnostic['mean_vitality'],
        'prediction_error': diagnostic['prediction_error'],
        'verified_strength': diagnostic['verified_strength'],
        'audits': int(core.auditor.completed),
        'audit_passes': int(core.auditor.passed),
        'audit_failures': int(core.auditor.failed),
        'audit_pass_rate': float(audit_rate),
        'audit_last_effect': float(core.auditor.last_target_effect),
        'audit_mean_quality': float(core.auditor.mean_quality()),
        'audit_last_context_mismatch': float(
            core.auditor.last_context_mismatch
        ),
        'audit_contaminated_segments': int(
            core.auditor.contaminated_segments
        ),
        'audit_retried_segments': int(core.auditor.retried_segments),
        'audit_forced_dirty_segments': int(
            core.auditor.forced_contaminated_segments
        ),
        'morph_proposals': int(core.morphology.proposals),
        'morph_accepted': int(core.morphology.accepted),
        'morph_rejected': int(core.morphology.rejected),
        'morph_complexity': float(core.morphology.complexity()),
        'sensor_mean': sensor_mean,
        'fin_mean': fin_mean,
        'shell_mean': shell_mean,
        'material': float(core.morphology.material),
        'leases_created': int(lease['created']),
        'leases_active': int(lease['active']),
        'lease_mean_trust': float(lease['mean_trust']),
        'lease_overdue': int(lease['overdue']),
        'lease_reviews': int(lease['reviews']),
        'lease_renewed': int(lease['renewed']),
        'lease_revoked': int(lease['revoked']),
        'lease_deferred': int(lease['deferred']),
        'lease_review_support_rate': float(review_support_rate),
        'trial_frozen_time': float(core.trial_frozen_time),
        'births': diagnostic['births'],
        'rewires': diagnostic['rewires'],
    }


def _print_smoke_test():
    result = run_headless_trial(seed=7, seconds=60.0)
    print('SOMA-2.1 headless smoke test')
    for key in sorted(result):
        print('{:>30}: {}'.format(key, result[key]))


if __name__ == '__main__':
    if soma2.IN_PYTHONISTA:
        soma2.run(
            SomaTwoOneScene(),
            orientation=LANDSCAPE,
            frame_interval=2,
            anti_alias=True,
            show_fps=False,
            multi_touch=True,
        )
    else:
        _print_smoke_test()
