# coding: utf-8
"""
SOMA-5R — Embodied Latent World / 内的世界・品質再構築版

Pythonista 3 / CPython + NumPy
Requires SOMA_1_pythonista.py ... SOMA_4_2_pythonista.py in the same folder.

The R suffix means "rebuild".  This module deliberately replaces the shallow
SOMA-5 alpha implementation while preserving the SOMA-4.2 embodied brain.

Main changes
------------
* Imagination is injected at the final action interface.  It never overwrites
  learned motor weights.
* A state-dependent, locally learned ensemble predicts latent transitions and
  four separate body-debt improvements.
* Planning performs short multi-step rollouts, pays an explicit energy/fatigue
  cost, and abstains when the model is too uncertain or the body is too weak.
* Experience replay is prioritized by learnable surprise, not raw randomness.
* Concepts bind context, action, outcome, and transitions between concepts.
* Dream/replay is limited to rest periods and also pays a metabolic cost.

This is a falsifiable artificial-life research prototype, not a claim of
consciousness or biological equivalence.
"""

from __future__ import division

import json
import math
import os
import time

import numpy as np

import SOMA_1_pythonista as soma1
import SOMA_2_pythonista as soma2
import SOMA_4_2_pythonista as soma42

from SOMA_1_pythonista import (
    CELL_COUNT,
    MAX_SPEED,
    TROPHIC_COUNT,
    clamp,
    encode_rng_state,
    restore_rng_state,
    wrapped_delta,
)
from SOMA_2_pythonista import bool_array, scalar_array


BUILD = 'SOMA-5R 1.0.0'
SAVE_VERSION = 10
SAVE_FILE = os.path.join(os.path.dirname(__file__), 'soma5r_life.npz')

LATENT_DIM = 20
ACTION_COUNT = 9
MODEL_MEMBERS = 3
MODEL_EXPERTS = 40
REPLAY_CAPACITY = 384
CONCEPT_COUNT = 16
CONCEPT_CONTEXT_DIM = LATENT_DIM + 2

ACTIONS = np.array([
    [0.0, 0.0],
    [1.0, 0.0],
    [-1.0, 0.0],
    [0.0, 1.0],
    [0.0, -1.0],
    [0.70710678, 0.70710678],
    [-0.70710678, 0.70710678],
    [0.70710678, -0.70710678],
    [-0.70710678, -0.70710678],
], dtype=float)


def _finite_array(value, shape=None, default=0.0):
    array = np.asarray(value, dtype=float)
    if shape is not None and array.shape != tuple(shape):
        raise ValueError('shape mismatch: {} != {}'.format(array.shape, shape))
    return np.nan_to_num(array, nan=default, posinf=default, neginf=default)


def _safe_norm(value):
    return float(np.linalg.norm(np.asarray(value, dtype=float)))


def _softmax(values, temperature=1.0):
    values = np.asarray(values, dtype=float)
    temperature = max(float(temperature), 1e-6)
    shifted = (values - float(np.max(values))) / temperature
    weights = np.exp(np.clip(shifted, -35.0, 0.0))
    total = float(np.sum(weights))
    if total <= 1e-12 or not np.isfinite(total):
        return np.full(values.shape, 1.0 / max(1, values.size), dtype=float)
    return weights / total


def _torus_delta(a, b):
    return (np.asarray(b, dtype=float) - np.asarray(a, dtype=float) + 0.5) % 1.0 - 0.5


def _clip_latent(latent):
    """Project a predicted latent state back into physically meaningful ranges."""
    latent = np.asarray(latent, dtype=float).copy()
    latent[0:2] %= 1.0                      # path-integrated position
    latent[2:4] = np.clip(latent[2:4], -1.5, 1.5)  # normalized velocity
    latent[4:8] = np.clip(latent[4:8], 0.0, 1.0)   # E, T, integrity, fatigue
    latent[8:20] = np.clip(latent[8:20], -1.0, 1.0)  # field summaries
    return latent


def latent_debt(latent):
    latent = np.asarray(latent, dtype=float)
    energy, temperature, integrity, fatigue = latent[4:8]
    return np.array([
        clamp((0.56 - float(energy)) / 0.56, 0.0, 1.0),
        clamp(abs(float(temperature) - 0.50) / 0.43, 0.0, 1.0),
        clamp(1.0 - float(integrity), 0.0, 1.0),
        clamp(float(fatigue), 0.0, 1.0),
    ], dtype=float)


class ImaginationActionCompiler(soma42.AdaptiveTwinFalsificationCompiler):
    """Adds a transient planner bias after all SOMA-4 interventions.

    The compiler object itself remains the SOMA-4.2 compiler.  Changing its
    pure-Python class adds this final action hook without copying or resetting
    any learned compiler state.
    """

    def alter_action(self, action):
        action = np.asarray(super().alter_action(action), dtype=float)
        bias = np.asarray(
            getattr(self, 'external_action_bias', np.zeros(2, dtype=float)),
            dtype=float,
        )
        scale = clamp(float(getattr(self, 'external_action_scale', 1.0)), 0.55, 1.15)
        return np.clip(action * scale + bias, -1.0, 1.0)


class LatentCodec(object):
    """Deterministic embodied state used by the internal model.

    The first eight values are path-integrated body state.  The final twelve
    are deterministic summaries of the three chemical fields and temperature.
    Subclasses for shared worlds override ``world_channels`` rather than
    changing the learned model's shape.
    """

    @staticmethod
    def _field_summary(core, positions, scale):
        positions = np.asarray(positions, dtype=float)
        if positions.size == 0:
            return np.zeros(3, dtype=float)
        deltas = positions - np.asarray(core.pos, dtype=float)[None, :]
        deltas = (deltas + 0.5) % 1.0 - 0.5
        distances = np.linalg.norm(deltas, axis=1)
        concentration = np.exp(-distances / max(float(scale), 1e-6))
        total = float(np.sum(concentration))
        if total <= 1e-12:
            vector = np.zeros(2, dtype=float)
        else:
            vector = np.sum(
                deltas / (distances[:, None] + 0.03) * concentration[:, None],
                axis=0,
            ) / total
        density = 1.0 - math.exp(-0.65 * total)
        return np.array([
            clamp(float(vector[0]), -1.0, 1.0),
            clamp(float(vector[1]), -1.0, 1.0),
            clamp(float(density) * 2.0 - 1.0, -1.0, 1.0),
        ], dtype=float)

    def world_channels(self, core):
        a = self._field_summary(core, core.nutrient_positions, 0.17)
        b = self._field_summary(core, core.toxin_positions, 0.15)
        c = self._field_summary(core, core.shelter_positions, 0.20)
        ambient, gradient = core.temperature_field()
        thermal = np.array([
            clamp(float(ambient) * 2.0 - 1.0, -1.0, 1.0),
            clamp(float(gradient[0]), -1.0, 1.0),
            clamp(float(gradient[1]), -1.0, 1.0),
        ], dtype=float)
        return np.concatenate([a, b, c, thermal])

    def encode(self, core):
        velocity = np.asarray(core.vel, dtype=float) / max(MAX_SPEED, 1e-9)
        latent = np.concatenate([
            np.asarray(core.pos, dtype=float),
            np.clip(velocity, -1.5, 1.5),
            np.array([
                core.energy,
                core.temperature,
                core.integrity,
                core.fatigue,
            ], dtype=float),
            self.world_channels(core),
        ])
        if latent.shape != (LATENT_DIM,):
            raise RuntimeError('latent codec produced {}'.format(latent.shape))
        return _clip_latent(latent)


class PrioritizedReplay(object):
    """Fixed-size, NumPy-only replay memory suitable for Pythonista."""

    def __init__(self, seed=1, capacity=REPLAY_CAPACITY):
        self.capacity = int(capacity)
        self.rng = np.random.default_rng(int(seed) + 5201)
        self.state = np.zeros((self.capacity, LATENT_DIM), dtype=float)
        self.action = np.zeros((self.capacity, 2), dtype=float)
        self.next_state = np.zeros((self.capacity, LATENT_DIM), dtype=float)
        self.improvement = np.zeros((self.capacity, TROPHIC_COUNT), dtype=float)
        self.priority = np.ones(self.capacity, dtype=float) * 1e-3
        self.concept = np.full(self.capacity, -1, dtype=np.int16)
        self.size = 0
        self.cursor = 0
        self.total_added = 0
        self.total_sampled = 0

    def add(self, state, action, next_state, improvement, priority, concept=-1):
        index = int(self.cursor)
        self.state[index] = _finite_array(state, (LATENT_DIM,))
        self.action[index] = np.clip(_finite_array(action, (2,)), -1.0, 1.0)
        self.next_state[index] = _finite_array(next_state, (LATENT_DIM,))
        self.improvement[index] = np.clip(
            _finite_array(improvement, (TROPHIC_COUNT,)), -1.0, 1.0
        )
        self.priority[index] = clamp(float(priority), 1e-4, 20.0)
        self.concept[index] = int(concept)
        self.cursor = (index + 1) % self.capacity
        self.size = min(self.capacity, self.size + 1)
        self.total_added += 1
        return index

    def update_priority(self, index, value):
        if 0 <= int(index) < self.size:
            self.priority[int(index)] = clamp(float(value), 1e-4, 20.0)

    def sample_indices(self, count=1):
        if self.size <= 0:
            return np.zeros(0, dtype=np.int64)
        n = min(int(count), self.size)
        weights = np.power(self.priority[:self.size] + 1e-3, 0.65)
        weights /= max(float(np.sum(weights)), 1e-12)
        replace = n > self.size
        indices = self.rng.choice(self.size, size=n, replace=replace, p=weights)
        self.total_sampled += int(n)
        return np.asarray(indices, dtype=np.int64)

    def transition(self, index):
        index = int(index)
        return (
            self.state[index].copy(),
            self.action[index].copy(),
            self.next_state[index].copy(),
            self.improvement[index].copy(),
            int(self.concept[index]),
        )

    def state_dict(self):
        return {
            'r5_replay_capacity': scalar_array(self.capacity, np.int64),
            'r5_replay_state': self.state,
            'r5_replay_action': self.action,
            'r5_replay_next': self.next_state,
            'r5_replay_improvement': self.improvement,
            'r5_replay_priority': self.priority,
            'r5_replay_concept': self.concept,
            'r5_replay_size': scalar_array(self.size, np.int64),
            'r5_replay_cursor': scalar_array(self.cursor, np.int64),
            'r5_replay_added': scalar_array(self.total_added, np.int64),
            'r5_replay_sampled': scalar_array(self.total_sampled, np.int64),
            'r5_replay_rng': encode_rng_state(self.rng),
        }

    def load_state(self, data):
        if int(data['r5_replay_capacity']) != self.capacity:
            raise ValueError('replay capacity mismatch')
        self.state = np.array(data['r5_replay_state'], dtype=float)
        self.action = np.array(data['r5_replay_action'], dtype=float)
        self.next_state = np.array(data['r5_replay_next'], dtype=float)
        self.improvement = np.array(data['r5_replay_improvement'], dtype=float)
        self.priority = np.array(data['r5_replay_priority'], dtype=float)
        self.concept = np.array(data['r5_replay_concept'], dtype=np.int16)
        self.size = int(data['r5_replay_size'])
        self.cursor = int(data['r5_replay_cursor'])
        self.total_added = int(data['r5_replay_added'])
        self.total_sampled = int(data['r5_replay_sampled'])
        restore_rng_state(self.rng, data['r5_replay_rng'])


class LocalLatentEnsemble(object):
    """Small ensemble of local transition experts.

    Each member stores sparse prototypes in state-action space.  It predicts
    the change of the latent state and the four body-debt improvements.  The
    spread between members is used as epistemic uncertainty, so random noise is
    less likely to be mistaken for reducible ignorance.
    """

    def __init__(self, seed=1, enabled=True):
        self.enabled = bool(enabled)
        self.rng = np.random.default_rng(int(seed) + 5301)
        input_dim = LATENT_DIM + 2
        output_dim = LATENT_DIM + TROPHIC_COUNT
        self.center = self.rng.normal(
            0.0, 0.12, (MODEL_MEMBERS, MODEL_EXPERTS, input_dim)
        )
        self.center[:, :, 0:2] = self.rng.random(
            (MODEL_MEMBERS, MODEL_EXPERTS, 2)
        )
        self.scale = np.ones_like(self.center) * 0.42
        self.mean = np.zeros(
            (MODEL_MEMBERS, MODEL_EXPERTS, output_dim), dtype=float
        )
        self.var = np.ones_like(self.mean) * 0.06
        self.count = np.zeros((MODEL_MEMBERS, MODEL_EXPERTS), dtype=float)
        self.utility = np.zeros((MODEL_MEMBERS, MODEL_EXPERTS), dtype=float)
        self.observations = 0
        self.replay_updates = 0
        self.last_error = 0.0
        self.mean_error = 0.0
        self.last_epistemic = 1.0

    @staticmethod
    def _input(state, action):
        x = np.concatenate([
            _finite_array(state, (LATENT_DIM,)),
            np.clip(_finite_array(action, (2,)), -1.0, 1.0),
        ])
        return x

    @staticmethod
    def _target(state, next_state, improvement, dt):
        dt = max(float(dt), 1e-5)
        delta = _finite_array(next_state, (LATENT_DIM,)) - _finite_array(
            state, (LATENT_DIM,)
        )
        # Toroidal positions use their shortest displacement.
        delta[0:2] = _torus_delta(state[0:2], next_state[0:2])
        delta = np.clip(delta / dt, -4.0, 4.0)
        imp = np.clip(
            _finite_array(improvement, (TROPHIC_COUNT,)) / dt,
            -2.0,
            2.0,
        )
        return np.concatenate([delta, imp])

    def _distances(self, member, x):
        difference = x[None, :] - self.center[member]
        difference[:, 0:2] = (
            difference[:, 0:2] + 0.5
        ) % 1.0 - 0.5
        return np.mean(
            (difference / np.maximum(self.scale[member], 0.06)) ** 2,
            axis=1,
        ) - 0.035 * np.log1p(self.count[member])

    def _member_prediction(self, member, x):
        distances = self._distances(member, x)
        nearest = np.argsort(distances)[:4]
        reliability = np.clip(self.count[member, nearest] / 16.0, 0.0, 1.0)
        weights = np.exp(-np.clip(distances[nearest], 0.0, 20.0)) * (
            0.10 + reliability
        )
        total = float(np.sum(weights))
        if total <= 1e-12:
            weights[:] = 1.0 / len(weights)
        else:
            weights /= total
        mean = np.sum(self.mean[member, nearest] * weights[:, None], axis=0)
        variance = np.sum(
            (self.var[member, nearest] +
             (self.mean[member, nearest] - mean[None, :]) ** 2)
            * weights[:, None],
            axis=0,
        )
        support = float(np.sum(weights * reliability))
        novelty = float(np.min(np.maximum(distances[nearest], 0.0)))
        return mean, variance, support, novelty

    def predict(self, state, action, dt):
        if not self.enabled:
            return (
                _finite_array(state, (LATENT_DIM,)).copy(),
                np.zeros(TROPHIC_COUNT, dtype=float),
                np.ones(TROPHIC_COUNT, dtype=float),
                0.0,
            )
        x = self._input(state, action)
        predictions = []
        variances = []
        supports = []
        novelties = []
        for member in range(MODEL_MEMBERS):
            mean, variance, support, novelty = self._member_prediction(member, x)
            predictions.append(mean)
            variances.append(variance)
            supports.append(support)
            novelties.append(novelty)
        predictions = np.asarray(predictions, dtype=float)
        variances = np.asarray(variances, dtype=float)
        ensemble_mean = np.mean(predictions, axis=0)
        epistemic = np.var(predictions, axis=0)
        total_var = np.mean(variances, axis=0) + epistemic
        self.last_epistemic = float(np.mean(epistemic[-TROPHIC_COUNT:]))

        next_state = _clip_latent(
            np.asarray(state, dtype=float)
            + ensemble_mean[:LATENT_DIM] * float(dt)
        )
        improvement = np.clip(
            ensemble_mean[LATENT_DIM:] * float(dt), -0.35, 0.35
        )
        uncertainty = np.sqrt(
            np.maximum(total_var[LATENT_DIM:], 1e-8)
        ) * float(dt)
        support = clamp(
            float(np.mean(supports)) * math.exp(-0.12 * float(np.mean(novelties))),
            0.0,
            1.0,
        )
        return next_state, improvement, uncertainty, support

    def observe(self, state, action, next_state, improvement, dt, replay=False):
        if not self.enabled:
            return 0.0
        x = self._input(state, action)
        target = self._target(state, next_state, improvement, dt)
        errors = []
        for member in range(MODEL_MEMBERS):
            # Bootstrap diversity without a separate dataset.
            if not replay and self.rng.random() > 0.84:
                continue
            distances = self._distances(member, x)
            index = int(np.argmin(distances))
            novelty = float(distances[index])
            if novelty > 2.25 and self.count[member, index] > 18.0:
                score = self.utility[member] + 0.0015 * self.count[member]
                index = int(np.argmin(score))
                self.center[member, index] = x + self.rng.normal(
                    0.0, 0.015, x.shape
                )
                self.scale[member, index] = 0.34
                self.mean[member, index] = 0.0
                self.var[member, index] = 0.08
                self.count[member, index] = 0.0
                self.utility[member, index] = 0.0

            old = self.mean[member, index].copy()
            error = target - old
            base_lr = 0.045 if not replay else 0.014
            lr = base_lr / (1.0 + 0.006 * self.count[member, index])
            center_lr = 0.35 * lr
            difference = x - self.center[member, index]
            difference[0:2] = (
                difference[0:2] + 0.5
            ) % 1.0 - 0.5
            self.center[member, index] += center_lr * difference
            self.center[member, index, 0:2] %= 1.0
            self.scale[member, index] += center_lr * (
                np.abs(difference) - self.scale[member, index]
            )
            self.scale[member, index] = np.clip(
                self.scale[member, index], 0.06, 1.4
            )
            self.mean[member, index] += lr * error
            self.var[member, index] += lr * (
                error * error - self.var[member, index]
            )
            self.var[member, index] = np.clip(
                self.var[member, index], 1e-6, 6.0
            )
            self.count[member, index] += 1.0 if not replay else 0.35
            learning_gain = float(np.mean(np.abs(error)))
            self.utility[member, index] = (
                0.997 * self.utility[member, index]
                + 0.003 * learning_gain
            )
            errors.append(float(np.mean(np.abs(error))))

        error_value = float(np.mean(errors)) if errors else self.last_error
        self.last_error = error_value
        self.mean_error = 0.995 * self.mean_error + 0.005 * error_value
        if replay:
            self.replay_updates += 1
        else:
            self.observations += 1
        return error_value

    def state_dict(self):
        return {
            'r5_model_enabled': bool_array(self.enabled),
            'r5_model_center': self.center,
            'r5_model_scale': self.scale,
            'r5_model_mean': self.mean,
            'r5_model_var': self.var,
            'r5_model_count': self.count,
            'r5_model_utility': self.utility,
            'r5_model_observations': scalar_array(self.observations, np.int64),
            'r5_model_replay_updates': scalar_array(self.replay_updates, np.int64),
            'r5_model_last_error': scalar_array(self.last_error),
            'r5_model_mean_error': scalar_array(self.mean_error),
            'r5_model_last_epistemic': scalar_array(self.last_epistemic),
            'r5_model_rng': encode_rng_state(self.rng),
        }

    def load_state(self, data):
        self.enabled = bool(int(data['r5_model_enabled']))
        self.center = np.array(data['r5_model_center'], dtype=float)
        self.scale = np.array(data['r5_model_scale'], dtype=float)
        self.mean = np.array(data['r5_model_mean'], dtype=float)
        self.var = np.array(data['r5_model_var'], dtype=float)
        self.count = np.array(data['r5_model_count'], dtype=float)
        self.utility = np.array(data['r5_model_utility'], dtype=float)
        self.observations = int(data['r5_model_observations'])
        self.replay_updates = int(data['r5_model_replay_updates'])
        self.last_error = float(data['r5_model_last_error'])
        self.mean_error = float(data['r5_model_mean_error'])
        self.last_epistemic = float(data['r5_model_last_epistemic'])
        restore_rng_state(self.rng, data['r5_model_rng'])


class EmbodiedConceptGraph(object):
    """Online concepts grounded in context, action, outcome and succession."""

    def __init__(self, seed=1, enabled=True):
        self.enabled = bool(enabled)
        self.rng = np.random.default_rng(int(seed) + 5401)
        self.context = self.rng.normal(
            0.0, 0.10, (CONCEPT_COUNT, CONCEPT_CONTEXT_DIM)
        )
        self.context[:, 0:2] = self.rng.random((CONCEPT_COUNT, 2))
        self.scale = np.ones_like(self.context) * 0.42
        self.effect = np.zeros((CONCEPT_COUNT, TROPHIC_COUNT), dtype=float)
        self.effect_var = np.ones_like(self.effect) * 0.08
        self.action_mean = np.zeros((CONCEPT_COUNT, 2), dtype=float)
        self.count = np.zeros(CONCEPT_COUNT, dtype=float)
        self.utility = np.zeros(CONCEPT_COUNT, dtype=float)
        self.transition = np.ones((CONCEPT_COUNT, CONCEPT_COUNT), dtype=float) * 0.02
        self.last = -1
        self.births = 0
        self.merges = 0
        self.splits = 0
        self.prequential_error = 0.0
        self.baseline_error = 0.0
        self.guidance_uses = 0
        self.next_maintenance_age = 30.0

    @staticmethod
    def descriptor(state, action):
        descriptor = np.concatenate([
            _finite_array(state, (LATENT_DIM,)),
            np.clip(_finite_array(action, (2,)), -1.0, 1.0),
        ])
        return descriptor

    def _distances(self, descriptor):
        difference = descriptor[None, :] - self.context
        difference[:, 0:2] = (
            difference[:, 0:2] + 0.5
        ) % 1.0 - 0.5
        distances = np.mean(
            (difference / np.maximum(self.scale, 0.06)) ** 2,
            axis=1,
        ) - 0.035 * np.log1p(self.count)
        return distances

    def assign(self, state, action):
        descriptor = self.descriptor(state, action)
        distances = self._distances(descriptor)
        index = int(np.argmin(distances))
        return index, float(distances[index]), descriptor

    def predict(self, state, action):
        if not self.enabled:
            return np.zeros(TROPHIC_COUNT), np.ones(TROPHIC_COUNT), 0.0, -1
        index, novelty, _ = self.assign(state, action)
        support = clamp(self.count[index] / 35.0, 0.0, 1.0)
        confidence = support * math.exp(-0.20 * max(0.0, novelty))
        return (
            self.effect[index].copy(),
            np.sqrt(np.maximum(self.effect_var[index], 1e-8)),
            clamp(confidence, 0.0, 1.0),
            index,
        )

    def observe(self, state, action, improvement, age, replay=False):
        if not self.enabled:
            return -1, 0.0
        index, novelty, descriptor = self.assign(state, action)
        improvement = np.clip(
            _finite_array(improvement, (TROPHIC_COUNT,)), -0.5, 0.5
        )
        before_error = float(np.mean(np.abs(improvement - self.effect[index])))

        # Split a repeatedly ambiguous concept rather than averaging opposites.
        residual_scale = float(np.mean(np.sqrt(self.effect_var[index] + 1e-8)))
        if (
            novelty > 1.75
            or (
                self.count[index] > 42.0
                and before_error > max(0.045, 2.2 * residual_scale)
            )
        ):
            score = self.utility + 0.001 * self.count
            replacement = int(np.argmin(score))
            if replacement != index:
                index = replacement
                self.context[index] = descriptor + self.rng.normal(
                    0.0, 0.012, descriptor.shape
                )
                self.context[index, 0:2] %= 1.0
                self.scale[index] = 0.34
                self.effect[index] = improvement
                self.effect_var[index] = 0.06
                self.action_mean[index] = action
                self.count[index] = 1.0
                self.utility[index] = 0.01
                self.births += 1
                self.splits += 1

        lr = (0.065 if not replay else 0.016) / (
            1.0 + 0.008 * self.count[index]
        )
        difference = descriptor - self.context[index]
        difference[0:2] = (difference[0:2] + 0.5) % 1.0 - 0.5
        self.context[index] += 0.55 * lr * difference
        self.context[index, 0:2] %= 1.0
        self.scale[index] += 0.55 * lr * (
            np.abs(difference) - self.scale[index]
        )
        self.scale[index] = np.clip(self.scale[index], 0.06, 1.4)

        error = improvement - self.effect[index]
        self.effect[index] += lr * error
        self.effect_var[index] += lr * (
            error * error - self.effect_var[index]
        )
        self.effect_var[index] = np.clip(self.effect_var[index], 1e-6, 1.0)
        self.action_mean[index] += lr * (
            np.asarray(action, dtype=float) - self.action_mean[index]
        )
        self.count[index] += 1.0 if not replay else 0.25

        after_error = float(np.mean(np.abs(improvement - self.effect[index])))
        prediction_gain = max(0.0, before_error - after_error)
        decision_relevance = float(np.max(np.abs(improvement)))
        self.utility[index] = (
            0.996 * self.utility[index]
            + 0.004 * (prediction_gain + 0.25 * decision_relevance)
        )
        self.prequential_error = 0.995 * self.prequential_error + 0.005 * before_error
        self.baseline_error = 0.995 * self.baseline_error + 0.005 * float(
            np.mean(np.abs(improvement))
        )

        if self.last >= 0:
            self.transition[self.last, index] += 1.0 if not replay else 0.10
        self.last = int(index)

        if float(age) >= self.next_maintenance_age:
            self._maintenance()
            self.next_maintenance_age += 30.0
        return int(index), before_error

    def _maintenance(self):
        candidates = np.flatnonzero(self.count > 8.0)
        if candidates.size < 2:
            return
        best = None
        best_distance = 1e9
        for p, i in enumerate(candidates):
            for j in candidates[p + 1:]:
                context_delta = self.context[i] - self.context[j]
                context_delta[0:2] = (
                    context_delta[0:2] + 0.5
                ) % 1.0 - 0.5
                distance = float(np.mean(context_delta * context_delta))
                distance += 0.7 * float(np.mean((self.effect[i] - self.effect[j]) ** 2))
                if distance < best_distance:
                    best = (int(i), int(j))
                    best_distance = distance
        if best is None or best_distance > 0.018:
            return
        i, j = best
        total = self.count[i] + self.count[j]
        if total <= 0.0:
            return
        wi = self.count[i] / total
        wj = self.count[j] / total
        self.context[i] = wi * self.context[i] + wj * self.context[j]
        self.context[i, 0:2] %= 1.0
        self.effect[i] = wi * self.effect[i] + wj * self.effect[j]
        self.effect_var[i] = wi * self.effect_var[i] + wj * self.effect_var[j]
        self.action_mean[i] = wi * self.action_mean[i] + wj * self.action_mean[j]
        self.count[i] = total
        self.utility[i] = max(self.utility[i], self.utility[j])
        self.transition[i] += self.transition[j]
        self.transition[:, i] += self.transition[:, j]

        self.context[j] = self.rng.normal(0.0, 0.12, CONCEPT_CONTEXT_DIM)
        self.context[j, 0:2] = self.rng.random(2)
        self.scale[j] = 0.42
        self.effect[j] = 0.0
        self.effect_var[j] = 0.08
        self.action_mean[j] = 0.0
        self.count[j] = 0.0
        self.utility[j] = 0.0
        self.transition[j] = 0.02
        self.transition[:, j] = 0.02
        self.merges += 1

    def guidance(self, state, need):
        if not self.enabled:
            return np.zeros(2, dtype=float), 0.0
        best_action = np.zeros(2, dtype=float)
        best_score = -1e9
        best_confidence = 0.0
        for index in range(CONCEPT_COUNT):
            if self.count[index] < 5.0:
                continue
            context_delta = self.context[index, :LATENT_DIM] - state
            context_delta[0:2] = (
                context_delta[0:2] + 0.5
            ) % 1.0 - 0.5
            distance = float(np.mean(
                (context_delta / np.maximum(self.scale[index, :LATENT_DIM], 0.08)) ** 2
            ))
            context_weight = math.exp(-0.25 * min(distance, 20.0))
            uncertainty = float(np.mean(np.sqrt(self.effect_var[index])))
            effect_score = float(np.dot(self.effect[index], need))
            no_harm = float(np.sum(np.maximum(-self.effect[index] - 0.01, 0.0)))
            score = context_weight * (effect_score - 0.9 * no_harm - 0.25 * uncertainty)
            if score > best_score:
                best_score = score
                best_action = self.action_mean[index].copy()
                best_confidence = (
                    context_weight
                    * clamp(self.count[index] / 45.0, 0.0, 1.0)
                    * math.exp(-2.2 * uncertainty)
                )
        if _safe_norm(best_action) > 1.0:
            best_action /= _safe_norm(best_action)
        if best_confidence > 0.08:
            self.guidance_uses += 1
        return best_action, clamp(best_confidence, 0.0, 1.0)

    def state_dict(self):
        return {
            'r5_concept_enabled': bool_array(self.enabled),
            'r5_concept_context': self.context,
            'r5_concept_scale': self.scale,
            'r5_concept_effect': self.effect,
            'r5_concept_effect_var': self.effect_var,
            'r5_concept_action': self.action_mean,
            'r5_concept_count': self.count,
            'r5_concept_utility': self.utility,
            'r5_concept_transition': self.transition,
            'r5_concept_last': scalar_array(self.last, np.int64),
            'r5_concept_births': scalar_array(self.births, np.int64),
            'r5_concept_merges': scalar_array(self.merges, np.int64),
            'r5_concept_splits': scalar_array(self.splits, np.int64),
            'r5_concept_prequential': scalar_array(self.prequential_error),
            'r5_concept_baseline': scalar_array(self.baseline_error),
            'r5_concept_guidance': scalar_array(self.guidance_uses, np.int64),
            'r5_concept_next_maintenance': scalar_array(self.next_maintenance_age),
            'r5_concept_rng': encode_rng_state(self.rng),
        }

    def load_state(self, data):
        self.enabled = bool(int(data['r5_concept_enabled']))
        self.context = np.array(data['r5_concept_context'], dtype=float)
        self.scale = np.array(data['r5_concept_scale'], dtype=float)
        self.effect = np.array(data['r5_concept_effect'], dtype=float)
        self.effect_var = np.array(data['r5_concept_effect_var'], dtype=float)
        self.action_mean = np.array(data['r5_concept_action'], dtype=float)
        self.count = np.array(data['r5_concept_count'], dtype=float)
        self.utility = np.array(data['r5_concept_utility'], dtype=float)
        self.transition = np.array(data['r5_concept_transition'], dtype=float)
        self.last = int(data['r5_concept_last'])
        self.births = int(data['r5_concept_births'])
        self.merges = int(data['r5_concept_merges'])
        self.splits = int(data['r5_concept_splits'])
        self.prequential_error = float(data['r5_concept_prequential'])
        self.baseline_error = float(data['r5_concept_baseline'])
        self.guidance_uses = int(data['r5_concept_guidance'])
        self.next_maintenance_age = float(data['r5_concept_next_maintenance'])
        restore_rng_state(self.rng, data['r5_concept_rng'])


class MetabolicRolloutPlanner(object):
    """Short-horizon model-predictive planner with an abstention option."""

    def __init__(
        self,
        seed=1,
        enabled=True,
        thought_cost_enabled=True,
        planning_interval=0.40,
        max_depth=6,
    ):
        self.enabled = bool(enabled)
        self.thought_cost_enabled = bool(thought_cost_enabled)
        self.planning_interval = float(planning_interval)
        self.max_depth = int(max_depth)
        self.rng = np.random.default_rng(int(seed) + 5501)
        self.cooldown = 0.0
        self.current_action = np.zeros(2, dtype=float)
        self.current_confidence = 0.0
        self.current_scale = 1.0
        self.last_score = 0.0
        self.last_uncertainty = 1.0
        self.last_depth = 0
        self.last_evaluations = 0
        self.plans = 0
        self.abstentions = 0
        self.evaluations = 0
        self.guided_time = 0.0
        self.thought_energy = 0.0
        self.thought_fatigue = 0.0
        self.predicted_gain = np.zeros(TROPHIC_COUNT, dtype=float)
        self.realized_guided_gain = np.zeros(TROPHIC_COUNT, dtype=float)

    @staticmethod
    def _busy(core):
        return bool(
            core.compiler.busy
            or core.auditor.busy
            or core.morphology.busy
            or core.questioner.busy
        )

    def _sequence_set(self, concept_action):
        """Eighteen compact sequences: persist or act-then-rest.

        This provides genuine multi-step state propagation without the
        combinatorial cost of expanding all 9^depth possibilities on an iPhone.
        """
        sequences = []
        for action in ACTIONS:
            sequences.append(('persist', action.copy()))
            sequences.append(('pulse', action.copy()))
        if _safe_norm(concept_action) > 0.08:
            sequences.append(('persist', np.clip(concept_action, -1.0, 1.0)))
        return sequences

    @staticmethod
    def _step_action(mode, action, step, depth):
        if mode == 'pulse' and step >= max(1, depth // 2):
            return ACTIONS[0]
        return action

    def _score_rollout(self, core, model, latent, mode, action, depth, step_dt):
        virtual = latent.copy()
        total_improvement = np.zeros(TROPHIC_COUNT, dtype=float)
        total_uncertainty = np.zeros(TROPHIC_COUNT, dtype=float)
        support_product = 1.0
        evaluations = 0
        discount = 1.0
        for step in range(depth):
            chosen = self._step_action(mode, action, step, depth)
            virtual, improvement, uncertainty, support = model.predict(
                virtual, chosen, step_dt
            )
            total_improvement += discount * improvement
            total_uncertainty += (discount ** 2) * uncertainty
            support_product *= 0.35 + 0.65 * support
            discount *= 0.88
            evaluations += 1

        need = 0.15 + latent_debt(latent)
        urgent = int(np.argmax(need))
        useful = float(np.dot(total_improvement, need))
        urgent_gain = float(total_improvement[urgent])
        harm = float(np.sum(np.maximum(-total_improvement - 0.012, 0.0) * (0.7 + need)))
        uncertainty_penalty = float(np.dot(total_uncertainty, 0.45 + need))
        action_cost = 0.008 * float(np.dot(action, action)) * depth
        score = (
            useful
            + 0.45 * urgent_gain
            - 1.35 * harm
            - 0.70 * uncertainty_penalty
            - action_cost
        )
        confidence = clamp(
            support_product * math.exp(-3.0 * float(np.mean(total_uncertainty))),
            0.0,
            1.0,
        )
        return score, confidence, total_improvement, total_uncertainty, evaluations

    def _charge(self, core, evaluations, depth):
        if not self.thought_cost_enabled or evaluations <= 0:
            return
        # Roughly one percent of the base metabolic rate for a typical plan.
        complexity = float(evaluations) * (1.0 + 0.10 * max(0, depth - 2))
        energy_cost = 1.5e-6 * complexity
        fatigue_cost = 1.0e-6 * complexity
        core.energy = clamp(core.energy - energy_cost, 0.0, 1.0)
        core.fatigue = clamp(core.fatigue + fatigue_cost, 0.0, 1.0)
        self.thought_energy += energy_cost
        self.thought_fatigue += fatigue_cost

    def additional_prior(self, core):
        provider = getattr(core, 'additional_planning_prior', None)
        if callable(provider):
            action, confidence = provider()
            return np.asarray(action, dtype=float), clamp(float(confidence), 0.0, 1.0)
        return np.zeros(2, dtype=float), 0.0

    def maybe_plan(self, core, latent, model, concepts, dt):
        self.cooldown -= float(dt)
        if not self.enabled:
            self.current_action[:] = 0.0
            self.current_confidence = 0.0
            self.current_scale = 1.0
            core.compiler.external_action_scale = 1.0
            return np.zeros(2, dtype=float), 0.0
        if self._busy(core):
            self.current_action[:] = 0.0
            self.current_confidence = 0.0
            self.current_scale = 1.0
            core.compiler.external_action_scale = 1.0
            self.abstentions += 1
            return np.zeros(2, dtype=float), 0.0
        if self.cooldown > 0.0:
            core.compiler.external_action_scale = self.current_scale
            if self.current_confidence > 0.08:
                self.guided_time += float(dt)
            return self.current_action.copy(), self.current_confidence

        debt = latent_debt(latent)
        if core.energy < 0.13 or core.integrity < 0.22 or float(np.max(debt)) > 0.94:
            self.current_action[:] = 0.0
            self.current_confidence = 0.0
            self.current_scale = 1.0
            core.compiler.external_action_scale = 1.0
            self.cooldown = 0.25
            self.abstentions += 1
            return self.current_action.copy(), 0.0

        need = 0.15 + debt
        concept_action, concept_conf = concepts.guidance(latent, need)
        social_action, social_conf = self.additional_prior(core)
        if social_conf > concept_conf:
            concept_action = social_action
            concept_conf = social_conf

        mean_support = clamp(model.observations / 220.0, 0.0, 1.0)
        depth = int(round(2 + (self.max_depth - 2) * mean_support))
        depth = max(2, min(self.max_depth, depth))
        # Weak bodies think less, not more.
        depth = max(2, int(round(depth * (0.55 + 0.45 * core.energy))))
        step_dt = 0.22

        best = None
        rest_score = -1e9
        total_evaluations = 0
        for mode, action in self._sequence_set(concept_action):
            score, confidence, gain, uncertainty, evaluations = self._score_rollout(
                core, model, latent, mode, action, depth, step_dt
            )
            if concept_conf > 0.0:
                score += 0.035 * concept_conf * float(np.dot(action, concept_action))
            total_evaluations += evaluations
            candidate = (score, confidence, action, gain, uncertainty)
            if _safe_norm(action) < 0.02:
                rest_score = max(rest_score, float(score))
            if best is None or candidate[0] > best[0]:
                best = candidate

        self._charge(core, total_evaluations, depth)
        self.evaluations += total_evaluations
        self.last_evaluations = total_evaluations
        self.last_depth = depth
        self.plans += 1
        self.cooldown = self.planning_interval

        if best is None:
            self.current_action[:] = 0.0
            self.current_confidence = 0.0
            self.abstentions += 1
            return self.current_action.copy(), 0.0

        score, confidence, action, gain, uncertainty = best
        advantage = float(score) - float(rest_score if np.isfinite(rest_score) else 0.0)
        self.last_score = float(advantage)
        self.last_uncertainty = float(np.mean(uncertainty))
        self.predicted_gain = np.asarray(gain, dtype=float)
        confidence *= clamp((model.observations - 18) / 80.0, 0.0, 1.0)
        # Relative advantage is meaningful even when all futures have a
        # metabolic cost.  Absolute reward would incorrectly make the planner
        # abstain forever in a living body that always spends energy.
        confidence *= clamp((advantage + 0.0015) / 0.020, 0.0, 1.0)
        if confidence < 0.045:
            self.current_action[:] = 0.0
            self.current_confidence = 0.0
            self.current_scale = 1.0
            core.compiler.external_action_scale = 1.0
            self.abstentions += 1
        elif _safe_norm(action) < 0.05:
            self.current_action[:] = 0.0
            self.current_confidence = clamp(confidence, 0.0, 1.0)
            self.current_scale = clamp(1.0 - 0.28 * confidence, 0.68, 1.0)
            core.compiler.external_action_scale = self.current_scale
            self.guided_time += float(dt)
        else:
            strength = 0.04 + 0.16 * confidence
            self.current_action = np.clip(action * strength, -0.22, 0.22)
            self.current_confidence = clamp(confidence, 0.0, 1.0)
            self.current_scale = 1.0
            core.compiler.external_action_scale = 1.0
            self.guided_time += float(dt)
        return self.current_action.copy(), self.current_confidence

    def observe_realized(self, improvement, dt):
        if self.current_confidence > 0.08:
            self.realized_guided_gain += np.asarray(improvement, dtype=float)

    def state_dict(self):
        return {
            'r5_plan_enabled': bool_array(self.enabled),
            'r5_plan_cost_enabled': bool_array(self.thought_cost_enabled),
            'r5_plan_interval': scalar_array(self.planning_interval),
            'r5_plan_max_depth': scalar_array(self.max_depth, np.int64),
            'r5_plan_cooldown': scalar_array(self.cooldown),
            'r5_plan_action': self.current_action,
            'r5_plan_confidence': scalar_array(self.current_confidence),
            'r5_plan_scale': scalar_array(self.current_scale),
            'r5_plan_last_score': scalar_array(self.last_score),
            'r5_plan_last_uncertainty': scalar_array(self.last_uncertainty),
            'r5_plan_last_depth': scalar_array(self.last_depth, np.int64),
            'r5_plan_last_evaluations': scalar_array(self.last_evaluations, np.int64),
            'r5_plan_plans': scalar_array(self.plans, np.int64),
            'r5_plan_abstentions': scalar_array(self.abstentions, np.int64),
            'r5_plan_evaluations': scalar_array(self.evaluations, np.int64),
            'r5_plan_guided_time': scalar_array(self.guided_time),
            'r5_plan_thought_energy': scalar_array(self.thought_energy),
            'r5_plan_thought_fatigue': scalar_array(self.thought_fatigue),
            'r5_plan_predicted_gain': self.predicted_gain,
            'r5_plan_realized_gain': self.realized_guided_gain,
            'r5_plan_rng': encode_rng_state(self.rng),
        }

    def load_state(self, data):
        self.enabled = bool(int(data['r5_plan_enabled']))
        self.thought_cost_enabled = bool(int(data['r5_plan_cost_enabled']))
        self.planning_interval = float(data['r5_plan_interval'])
        self.max_depth = int(data['r5_plan_max_depth'])
        self.cooldown = float(data['r5_plan_cooldown'])
        self.current_action = np.array(data['r5_plan_action'], dtype=float)
        self.current_confidence = float(data['r5_plan_confidence'])
        self.current_scale = float(data['r5_plan_scale']) if 'r5_plan_scale' in data else 1.0
        self.last_score = float(data['r5_plan_last_score'])
        self.last_uncertainty = float(data['r5_plan_last_uncertainty'])
        self.last_depth = int(data['r5_plan_last_depth'])
        self.last_evaluations = int(data['r5_plan_last_evaluations'])
        self.plans = int(data['r5_plan_plans'])
        self.abstentions = int(data['r5_plan_abstentions'])
        self.evaluations = int(data['r5_plan_evaluations'])
        self.guided_time = float(data['r5_plan_guided_time'])
        self.thought_energy = float(data['r5_plan_thought_energy'])
        self.thought_fatigue = float(data['r5_plan_thought_fatigue'])
        self.predicted_gain = np.array(data['r5_plan_predicted_gain'], dtype=float)
        self.realized_guided_gain = np.array(data['r5_plan_realized_gain'], dtype=float)
        restore_rng_state(self.rng, data['r5_plan_rng'])


class OfflineReplay(object):
    """Rest-gated replay and reconsolidation with explicit metabolic expense."""

    def __init__(self, seed=1, enabled=True, interval=0.55):
        self.enabled = bool(enabled)
        self.interval = float(interval)
        self.rng = np.random.default_rng(int(seed) + 5601)
        self.cooldown = 0.0
        self.events = 0
        self.updates = 0
        self.cost_energy = 0.0
        self.cost_fatigue = 0.0
        self.last_priority = 0.0
        self.rest_time = 0.0

    def maybe_replay(self, core, replay, model, concepts, dt):
        self.cooldown -= float(dt)
        # Rest is a graded embodied state rather than a brittle exact
        # zero-action test.  Real organisms can perform low-speed maintenance
        # while still emitting small motor commands, especially in a refuge.
        speed_fraction = clamp(
            _safe_norm(core.vel) / max(MAX_SPEED, 1e-9), 0.0, 1.5
        )
        action_fraction = clamp(_safe_norm(core.last_action), 0.0, 1.5)
        try:
            shelter = clamp(float(core.shelter_level()), 0.0, 1.0)
        except Exception:
            shelter = 0.0
        rest_score = (
            0.48 * clamp(1.0 - speed_fraction, 0.0, 1.0)
            + 0.34 * clamp(1.0 - action_fraction, 0.0, 1.0)
            + 0.18 * shelter
        )
        resting = (
            rest_score > 0.56
            and core.fatigue > 0.18
            and core.energy > 0.18
            and not MetabolicRolloutPlanner._busy(core)
        )
        if not (self.enabled and resting and replay.size >= 12):
            return
        self.rest_time += float(dt)
        if self.cooldown > 0.0:
            return
        batch = 3 if core.energy > 0.38 else 1
        indices = replay.sample_indices(batch)
        if indices.size == 0:
            return
        self.events += 1
        for index in indices:
            state, action, next_state, improvement, _ = replay.transition(index)
            prediction, pred_imp, uncertainty, support = model.predict(
                state, action, 1.0 / 12.0
            )
            error_before = float(np.mean(np.abs(next_state - prediction)))
            error_before += 0.7 * float(np.mean(np.abs(improvement - pred_imp)))
            model.observe(
                state, action, next_state, improvement, 1.0 / 12.0, replay=True
            )
            concepts.observe(state, action, improvement, core.age, replay=True)
            replay.update_priority(index, 0.35 * replay.priority[index] + error_before)
            self.last_priority = float(replay.priority[index])
            self.updates += 1

        energy_cost = 8.0e-6 * int(indices.size)
        fatigue_cost = 4.0e-6 * int(indices.size)
        core.energy = clamp(core.energy - energy_cost, 0.0, 1.0)
        core.fatigue = clamp(core.fatigue + fatigue_cost, 0.0, 1.0)
        self.cost_energy += energy_cost
        self.cost_fatigue += fatigue_cost
        self.cooldown = self.interval

    def state_dict(self):
        return {
            'r5_dream_enabled': bool_array(self.enabled),
            'r5_dream_interval': scalar_array(self.interval),
            'r5_dream_cooldown': scalar_array(self.cooldown),
            'r5_dream_events': scalar_array(self.events, np.int64),
            'r5_dream_updates': scalar_array(self.updates, np.int64),
            'r5_dream_cost_energy': scalar_array(self.cost_energy),
            'r5_dream_cost_fatigue': scalar_array(self.cost_fatigue),
            'r5_dream_last_priority': scalar_array(self.last_priority),
            'r5_dream_rest_time': scalar_array(self.rest_time),
            'r5_dream_rng': encode_rng_state(self.rng),
        }

    def load_state(self, data):
        self.enabled = bool(int(data['r5_dream_enabled']))
        self.interval = float(data['r5_dream_interval'])
        self.cooldown = float(data['r5_dream_cooldown'])
        self.events = int(data['r5_dream_events'])
        self.updates = int(data['r5_dream_updates'])
        self.cost_energy = float(data['r5_dream_cost_energy'])
        self.cost_fatigue = float(data['r5_dream_cost_fatigue'])
        self.last_priority = float(data['r5_dream_last_priority'])
        self.rest_time = float(data['r5_dream_rest_time'])
        restore_rng_state(self.rng, data['r5_dream_rng'])


class SomaFiveRCore(soma42.SomaFourTwoCore):
    """SOMA-4.2 organism plus a metabolically constrained internal world."""

    def __init__(
        self,
        seed=None,
        concepts_enabled=True,
        world_model_enabled=True,
        planning_enabled=True,
        thought_cost_enabled=True,
        dream_enabled=True,
        planning_interval=0.40,
        max_rollout_depth=6,
        lightweight=False,
        **kwargs
    ):
        if lightweight:
            kwargs.setdefault('audit_enabled', False)
            kwargs.setdefault('morphogenesis_enabled', False)
            kwargs.setdefault('question_enabled', False)
            kwargs.setdefault('compiler_enabled', False)
            kwargs.setdefault('turnover_enabled', True)
        super().__init__(seed=seed, **kwargs)
        # Add a final, transient action channel without touching brain.motor.
        if not isinstance(self.compiler, ImaginationActionCompiler):
            self.compiler.__class__ = ImaginationActionCompiler
        self.compiler.external_action_bias = np.zeros(2, dtype=float)
        self.compiler.external_action_scale = 1.0

        self.latent_codec = LatentCodec()
        self.world_model = LocalLatentEnsemble(
            seed=self.seed, enabled=world_model_enabled
        )
        self.concepts = EmbodiedConceptGraph(
            seed=self.seed, enabled=concepts_enabled
        )
        self.replay = PrioritizedReplay(seed=self.seed)
        self.planner = MetabolicRolloutPlanner(
            seed=self.seed,
            enabled=planning_enabled,
            thought_cost_enabled=thought_cost_enabled,
            planning_interval=planning_interval,
            max_depth=max_rollout_depth,
        )
        self.dreamer = OfflineReplay(seed=self.seed, enabled=dream_enabled)
        self.last_latent = self.latent_codec.encode(self)
        self.last_model_error = 0.0
        self.last_concept = -1
        self.real_transition_count = 0
        self.motor_learning_preserved = True
        self.last_motor_delta = 0.0
        self.model_guidance_steps = 0

    def additional_planning_prior(self):
        """Hook used by SOMA-6R social hypotheses."""
        return np.zeros(2, dtype=float), 0.0

    def _after_embodied_transition(
        self,
        latent_before,
        action,
        latent_after,
        improvement,
        concept_index,
        model_error,
        concept_error,
    ):
        """Subclass hook for culture/trust verification; base SOMA-5R is inert."""
        return None

    def model_world_channels(self):
        return self.latent_codec.world_channels(self)

    def _encode_latent(self):
        # Subclasses can replace the codec or override world_channels.
        return self.latent_codec.encode(self)

    def _transition_priority(
        self,
        state,
        action,
        next_state,
        improvement,
        dt,
    ):
        predicted_state, predicted_imp, uncertainty, support = self.world_model.predict(
            state, action, dt
        )
        state_error = float(np.mean(np.abs(next_state - predicted_state)))
        outcome_error = float(np.mean(np.abs(improvement - predicted_imp)))
        event_strength = float(np.max(np.abs(improvement)))
        change = float(getattr(self.change_sentinel, 'global_probability', 0.0))
        return clamp(
            0.10
            + 2.2 * state_error
            + 3.0 * outcome_error
            + 1.4 * event_strength
            + 0.8 * change
            + 0.25 * float(np.mean(uncertainty)),
            1e-4,
            20.0,
        )

    def step(self, dt=1.0 / 30.0):
        dt = clamp(float(dt), 1.0 / 240.0, 0.10)
        if not self.alive:
            return

        latent_before = self._encode_latent()
        debt_before = self.body_debt().copy()
        motor_before = self.brain.motor.copy()

        bias, confidence = self.planner.maybe_plan(
            self,
            latent_before,
            self.world_model,
            self.concepts,
            dt,
        )
        self.compiler.external_action_bias = np.asarray(bias, dtype=float)
        if confidence > 0.08:
            self.model_guidance_steps += 1

        super().step(dt)

        latent_after = self._encode_latent()
        debt_after = self.body_debt().copy()
        improvement = debt_before - debt_after
        action = np.asarray(self.last_action, dtype=float).copy()

        priority = self._transition_priority(
            latent_before, action, latent_after, improvement, dt
        )
        model_error = self.world_model.observe(
            latent_before, action, latent_after, improvement, dt, replay=False
        )
        concept_index, concept_error = self.concepts.observe(
            latent_before, action, improvement, self.age, replay=False
        )
        self.replay.add(
            latent_before,
            action,
            latent_after,
            improvement,
            priority,
            concept=concept_index,
        )
        self._after_embodied_transition(
            latent_before,
            action,
            latent_after,
            improvement,
            concept_index,
            model_error,
            concept_error,
        )
        self.planner.observe_realized(improvement, dt)
        self.dreamer.maybe_replay(
            self, self.replay, self.world_model, self.concepts, dt
        )

        self.last_latent = latent_after
        self.last_model_error = float(model_error)
        self.last_concept = int(concept_index)
        self.real_transition_count += 1
        self.last_motor_delta = float(np.max(np.abs(self.brain.motor - motor_before)))
        # A regression guard: planning must never restore a stale motor matrix.
        if not np.all(np.isfinite(self.brain.motor)):
            self.motor_learning_preserved = False

    def diagnostics5r(self):
        active_concepts = int(np.count_nonzero(self.concepts.count >= 5.0))
        concept_advantage = (
            self.concepts.baseline_error - self.concepts.prequential_error
        )
        return {
            'build': BUILD,
            'active_concepts': active_concepts,
            'concept_births': int(self.concepts.births),
            'concept_splits': int(self.concepts.splits),
            'concept_merges': int(self.concepts.merges),
            'concept_prediction_advantage': float(concept_advantage),
            'model_observations': int(self.world_model.observations),
            'model_replay_updates': int(self.world_model.replay_updates),
            'model_error': float(self.world_model.mean_error),
            'model_epistemic': float(self.world_model.last_epistemic),
            'plans': int(self.planner.plans),
            'plan_abstentions': int(self.planner.abstentions),
            'plan_depth': int(self.planner.last_depth),
            'plan_evaluations': int(self.planner.evaluations),
            'plan_confidence': float(self.planner.current_confidence),
            'plan_score': float(self.planner.last_score),
            'thought_energy': float(self.planner.thought_energy),
            'thought_fatigue': float(self.planner.thought_fatigue),
            'guided_time': float(self.planner.guided_time),
            'dream_events': int(self.dreamer.events),
            'dream_updates': int(self.dreamer.updates),
            'dream_energy': float(self.dreamer.cost_energy),
            'replay_size': int(self.replay.size),
            'motor_learning_preserved': int(self.motor_learning_preserved),
            'last_motor_delta': float(self.last_motor_delta),
        }

    def state_dict(self):
        state = super().state_dict()
        state['save_version'] = scalar_array(SAVE_VERSION, np.int64)
        state.update(self.world_model.state_dict())
        state.update(self.concepts.state_dict())
        state.update(self.replay.state_dict())
        state.update(self.planner.state_dict())
        state.update(self.dreamer.state_dict())
        state.update({
            'r5_last_latent': self.last_latent,
            'r5_last_model_error': scalar_array(self.last_model_error),
            'r5_last_concept': scalar_array(self.last_concept, np.int64),
            'r5_real_transitions': scalar_array(
                self.real_transition_count, np.int64
            ),
            'r5_motor_preserved': bool_array(self.motor_learning_preserved),
            'r5_last_motor_delta': scalar_array(self.last_motor_delta),
            'r5_guidance_steps': scalar_array(self.model_guidance_steps, np.int64),
            'r5_compiler_bias': np.asarray(
                self.compiler.external_action_bias, dtype=float
            ),
            'r5_compiler_scale': scalar_array(
                getattr(self.compiler, 'external_action_scale', 1.0)
            ),
        })
        return state

    def load_state(self, data):
        version = int(data['save_version'])
        if version not in (soma42.SAVE_VERSION, SAVE_VERSION):
            raise ValueError('unsupported SOMA-5R save version {}'.format(version))
        keys = list(data.files) if hasattr(data, 'files') else list(data.keys())
        base = {key: data[key] for key in keys}
        base['save_version'] = scalar_array(soma42.SAVE_VERSION, np.int64)
        super().load_state(base)
        if not isinstance(self.compiler, ImaginationActionCompiler):
            self.compiler.__class__ = ImaginationActionCompiler
        self.compiler.external_action_bias = np.zeros(2, dtype=float)
        self.compiler.external_action_scale = 1.0
        if version == soma42.SAVE_VERSION or 'r5_model_center' not in data:
            return
        self.world_model.load_state(data)
        self.concepts.load_state(data)
        self.replay.load_state(data)
        self.planner.load_state(data)
        self.dreamer.load_state(data)
        self.last_latent = np.array(data['r5_last_latent'], dtype=float)
        self.last_model_error = float(data['r5_last_model_error'])
        self.last_concept = int(data['r5_last_concept'])
        self.real_transition_count = int(data['r5_real_transitions'])
        self.motor_learning_preserved = bool(int(data['r5_motor_preserved']))
        self.last_motor_delta = float(data['r5_last_motor_delta'])
        self.model_guidance_steps = int(data['r5_guidance_steps'])
        self.compiler.external_action_bias = np.array(
            data['r5_compiler_bias'], dtype=float
        )
        self.compiler.external_action_scale = (
            float(data['r5_compiler_scale']) if 'r5_compiler_scale' in data else self.planner.current_scale
        )


def clone_core(core, **overrides):
    state = {key: np.array(value, copy=True) for key, value in core.state_dict().items()}
    cloned = SomaFiveRCore(seed=core.seed)
    cloned.load_state(state)
    for name, value in overrides.items():
        setattr(cloned, name, value)
    return cloned


def save_core(core, path=SAVE_FILE):
    np.savez(path, **core.state_dict())


def load_core(path=SAVE_FILE):
    core = SomaFiveRCore(seed=101)
    with np.load(path, allow_pickle=False) as data:
        core.load_state(data)
    return core


def run_headless_trial(
    seed=101,
    seconds=120.0,
    dt=1.0 / 30.0,
    **kwargs
):
    core = SomaFiveRCore(seed=seed, **kwargs)
    debt_integral = np.zeros(TROPHIC_COUNT, dtype=float)
    motor_initial = core.brain.motor.copy()
    for _ in range(int(max(0.0, seconds) / dt)):
        if not core.alive:
            break
        debt_integral += core.body_debt() * dt
        core.step(dt)
    age = max(core.age, 1e-9)
    diagnostics = core.diagnostics5r()
    return {
        'seed': int(seed),
        'age': float(core.age),
        'alive': int(core.alive),
        'health': float(1.0 - np.mean(debt_integral / age)),
        'food': int(core.eaten),
        'toxin': int(core.poisoned),
        'motor_total_change': float(np.max(np.abs(core.brain.motor - motor_initial))),
        **diagnostics
    }


# -----------------------------------------------------------------------------
# Pythonista scene
# -----------------------------------------------------------------------------

if soma2.IN_PYTHONISTA:
    class SomaFiveRScene(soma42.SomaFourTwoScene):
        def setup(self):
            self._building_5r = True
            super().setup()
            self._building_5r = False
            self.core = SomaFiveRCore()
            self.help_label.text = (
                'tap: relocate nutrient   {}   autosave 20 s'.format(BUILD)
            )
            self._load_life_if_possible()
            self._sync_nodes(force_tiles=True)

        def _save_life(self):
            if getattr(self, '_building_5r', False):
                return
            try:
                save_core(self.core, SAVE_FILE)
            except Exception as exc:
                print('SOMA-5R save failed:', exc)

        def _load_life_if_possible(self):
            if getattr(self, '_building_5r', False) or not os.path.exists(SAVE_FILE):
                return
            try:
                with np.load(SAVE_FILE, allow_pickle=False) as data:
                    self.core.load_state(data)
            except Exception as exc:
                print('SOMA-5R load ignored:', exc)

        def _sync_nodes(self, force_tiles=False):
            super()._sync_nodes(force_tiles=force_tiles)
            if getattr(self, '_building_5r', False):
                return
            d = self.core.diagnostics5r()
            self.info_label.text += (
                '\n{}  concepts {} births/splits/merge {}/{}/{}\n'
                'MODEL err {:.3f} epi {:.4f} real/replay {}/{}  replay {}\n'
                'PLAN n {} depth {} conf {:.2f} score {:+.3f} eval {}\n'
                'THOUGHT E {:.5f} DREAM {} updates {} guided {:.1f}s'
            ).format(
                BUILD,
                d['active_concepts'],
                d['concept_births'], d['concept_splits'], d['concept_merges'],
                d['model_error'], d['model_epistemic'],
                d['model_observations'], d['model_replay_updates'],
                d['replay_size'], d['plans'], d['plan_depth'],
                d['plan_confidence'], d['plan_score'],
                d['plan_evaluations'], d['thought_energy'],
                d['dream_events'], d['dream_updates'], d['guided_time'],
            )


if __name__ == '__main__':
    if soma2.IN_PYTHONISTA:
        from scene import LANDSCAPE, run
        run(SomaFiveRScene(), orientation=LANDSCAPE, show_fps=False)
    else:
        print(run_headless_trial(seed=101, seconds=20.0))
