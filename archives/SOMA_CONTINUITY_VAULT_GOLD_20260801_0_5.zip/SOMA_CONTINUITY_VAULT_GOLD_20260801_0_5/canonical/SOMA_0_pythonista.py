# coding: utf-8
"""
SOMA-0 — single embodied artificial life for Pythonista 3

特徴
- 事前データセットなし / 教師ラベルなし
- 生きている最中だけ、毎フレーム学習
- 体内エネルギー変化による三因子可塑性
- 次の感覚を予測する局所学習
- 神経活動の恒常化
- 再帰結線の低速な刈り込み・発芽
- 個体と脳を soma0_life.npz に保存

操作
- 画面タップ: 食物をその位置へ移す
- 死亡後にタップ: 同じ脳を保った研究用再生
- 完全な新生個体にしたい場合: soma0_life.npz を削除
"""

import math
import os
import time

import numpy as np
import ui
from scene import Scene, ShapeNode, SpriteNode, LabelNode, run, LANDSCAPE


SAVE_FILE = os.path.join(os.path.dirname(__file__), 'soma0_life.npz')
SAVE_VERSION = 2

SENSOR_COUNT = 10
HIDDEN_COUNT = 32
ACTION_COUNT = 2
FOOD_COUNT = 14

HUD_HEIGHT = 66.0
ARENA_BOTTOM = 8.0
BODY_RADIUS = 18.0
FOOD_RADIUS = 9.0


# -----------------------------------------------------------------------------
# Utility
# -----------------------------------------------------------------------------

def clamp(value, low, high):
    return low if value < low else high if value > high else value


def circle_node(radius, fill_color, stroke_color='clear', parent=None):
    """Create a centered circular ShapeNode."""
    path = ui.Path.oval(-radius, -radius, radius * 2.0, radius * 2.0)
    path.line_width = 1.0
    return ShapeNode(
        path=path,
        fill_color=fill_color,
        stroke_color=stroke_color,
        parent=parent,
    )


# -----------------------------------------------------------------------------
# Plastic brain
# -----------------------------------------------------------------------------

class SomaBrain:
    """
    A small online plastic dynamical system.

    This is intentionally not a standard train-then-run network.

    1. Recurrent state produces action continuously.
    2. A predictor guesses the next sensory state.
    3. Motor and recurrent synapses keep eligibility traces.
    4. Unexpected improvement/damage to the body modulates those traces.
    5. Neuron gain/bias self-regulate their activity.
    6. A few weak recurrent edges are periodically pruned and regrown.
    """

    def __init__(self, seed=None):
        if seed is None:
            seed = int(time.time() * 1000.0) & 0xFFFFFFFF
        self.rng = np.random.default_rng(seed)

        self.n_sensor = SENSOR_COUNT
        self.n_hidden = HIDDEN_COUNT
        self.n_action = ACTION_COUNT

        # Sensory wiring is the closest thing to a genetic starting morphology.
        self.w_in = self.rng.normal(
            0.0, 0.42, (self.n_hidden, self.n_sensor)
        )

        # Sparse recurrent core.
        self.rec_mask = self.rng.random(
            (self.n_hidden, self.n_hidden)
        ) < 0.18
        np.fill_diagonal(self.rec_mask, False)
        self.w_rec = self.rng.normal(
            0.0, 0.16, (self.n_hidden, self.n_hidden)
        ) * self.rec_mask
        self._limit_recurrent_rows(max_l1=0.92)

        feature_count = self.n_hidden + self.n_sensor
        predictor_feature_count = feature_count + self.n_action

        # Plastic motor synapses.
        self.w_motor = self.rng.normal(
            0.0, 0.025, (self.n_action, feature_count)
        )

        # Online next-sensation predictor.
        self.w_predict = self.rng.normal(
            0.0, 0.025,
            (self.n_sensor, predictor_feature_count),
        )

        self.bias = np.zeros(self.n_hidden, dtype=float)
        self.gain = np.ones(self.n_hidden, dtype=float)
        self.hidden = np.zeros(self.n_hidden, dtype=float)
        self.prev_hidden = np.zeros(self.n_hidden, dtype=float)

        self.motor_trace = np.zeros_like(self.w_motor)
        self.rec_trace = np.zeros_like(self.w_rec)

        self.activity_mean = np.zeros(self.n_hidden, dtype=float)
        self.activity_square = np.zeros(self.n_hidden, dtype=float)

        self.reward_baseline = 0.0
        self.surprise = 0.0
        self.last_prediction_rms = 0.0
        self.last_modulator = 0.0
        self.last_action = np.zeros(self.n_action, dtype=float)
        self.exploration_state = np.zeros(self.n_action, dtype=float)
        self.last_sigma = 0.30
        self.step_count = 0
        self.rewire_count = 0

        self._predict_feature = None
        self._prediction = None

    def act(self, sensor, energy):
        """Generate one action and prepare local eligibility/prediction state."""
        sensor = np.asarray(sensor, dtype=float)
        sensor = np.clip(sensor, -1.0, 1.0)

        self.prev_hidden = self.hidden.copy()

        recurrent_drive = self.w_in @ sensor + self.w_rec @ self.prev_hidden
        self.hidden = np.tanh(self.gain * recurrent_drive + self.bias)

        feature = np.concatenate((self.hidden, sensor))

        # Exploration increases when hungry or when the world is poorly predicted.
        hunger = 1.0 - clamp(float(energy), 0.0, 1.0)
        sigma = 0.24 + 0.13 * hunger + 0.18 * clamp(self.surprise, 0.0, 1.0)
        sigma = clamp(sigma, 0.20, 0.55)
        self.last_sigma = sigma

        # Temporally correlated exploration produces coherent movement instead
        # of frame-by-frame jitter, while remaining intrinsically stochastic.
        correlation = 0.97
        fresh_noise = self.rng.normal(0.0, 1.0, self.n_action)
        self.exploration_state = (
            correlation * self.exploration_state
            + math.sqrt(1.0 - correlation ** 2) * fresh_noise
        )
        perturbation = self.exploration_state
        motor_pre = self.w_motor @ feature + sigma * perturbation
        action = np.tanh(motor_pre)
        self.last_action = action.copy()

        # Eligibility says which synapses were recently involved. It does not
        # change weights until a later body-derived modulatory signal arrives.
        self.motor_trace *= 0.992
        self.motor_trace += np.outer(perturbation / sigma, feature)
        np.clip(self.motor_trace, -30.0, 30.0, out=self.motor_trace)

        self.rec_trace *= 0.985
        self.rec_trace += np.outer(self.hidden, self.prev_hidden) * self.rec_mask
        np.clip(self.rec_trace, -12.0, 12.0, out=self.rec_trace)

        # Predict the sensory state after this action.
        self._predict_feature = np.concatenate((self.hidden, sensor, action))
        self._prediction = np.tanh(self.w_predict @ self._predict_feature)

        return action

    def learn(self, next_sensor, body_signal):
        """
        Apply one online update.

        body_signal is not an externally supplied task score. It is the body's
        unexpected energetic improvement or damage during this same life step.
        """
        if self._prediction is None or self._predict_feature is None:
            return

        next_sensor = np.asarray(next_sensor, dtype=float)
        next_sensor = np.clip(next_sensor, -1.0, 1.0)

        # --- Local predictive learning --------------------------------------
        prediction_error = next_sensor - self._prediction
        prediction_rms = float(np.sqrt(np.mean(prediction_error ** 2)))
        expected_error = self.surprise
        self.surprise = 0.985 * self.surprise + 0.015 * prediction_rms
        self.last_prediction_rms = prediction_rms

        local_delta = prediction_error * (1.0 - self._prediction ** 2)
        self.w_predict += 0.0018 * np.outer(local_delta, self._predict_feature)
        np.clip(self.w_predict, -3.0, 3.0, out=self.w_predict)

        # Learning progress is mildly interesting while the body is safe.
        energy = clamp((float(next_sensor[3]) + 1.0) * 0.5, 0.0, 1.0)
        learning_progress = clamp(expected_error - prediction_rms, -0.20, 0.20)
        curiosity = 0.004 * energy * learning_progress

        # The third factor: change in bodily viability + tiny learning progress.
        modulator = clamp(float(body_signal) + curiosity, -0.30, 0.30)
        self.reward_baseline = (
            0.995 * self.reward_baseline + 0.005 * modulator
        )
        advantage = modulator - self.reward_baseline
        self.last_modulator = modulator

        # --- Three-factor motor/recurrent plasticity ------------------------
        self.w_motor += 0.0080 * advantage * self.motor_trace
        self.w_rec += 0.000018 * advantage * self.rec_trace

        # Very slow Oja-like local stabilization: correlated transitions remain,
        # but runaway recurrent growth is opposed locally.
        hebb = np.outer(self.hidden, self.prev_hidden)
        oja = hebb - (self.hidden[:, None] ** 2) * self.w_rec
        self.w_rec += 0.000002 * oja * self.rec_mask
        self.w_rec *= self.rec_mask

        # --- Neuronal homeostasis -------------------------------------------
        self.activity_mean = (
            0.995 * self.activity_mean + 0.005 * self.hidden
        )
        self.activity_square = (
            0.995 * self.activity_square + 0.005 * (self.hidden ** 2)
        )
        self.bias -= 0.00012 * self.activity_mean
        self.gain += 0.000055 * (0.16 - self.activity_square)
        np.clip(self.bias, -1.2, 1.2, out=self.bias)
        np.clip(self.gain, 0.55, 1.85, out=self.gain)

        # Tiny forgetting keeps the organism adaptable for a long life.
        self.w_motor *= 0.9999995
        np.clip(self.w_motor, -2.5, 2.5, out=self.w_motor)
        np.clip(self.w_rec, -1.2, 1.2, out=self.w_rec)
        self._limit_recurrent_rows(max_l1=1.28)

        self.step_count += 1
        if self.step_count % 900 == 0:
            self._rewire_weak_connections()

    def neural_cost(self):
        """Metabolic cost of maintaining current neural activity."""
        return float(np.mean(self.hidden ** 2))

    def _limit_recurrent_rows(self, max_l1):
        row_l1 = np.sum(np.abs(self.w_rec), axis=1)
        scale = np.maximum(1.0, row_l1 / max_l1)
        self.w_rec /= scale[:, None]

    def _rewire_weak_connections(self):
        """Slow structural plasticity: prune weak edges and sprout replacements."""
        allowed = ~np.eye(self.n_hidden, dtype=bool)
        active_flat = np.flatnonzero(self.rec_mask & allowed)
        inactive_flat = np.flatnonzero((~self.rec_mask) & allowed)
        if active_flat.size == 0 or inactive_flat.size == 0:
            return

        amount = max(1, int(active_flat.size * 0.01))
        amount = min(amount, inactive_flat.size)

        importance = (
            np.abs(self.w_rec).ravel()[active_flat]
            + 0.025 * np.abs(self.rec_trace).ravel()[active_flat]
        )
        prune_order = np.argsort(importance)[:amount]
        prune_flat = active_flat[prune_order]
        grow_flat = self.rng.choice(inactive_flat, size=amount, replace=False)

        mask_flat = self.rec_mask.ravel()
        weight_flat = self.w_rec.ravel()
        trace_flat = self.rec_trace.ravel()

        mask_flat[prune_flat] = False
        weight_flat[prune_flat] = 0.0
        trace_flat[prune_flat] = 0.0

        mask_flat[grow_flat] = True
        weight_flat[grow_flat] = self.rng.normal(0.0, 0.045, size=amount)
        trace_flat[grow_flat] = 0.0

        self.rewire_count += int(amount)
        self._limit_recurrent_rows(max_l1=1.20)

    # --- Persistence ---------------------------------------------------------

    def state_dict(self):
        return {
            'brain_w_in': self.w_in,
            'brain_w_rec': self.w_rec,
            'brain_rec_mask': self.rec_mask.astype(np.uint8),
            'brain_w_motor': self.w_motor,
            'brain_w_predict': self.w_predict,
            'brain_bias': self.bias,
            'brain_gain': self.gain,
            'brain_hidden': self.hidden,
            'brain_prev_hidden': self.prev_hidden,
            'brain_motor_trace': self.motor_trace,
            'brain_exploration_state': self.exploration_state,
            'brain_rec_trace': self.rec_trace,
            'brain_activity_mean': self.activity_mean,
            'brain_activity_square': self.activity_square,
            'brain_reward_baseline': np.array(self.reward_baseline),
            'brain_surprise': np.array(self.surprise),
            'brain_step_count': np.array(self.step_count, dtype=np.int64),
            'brain_rewire_count': np.array(self.rewire_count, dtype=np.int64),
        }

    def load_state(self, data):
        # Shape validation prevents a stale or incompatible save from silently
        # corrupting the simulation.
        expected = {
            'brain_w_in': self.w_in.shape,
            'brain_w_rec': self.w_rec.shape,
            'brain_rec_mask': self.rec_mask.shape,
            'brain_w_motor': self.w_motor.shape,
            'brain_w_predict': self.w_predict.shape,
            'brain_bias': self.bias.shape,
            'brain_gain': self.gain.shape,
            'brain_hidden': self.hidden.shape,
            'brain_prev_hidden': self.prev_hidden.shape,
            'brain_motor_trace': self.motor_trace.shape,
            'brain_exploration_state': self.exploration_state.shape,
            'brain_rec_trace': self.rec_trace.shape,
            'brain_activity_mean': self.activity_mean.shape,
            'brain_activity_square': self.activity_square.shape,
        }
        for key, shape in expected.items():
            if key not in data or tuple(data[key].shape) != tuple(shape):
                raise ValueError('Incompatible brain state: ' + key)

        self.w_in = np.array(data['brain_w_in'], dtype=float)
        self.w_rec = np.array(data['brain_w_rec'], dtype=float)
        self.rec_mask = np.array(data['brain_rec_mask'], dtype=bool)
        self.w_motor = np.array(data['brain_w_motor'], dtype=float)
        self.w_predict = np.array(data['brain_w_predict'], dtype=float)
        self.bias = np.array(data['brain_bias'], dtype=float)
        self.gain = np.array(data['brain_gain'], dtype=float)
        self.hidden = np.array(data['brain_hidden'], dtype=float)
        self.prev_hidden = np.array(data['brain_prev_hidden'], dtype=float)
        self.motor_trace = np.array(data['brain_motor_trace'], dtype=float)
        self.exploration_state = np.array(
            data['brain_exploration_state'], dtype=float
        )
        self.rec_trace = np.array(data['brain_rec_trace'], dtype=float)
        self.activity_mean = np.array(data['brain_activity_mean'], dtype=float)
        self.activity_square = np.array(data['brain_activity_square'], dtype=float)

        self.reward_baseline = float(data['brain_reward_baseline'])
        self.surprise = float(data['brain_surprise'])
        self.step_count = int(data['brain_step_count'])
        self.rewire_count = int(data['brain_rewire_count'])
        self.w_rec *= self.rec_mask
        self._limit_recurrent_rows(max_l1=1.28)


# -----------------------------------------------------------------------------
# Embodied world
# -----------------------------------------------------------------------------

class SomaWorld(Scene):

    def setup(self):
        self.background_color = '#071014'
        self.brain = SomaBrain()

        self.energy = 0.80
        self.age = 0.0
        self.eaten = 0
        self.alive = True
        self.pos = np.array([
            self.size.w * 0.5,
            ARENA_BOTTOM + self.play_height * 0.5,
        ])
        self.vel = np.zeros(2, dtype=float)
        self.last_action = np.zeros(2, dtype=float)
        self.food_positions = [self._random_food_position() for _ in range(FOOD_COUNT)]

        self.body = circle_node(BODY_RADIUS, '#55E6C1', '#B9FFF0', parent=self)
        self.core = circle_node(6.5, '#E8FFF9', 'clear', parent=self.body)

        self.neuron_nodes = []
        visible_neurons = 16
        for i in range(visible_neurons):
            angle = 2.0 * math.pi * i / visible_neurons
            node = circle_node(1.65, '#D7FFF7', 'clear', parent=self.body)
            node.position = (9.8 * math.cos(angle), 9.8 * math.sin(angle))
            self.neuron_nodes.append(node)

        self.food_nodes = []
        for _ in range(FOOD_COUNT):
            node = circle_node(FOOD_RADIUS, '#FFCA58', '#FFF0B8', parent=self)
            self.food_nodes.append(node)

        self.energy_bg = SpriteNode(
            texture=None, color='#26363B', size=(210, 9), parent=self
        )
        self.energy_bg.anchor_point = (0.0, 0.5)
        self.energy_fg = SpriteNode(
            texture=None, color='#55E6C1', size=(210, 9), parent=self
        )
        self.energy_fg.anchor_point = (0.0, 0.5)

        self.info_label = LabelNode('', font=('Menlo', 11), parent=self)
        self.info_label.anchor_point = (0.0, 1.0)
        self.info_label.color = '#DCEAEC'

        self.help_label = LabelNode(
            'tap: move food   save: automatic',
            font=('Menlo', 10),
            parent=self,
        )
        self.help_label.anchor_point = (1.0, 1.0)
        self.help_label.color = '#789399'

        self.death_label = LabelNode(
            'DORMANT — tap to regenerate with the same brain',
            font=('Menlo-Bold', 15),
            parent=self,
        )
        self.death_label.color = '#FF7A7A'
        self.death_label.alpha = 0.0

        self.last_save_time = 0.0
        self._layout_hud()
        self._load_life_if_possible()
        self._sync_nodes()

    @property
    def arena_top(self):
        return max(ARENA_BOTTOM + 80.0, float(self.size.h) - HUD_HEIGHT)

    @property
    def play_height(self):
        return self.arena_top - ARENA_BOTTOM

    def did_change_size(self):
        if hasattr(self, 'info_label'):
            self._layout_hud()
            self.pos[0] = clamp(self.pos[0], 0.0, float(self.size.w))
            self.pos[1] = clamp(self.pos[1], ARENA_BOTTOM, self.arena_top)

    def _layout_hud(self):
        top = float(self.size.h) - 8.0
        self.info_label.position = (10.0, top)
        self.help_label.position = (float(self.size.w) - 10.0, top)
        self.energy_bg.position = (10.0, float(self.size.h) - 51.0)
        self.energy_fg.position = self.energy_bg.position
        self.death_label.position = (
            float(self.size.w) * 0.5,
            ARENA_BOTTOM + self.play_height * 0.5,
        )

    def update(self):
        dt = clamp(float(self.dt), 1.0 / 120.0, 1.0 / 15.0)

        if self.alive:
            sensor = self._make_sensor()
            action = self.brain.act(sensor, self.energy)
            body_signal = self._apply_body_and_world(action, dt)
            next_sensor = self._make_sensor()
            self.brain.learn(next_sensor, body_signal)
            self.last_action = np.array(action, dtype=float)
            self.age += dt

            if self.energy <= 0.0:
                self.energy = 0.0
                self.alive = False
                self.vel[:] = 0.0
                # Strong bodily failure reaches the still-plastic traces once.
                self.brain.learn(self._make_sensor(), -0.25)

        self._sync_nodes()

        if self.t - self.last_save_time >= 20.0:
            self._save_life()
            self.last_save_time = self.t

    def _apply_body_and_world(self, action, dt):
        previous_energy = self.energy

        # Continuous body dynamics. The action specifies a desired velocity;
        # the body approaches it with inertia instead of teleporting.
        max_speed = 105.0
        target_velocity = np.asarray(action, dtype=float) * max_speed
        response = 1.0 - math.exp(-3.5 * dt)
        self.vel += (target_velocity - self.vel) * response

        self.pos += self.vel * dt
        self._wrap_position(self.pos)

        # Metabolism: merely existing, moving, and neural firing all cost energy.
        basal_cost = 0.0018 * dt
        movement_cost = 0.0018 * float(np.dot(action, action)) * dt
        neural_cost = 0.0007 * self.brain.neural_cost() * dt
        self.energy -= basal_cost + movement_cost + neural_cost

        # Food is never labelled "good" for the brain. Contact simply changes
        # the body, and that consequence becomes the modulatory signal.
        for i, food in enumerate(self.food_positions):
            delta = self._wrapped_delta(self.pos, food)
            if float(np.linalg.norm(delta)) < BODY_RADIUS + FOOD_RADIUS:
                self.energy = min(1.0, self.energy + 0.16)
                self.eaten += 1
                self.food_positions[i] = self._random_food_position()

        self.energy = clamp(self.energy, 0.0, 1.0)

        # Remove unavoidable basal loss from the learning signal. Movement,
        # neural expense, food, and damage remain meaningful consequences.
        return (self.energy - previous_energy) + basal_cost

    def _make_sensor(self):
        nearest_delta = np.zeros(2, dtype=float)
        nearest_distance = 1e9
        for food in self.food_positions:
            delta = self._wrapped_delta(self.pos, food)
            distance = float(np.linalg.norm(delta))
            if distance < nearest_distance:
                nearest_distance = distance
                nearest_delta = delta

        half_w = max(1.0, float(self.size.w) * 0.5)
        half_h = max(1.0, self.play_height * 0.5)
        world_diag = math.hypot(half_w, half_h)
        proximity = math.exp(-3.5 * nearest_distance / max(1.0, world_diag))

        max_speed = 105.0
        surprise_sensor = clamp(self.brain.surprise * 2.5, 0.0, 1.0)

        sensor = np.array([
            nearest_delta[0] / half_w,          # nearest food x direction
            nearest_delta[1] / half_h,          # nearest food y direction
            proximity * 2.0 - 1.0,              # food proximity
            self.energy * 2.0 - 1.0,            # internal energy
            self.vel[0] / max_speed,             # own velocity x
            self.vel[1] / max_speed,             # own velocity y
            self.last_action[0],                 # previous motor state x
            self.last_action[1],                 # previous motor state y
            surprise_sensor * 2.0 - 1.0,         # prediction uncertainty
            1.0,                                 # tonic/bias receptor
        ], dtype=float)
        return np.clip(sensor, -1.0, 1.0)

    def _random_food_position(self):
        x = self.brain.rng.uniform(18.0, max(19.0, float(self.size.w) - 18.0))
        y = self.brain.rng.uniform(
            ARENA_BOTTOM + 18.0,
            max(ARENA_BOTTOM + 19.0, self.arena_top - 18.0),
        )
        return np.array([x, y], dtype=float)

    def _wrapped_delta(self, source, target):
        dx = float(target[0] - source[0])
        width = max(1.0, float(self.size.w))
        if dx > width * 0.5:
            dx -= width
        elif dx < -width * 0.5:
            dx += width

        dy = float(target[1] - source[1])
        height = max(1.0, self.play_height)
        if dy > height * 0.5:
            dy -= height
        elif dy < -height * 0.5:
            dy += height
        return np.array([dx, dy], dtype=float)

    def _wrap_position(self, position):
        width = max(1.0, float(self.size.w))
        height = max(1.0, self.play_height)
        position[0] %= width
        position[1] = ARENA_BOTTOM + ((position[1] - ARENA_BOTTOM) % height)

    def _sync_nodes(self):
        self.body.position = (float(self.pos[0]), float(self.pos[1]))
        for node, position in zip(self.food_nodes, self.food_positions):
            node.position = (float(position[0]), float(position[1]))

        for i, node in enumerate(self.neuron_nodes):
            activity = abs(float(self.brain.hidden[i]))
            node.alpha = 0.18 + 0.82 * activity
            node.scale = 0.72 + 0.48 * activity

        self.core.alpha = 0.35 + 0.65 * self.energy
        self.body.alpha = 1.0 if self.alive else 0.28
        self.death_label.alpha = 0.0 if self.alive else 1.0

        self.energy_fg.size = (max(1.0, 210.0 * self.energy), 9.0)

        rec_edges = int(np.count_nonzero(self.brain.rec_mask))
        self.info_label.text = (
            'SOMA-0  age {:6.1f}s  E {:.3f}  food {}\n'
            'predict {:.3f}  M {:+.4f}  sigma {:.2f}  rec {}  rewired {}'
        ).format(
            self.age,
            self.energy,
            self.eaten,
            self.brain.last_prediction_rms,
            self.brain.last_modulator,
            self.brain.last_sigma,
            rec_edges,
            self.brain.rewire_count,
        )

    # --- Touch ---------------------------------------------------------------

    def touch_began(self, touch):
        x = clamp(float(touch.location.x), 10.0, float(self.size.w) - 10.0)
        y = clamp(float(touch.location.y), ARENA_BOTTOM + 10.0, self.arena_top - 10.0)

        if not self.alive:
            # Research convenience: body regenerates but acquired synapses stay.
            self.energy = 0.38
            self.vel[:] = 0.0
            self.pos[:] = (x, y)
            self.alive = True
            self._save_life()
            return

        # Move the nearest food to the touched point. This tests whether the
        # organism has learned a general relation rather than one fixed route.
        touch_point = np.array([x, y], dtype=float)
        distances = [
            float(np.linalg.norm(self._wrapped_delta(touch_point, food)))
            for food in self.food_positions
        ]
        index = int(np.argmin(distances))
        self.food_positions[index] = touch_point

    # --- Persistence ---------------------------------------------------------

    def _save_life(self):
        try:
            width = max(1.0, float(self.size.w))
            height = max(1.0, self.play_height)
            pos_norm = np.array([
                self.pos[0] / width,
                (self.pos[1] - ARENA_BOTTOM) / height,
            ])
            food_norm = np.array([
                [p[0] / width, (p[1] - ARENA_BOTTOM) / height]
                for p in self.food_positions
            ])
            vel_norm = np.array([
                self.vel[0] / width,
                self.vel[1] / height,
            ])

            state = self.brain.state_dict()
            state.update({
                'save_version': np.array(SAVE_VERSION, dtype=np.int64),
                'life_energy': np.array(self.energy),
                'life_age': np.array(self.age),
                'life_eaten': np.array(self.eaten, dtype=np.int64),
                'life_alive': np.array(1 if self.alive else 0, dtype=np.uint8),
                'life_pos_norm': pos_norm,
                'life_vel_norm': vel_norm,
                'life_food_norm': food_norm,
                'life_last_action': self.last_action,
            })
            np.savez(SAVE_FILE, **state)
        except Exception as exc:
            print('SOMA-0 save failed:', exc)

    def _load_life_if_possible(self):
        if not os.path.exists(SAVE_FILE):
            return
        try:
            with np.load(SAVE_FILE, allow_pickle=False) as data:
                version = int(data['save_version'])
                if version != SAVE_VERSION:
                    raise ValueError('Unsupported save version')

                self.brain.load_state(data)
                self.energy = clamp(float(data['life_energy']), 0.0, 1.0)
                self.age = max(0.0, float(data['life_age']))
                self.eaten = max(0, int(data['life_eaten']))
                self.alive = bool(int(data['life_alive']))
                self.last_action = np.array(data['life_last_action'], dtype=float)

                width = max(1.0, float(self.size.w))
                height = max(1.0, self.play_height)
                pos_norm = np.array(data['life_pos_norm'], dtype=float)
                vel_norm = np.array(data['life_vel_norm'], dtype=float)
                food_norm = np.array(data['life_food_norm'], dtype=float)

                if pos_norm.shape != (2,) or vel_norm.shape != (2,):
                    raise ValueError('Invalid body save')
                if food_norm.shape != (FOOD_COUNT, 2):
                    raise ValueError('Invalid food save')

                self.pos = np.array([
                    clamp(pos_norm[0], 0.0, 1.0) * width,
                    ARENA_BOTTOM + clamp(pos_norm[1], 0.0, 1.0) * height,
                ])
                self.vel = np.array([
                    vel_norm[0] * width,
                    vel_norm[1] * height,
                ])
                self.food_positions = [
                    np.array([
                        clamp(p[0], 0.0, 1.0) * width,
                        ARENA_BOTTOM + clamp(p[1], 0.0, 1.0) * height,
                    ])
                    for p in food_norm
                ]
        except Exception as exc:
            print('SOMA-0 load ignored:', exc)

    def pause(self):
        self._save_life()

    def stop(self):
        self._save_life()


if __name__ == '__main__':
    # 30 fps is enough for this organism and reduces heat/battery use on iPhone.
    run(
        SomaWorld(),
        orientation=LANDSCAPE,
        frame_interval=2,
        anti_alias=True,
        show_fps=False,
        multi_touch=True,
    )
