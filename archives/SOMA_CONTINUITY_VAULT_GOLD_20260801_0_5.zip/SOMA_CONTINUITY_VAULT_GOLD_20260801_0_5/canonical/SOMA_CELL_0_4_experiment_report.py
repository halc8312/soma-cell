# coding: utf-8
"""Build a human-readable report from the official SOMA-CELL 0.4 CSVs."""
from __future__ import division

import csv
import os
import statistics

BASE_DIR = os.path.dirname(__file__)
RESULTS = os.path.join(BASE_DIR, 'soma_cell_0_4_experiment_results.csv')
OUTPUT = os.path.join(BASE_DIR, 'SOMA_CELL_0_4_EXPERIMENT_REPORT.txt')


def number(row, key, default=0.0):
    try:
        return float(row.get(key, default))
    except (TypeError, ValueError):
        return float(default)


def mean(rows, key):
    values = [number(row, key) for row in rows if row.get(key, '') not in ('', None)]
    return statistics.mean(values) if values else 0.0


def group(rows, condition):
    return sorted(
        [row for row in rows if row.get('condition') == condition],
        key=lambda row: int(row['seed']),
    )


def paired(rows, treatment, control, key):
    left = {int(row['seed']): number(row, key) for row in group(rows, treatment)}
    right = {int(row['seed']): number(row, key) for row in group(rows, control)}
    seeds = sorted(set(left) & set(right))
    differences = [left[seed] - right[seed] for seed in seeds]
    return differences


def run_report():
    with open(RESULTS, 'r', encoding='utf-8', newline='') as handle:
        rows = list(csv.DictReader(handle))
    behaviour = [row for row in rows if row['mode'] == 'behaviour']
    division = [row for row in rows if row['mode'] == 'division']

    conditions = [
        'patchy_adaptive', 'patchy_no_plasticity', 'patchy_no_motion',
        'patchy_no_sensorimotor', 'patchy_fixed_reflex', 'uniform_adaptive',
        'reversal_adaptive', 'reversal_no_plasticity',
        'reversal_fixed_reflex', 'reversal_no_motion',
    ]
    lines = [
        'SOMA-CELL 0.4 OFFICIAL EXPERIMENT REPORT',
        '========================================',
        '',
        'Design: 3 seeds x 10 behavioural conditions x 100 simulated seconds,',
        'plus 3 full-chemistry first-division trials. Behavioural trials disable',
        'division to isolate lifetime sensorimotor effects.',
        '',
        'CONDITION MEANS',
        '---------------',
        'condition                    margin    post-switch   fuel distance   contamination',
    ]
    for condition in conditions:
        items = group(behaviour, condition)
        lines.append('{:28s} {:8.5f} {:12.5f} {:15.5f} {:14.5f}'.format(
            condition,
            mean(items, 'mean_margin_over_life'),
            mean(items, 'post_switch_mean_margin'),
            mean(items, 'mean_fuel_patch_distance'),
            mean(items, 'fuel_contamination_total'),
        ))

    comparisons = [
        ('patchy_adaptive', 'patchy_no_motion'),
        ('patchy_adaptive', 'patchy_no_sensorimotor'),
        ('patchy_adaptive', 'patchy_no_plasticity'),
        ('reversal_adaptive', 'reversal_no_plasticity'),
        ('reversal_adaptive', 'reversal_fixed_reflex'),
        ('reversal_adaptive', 'reversal_no_motion'),
    ]
    lines.extend(['', 'PAIRED MARGIN DIFFERENCES', '-------------------------'])
    for treatment, control in comparisons:
        differences = paired(behaviour, treatment, control, 'mean_margin_over_life')
        lines.append('{} - {}: mean {:+.6f}, wins {}/{}, values {}'.format(
            treatment, control,
            statistics.mean(differences),
            sum(value > 0.0 for value in differences), len(differences),
            ', '.join('{:+.6f}'.format(value) for value in differences),
        ))

    post = paired(
        behaviour, 'reversal_adaptive', 'reversal_no_plasticity',
        'post_switch_mean_margin',
    )
    contamination = paired(
        behaviour, 'reversal_adaptive', 'reversal_no_plasticity',
        'fuel_contamination_total',
    )
    lines.extend([
        '',
        'REVERSAL-SPECIFIC DIAGNOSIS',
        '---------------------------',
        'adaptive - no-plasticity post-switch margin: mean {:+.6f}, wins {}/3, values {}'.format(
            statistics.mean(post), sum(value > 0.0 for value in post),
            ', '.join('{:+.6f}'.format(value) for value in post),
        ),
        'adaptive - no-plasticity contaminated fuel: mean {:+.6f}, lower exposure in {}/3, values {}'.format(
            statistics.mean(contamination), sum(value < 0.0 for value in contamination),
            ', '.join('{:+.6f}'.format(value) for value in contamination),
        ),
        '',
        'Interpretation: adaptive cells retained a higher post-switch self-production',
        'margin in all three seeds, but did not consistently reduce contact with the',
        'newly harmful fuel. Therefore the experiment supports useful lifetime',
        'adaptation, not a robustly demonstrated semantic sign reversal.',
    ])

    ages = [number(row, 'first_division_age') for row in division if row.get('first_division_age')]
    residuals = [abs(number(row, 'division_residual')) for row in division]
    lines.extend([
        '',
        'PHYSICAL FIRST DIVISION',
        '-----------------------',
        'divided: {}/{}'.format(len(ages), len(division)),
        'ages: {}'.format(', '.join('{:.2f}'.format(value) for value in ages)),
        'mean age: {:.2f}'.format(statistics.mean(ages) if ages else 0.0),
        'maximum |division ledger residual|: {:.3e}'.format(max(residuals) if residuals else 0.0),
        '',
        'BOUNDARIES OF THE RESULT',
        '------------------------',
        '- n=3 is a mechanism check, not a population-level statistical proof.',
        '- Natural functional-meaning signs did not reliably reverse after the switch.',
        '- The chemistry grammar, receptor grammar, effector grammar and learning law',
        '  are still human-designed.',
        '- The full physical simulation reached one generation; long evolutionary',
        '  sensorimotor adaptation is not yet demonstrated.',
    ])
    with open(OUTPUT, 'w', encoding='utf-8') as handle:
        handle.write('\n'.join(lines) + '\n')
    print('\n'.join(lines))
    return OUTPUT


if __name__ == '__main__':
    run_report()
