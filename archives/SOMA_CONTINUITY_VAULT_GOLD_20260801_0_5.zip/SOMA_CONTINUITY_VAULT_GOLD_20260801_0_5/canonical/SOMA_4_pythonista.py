# coding: utf-8
"""
SOMA-4 — Falsification Compiler / 反証コンパイラ
Pythonista 3 向け

必要ファイル（同じフォルダ）
- SOMA_1_pythonista.py
- SOMA_2_pythonista.py
- SOMA_2_1_pythonista.py
- SOMA_3_pythonista.py
- SOMA_4_pythonista.py

SOMA-3 は固定された原始介入（8方向パルスと休止）から問いを選んだ。
SOMA-4 は、現在の神経組織・因果監査・器官・身体負債から「壊す価値のある
因果主張」を抽出し、その主張の一リンクだけを外す最小の対照実験を組み立てる。

    structural claim
        sensor -> audited cell coalition -> motor tendency -> body maintenance

    compiled experiment
        reference program  versus  matched counterexample program

プログラムは最大3命令からなる。命令は、微小運動、休止、感覚遮断、神経細胞群
の出力停止、器官差分の一時撤去である。命令には実行区間があるため、同時介入だけ
でなく A→B と B→A の順序比較も生成できる。比較は ABBA/BAAB で実行される。

反証された主張は単なるログにならない。関連細胞の資源ゲートを弱め、成熟度を少し
戻し、予測誤差を再び開く。つまり「間違いを見つけること」が再可塑化を起こす。

研究仮説を動く形にしたモデルであり、意識・生命・学術的新規性を証明しない。
"""

import json
import math
import os
import numpy as np

import SOMA_1_pythonista as soma1
import SOMA_2_pythonista as soma2
import SOMA_2_1_pythonista as soma21
import SOMA_3_pythonista as soma3
from SOMA_1_pythonista import (
    CELL_COUNT,
    SENSOR_COUNT,
    TROPHIC_COUNT,
    MAX_SPEED,
    clamp,
)
from SOMA_2_pythonista import (
    MORPH_SENSOR,
    MORPH_FIN,
    MORPH_SHELL,
    MORPH_SLOT_COUNT,
    MORPH_MODALITY_COUNT,
    scalar_array,
    bool_array,
)
from SOMA_3_pythonista import SomaThreeCore

SAVE_FILE = os.path.join(os.path.dirname(__file__), 'soma4_life.npz')
SAVE_VERSION = 6

# -----------------------------------------------------------------------------
# Executable intervention language
# -----------------------------------------------------------------------------

OP_NONE = 0
OP_MOTOR = 1
OP_REST = 2
OP_SENSOR_MASK = 3
OP_NEURAL_KO = 4
OP_ORGAN_DAMP = 5
OP_NEURAL_STIM = 6
OP_ORGAN_BOOST = 7

OP_NAMES = (
    'none', 'motor', 'rest', 'sensor-mask', 'neural-KO', 'organ-damp',
    'neural-stim', 'organ-boost'
)

MAX_PROGRAM_STEPS = 3
PROGRAM_PERIODS = 4
PROGRAM_CONTEXT_DIM = 7
MAX_CLAIMS = 64

CLAIM_SENSOR_MEDIATION = 0
CLAIM_NEURAL_MEDIATION = 1
CLAIM_ORGAN_MEDIATION = 2
CLAIM_ORDER = 3
CLAIM_NEURAL_RESCUE = 4
CLAIM_ORGAN_DOSE = 5
CLAIM_NAMES = (
    'sensor-path', 'cell-path', 'organ-path', 'order-path',
    'neural-rescue', 'organ-dose'
)

# Sensor groups are intentionally coarse. A claim is about a functional receptor
# family, not one arbitrary scalar channel.
SENSOR_GROUPS = (
    np.array([0, 1, 2], dtype=np.int16),       # chemical A
    np.array([3, 4, 5], dtype=np.int16),       # chemical B
    np.array([6, 7, 8], dtype=np.int16),       # chemical C
    np.array([9, 10, 11], dtype=np.int16),     # temperature
    np.array([12, 13, 14, 15, 20], dtype=np.int16),  # interoception/pain
    np.array([16, 17, 18, 19], dtype=np.int16),      # proprioception/action
    np.array([21, 22], dtype=np.int16),        # neural distress/uncertainty
)
SENSOR_GROUP_NAMES = (
    'chemical-A', 'chemical-B', 'chemical-C', 'thermal',
    'interoception', 'proprioception', 'tissue-state',
)
TROPHIC_NAMES = ('energy', 'thermal', 'integrity', 'fatigue')
DIR_NAMES = ('E', 'NE', 'N', 'NW', 'W', 'SW', 'S', 'SE')


def _unit_directions():
    angles = np.arange(8, dtype=float) * (2.0 * math.pi / 8.0)
    return np.column_stack((np.cos(angles), np.sin(angles)))


def _empty_program():
    return {
        'opcode': np.zeros(MAX_PROGRAM_STEPS, dtype=np.int8),
        'arg0': np.zeros(MAX_PROGRAM_STEPS, dtype=np.int16),
        'arg1': np.zeros(MAX_PROGRAM_STEPS, dtype=np.int16),
        'strength': np.zeros(MAX_PROGRAM_STEPS, dtype=float),
        'start': np.zeros(MAX_PROGRAM_STEPS, dtype=float),
        'end': np.zeros(MAX_PROGRAM_STEPS, dtype=float),
    }


def _program(*ops):
    """Build a fixed-size program from tuples.

    Tuple format: (opcode, arg0, arg1, strength, start_fraction, end_fraction)
    """
    p = _empty_program()
    for i, op in enumerate(ops[:MAX_PROGRAM_STEPS]):
        p['opcode'][i] = int(op[0])
        p['arg0'][i] = int(op[1])
        p['arg1'][i] = int(op[2])
        p['strength'][i] = float(op[3])
        p['start'][i] = clamp(float(op[4]), 0.0, 1.0)
        p['end'][i] = clamp(float(op[5]), p['start'][i], 1.0)
    return p


def _copy_program(program):
    return {key: np.array(value, copy=True) for key, value in program.items()}


def _program_complexity(program):
    active = program['opcode'] != OP_NONE
    count = int(np.count_nonzero(active))
    temporal = 0.0
    for i in np.flatnonzero(active):
        temporal += max(0.0, float(program['end'][i] - program['start'][i]))
    return float(count + 0.30 * temporal)


def _program_text(program):
    bits = []
    for i in range(MAX_PROGRAM_STEPS):
        op = int(program['opcode'][i])
        if op == OP_NONE:
            continue
        a0 = int(program['arg0'][i])
        a1 = int(program['arg1'][i])
        strength = float(program['strength'][i])
        window = '{:.0f}-{:.0f}%'.format(
            100.0 * float(program['start'][i]),
            100.0 * float(program['end'][i]),
        )
        if op == OP_MOTOR:
            label = '{} {:.2f}'.format(DIR_NAMES[a0 % 8], strength)
        elif op == OP_REST:
            label = 'rest {:.2f}'.format(strength)
        elif op == OP_SENSOR_MASK:
            label = 'mask {} {:.2f}'.format(SENSOR_GROUP_NAMES[a0], strength)
        elif op == OP_NEURAL_KO:
            label = 'coalition-KO {:.2f}'.format(strength)
        elif op == OP_ORGAN_DAMP:
            kind = ('sensor', 'fin', 'shell')[max(0, min(2, a0))]
            label = 'damp {} slot{} {:.2f}'.format(kind, a1, strength)
        elif op == OP_NEURAL_STIM:
            label = 'coalition-STIM {:.2f}'.format(strength)
        elif op == OP_ORGAN_BOOST:
            kind = ('sensor', 'fin', 'shell')[max(0, min(2, a0))]
            label = 'boost {} slot{} {:.2f}'.format(kind, a1, strength)
        else:
            label = OP_NAMES[op]
        bits.append(label + '@' + window)
    return ' + '.join(bits) if bits else 'intact'


class FalsificationCompiler:
    """Compiles minimal embodied counterexamples against causal claims.

    It does not search arbitrary Python code. It searches a deliberately small,
    inspectable intervention language. Each candidate is a pair of programs:
    a reference that leaves a claimed pathway intact and a challenge that removes
    one link while matching the rest of the intervention as closely as possible.
    """

    def __init__(
        self,
        seed=0,
        enabled=True,
        feedback_enabled=True,
        safety_enabled=True,
        allow_composite=True,
        random_selection=False,
        minimal_counterexample=True,
        value_threshold=0.018,
    ):
        self.rng = np.random.default_rng(int(seed) + 440041)
        self.enabled = bool(enabled)
        self.feedback_enabled = bool(feedback_enabled)
        self.safety_enabled = bool(safety_enabled)
        self.allow_composite = bool(allow_composite)
        self.random_selection = bool(random_selection)
        self.minimal_counterexample = bool(minimal_counterexample)
        self.value_threshold = float(value_threshold)
        self.directions = _unit_directions()

        # Fixed-capacity causal-claim memory; no pickle/object arrays are needed.
        self.claim_used = np.zeros(MAX_CLAIMS, dtype=bool)
        self.claim_key = np.full((MAX_CLAIMS, 5), -1, dtype=np.int16)
        self.claim_alpha = np.ones(MAX_CLAIMS, dtype=float)
        self.claim_beta = np.ones(MAX_CLAIMS, dtype=float)
        self.claim_effect_mean = np.zeros((MAX_CLAIMS, TROPHIC_COUNT), dtype=float)
        self.claim_effect_m2 = np.zeros((MAX_CLAIMS, TROPHIC_COUNT), dtype=float)
        self.claim_effect_weight = np.zeros(MAX_CLAIMS, dtype=float)
        self.claim_context = np.zeros((MAX_CLAIMS, PROGRAM_CONTEXT_DIM), dtype=float)
        self.claim_context_weight = np.zeros(MAX_CLAIMS, dtype=float)
        self.claim_risk_mean = np.full(MAX_CLAIMS, 0.10, dtype=float)
        self.claim_risk_weight = np.full(MAX_CLAIMS, 0.5, dtype=float)
        self.claim_last_age = np.full(MAX_CLAIMS, -1e9, dtype=float)
        self.claim_next_allowed = np.zeros(MAX_CLAIMS, dtype=float)
        self.claim_trials = np.zeros(MAX_CLAIMS, dtype=np.int32)
        self.claim_supports = np.zeros(MAX_CLAIMS, dtype=np.int32)
        self.claim_contradictions = np.zeros(MAX_CLAIMS, dtype=np.int32)
        self.claim_signature = np.zeros((MAX_CLAIMS, CELL_COUNT), dtype=float)

        self.active = False
        self.claim_slot = -1
        self.claim_type = -1
        self.target_currency = 0
        self.expected_sign = 1.0
        self.reference = _empty_program()
        self.challenge = _empty_program()
        self.coalition_mask = np.zeros(CELL_COUNT, dtype=bool)
        self.sequence = np.zeros(PROGRAM_PERIODS, dtype=np.int8)
        self.period_index = 0
        self.period_elapsed = 0.0
        self.period_duration = 1.55
        self.washout_duration = 0.45
        self.washout = False
        self.start_debt = np.zeros(TROPHIC_COUNT, dtype=float)
        self.pretrial_debt = np.zeros(TROPHIC_COUNT, dtype=float)
        self.abort_debt = np.zeros(TROPHIC_COUNT, dtype=float)
        self.period_rates = np.zeros((PROGRAM_PERIODS, TROPHIC_COUNT), dtype=float)
        self.period_context = np.zeros((PROGRAM_PERIODS, PROGRAM_CONTEXT_DIM), dtype=float)
        self.period_event = np.zeros(PROGRAM_PERIODS, dtype=np.int16)
        self.period_complete = np.zeros(PROGRAM_PERIODS, dtype=bool)
        self.segment_context_sum = np.zeros(PROGRAM_CONTEXT_DIM, dtype=float)
        self.segment_context_time = 0.0
        self.segment_event_mask = 0

        self.cooldown = 12.0
        self.compiled = 0
        self.completed = 0
        self.aborted = 0
        self.deferred = 0
        self.supported = 0
        self.contradicted = 0
        self.inconclusive = 0
        self.composite_completed = 0
        self.reopened_cells = 0
        self.feedback_events = 0
        self.total_program_complexity = 0.0
        self.last_value = 0.0
        self.last_risk = 0.0
        self.last_quality = 0.0
        self.last_effect = np.zeros(TROPHIC_COUNT, dtype=float)
        self.last_support_probability = 0.5
        self.last_status = 'waiting'
        self.last_claim_text = 'none'
        self.last_reference_text = 'intact'
        self.last_challenge_text = 'intact'

    @property
    def busy(self):
        return bool(self.active)

    def context(self, core, debt):
        ambient, _ = core.temperature_field()
        speed = float(np.linalg.norm(core.vel)) / max(MAX_SPEED, 1e-9)
        return np.array([
            float(debt[0]), float(debt[1]), float(debt[2]), float(debt[3]),
            clamp(speed, 0.0, 1.5), float(ambient), float(core.shelter_level()),
        ], dtype=float)

    def _context_distance(self, slot, context):
        if slot < 0 or self.claim_context_weight[slot] < 0.10:
            return 0.40
        scale = np.array([0.22, 0.22, 0.18, 0.24, 0.35, 0.22, 0.35])
        return float(np.sqrt(np.mean(((context - self.claim_context[slot]) / scale) ** 2)))

    def _lookup_slot(self, key):
        key = np.asarray(key, dtype=np.int16)
        matches = self.claim_used & np.all(self.claim_key == key[None, :], axis=1)
        found = np.flatnonzero(matches)
        return int(found[0]) if found.size else -1

    def _allocate_slot(self, key, signature, age):
        slot = self._lookup_slot(key)
        if slot >= 0:
            # A claim's coalition may drift. Preserve memory but update the
            # signature slowly rather than pretending the pathway is immutable.
            sig = np.asarray(signature, dtype=float)
            self.claim_signature[slot] = np.maximum(
                0.72 * self.claim_signature[slot], 0.28 * sig
            )
            return slot
        free = np.flatnonzero(~self.claim_used)
        if free.size:
            slot = int(free[0])
        else:
            score = (
                0.12 * self.claim_trials.astype(float)
                + 0.002 * np.maximum(0.0, float(age) - self.claim_last_age)
            )
            slot = int(np.argmin(score))
        self.claim_used[slot] = True
        self.claim_key[slot] = np.asarray(key, dtype=np.int16)
        self.claim_alpha[slot] = 1.0
        self.claim_beta[slot] = 1.0
        self.claim_effect_mean[slot] = 0.0
        self.claim_effect_m2[slot] = 0.0
        self.claim_effect_weight[slot] = 0.0
        self.claim_context[slot] = 0.0
        self.claim_context_weight[slot] = 0.0
        self.claim_risk_mean[slot] = 0.10
        self.claim_risk_weight[slot] = 0.5
        self.claim_last_age[slot] = -1e9
        self.claim_next_allowed[slot] = 0.0
        self.claim_trials[slot] = 0
        self.claim_supports[slot] = 0
        self.claim_contradictions[slot] = 0
        self.claim_signature[slot] = np.asarray(signature, dtype=float)
        return slot

    def _claim_stats(self, slot):
        if slot < 0:
            return 0.5, 0.289, 0.00045
        a = float(self.claim_alpha[slot])
        b = float(self.claim_beta[slot])
        p = a / max(a + b, 1e-9)
        p_sd = math.sqrt(max(a * b / ((a + b) ** 2 * (a + b + 1.0)), 0.0))
        w = float(self.claim_effect_weight[slot])
        if w > 1.0:
            var = self.claim_effect_m2[slot] / max(w - 1.0, 1.0)
            effect_sd = float(np.sqrt(max(var[int(self.claim_key[slot, 1])], 0.0)))
        else:
            effect_sd = 0.00045
        return p, p_sd, effect_sd

    def _need(self, debt):
        return np.clip((np.asarray(debt, dtype=float) - 0.06) / 0.58, 0.0, 1.5)

    def _verified_matrix(self, core):
        verified = core.auditor.verified_matrix(core.brain)
        raw = np.maximum(core.brain.causal_estimate, 0.0)
        if float(np.sum(verified)) < 1e-5:
            verified = 0.12 * raw
        return verified

    def _coalition_for_currency(self, core, currency, verified):
        brain = core.brain
        claim = verified[:, currency]
        fallback = np.maximum(brain.causal_estimate[:, currency], 0.0)
        motor_norm = np.linalg.norm(brain.motor, axis=1)
        live = (0.15 + np.abs(brain.hidden)) * (0.25 + motor_norm) * (0.35 + 0.65 * brain.vitality)
        score = claim * live
        if float(np.max(score)) < 1e-8:
            score = (0.05 + fallback) * live
        indices = np.argsort(score)[-5:]
        mask = np.zeros(CELL_COUNT, dtype=bool)
        mask[indices] = True
        weights = np.maximum(score[indices], 1e-8)
        signature = np.zeros(CELL_COUNT, dtype=float)
        signature[indices] = weights / max(float(np.max(weights)), 1e-9)
        motor = np.sum(weights[:, None] * brain.motor[indices], axis=0)
        if float(np.linalg.norm(motor)) < 1e-8:
            motor = np.array([1.0, 0.0])
        direction = int(np.argmax(self.directions @ motor))
        strength = clamp(float(np.sum(claim[indices])) * 16.0, 0.05, 1.0)
        return mask, signature, direction, strength

    def _sensor_reliance(self, brain, coalition_signature):
        denom = max(float(np.sum(coalition_signature)), 1e-9)
        relevance = np.zeros(len(SENSOR_GROUPS), dtype=float)
        for g, indices in enumerate(SENSOR_GROUPS):
            local = np.mean(np.abs(brain.w_sensor[:, indices]), axis=1)
            relevance[g] = float(np.sum(coalition_signature * local) / denom)
        if float(np.max(relevance)) > 1e-12:
            relevance /= float(np.max(relevance))
        return relevance

    def _environment_direction(self, core, sensor, currency):
        if currency == 0:
            vec = sensor[0:2]
        elif currency == 2:
            vec = -sensor[3:5]
        elif currency == 1:
            sign = -1.0 if core.temperature > 0.50 else 1.0
            vec = sign * sensor[10:12]
        else:
            return -1  # rest is the natural comparison for fatigue
        if float(np.linalg.norm(vec)) < 0.06:
            return -1
        return int(np.argmax(self.directions @ vec))

    def _program_motor(self, direction, strength=0.15):
        return _program((OP_MOTOR, direction, 0, strength, 0.0, 1.0))

    def _program_sequence(self, first, second, strength=0.19):
        ops = []
        if first < 0:
            ops.append((OP_REST, 0, 0, 0.78, 0.0, 0.5))
        else:
            ops.append((OP_MOTOR, first, 0, strength, 0.0, 0.5))
        if second < 0:
            ops.append((OP_REST, 0, 0, 0.78, 0.5, 1.0))
        else:
            ops.append((OP_MOTOR, second, 0, strength, 0.5, 1.0))
        return _program(*ops)

    def _make_candidate(
        self,
        key,
        claim_type,
        target,
        signature,
        coalition_mask,
        reference,
        challenge,
        structural,
        prior_effect,
        risk,
        description,
        age,
        context,
        expected_sign=1.0,
    ):
        slot = self._lookup_slot(key)
        if slot >= 0 and age < float(self.claim_next_allowed[slot]):
            return None
        p, p_sd, effect_sd = self._claim_stats(slot)
        need = float(self._need(context[:4])[target])
        context_distance = self._context_distance(slot, context)
        complexity = 0.5 * (_program_complexity(reference) + _program_complexity(challenge))
        # A useful falsification target is important, uncertain/fragile, and can
        # be challenged with a short, discriminating program.
        fragility = 0.30 + 0.80 * (1.0 - p) + 0.75 * p_sd
        discrimination = abs(float(prior_effect)) + effect_sd + 0.00010
        relevance = (0.18 + need) * (0.15 + float(structural))
        numerator = 780.0 * discrimination * relevance * fragility
        denominator = 0.22 + float(risk) + 0.10 * complexity + 0.08 * context_distance
        value = numerator / max(denominator, 1e-8)
        return {
            'key': tuple(int(x) for x in key),
            'slot': slot,
            'claim_type': int(claim_type),
            'target': int(target),
            'signature': np.asarray(signature, dtype=float),
            'coalition_mask': np.asarray(coalition_mask, dtype=bool),
            'reference': reference,
            'challenge': challenge,
            'structural': float(structural),
            'prior_effect': float(prior_effect),
            'risk': float(risk),
            'complexity': float(complexity),
            'value': float(value),
            'description': str(description),
            'expected_sign': float(expected_sign),
        }

    def compile_candidates(self, core, debt, context):
        brain = core.brain
        sensor = core.make_sensor()
        verified = self._verified_matrix(core)
        need = self._need(debt)
        candidates = []

        for currency in range(TROPHIC_COUNT):
            mask, signature, direction, verified_strength = self._coalition_for_currency(
                core, currency, verified
            )
            reliance = self._sensor_reliance(brain, signature)
            group = int(np.argmax(reliance))
            sensor_signature = signature * np.clip(
                np.mean(np.abs(brain.w_sensor[:, SENSOR_GROUPS[group]]), axis=1)
                / max(float(np.max(np.mean(np.abs(brain.w_sensor[:, SENSOR_GROUPS[group]]), axis=1))), 1e-9),
                0.0, 1.0,
            )
            structural = clamp(
                0.20 + 0.55 * verified_strength + 0.30 * float(reliance[group]),
                0.05, 1.35,
            )
            q_mean, q_var = core.questioner._posterior_stats(direction)
            q_evidence = float(core.questioner.evidence[direction])
            prior_action = float(q_mean[currency]) if q_evidence > 0.10 else 0.0
            prior_effect = max(0.00012, 0.00026 * structural + 0.35 * max(prior_action, 0.0))
            pulse = self._program_motor(direction, 0.13)

            # Sensor mediation: same weak motor probe; only the receptor family
            # is removed in the challenge arm.
            ref = pulse
            chal = _program(
                (OP_MOTOR, direction, 0, 0.13, 0.0, 1.0),
                (OP_SENSOR_MASK, group, 0, 0.78, 0.0, 1.0),
            )
            c = self._make_candidate(
                (CLAIM_SENSOR_MEDIATION, currency, group, direction, 0),
                CLAIM_SENSOR_MEDIATION, currency, sensor_signature, mask,
                ref, chal, structural, prior_effect,
                0.09 + 0.04 * float(need[currency]),
                '{} sensing mediates {} maintenance via {} tendency'.format(
                    SENSOR_GROUP_NAMES[group], TROPHIC_NAMES[currency], DIR_NAMES[direction]
                ),
                core.age, context,
            )
            if c is not None:
                candidates.append(c)

            # Neural mediation: matched motor probe; audited coalition alone is
            # prevented from voting to the body.
            chal = _program(
                (OP_MOTOR, direction, 0, 0.13, 0.0, 1.0),
                (OP_NEURAL_KO, 0, 0, 1.0, 0.0, 1.0),
            )
            c = self._make_candidate(
                (CLAIM_NEURAL_MEDIATION, currency, direction, 0, 0),
                CLAIM_NEURAL_MEDIATION, currency, signature, mask,
                ref, chal, clamp(structural + 0.12, 0.05, 1.4),
                prior_effect * 1.10,
                0.13 + 0.06 * float(need[currency]),
                'audited {} coalition is necessary for {} tendency'.format(
                    TROPHIC_NAMES[currency], DIR_NAMES[direction]
                ),
                core.age, context,
            )
            if c is not None:
                candidates.append(c)

            if self.allow_composite:
                # Rescue test: first remove the receptor family in both arms,
                # then add a weak, direction-aware stimulation only in the
                # challenge. If the downstream coalition really carries the
                # pathway, stimulation should partially restore body benefit.
                rescue_ref = _program(
                    (OP_MOTOR, direction, 0, 0.12, 0.0, 1.0),
                    (OP_SENSOR_MASK, group, 0, 0.76, 0.0, 1.0),
                )
                rescue_chal = _program(
                    (OP_MOTOR, direction, 0, 0.12, 0.0, 1.0),
                    (OP_SENSOR_MASK, group, 0, 0.76, 0.0, 1.0),
                    (OP_NEURAL_STIM, 0, 0, 0.42, 0.42, 1.0),
                )
                c = self._make_candidate(
                    (CLAIM_NEURAL_RESCUE, currency, group, direction, 0),
                    CLAIM_NEURAL_RESCUE, currency, signature, mask,
                    rescue_ref, rescue_chal,
                    clamp(structural + 0.08, 0.05, 1.4),
                    prior_effect * 0.72,
                    0.16 + 0.07 * float(need[currency]),
                    'stimulating the {} coalition rescues a masked {} pathway'.format(
                        TROPHIC_NAMES[currency], SENSOR_GROUP_NAMES[group]
                    ),
                    core.age, context, expected_sign=-1.0,
                )
                if c is not None:
                    candidates.append(c)

                # Organ mediation candidate. The selected organ is the smallest
                # local body component plausibly carrying this pathway.
                slot = direction % MORPH_SLOT_COUNT
                modality = min(group, MORPH_MODALITY_COUNT - 1)
                if currency in (1, 2):
                    kind = MORPH_SHELL
                    modality = 0
                    slot = int(np.argmax(core.morphology.shell))
                elif group <= 3 and float(np.max(core.morphology.sensor[:, modality])) > 0.10:
                    kind = MORPH_SENSOR
                    slot = int(np.argmax(core.morphology.sensor[:, modality]))
                else:
                    kind = MORPH_FIN
                    modality = 0
                    align = core.morphology.directions @ self.directions[direction]
                    slot = int(np.argmax(align + 0.20 * core.morphology.fin))
                organ_signature = 0.65 * signature
                chal = _program(
                    (OP_MOTOR, direction, 0, 0.12, 0.0, 1.0),
                    (OP_ORGAN_DAMP, kind, slot, 0.72, 0.0, 1.0),
                )
                c = self._make_candidate(
                    (CLAIM_ORGAN_MEDIATION, currency, kind, slot, modality),
                    CLAIM_ORGAN_MEDIATION, currency, organ_signature, mask,
                    self._program_motor(direction, 0.12), chal,
                    clamp(0.72 * structural, 0.05, 1.1), prior_effect * 0.80,
                    0.11 + 0.07 * float(need[currency]),
                    '{} organ at slot {} carries a {} pathway'.format(
                        ('sensor', 'fin', 'shell')[kind], slot, TROPHIC_NAMES[currency]
                    ),
                    core.age, context,
                )
                if c is not None:
                    candidates.append(c)

                # Dose-direction test: the two arms use the same motor probe,
                # but one weakens and the other strengthens the same organ
                # element. A real organ pathway should change monotonically in
                # the predicted direction rather than merely react to novelty.
                dose_ref = _program(
                    (OP_MOTOR, direction, 0, 0.11, 0.0, 1.0),
                    (OP_ORGAN_DAMP, kind, slot, 0.48, 0.0, 1.0),
                )
                dose_chal = _program(
                    (OP_MOTOR, direction, 0, 0.11, 0.0, 1.0),
                    (OP_ORGAN_BOOST, kind, slot, 0.38, 0.0, 1.0),
                )
                c = self._make_candidate(
                    (CLAIM_ORGAN_DOSE, currency, kind, slot, modality),
                    CLAIM_ORGAN_DOSE, currency, organ_signature, mask,
                    dose_ref, dose_chal,
                    clamp(0.66 * structural, 0.05, 1.05),
                    prior_effect * 0.62,
                    0.15 + 0.08 * float(need[currency]),
                    'increasing {} organ slot {} improves {} more than damping it'.format(
                        ('sensor', 'fin', 'shell')[kind], slot, TROPHIC_NAMES[currency]
                    ),
                    core.age, context, expected_sign=-1.0,
                )
                if c is not None:
                    candidates.append(c)

                # Order claim: same two primitives and total duration, reversed.
                other = self._environment_direction(core, sensor, currency)
                if other == direction:
                    other = (direction + 2) % 8
                if other != direction:
                    forward = self._program_sequence(direction, other)
                    reverse = self._program_sequence(other, direction)
                    # Recurrent hand-off heuristic chooses the predicted order.
                    slow = np.clip(brain.tau / max(float(np.max(brain.tau)), 1e-9), 0.0, 1.0)
                    align_a = brain.motor @ self.directions[direction]
                    if other < 0:
                        align_b = -np.linalg.norm(brain.motor, axis=1)
                    else:
                        align_b = brain.motor @ self.directions[other]
                    handoff = float(np.sum(signature * slow * align_a * align_b))
                    if handoff < 0.0:
                        forward, reverse = reverse, forward
                        first, second = other, direction
                    else:
                        first, second = direction, other
                    sequence_signature = signature * slow
                    c = self._make_candidate(
                        (CLAIM_ORDER, currency, first, second, 0),
                        CLAIM_ORDER, currency, sequence_signature, mask,
                        forward, reverse,
                        clamp(0.35 + 0.45 * abs(handoff), 0.10, 1.0),
                        0.00020 + 0.00022 * min(abs(handoff), 1.0),
                        0.10 + 0.05 * float(need[currency]),
                        'order {}→{} differs from {}→{} for {}'.format(
                            'REST' if first < 0 else DIR_NAMES[first],
                            'REST' if second < 0 else DIR_NAMES[second],
                            'REST' if second < 0 else DIR_NAMES[second],
                            'REST' if first < 0 else DIR_NAMES[first],
                            TROPHIC_NAMES[currency],
                        ),
                        core.age, context,
                    )
                    if c is not None:
                        candidates.append(c)
        return candidates

    def maybe_start(self, core, debt, context, other_busy=False, force=False):
        if not self.enabled or self.active or other_busy:
            return False
        if not force:
            if self.cooldown > 0.0 or core.age < 24.0:
                return False
            if float(np.max(debt)) > 0.80:
                self.deferred += 1
                self.cooldown = 4.0
                self.last_status = 'deferred: body crisis'
                return False
            if core.auditor.completed < 1 and core.age < 45.0:
                return False

        candidates = self.compile_candidates(core, debt, context)
        if not candidates:
            self.deferred += 1
            self.cooldown = 5.0
            self.last_status = 'deferred: no compilable claim'
            return False
        if self.random_selection and not force:
            chosen = candidates[int(self.rng.integers(len(candidates)))]
        else:
            best_value = max(float(x['value']) for x in candidates)
            if self.minimal_counterexample:
                near = [x for x in candidates if float(x['value']) >= 0.90 * best_value]
                chosen = min(
                    near,
                    key=lambda x: (float(x['complexity']), float(x['risk']), -float(x['value'])),
                )
            else:
                chosen = max(candidates, key=lambda x: x['value'])
        value = float(chosen['value'])
        risk = float(chosen['risk'])
        self.last_value = value
        self.last_risk = risk
        safety_limit = 0.34 + 0.24 * (1.0 - float(np.max(debt)))
        if self.safety_enabled and risk > safety_limit and not force:
            self.deferred += 1
            self.cooldown = 4.5
            self.last_status = 'deferred: compiled program unsafe'
            return False
        if value < self.value_threshold and not force:
            self.deferred += 1
            self.cooldown = 5.5
            self.last_status = 'deferred: weak falsification value'
            return False

        slot = self._allocate_slot(
            chosen['key'], chosen['signature'], core.age
        )
        self.claim_slot = slot
        self.claim_type = int(chosen['claim_type'])
        self.target_currency = int(chosen['target'])
        self.reference = _copy_program(chosen['reference'])
        self.challenge = _copy_program(chosen['challenge'])
        self.coalition_mask = np.asarray(chosen['coalition_mask'], dtype=bool).copy()
        self.expected_sign = float(chosen.get('expected_sign', 1.0))
        a = np.array([0, 1, 1, 0], dtype=np.int8)
        self.sequence = a if self.rng.random() < 0.5 else 1 - a
        self.period_index = 0
        self.period_elapsed = 0.0
        self.washout = False
        self.start_debt = np.asarray(debt, dtype=float).copy()
        self.pretrial_debt = np.asarray(debt, dtype=float).copy()
        self.abort_debt = np.minimum(
            0.98,
            self.pretrial_debt + np.array([0.13, 0.12, 0.10, 0.14]),
        )
        self.period_rates[:] = 0.0
        self.period_context[:] = 0.0
        self.period_event[:] = 0
        self.period_complete[:] = False
        self.segment_context_sum[:] = 0.0
        self.segment_context_time = 0.0
        self.segment_event_mask = 0
        self.active = True
        self.compiled += 1
        self.total_program_complexity += float(chosen['complexity'])
        self.last_claim_text = chosen['description']
        self.last_reference_text = _program_text(self.reference)
        self.last_challenge_text = _program_text(self.challenge)
        self.last_status = 'running compiled counterexample'
        return True

    def _active_program(self):
        if not self.active or self.washout:
            return None
        return self.challenge if int(self.sequence[self.period_index]) == 1 else self.reference

    def phase(self):
        return clamp(self.period_elapsed / max(self.period_duration, 1e-9), 0.0, 1.0)

    def _active_step_indices(self, opcode=None):
        program = self._active_program()
        if program is None:
            return []
        phase = self.phase()
        result = []
        for i in range(MAX_PROGRAM_STEPS):
            op = int(program['opcode'][i])
            if op == OP_NONE or (opcode is not None and op != opcode):
                continue
            if float(program['start'][i]) <= phase < float(program['end'][i]) + 1e-12:
                result.append(i)
        return result

    def alter_sensor(self, sensor):
        sensor = np.asarray(sensor, dtype=float).copy()
        program = self._active_program()
        if program is None:
            return sensor
        for i in self._active_step_indices(OP_SENSOR_MASK):
            group = int(program['arg0'][i])
            strength = clamp(float(program['strength'][i]), 0.0, 1.0)
            sensor[SENSOR_GROUPS[group]] *= 1.0 - strength
        return np.clip(sensor, -1.0, 1.0)

    def current_knockout_mask(self):
        program = self._active_program()
        if program is None:
            return None
        indices = self._active_step_indices(OP_NEURAL_KO)
        if not indices:
            return None
        # A graded KO is represented deterministically by selecting the most
        # strongly signed members first. Current candidates use full strength.
        strength = max(float(program['strength'][i]) for i in indices)
        if strength >= 0.999:
            return self.coalition_mask.copy()
        sig = self.claim_signature[self.claim_slot]
        members = np.flatnonzero(self.coalition_mask)
        count = max(1, int(round(strength * len(members))))
        chosen = members[np.argsort(sig[members])[-count:]]
        mask = np.zeros(CELL_COUNT, dtype=bool)
        mask[chosen] = True
        return mask

    def morph_overlay(self):
        program = self._active_program()
        if program is None:
            return None
        damp = self._active_step_indices(OP_ORGAN_DAMP)
        boost = self._active_step_indices(OP_ORGAN_BOOST)
        indices = damp if damp else boost
        if not indices:
            return None
        i = indices[0]
        kind = int(program['arg0'][i])
        slot = int(program['arg1'][i]) % MORPH_SLOT_COUNT
        strength = clamp(float(program['strength'][i]), 0.0, 1.0)
        modality = int(self.claim_key[self.claim_slot, 4]) if self.claim_slot >= 0 else 0
        modality = max(0, min(MORPH_MODALITY_COUNT - 1, modality))
        operation = OP_ORGAN_DAMP if damp else OP_ORGAN_BOOST
        return operation, kind, slot, modality, strength

    def alter_neural_action(self, brain, action):
        """Apply a weak, direction-aware stimulation to the claimed coalition."""
        program = self._active_program()
        if program is None:
            return np.asarray(action, dtype=float)
        indices = self._active_step_indices(OP_NEURAL_STIM)
        if not indices or self.claim_slot < 0:
            return np.asarray(action, dtype=float)
        strength = clamp(max(float(program['strength'][i]) for i in indices), 0.0, 1.0)
        members = np.flatnonzero(self.coalition_mask)
        if members.size == 0:
            return np.asarray(action, dtype=float)
        direction = int(self.claim_key[self.claim_slot, 3]) % 8
        target = self.directions[direction]
        desired_sign = np.sign(brain.motor[members] @ target)
        desired_sign[desired_sign == 0.0] = 1.0
        blend = 0.08 + 0.16 * strength
        brain.hidden[members] = (
            (1.0 - blend) * brain.hidden[members]
            + blend * desired_sign * 0.72
        )

        brain.vitality = brain._cell_vitality()
        influence = 0.45 + 0.55 * np.sqrt(brain.vitality)
        effective_motor = brain.motor + brain.last_motor_sigma[:, None] * brain.motor_probe
        effective_hidden = brain.hidden * brain.efferent_gate
        raw_action = np.sum(
            influence[:, None] * effective_hidden[:, None] * effective_motor,
            axis=0,
        ) / math.sqrt(brain.n_cell)
        action = np.tanh(3.8 * raw_action)
        brain.last_action = action.copy()
        brain.last_predict_feature[:, 0] = brain.hidden
        brain.last_predict_feature[:, 1] = action[0]
        brain.last_predict_feature[:, 2] = action[1]
        brain.prediction = np.tanh(
            np.sum(brain.predict_w * brain.last_predict_feature, axis=1)
        )
        return action

    def alter_action(self, action):
        action = np.asarray(action, dtype=float).copy()
        program = self._active_program()
        if program is None:
            return action
        for i in self._active_step_indices():
            op = int(program['opcode'][i])
            strength = float(program['strength'][i])
            if op == OP_MOTOR:
                direction = int(program['arg0'][i]) % 8
                action += strength * self.directions[direction]
            elif op == OP_REST:
                action *= max(0.0, 1.0 - clamp(strength, 0.0, 1.0))
        return np.clip(action, -1.0, 1.0)

    def intervention_cost(self):
        program = self._active_program()
        if program is None:
            return 0.0
        cost = 0.0
        for i in self._active_step_indices():
            op = int(program['opcode'][i])
            strength = float(program['strength'][i])
            if op == OP_MOTOR:
                cost += 0.00010 * strength
            elif op == OP_SENSOR_MASK:
                cost += 0.000025 * strength
            elif op == OP_NEURAL_KO:
                cost += 0.000035 * strength
            elif op == OP_ORGAN_DAMP:
                cost += 0.000045 * strength
            elif op == OP_NEURAL_STIM:
                cost += 0.000060 * strength
            elif op == OP_ORGAN_BOOST:
                cost += 0.000070 * strength
        return cost

    def observe(self, core, debt_before, debt_after, dt, context, event_mask=0):
        dt = float(dt)
        if not self.active:
            self.cooldown = max(0.0, self.cooldown - dt)
            return
        debt_after = np.asarray(debt_after, dtype=float)
        if self.safety_enabled and np.any(debt_after > self.abort_debt):
            self._abort(core, 'aborted: safety boundary')
            return
        if self.washout:
            self.period_elapsed += dt
            if self.period_elapsed >= self.washout_duration:
                self.washout = False
                self.period_elapsed = 0.0
                self.start_debt = debt_after.copy()
                self.segment_context_sum[:] = 0.0
                self.segment_context_time = 0.0
                self.segment_event_mask = 0
            return

        self.period_elapsed += dt
        self.segment_context_sum += dt * np.asarray(context, dtype=float)
        self.segment_context_time += dt
        self.segment_event_mask |= int(event_mask)
        if self.period_elapsed < self.period_duration:
            return

        i = self.period_index
        self.period_rates[i] = (self.start_debt - debt_after) / max(self.period_elapsed, 1e-9)
        self.period_context[i] = self.segment_context_sum / max(self.segment_context_time, 1e-9)
        self.period_event[i] = self.segment_event_mask
        self.period_complete[i] = True
        self.period_index += 1
        if self.period_index >= PROGRAM_PERIODS:
            self._finish(core)
            return
        self.washout = True
        self.period_elapsed = 0.0

    def _finish(self, core):
        if not bool(np.all(self.period_complete)):
            self._abort(core, 'aborted: incomplete program')
            return
        reference_rates = self.period_rates[self.sequence == 0]
        challenge_rates = self.period_rates[self.sequence == 1]
        effect = np.median(reference_rates, axis=0) - np.median(challenge_rates, axis=0)
        residual = self.period_rates - np.median(self.period_rates, axis=0)
        noise = np.median(np.abs(residual), axis=0)
        context_spread = float(np.mean(np.std(self.period_context, axis=0)))
        hard = int(np.sum((self.period_event & (soma21.EVENT_NUTRIENT | soma21.EVENT_TOXIN)) != 0))
        soft = int(np.sum((self.period_event & ~(soma21.EVENT_NUTRIENT | soma21.EVENT_TOXIN)) != 0))
        quality = math.exp(-7.0 * float(np.mean(noise)) - 1.8 * context_spread)
        quality *= 0.38 ** hard
        quality *= 0.94 ** soft
        quality = clamp(quality, 0.03, 1.0)

        slot = int(self.claim_slot)
        target = int(self.target_currency)
        signed = self.expected_sign * float(effect[target])
        scale = 0.00014 + float(noise[target]) + 0.00005
        z = (signed - 0.00006) / max(scale, 1e-9)
        support_probability = 1.0 / (1.0 + math.exp(-clamp(z, -12.0, 12.0)))
        evidence_mass = quality * (0.35 + min(abs(z), 2.5))
        self.claim_alpha[slot] += evidence_mass * support_probability
        self.claim_beta[slot] += evidence_mass * (1.0 - support_probability)

        old_w = float(self.claim_effect_weight[slot])
        new_w = old_w + quality
        delta = effect - self.claim_effect_mean[slot]
        self.claim_effect_mean[slot] += (quality / max(new_w, 1e-9)) * delta
        delta2 = effect - self.claim_effect_mean[slot]
        self.claim_effect_m2[slot] += quality * delta * delta2
        self.claim_effect_weight[slot] = new_w
        context = np.mean(self.period_context, axis=0)
        cw = float(self.claim_context_weight[slot])
        self.claim_context[slot] = (
            cw * self.claim_context[slot] + quality * context
        ) / max(cw + quality, 1e-9)
        self.claim_context_weight[slot] = cw + quality
        self.claim_last_age[slot] = float(core.age)
        self.claim_trials[slot] += 1

        harmful = float(np.mean(np.maximum(-effect, 0.0)))
        rw = float(self.claim_risk_weight[slot])
        observed_risk = clamp(550.0 * harmful, 0.0, 1.0)
        self.claim_risk_mean[slot] = (
            rw * self.claim_risk_mean[slot] + quality * observed_risk
        ) / max(rw + quality, 1e-9)
        self.claim_risk_weight[slot] = rw + quality

        posterior = float(self.claim_alpha[slot] / (self.claim_alpha[slot] + self.claim_beta[slot]))
        self.last_effect = effect.copy()
        self.last_quality = quality
        self.last_support_probability = posterior
        if quality >= 0.20 and support_probability >= 0.67:
            self.supported += 1
            self.claim_supports[slot] += 1
            self.last_status = 'claim survived counterexample'
        elif quality >= 0.20 and support_probability <= 0.33:
            self.contradicted += 1
            self.claim_contradictions[slot] += 1
            self.last_status = 'claim falsified; tissue reopened'
            self._apply_counterexample_feedback(core, slot, quality, posterior)
        else:
            self.inconclusive += 1
            self.last_status = 'counterexample inconclusive'

        if _program_complexity(self.reference) > 1.7 or _program_complexity(self.challenge) > 1.7:
            self.composite_completed += 1
        self.completed += 1
        self.claim_next_allowed[slot] = float(core.age) + 16.0 + 8.0 * (1.0 - quality)
        self.active = False
        self.claim_slot = -1
        self.claim_type = -1
        self.cooldown = 11.0 + 5.0 * (1.0 - quality)

    def _apply_counterexample_feedback(self, core, slot, quality, posterior):
        if not self.feedback_enabled:
            return
        signature = np.asarray(self.claim_signature[slot], dtype=float)
        affected = signature > 0.18
        if np.any(affected):
            magnitude = quality * (1.0 - posterior)
            core.brain.maturity[affected] *= 1.0 - 0.22 * magnitude
            core.brain.prediction_error[affected] = np.clip(
                core.brain.prediction_error[affected] + 0.09 * magnitude,
                0.0, 1.0,
            )
            self.reopened_cells += int(np.count_nonzero(affected))
            self.feedback_events += 1

        key = self.claim_key[slot]
        if int(key[0]) in (CLAIM_ORGAN_MEDIATION, CLAIM_ORGAN_DOSE):
            kind, organ_slot, modality = int(key[2]), int(key[3]), int(key[4])
            morph = core.morphology
            matches = (
                morph.lease_active
                & (morph.lease_kind == kind)
                & (morph.lease_slot == organ_slot)
                & (morph.lease_modality == modality)
            )
            for index in np.flatnonzero(matches):
                morph.lease_trust[index] *= 0.72 + 0.20 * posterior
                morph.lease_next_review_age[index] = min(
                    float(morph.lease_next_review_age[index]), float(core.age) + 5.0
                )

    def _abort(self, core, reason):
        slot = int(self.claim_slot)
        if slot >= 0:
            rw = float(self.claim_risk_weight[slot])
            self.claim_risk_mean[slot] = (rw * self.claim_risk_mean[slot] + 0.65) / (rw + 1.0)
            self.claim_risk_weight[slot] = rw + 1.0
            self.claim_next_allowed[slot] = float(core.age) + 20.0
        self.active = False
        self.claim_slot = -1
        self.claim_type = -1
        self.aborted += 1
        self.cooldown = 13.0
        self.last_status = str(reason)

    def cancel_active(self, core, reason='cancelled'):
        if self.active:
            self._abort(core, reason)

    def cell_gate(self, brain, age, context):
        gate = np.ones((CELL_COUNT, TROPHIC_COUNT), dtype=float)
        if not self.feedback_enabled:
            return gate
        for slot in np.flatnonzero(self.claim_used & (self.claim_trials > 0)):
            claim_type = int(self.claim_key[slot, 0])
            if claim_type not in (
                CLAIM_SENSOR_MEDIATION, CLAIM_NEURAL_MEDIATION, CLAIM_NEURAL_RESCUE
            ):
                continue
            currency = int(self.claim_key[slot, 1])
            p = float(self.claim_alpha[slot] / (self.claim_alpha[slot] + self.claim_beta[slot]))
            coverage = 1.0 - math.exp(-float(self.claim_trials[slot]) / 2.0)
            elapsed = max(0.0, float(age) - float(self.claim_last_age[slot]))
            recency = math.exp(-math.log(2.0) * elapsed / 115.0)
            context_factor = math.exp(-0.24 * self._context_distance(int(slot), context))
            contradiction = coverage * recency * context_factor * (1.0 - p)
            signature = np.clip(self.claim_signature[slot], 0.0, 1.0)
            gate[:, currency] *= 1.0 - 0.70 * contradiction * signature
        return np.clip(gate, 0.18, 1.0)

    def diagnostics(self):
        used = self.claim_used & (self.claim_trials > 0)
        if np.any(used):
            posterior = self.claim_alpha[used] / (self.claim_alpha[used] + self.claim_beta[used])
            mean_trust = float(np.mean(posterior))
            claims_tested = int(np.count_nonzero(used))
        else:
            mean_trust = 0.5
            claims_tested = 0
        average_complexity = self.total_program_complexity / max(self.compiled, 1)
        type_trials = np.zeros(len(CLAIM_NAMES), dtype=np.int64)
        for slot in np.flatnonzero(self.claim_used & (self.claim_trials > 0)):
            claim_type = int(self.claim_key[slot, 0])
            if 0 <= claim_type < len(type_trials):
                type_trials[claim_type] += int(self.claim_trials[slot])
        return {
            'compiled': int(self.compiled),
            'completed': int(self.completed),
            'aborted': int(self.aborted),
            'deferred': int(self.deferred),
            'supported': int(self.supported),
            'contradicted': int(self.contradicted),
            'inconclusive': int(self.inconclusive),
            'composite': int(self.composite_completed),
            'claims_tested': claims_tested,
            'mean_trust': mean_trust,
            'average_complexity': float(average_complexity),
            'reopened_cells': int(self.reopened_cells),
            'feedback_events': int(self.feedback_events),
            'sensor_trials': int(type_trials[CLAIM_SENSOR_MEDIATION]),
            'neural_trials': int(type_trials[CLAIM_NEURAL_MEDIATION]),
            'organ_trials': int(type_trials[CLAIM_ORGAN_MEDIATION]),
            'order_trials': int(type_trials[CLAIM_ORDER]),
            'rescue_trials': int(type_trials[CLAIM_NEURAL_RESCUE]),
            'dose_trials': int(type_trials[CLAIM_ORGAN_DOSE]),
        }

    def state_dict(self):
        state = {
            'fc_enabled': bool_array(self.enabled),
            'fc_feedback': bool_array(self.feedback_enabled),
            'fc_safety': bool_array(self.safety_enabled),
            'fc_composite': bool_array(self.allow_composite),
            'fc_random': bool_array(self.random_selection),
            'fc_minimal': bool_array(self.minimal_counterexample),
            'fc_value_threshold': scalar_array(self.value_threshold),
            'fc_claim_used': self.claim_used.astype(np.uint8),
            'fc_claim_key': self.claim_key,
            'fc_claim_alpha': self.claim_alpha,
            'fc_claim_beta': self.claim_beta,
            'fc_claim_effect_mean': self.claim_effect_mean,
            'fc_claim_effect_m2': self.claim_effect_m2,
            'fc_claim_effect_weight': self.claim_effect_weight,
            'fc_claim_context': self.claim_context,
            'fc_claim_context_weight': self.claim_context_weight,
            'fc_claim_risk_mean': self.claim_risk_mean,
            'fc_claim_risk_weight': self.claim_risk_weight,
            'fc_claim_last_age': self.claim_last_age,
            'fc_claim_next_allowed': self.claim_next_allowed,
            'fc_claim_trials': self.claim_trials,
            'fc_claim_supports': self.claim_supports,
            'fc_claim_contradictions': self.claim_contradictions,
            'fc_claim_signature': self.claim_signature,
            'fc_active': bool_array(self.active),
            'fc_claim_slot': scalar_array(self.claim_slot, np.int64),
            'fc_claim_type': scalar_array(self.claim_type, np.int64),
            'fc_target_currency': scalar_array(self.target_currency, np.int64),
            'fc_expected_sign': scalar_array(self.expected_sign),
            'fc_coalition_mask': self.coalition_mask.astype(np.uint8),
            'fc_sequence': self.sequence,
            'fc_period_index': scalar_array(self.period_index, np.int64),
            'fc_period_elapsed': scalar_array(self.period_elapsed),
            'fc_washout': bool_array(self.washout),
            'fc_start_debt': self.start_debt,
            'fc_pretrial_debt': self.pretrial_debt,
            'fc_abort_debt': self.abort_debt,
            'fc_period_rates': self.period_rates,
            'fc_period_context': self.period_context,
            'fc_period_event': self.period_event,
            'fc_period_complete': self.period_complete.astype(np.uint8),
            'fc_segment_context_sum': self.segment_context_sum,
            'fc_segment_context_time': scalar_array(self.segment_context_time),
            'fc_segment_event_mask': scalar_array(self.segment_event_mask, np.int64),
            'fc_cooldown': scalar_array(self.cooldown),
            'fc_compiled_count': scalar_array(self.compiled, np.int64),
            'fc_completed_count': scalar_array(self.completed, np.int64),
            'fc_aborted_count': scalar_array(self.aborted, np.int64),
            'fc_deferred_count': scalar_array(self.deferred, np.int64),
            'fc_supported_count': scalar_array(self.supported, np.int64),
            'fc_contradicted_count': scalar_array(self.contradicted, np.int64),
            'fc_inconclusive_count': scalar_array(self.inconclusive, np.int64),
            'fc_composite_count': scalar_array(self.composite_completed, np.int64),
            'fc_reopened_cells': scalar_array(self.reopened_cells, np.int64),
            'fc_feedback_events': scalar_array(self.feedback_events, np.int64),
            'fc_total_complexity': scalar_array(self.total_program_complexity),
            'fc_last_value': scalar_array(self.last_value),
            'fc_last_risk': scalar_array(self.last_risk),
            'fc_last_quality': scalar_array(self.last_quality),
            'fc_last_effect': self.last_effect,
            'fc_last_support_probability': scalar_array(self.last_support_probability),
            'fc_last_status': np.array(self.last_status),
            'fc_last_claim_text': np.array(self.last_claim_text),
            'fc_last_reference_text': np.array(self.last_reference_text),
            'fc_last_challenge_text': np.array(self.last_challenge_text),
            'fc_rng_state': np.array(json.dumps(self.rng.bit_generator.state)),
        }
        for prefix, program in (('fc_ref', self.reference), ('fc_chal', self.challenge)):
            for key, value in program.items():
                state[prefix + '_' + key] = value
        return state

    def load_state(self, data):
        self.enabled = bool(int(data['fc_enabled']))
        self.feedback_enabled = bool(int(data['fc_feedback']))
        self.safety_enabled = bool(int(data['fc_safety']))
        self.allow_composite = bool(int(data['fc_composite']))
        self.random_selection = bool(int(data['fc_random']))
        self.minimal_counterexample = bool(int(data['fc_minimal']))
        self.value_threshold = float(data['fc_value_threshold'])
        array_fields = [
            ('claim_used', 'fc_claim_used', bool),
            ('claim_key', 'fc_claim_key', np.int16),
            ('claim_alpha', 'fc_claim_alpha', float),
            ('claim_beta', 'fc_claim_beta', float),
            ('claim_effect_mean', 'fc_claim_effect_mean', float),
            ('claim_effect_m2', 'fc_claim_effect_m2', float),
            ('claim_effect_weight', 'fc_claim_effect_weight', float),
            ('claim_context', 'fc_claim_context', float),
            ('claim_context_weight', 'fc_claim_context_weight', float),
            ('claim_risk_mean', 'fc_claim_risk_mean', float),
            ('claim_risk_weight', 'fc_claim_risk_weight', float),
            ('claim_last_age', 'fc_claim_last_age', float),
            ('claim_next_allowed', 'fc_claim_next_allowed', float),
            ('claim_trials', 'fc_claim_trials', np.int32),
            ('claim_supports', 'fc_claim_supports', np.int32),
            ('claim_contradictions', 'fc_claim_contradictions', np.int32),
            ('claim_signature', 'fc_claim_signature', float),
            ('coalition_mask', 'fc_coalition_mask', bool),
            ('sequence', 'fc_sequence', np.int8),
            ('start_debt', 'fc_start_debt', float),
            ('pretrial_debt', 'fc_pretrial_debt', float),
            ('abort_debt', 'fc_abort_debt', float),
            ('period_rates', 'fc_period_rates', float),
            ('period_context', 'fc_period_context', float),
            ('period_event', 'fc_period_event', np.int16),
            ('period_complete', 'fc_period_complete', bool),
            ('segment_context_sum', 'fc_segment_context_sum', float),
            ('last_effect', 'fc_last_effect', float),
        ]
        for attr, key, dtype in array_fields:
            setattr(self, attr, np.array(data[key], dtype=dtype))
        self.reference = _empty_program()
        self.challenge = _empty_program()
        for prefix, program in (('fc_ref', self.reference), ('fc_chal', self.challenge)):
            for key in program:
                dtype = program[key].dtype
                program[key] = np.array(data[prefix + '_' + key], dtype=dtype)
        self.active = bool(int(data['fc_active']))
        self.claim_slot = int(data['fc_claim_slot'])
        self.claim_type = int(data['fc_claim_type'])
        self.target_currency = int(data['fc_target_currency'])
        self.expected_sign = float(data['fc_expected_sign'])
        self.period_index = int(data['fc_period_index'])
        self.period_elapsed = float(data['fc_period_elapsed'])
        self.washout = bool(int(data['fc_washout']))
        self.segment_context_time = float(data['fc_segment_context_time'])
        self.segment_event_mask = int(data['fc_segment_event_mask'])
        self.cooldown = float(data['fc_cooldown'])
        self.compiled = int(data['fc_compiled_count'])
        self.completed = int(data['fc_completed_count'])
        self.aborted = int(data['fc_aborted_count'])
        self.deferred = int(data['fc_deferred_count'])
        self.supported = int(data['fc_supported_count'])
        self.contradicted = int(data['fc_contradicted_count'])
        self.inconclusive = int(data['fc_inconclusive_count'])
        self.composite_completed = int(data['fc_composite_count'])
        self.reopened_cells = int(data['fc_reopened_cells'])
        self.feedback_events = int(data['fc_feedback_events'])
        self.total_program_complexity = float(data['fc_total_complexity'])
        self.last_value = float(data['fc_last_value'])
        self.last_risk = float(data['fc_last_risk'])
        self.last_quality = float(data['fc_last_quality'])
        self.last_support_probability = float(data['fc_last_support_probability'])
        self.last_status = str(np.asarray(data['fc_last_status']).item())
        self.last_claim_text = str(np.asarray(data['fc_last_claim_text']).item())
        self.last_reference_text = str(np.asarray(data['fc_last_reference_text']).item())
        self.last_challenge_text = str(np.asarray(data['fc_last_challenge_text']).item())
        self.rng.bit_generator.state = json.loads(str(np.asarray(data['fc_rng_state']).item()))


class SomaFourCore(SomaThreeCore):
    def __init__(
        self,
        seed=None,
        compiler_enabled=True,
        compiler_feedback=True,
        compiler_safety=True,
        compiler_composite=True,
        compiler_random_selection=False,
        compiler_minimal_counterexample=True,
        freeze_learning_during_compiler=True,
        **kwargs
    ):
        super().__init__(seed=seed, **kwargs)
        self.compiler = FalsificationCompiler(
            seed=self.seed,
            enabled=compiler_enabled,
            feedback_enabled=compiler_feedback,
            safety_enabled=compiler_safety,
            allow_composite=compiler_composite,
            random_selection=compiler_random_selection,
            minimal_counterexample=compiler_minimal_counterexample,
        )
        self.freeze_learning_during_compiler = bool(freeze_learning_during_compiler)
        self.compiler_frozen_time = 0.0

    def _apply_compiler_morph_overlay(self):
        spec = self.compiler.morph_overlay()
        if spec is None:
            return None
        operation, kind, slot, modality, strength = spec
        if kind == MORPH_SENSOR:
            array = self.morphology.sensor
            index = (slot, modality)
        elif kind == MORPH_FIN:
            array = self.morphology.fin
            index = slot
        else:
            array = self.morphology.shell
            index = slot
        old = float(array[index])
        if operation == OP_ORGAN_BOOST:
            array[index] = clamp(old + strength * (1.0 - old), 0.0, 1.0)
        else:
            array[index] = clamp(old * (1.0 - strength), 0.0, 1.0)
        return array, index, old

    @staticmethod
    def _restore_compiler_morph_overlay(token):
        if token is not None:
            array, index, old = token
            array[index] = old

    def _compiler_sensor(self):
        token = self._apply_compiler_morph_overlay()
        try:
            sensor = self.make_sensor()
        finally:
            self._restore_compiler_morph_overlay(token)
        return self.compiler.alter_sensor(sensor)

    def _compiler_body_step(self, action, dt):
        token = self._apply_compiler_morph_overlay()
        try:
            self._apply_body_and_world(action, dt)
        finally:
            self._restore_compiler_morph_overlay(token)
        self.energy = clamp(
            self.energy - self.compiler.intervention_cost() * dt,
            0.0, 1.0,
        )

    def step(self, dt=1.0 / 30.0):
        dt = clamp(float(dt), 1.0 / 240.0, 0.10)
        if not self.alive:
            return
        debt_before = self.body_debt()
        compiler_context_before = self.compiler.context(self, debt_before)
        question_context_before = self.questioner.context(self, debt_before)

        all_idle = (
            not self.auditor.busy
            and not self.morphology.busy
            and not self.questioner.busy
            and not self.compiler.busy
        )
        if all_idle:
            started = False
            if self.compiler.enabled and self.age > 24.0 and self.compiler.cooldown <= 0.0:
                started = self.compiler.maybe_start(
                    self, debt_before, compiler_context_before, other_busy=False
                )
            if not started and self.age > 18.0 and self.questioner.cooldown <= 0.0:
                started = self.questioner.maybe_start(
                    self.age, debt_before, question_context_before, other_busy=False
                )
            if not started and self.morphology.review_due(self.age, debt_before):
                started = self.morphology.maybe_start(
                    self.age, debt_before, self.brain, self.auditor, audit_busy=False
                )
            if not started and self.auditor.enabled:
                priority_audit = self.auditor.completed < 2 or self.auditor.cooldown <= 0.0
                if priority_audit:
                    started = self.auditor.maybe_start(
                        self.age, debt_before, self.brain, morphology_busy=False
                    )
            if not started:
                started = self.morphology.maybe_start(
                    self.age, debt_before, self.brain, self.auditor, audit_busy=False
                )
            if not started and self.auditor.enabled:
                self.auditor.maybe_start(
                    self.age, debt_before, self.brain, morphology_busy=False
                )

        base_gate = (
            self.auditor.gate()
            if self.auditor.enabled
            else np.ones((CELL_COUNT, TROPHIC_COUNT), dtype=float)
        )
        compiler_gate = self.compiler.cell_gate(
            self.brain, self.age, compiler_context_before
        )
        self.brain.set_audit_gate(base_gate * compiler_gate)
        knockout = self.auditor.current_knockout_mask()
        if knockout is None:
            knockout = self.compiler.current_knockout_mask()
        self.brain.set_efferent_knockout(knockout)

        sensor = self._compiler_sensor()
        action = self.brain.act(sensor, debt_before, dt)
        action = self.compiler.alter_neural_action(self.brain, action)
        action = self.questioner.alter_action(action, dt)
        action = self.compiler.alter_action(action)

        eaten_before = self.eaten
        poisoned_before = self.poisoned
        shelter_before = self.shelter_level()
        ambient_before, _ = self.temperature_field()
        self._compiler_body_step(action, dt)
        if self.eaten > eaten_before:
            self.morphology.add_material(0.070 * (self.eaten - eaten_before))

        next_sensor = self._compiler_sensor()
        debt_after = self.body_debt()
        event_mask = self._event_mask(
            eaten_before, poisoned_before, shelter_before, ambient_before
        )
        audit_context = self._audit_context(debt_after)
        question_context = self.questioner.context(self, debt_after)
        compiler_context = self.compiler.context(self, debt_after)

        was_learning = self.brain.learning_enabled
        causal_snapshot = None
        freeze = (
            self.auditor.busy
            or (self.freeze_learning_during_trials and self.morphology.busy)
            or (self.freeze_learning_during_questions and self.questioner.busy)
            or (self.freeze_learning_during_compiler and self.compiler.busy)
        )
        if freeze:
            self.brain.learning_enabled = False
            if self.compiler.busy:
                self.compiler_frozen_time += dt
            elif self.questioner.busy:
                self.question_frozen_time += dt
            else:
                self.trial_frozen_time += dt
        if self.auditor.busy or self.compiler.busy:
            causal_snapshot = self.brain.causal_estimate.copy()
        self.brain.learn(next_sensor, debt_after, dt)
        if causal_snapshot is not None:
            self.brain.causal_estimate = causal_snapshot
        self.brain.learning_enabled = was_learning
        self.brain.set_efferent_knockout(None)

        self.auditor.observe(
            debt_after, dt, self.age + dt,
            event_mask=event_mask, context=audit_context,
        )
        self.morphology.observe(debt_before, debt_after, dt, age=self.age + dt)
        self.questioner.observe(
            debt_before, debt_after, dt, question_context, event_mask=event_mask
        )
        self.compiler.observe(
            self, debt_before, debt_after, dt, compiler_context,
            event_mask=event_mask,
        )

        self.last_action = np.asarray(action, dtype=float)
        self.age += dt
        self.last_body_debt = debt_after
        self.viability_integral += dt * (1.0 - float(np.mean(debt_after)))
        if self.energy <= 0.0 or self.integrity <= 0.0:
            self.energy = max(0.0, self.energy)
            self.integrity = max(0.0, self.integrity)
            self.vel[:] = 0.0
            self.alive = False

    def regenerate_body(self, normalized_position=None):
        self.compiler.cancel_active(self, 'cancelled by regeneration')
        super().regenerate_body(normalized_position)

    def state_dict(self):
        state = super().state_dict()
        state['save_version'] = scalar_array(SAVE_VERSION, np.int64)
        state.update({
            'soma4_freeze_compiler': bool_array(self.freeze_learning_during_compiler),
            'soma4_compiler_frozen_time': scalar_array(self.compiler_frozen_time),
        })
        state.update(self.compiler.state_dict())
        return state

    def load_state(self, data):
        if int(data['save_version']) != SAVE_VERSION:
            raise ValueError('unsupported SOMA-4 save version')
        keys = list(data.files) if hasattr(data, 'files') else list(data.keys())
        base = {key: data[key] for key in keys}
        base['save_version'] = scalar_array(5, np.int64)
        super().load_state(base)
        self.freeze_learning_during_compiler = bool(int(data['soma4_freeze_compiler']))
        self.compiler_frozen_time = float(data['soma4_compiler_frozen_time'])
        self.compiler.load_state(data)


if soma2.IN_PYTHONISTA:
    class SomaFourScene(soma3.SomaThreeScene):
        def setup(self):
            self._building_base_scene = True
            super().setup()
            self._building_base_scene = False
            self.core = SomaFourCore()
            self.help_label.text = 'tap: relocate nutrient   falsification compiler   autosave: 20 s'
            self._load_life_if_possible()
            self._sync_nodes(force_tiles=True)

        def _save_life(self):
            if getattr(self, '_building_base_scene', False):
                return
            try:
                np.savez(SAVE_FILE, **self.core.state_dict())
            except Exception as exc:
                print('SOMA-4 save failed:', exc)

        def _load_life_if_possible(self):
            if getattr(self, '_building_base_scene', False) or not os.path.exists(SAVE_FILE):
                return
            try:
                with np.load(SAVE_FILE, allow_pickle=False) as data:
                    self.core.load_state(data)
            except Exception as exc:
                print('SOMA-4 load ignored:', exc)

        def _sync_nodes(self, force_tiles=False):
            super()._sync_nodes(force_tiles=force_tiles)
            if getattr(self, '_building_base_scene', False):
                return
            fc = self.core.compiler
            d = fc.diagnostics()
            self.info_label.text += (
                '\nFALSIFY {:31s} C/D/S/F/I {}/{}/{}/{}/{} q {:.2f} p {:.2f}\n'
                '{}\nREF: {}\nALT: {}\nclaims {} composite {} avglen {:.2f} reopened {} frozen {:.1f}s'
            ).format(
                fc.last_status,
                d['compiled'], d['completed'], d['supported'],
                d['contradicted'], d['inconclusive'],
                fc.last_quality, fc.last_support_probability,
                fc.last_claim_text,
                fc.last_reference_text,
                fc.last_challenge_text,
                d['claims_tested'], d['composite'],
                d['average_complexity'], d['reopened_cells'],
                self.core.compiler_frozen_time,
            )


def run_headless_trial(
    seed=0,
    seconds=300.0,
    compiler_enabled=True,
    compiler_feedback=True,
    compiler_safety=True,
    compiler_composite=True,
    compiler_random_selection=False,
    compiler_minimal_counterexample=True,
    freeze_learning_during_compiler=True,
    dt=1.0/30.0,
    **kwargs
):
    core = SomaFourCore(
        seed=seed,
        compiler_enabled=compiler_enabled,
        compiler_feedback=compiler_feedback,
        compiler_safety=compiler_safety,
        compiler_composite=compiler_composite,
        compiler_random_selection=compiler_random_selection,
        compiler_minimal_counterexample=compiler_minimal_counterexample,
        freeze_learning_during_compiler=freeze_learning_during_compiler,
        **kwargs
    )
    for _ in range(int(max(0.0, seconds) / dt)):
        core.step(dt)
        if not core.alive:
            break
    fd = core.compiler.diagnostics()
    qd = core.questioner.diagnostics(
        core.age, core.body_debt(),
        core.questioner.context(core, core.body_debt())
    )
    return {
        'seed': int(seed),
        'age': float(core.age),
        'alive': int(core.alive),
        'health': float(core.viability_integral / max(core.age, 1e-9)),
        'energy': float(core.energy),
        'temperature': float(core.temperature),
        'integrity': float(core.integrity),
        'fatigue': float(core.fatigue),
        'food': int(core.eaten),
        'toxin': int(core.poisoned),
        'compiler_compiled': fd['compiled'],
        'compiler_completed': fd['completed'],
        'compiler_aborted': fd['aborted'],
        'compiler_deferred': fd['deferred'],
        'compiler_supported': fd['supported'],
        'compiler_contradicted': fd['contradicted'],
        'compiler_inconclusive': fd['inconclusive'],
        'compiler_composite': fd['composite'],
        'compiler_claims_tested': fd['claims_tested'],
        'compiler_mean_trust': fd['mean_trust'],
        'compiler_avg_complexity': fd['average_complexity'],
        'compiler_reopened_cells': fd['reopened_cells'],
        'compiler_feedback_events': fd['feedback_events'],
        'compiler_sensor_trials': fd['sensor_trials'],
        'compiler_neural_trials': fd['neural_trials'],
        'compiler_organ_trials': fd['organ_trials'],
        'compiler_order_trials': fd['order_trials'],
        'compiler_rescue_trials': fd['rescue_trials'],
        'compiler_dose_trials': fd['dose_trials'],
        'compiler_last_claim': str(core.compiler.last_claim_text),
        'compiler_last_reference': str(core.compiler.last_reference_text),
        'compiler_last_challenge': str(core.compiler.last_challenge_text),
        'questions_completed': qd['completed'],
        'questions_aborted': qd['aborted'],
        'question_evidence': qd['evidence'],
        'audit_completed': int(core.auditor.completed),
        'leases_active': int(np.sum(core.morphology.lease_active)),
        'leases_revoked': int(core.morphology.leases_revoked),
        'prediction_error': float(np.mean(core.brain.prediction_error)),
        'compiler_frozen_time': float(core.compiler_frozen_time),
    }


if __name__ == '__main__':
    if soma2.IN_PYTHONISTA:
        from scene import run, LANDSCAPE
        run(SomaFourScene(), orientation=LANDSCAPE, show_fps=False)
    else:
        print(run_headless_trial(seed=101, seconds=90.0))
