# coding: utf-8
"""
SOMA-7R — Conservative Spatial Ecosystem / 保存的・空間生態系版

Pythonista 3 / CPython + NumPy.
Requires SOMA_1 ... SOMA_4_2, SOMA_5R_pythonista.py and
SOMA_6R_pythonista.py in the same folder.

The R suffix means "rebuild".  This module replaces the SOMA-7 alpha's
non-spatial resource counters with one shared toroidal ecosystem:

* every organism sees and consumes the same spatial resource patches;
* three resource niches share a finite digestion budget;
* sensor, motor, armour, and social investment share a finite soma budget;
* faster bodies move faster but pay super-linear metabolic cost;
* reproduction transfers parent energy to offspring with explicit loss;
* death returns only a declared fraction of residual energy to detritus;
* cultural packets are local and must be embodiedly verified (SOMA-6R);
* species are current genetic connected components, not mutation labels;
* lineage records keep both parents and generation.

This is a falsifiable artificial-life research prototype, not a claim of
consciousness, biological equivalence, or demonstrated open-ended evolution.
"""

from __future__ import division

import csv
import gc
import math
import os
import pickle
import time

import numpy as np

import SOMA_1_pythonista as soma1
import SOMA_2_pythonista as soma2
import SOMA_5R_pythonista as soma5r
import SOMA_6R_pythonista as soma6r

from SOMA_1_pythonista import BODY_RADIUS, MAX_SPEED, TROPHIC_COUNT, clamp, wrapped_delta


BUILD = 'SOMA-7R 1.0.2'
SAVE_VERSION = 1
COMPATIBLE_SAVE_BUILDS = ('SOMA-7R 1.0.0', 'SOMA-7R 1.0.1', BUILD)
SAVE_FILE = os.path.join(os.path.dirname(__file__), 'soma7r_ecosystem.pkl')
LONGRUN_LOG_FILE = os.path.join(os.path.dirname(__file__), 'soma7r_longrun_v101.csv')
LONGRUN_LOG_INTERVAL = 10.0
LONGRUN_SCHEMA_VERSION = 1
SIM_HZ = 12.0
AUTO_SAVE_INTERVAL = 60.0

# Ecological stability controls.  The protected seed fraction is not edible:
# it represents dormant propagules / roots that let a depleted patch regrow.
RESOURCE_SEED_FRACTION = 0.018
RESOURCE_GROWTH_SCALE = 1.55
RESOURCE_UPTAKE_RATE = 0.048
MIN_REPRODUCTION_SECURITY = 0.40
MIN_COMMUNICATION_SECURITY = 0.14

RESOURCE_TYPES = 3
RESOURCE_PATCHES = 21
HAZARD_PATCHES = 6
REFUGE_PATCHES = 4
GENOME_DIM = 11
DEFAULT_CAPACITY = 10
COMMUNICATION_INTERVAL = 0.9
REPRODUCTION_INTERVAL = 2.0
CLUSTER_INTERVAL = 3.0

RESOURCE_RADIUS = 0.052
HAZARD_RADIUS = 0.038
REFUGE_RADIUS = 0.095


# -----------------------------------------------------------------------------
# Utilities
# -----------------------------------------------------------------------------


def _norm(value):
    return float(np.linalg.norm(np.asarray(value, dtype=float)))


def _torus_distance(a, b):
    return _norm(wrapped_delta(a, b))


def _sigmoid(value):
    value = float(np.clip(value, -20.0, 20.0))
    return 1.0 / (1.0 + math.exp(-value))


def _softmax(values):
    values = np.asarray(values, dtype=float)
    shifted = values - float(np.max(values))
    weights = np.exp(np.clip(shifted, -35.0, 0.0))
    total = float(np.sum(weights))
    if total <= 1e-12 or not np.isfinite(total):
        return np.full(values.shape, 1.0 / max(1, values.size), dtype=float)
    return weights / total


def _field_components(position, sources, weights, scale):
    sources = np.asarray(sources, dtype=float)
    if sources.size == 0:
        return np.zeros(2, dtype=float), 0.0
    weights = np.asarray(weights, dtype=float)
    deltas = sources - np.asarray(position, dtype=float)[None, :]
    deltas = (deltas + 0.5) % 1.0 - 0.5
    distances = np.linalg.norm(deltas, axis=1)
    concentration = np.exp(-distances / max(float(scale), 1e-6)) * weights
    total = float(np.sum(concentration))
    if total <= 1e-12:
        gradient = np.zeros(2, dtype=float)
    else:
        gradient = np.sum(
            deltas / (distances[:, None] + 0.03) * concentration[:, None],
            axis=0,
        ) / total
    density = 1.0 - math.exp(-0.65 * total)
    return np.clip(gradient, -1.0, 1.0), clamp(density, 0.0, 1.0)



def _clip_segment_to_unit_square(start, end):
    """Clip a 2-D line segment to [0, 1] x [0, 1]."""
    start = np.asarray(start, dtype=float)
    end = np.asarray(end, dtype=float)
    delta = end - start
    t0, t1 = 0.0, 1.0
    tests = (
        (-delta[0], start[0]),
        (delta[0], 1.0 - start[0]),
        (-delta[1], start[1]),
        (delta[1], 1.0 - start[1]),
    )
    for p_value, q_value in tests:
        if abs(float(p_value)) < 1e-12:
            if q_value < 0.0:
                return None
            continue
        ratio = float(q_value) / float(p_value)
        if p_value < 0.0:
            if ratio > t1:
                return None
            t0 = max(t0, ratio)
        else:
            if ratio < t0:
                return None
            t1 = min(t1, ratio)
    if t1 < t0:
        return None
    return start + t0 * delta, start + t1 * delta


def torus_line_segments(source, target):
    """Return shortest torus connection as visible unit-square segments.

    Drawing a wrapped edge as one ordinary line creates a misleading line that
    crosses the whole screen.  We instead draw translated copies of the
    shortest toroidal segment and clip them to the visible unit square.
    """
    source = np.asarray(source, dtype=float) % 1.0
    unwrapped_target = source + wrapped_delta(source, target)
    segments = []
    seen = set()
    for shift_x in (-1.0, 0.0, 1.0):
        for shift_y in (-1.0, 0.0, 1.0):
            shift = np.array([shift_x, shift_y], dtype=float)
            clipped = _clip_segment_to_unit_square(
                source + shift, unwrapped_target + shift
            )
            if clipped is None:
                continue
            first, second = clipped
            if _norm(second - first) <= 1e-9:
                continue
            key = tuple(np.round(np.concatenate([first, second]), 9))
            reverse = tuple(np.round(np.concatenate([second, first]), 9))
            if key in seen or reverse in seen:
                continue
            seen.add(key)
            segments.append((first, second))
    return segments


def _safe_float(value, default=0.0):
    try:
        value = float(value)
    except Exception:
        return float(default)
    return value if np.isfinite(value) else float(default)


def _memory_peak_mb_estimate():
    """Best-effort peak resident-memory estimate for long iPhone runs."""
    try:
        import resource
        raw = float(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
        if not np.isfinite(raw) or raw <= 0.0:
            return float('nan')
        # Darwin/iOS commonly reports bytes; Linux commonly reports KiB.
        return raw / (1024.0 * 1024.0) if raw > 5.0e6 else raw / 1024.0
    except Exception:
        return float('nan')


LONGRUN_FIELDS = (
    'schema_version', 'session_id', 'build', 'wall_utc', 'reason', 'seed',
    'age_s', 'frame_fps', 'sim_seconds_per_wall_second',
    'wall_epoch_s', 'session_wall_elapsed_s', 'memory_peak_mb_est',
    'sim_backlog_s', 'log_rows',
    'population', 'capacity', 'clusters',
    'births_total', 'births_delta', 'sexual_births', 'asexual_births',
    'deaths_total', 'deaths_delta', 'max_generation', 'mean_generation',
    'mean_health', 'mean_energy', 'genetic_diversity',
    'transmissions_total', 'transmissions_delta', 'communication_rounds',
    'accepted_hypotheses', 'planning_events', 'active_concepts',
    'food_events', 'hazard_events',
    'resource_biomass_total', 'resource_biomass_0', 'resource_biomass_1',
    'resource_biomass_2', 'resource_ratio_0', 'resource_ratio_1',
    'resource_ratio_2', 'detritus', 'climate',
    'mean_sensor', 'mean_motor', 'mean_armour', 'mean_social', 'mean_pace',
    'mean_reproduction', 'mean_exploration', 'mean_digestion_0',
    'mean_digestion_1', 'mean_digestion_2', 'reproduction_residual',
)


def longrun_snapshot(
    ecosystem, frame_fps=0.0, sim_rate=0.0,
    memory_peak_mb_est=float('nan'), sim_backlog_s=0.0,
):
    """Create one finite, flat row for long-duration observation."""
    summary = ecosystem.summary()
    alive = [agent for agent in ecosystem.agents if agent.alive]
    resource_biomass = []
    resource_ratios = []
    for resource_type in range(RESOURCE_TYPES):
        mask = ecosystem.world.patch_types == resource_type
        biomass = float(np.sum(ecosystem.world.patch_biomass[mask]))
        capacity = float(np.sum(ecosystem.world.patch_capacity[mask]))
        resource_biomass.append(biomass)
        resource_ratios.append(biomass / max(capacity, 1e-12))
    if alive:
        mean_generation = float(np.mean([agent.generation for agent in alive]))
        phenotype_mean = {
            name: float(np.mean([agent.phenotype[name] for agent in alive]))
            for name in (
                'sensor', 'motor', 'armour', 'social', 'pace',
                'reproduction', 'exploration'
            )
        }
        digestion = np.mean(
            np.asarray([agent.phenotype['digestion'] for agent in alive]),
            axis=0,
        )
    else:
        mean_generation = 0.0
        phenotype_mean = {
            name: 0.0 for name in (
                'sensor', 'motor', 'armour', 'social', 'pace',
                'reproduction', 'exploration'
            )
        }
        digestion = np.zeros(RESOURCE_TYPES, dtype=float)
    return {
        'seed': int(ecosystem.seed),
        'age_s': _safe_float(summary['age']),
        'frame_fps': _safe_float(frame_fps),
        'sim_seconds_per_wall_second': _safe_float(sim_rate),
        'memory_peak_mb_est': (
            '' if not np.isfinite(float(memory_peak_mb_est))
            else _safe_float(memory_peak_mb_est)
        ),
        'sim_backlog_s': _safe_float(sim_backlog_s),
        'population': int(summary['population']),
        'capacity': int(summary['capacity']),
        'clusters': int(summary['clusters']),
        'births_total': int(summary['births']),
        'sexual_births': int(summary['sexual_births']),
        'asexual_births': int(summary['asexual_births']),
        'deaths_total': int(summary['deaths']),
        'max_generation': int(summary['max_generation']),
        'mean_generation': _safe_float(mean_generation),
        'mean_health': _safe_float(summary['mean_health']),
        'mean_energy': _safe_float(summary['mean_energy']),
        'genetic_diversity': _safe_float(summary['genetic_diversity']),
        'transmissions_total': int(summary['transmissions']),
        'communication_rounds': int(ecosystem.communication_rounds),
        'accepted_hypotheses': int(summary['accepted_hypotheses']),
        'planning_events': int(summary['planning_events']),
        'active_concepts': int(summary['active_concepts']),
        'food_events': int(summary['food_events']),
        'hazard_events': int(summary['hazard_events']),
        'resource_biomass_total': _safe_float(summary['resource_biomass']),
        'resource_biomass_0': _safe_float(resource_biomass[0]),
        'resource_biomass_1': _safe_float(resource_biomass[1]),
        'resource_biomass_2': _safe_float(resource_biomass[2]),
        'resource_ratio_0': _safe_float(resource_ratios[0]),
        'resource_ratio_1': _safe_float(resource_ratios[1]),
        'resource_ratio_2': _safe_float(resource_ratios[2]),
        'detritus': _safe_float(summary['detritus']),
        'climate': _safe_float(summary['climate']),
        'mean_sensor': _safe_float(phenotype_mean['sensor']),
        'mean_motor': _safe_float(phenotype_mean['motor']),
        'mean_armour': _safe_float(phenotype_mean['armour']),
        'mean_social': _safe_float(phenotype_mean['social']),
        'mean_pace': _safe_float(phenotype_mean['pace']),
        'mean_reproduction': _safe_float(phenotype_mean['reproduction']),
        'mean_exploration': _safe_float(phenotype_mean['exploration']),
        'mean_digestion_0': _safe_float(digestion[0]),
        'mean_digestion_1': _safe_float(digestion[1]),
        'mean_digestion_2': _safe_float(digestion[2]),
        'reproduction_residual': _safe_float(summary['reproduction_residual']),
    }


class LongRunCSVLogger(object):
    """Append-only observer; it never changes ecosystem dynamics."""

    def __init__(self, ecosystem, path=LONGRUN_LOG_FILE, session_id=None):
        self.path = path
        self.session_id = session_id or self._new_session_id(ecosystem.seed)
        self.last_age = -1e30
        self.wall_start = time.time()
        self.rows_written = 0
        self.status = 'READY'
        summary = ecosystem.summary()
        self.previous_births = int(summary['births'])
        self.previous_deaths = int(summary['deaths'])
        self.previous_transmissions = int(summary['transmissions'])

    @staticmethod
    def _new_session_id(seed):
        return '{}-{}-{:06d}'.format(
            int(seed),
            time.strftime('%Y%m%dT%H%M%SZ', time.gmtime()),
            int(time.time() * 1000000) % 1000000,
        )

    def due(self, ecosystem):
        return float(ecosystem.age) - self.last_age >= LONGRUN_LOG_INTERVAL - 1e-9

    def log(
        self, ecosystem, frame_fps=0.0, sim_rate=0.0,
        reason='interval', force=False, memory_peak_mb_est=float('nan'),
        sim_backlog_s=0.0,
    ):
        if not force and not self.due(ecosystem):
            return False
        try:
            row = longrun_snapshot(
                ecosystem, frame_fps, sim_rate,
                memory_peak_mb_est=memory_peak_mb_est,
                sim_backlog_s=sim_backlog_s,
            )
            row.update({
                'schema_version': LONGRUN_SCHEMA_VERSION,
                'session_id': self.session_id,
                'build': BUILD,
                'wall_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                'wall_epoch_s': time.time(),
                'session_wall_elapsed_s': time.time() - self.wall_start,
                'log_rows': self.rows_written + 1,
                'reason': str(reason),
                'births_delta': int(row['births_total']) - self.previous_births,
                'deaths_delta': int(row['deaths_total']) - self.previous_deaths,
                'transmissions_delta': (
                    int(row['transmissions_total']) - self.previous_transmissions
                ),
            })
            folder = os.path.dirname(self.path)
            if folder and not os.path.exists(folder):
                os.makedirs(folder)
            exists = os.path.exists(self.path) and os.path.getsize(self.path) > 0
            with open(self.path, 'a', newline='', encoding='utf-8') as handle:
                writer = csv.DictWriter(
                    handle,
                    fieldnames=LONGRUN_FIELDS,
                    extrasaction='ignore',
                )
                if not exists:
                    writer.writeheader()
                writer.writerow({name: row.get(name, '') for name in LONGRUN_FIELDS})
            self.last_age = float(ecosystem.age)
            self.previous_births = int(row['births_total'])
            self.previous_deaths = int(row['deaths_total'])
            self.previous_transmissions = int(row['transmissions_total'])
            self.rows_written += 1
            self.status = 'OK'
            return True
        except Exception as exc:
            self.status = 'ERROR'
            print('SOMA-7R long-run log error:', exc)
            return False


def normalized_genetic_distance(a, b):
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    return float(np.linalg.norm(a - b) / math.sqrt(max(1, a.size)))


class EcoGenome(object):
    """Real-valued genotype with explicit allocation trade-offs."""

    def __init__(self, values):
        values = np.asarray(values, dtype=float)
        if values.shape != (GENOME_DIM,):
            raise ValueError('genome shape {} != {}'.format(values.shape, GENOME_DIM))
        self.values = np.clip(values, -4.0, 4.0)

    @staticmethod
    def random(rng, founder=0):
        # Two modestly separated founder clouds make cluster diagnostics useful
        # without hard-coding permanent species labels.
        centre = np.zeros(GENOME_DIM, dtype=float)
        if int(founder) % 2:
            centre[[0, 2, 5, 8]] = [0.45, 0.55, -0.35, 0.35]
        else:
            centre[[0, 2, 5, 8]] = [-0.35, -0.30, 0.45, -0.20]
        return EcoGenome(centre + rng.normal(0.0, 0.28, GENOME_DIM))

    @staticmethod
    def recombine(first, second, rng, mutation_sigma=0.09):
        first = np.asarray(first.values, dtype=float)
        second = np.asarray(second.values, dtype=float)
        mask = rng.random(GENOME_DIM) < 0.5
        blend = rng.uniform(0.25, 0.75, GENOME_DIM)
        child = np.where(mask, first, second)
        # A subset is arithmetic recombination, preventing purely discrete
        # founder-lineage inheritance.
        arithmetic = rng.random(GENOME_DIM) < 0.35
        child[arithmetic] = (
            blend[arithmetic] * first[arithmetic]
            + (1.0 - blend[arithmetic]) * second[arithmetic]
        )
        child += rng.normal(0.0, float(mutation_sigma), GENOME_DIM)
        return EcoGenome(child)

    def phenotype(self):
        soma_budget = _softmax(self.values[0:4])
        digestion = _softmax(self.values[4:7])
        pace = 0.62 + 0.82 * _sigmoid(self.values[7])
        reproduction = 0.10 + 0.78 * _sigmoid(self.values[8])
        thermal_target = 0.38 + 0.24 * _sigmoid(self.values[9])
        exploration = 0.62 + 0.76 * _sigmoid(self.values[10])
        return {
            'sensor': float(soma_budget[0]),
            'motor': float(soma_budget[1]),
            'armour': float(soma_budget[2]),
            'social': float(soma_budget[3]),
            'soma_budget': soma_budget,
            'digestion': digestion,
            'pace': float(pace),
            'reproduction': float(reproduction),
            'thermal_target': float(thermal_target),
            'exploration': float(exploration),
        }


# -----------------------------------------------------------------------------
# Shared spatial environment
# -----------------------------------------------------------------------------


class EcoWorld7R(object):
    def __init__(self, seed=101):
        self.seed = int(seed)
        self.rng = np.random.default_rng(self.seed + 7101)
        self.age = 0.0
        self.patch_positions = self.rng.random((RESOURCE_PATCHES, 2))
        self.patch_types = np.arange(RESOURCE_PATCHES, dtype=np.int16) % RESOURCE_TYPES
        self.rng.shuffle(self.patch_types)
        self.patch_capacity = self.rng.uniform(0.55, 1.05, RESOURCE_PATCHES)
        self.patch_biomass = self.patch_capacity * self.rng.uniform(
            0.48, 0.90, RESOURCE_PATCHES
        )
        self.patch_base_growth = (
            self.rng.uniform(0.017, 0.030, RESOURCE_PATCHES)
            * RESOURCE_GROWTH_SCALE
        )
        self.patch_seed_reserve = self.patch_capacity * RESOURCE_SEED_FRACTION
        self.hazard_positions = self.rng.random((HAZARD_PATCHES, 2))
        self.hazard_strength = self.rng.uniform(0.45, 1.0, HAZARD_PATCHES)
        self.refuge_positions = self.rng.random((REFUGE_PATCHES, 2))
        self.agents = []
        self.climate = 0.50
        self.detritus = 0.0

        # Transparent ledgers.  Environmental growth is an external input;
        # reproduction itself is internally conservative apart from declared loss.
        self.external_growth_biomass = 0.0
        self.detritus_recycled_biomass = 0.0
        self.consumed_biomass = 0.0
        self.assimilated_energy = 0.0
        self.unassimilated_food_loss = 0.0
        self.metabolic_dissipation = 0.0
        self.reproductive_parent_energy = 0.0
        self.offspring_initial_energy = 0.0
        self.reproductive_dissipation = 0.0
        self.death_energy_returned = 0.0
        self.death_dissipation = 0.0

    def step(self, dt):
        dt = float(dt)
        self.age += dt
        self.climate = 0.50 + 0.18 * math.sin(self.age / 47.0)
        phase = 2.0 * math.pi * (self.climate - 0.32)
        type_growth = np.array([
            0.72 + 0.28 * math.cos(phase),
            0.72 + 0.28 * math.cos(phase - 2.0 * math.pi / 3.0),
            0.72 + 0.28 * math.cos(phase + 2.0 * math.pi / 3.0),
        ], dtype=float)
        carrying_gap = 1.0 - self.patch_biomass / np.maximum(
            self.patch_capacity, 1e-9
        )
        # Growth is driven by visible biomass plus a protected dormant seed
        # bank.  The old equation used biomass itself, so an exactly empty
        # patch became an absorbing zero state and could never recover.
        reproductive_biomass = np.maximum(
            self.patch_biomass, self.patch_seed_reserve
        )
        growth = (
            self.patch_base_growth
            * type_growth[self.patch_types]
            * reproductive_biomass
            * carrying_gap
            * dt
        )
        # Detritus is recycled slowly and spread across depleted patches.
        recycle = min(self.detritus, 0.010 * dt)
        if recycle > 0.0:
            scarcity = np.maximum(self.patch_capacity - self.patch_biomass, 0.0)
            total_scarcity = float(np.sum(scarcity))
            if total_scarcity > 1e-12:
                addition = recycle * scarcity / total_scarcity
                growth += addition
                self.detritus -= recycle
                self.detritus_recycled_biomass += recycle
        self.patch_biomass += growth
        np.minimum(self.patch_biomass, self.patch_capacity, out=self.patch_biomass)
        # Dormant seed biomass is protected from harvest.  This prevents a
        # numerical one-way door while keeping near-empty patches effectively
        # unavailable to organisms.
        np.maximum(
            self.patch_biomass, self.patch_seed_reserve,
            out=self.patch_biomass,
        )
        self.external_growth_biomass += float(np.sum(np.maximum(growth, 0.0))) - recycle

    def resource_ratios(self):
        ratios = np.zeros(RESOURCE_TYPES, dtype=float)
        for resource_type in range(RESOURCE_TYPES):
            mask = self.patch_types == resource_type
            capacity = float(np.sum(self.patch_capacity[mask]))
            biomass = float(np.sum(self.patch_biomass[mask]))
            ratios[resource_type] = biomass / max(capacity, 1e-12)
        return np.clip(ratios, 0.0, 1.0)

    def resource_security(self):
        ratios = self.resource_ratios()
        # Mean availability captures total carrying power; the minimum term
        # prevents one niche from being silently sacrificed.
        return clamp(
            0.68 * float(np.mean(ratios)) + 0.32 * float(np.min(ratios)),
            0.0, 1.0,
        )

    def resource_field(self, position, resource_type):
        mask = self.patch_types == int(resource_type)
        weights = self.patch_biomass[mask] / np.maximum(
            self.patch_capacity[mask], 1e-9
        )
        return _field_components(
            position, self.patch_positions[mask], weights, 0.19
        )

    # Compatibility names used by SOMA-6R infrastructure.
    def nutrient_field(self, position):
        return self.resource_field(position, 0)

    def toxin_field(self, position):
        return self.resource_field(position, 1)

    def social_field(self, observer):
        positions = []
        weights = []
        for agent in self.agents:
            if agent is observer or not agent.alive:
                continue
            positions.append(agent.pos)
            health = 1.0 - float(np.mean(agent.body_debt()))
            weights.append(0.20 + 0.80 * clamp(health, 0.0, 1.0))
        if not positions:
            return np.zeros(2, dtype=float), 0.0
        return _field_components(
            observer.pos, np.asarray(positions), np.asarray(weights), 0.22
        )

    def temperature_field(self, position, at_time=None):
        if at_time is None:
            at_time = self.age
        x, y = map(float, np.asarray(position, dtype=float))
        drift = 0.055 * math.sin(float(at_time) * 0.011)
        ax = 2.0 * math.pi * (x + drift)
        by = 2.0 * math.pi * (y - 0.57 * drift)
        climate_shift = 0.34 * (self.climate - 0.50)
        value = (
            0.50 + climate_shift
            + 0.20 * math.sin(ax)
            + 0.105 * math.cos(by)
            + 0.045 * math.sin(ax + by)
        )
        value = clamp(value, 0.04, 0.96)
        gx = (
            0.20 * 2.0 * math.pi * math.cos(ax)
            + 0.045 * 2.0 * math.pi * math.cos(ax + by)
        ) / 2.1
        gy = (
            -0.105 * 2.0 * math.pi * math.sin(by)
            + 0.045 * 2.0 * math.pi * math.cos(ax + by)
        ) / 2.1
        return value, np.clip(np.array([gx, gy]), -1.0, 1.0)

    def refuge_level(self, position):
        level = 0.0
        for refuge in self.refuge_positions:
            distance = _torus_distance(position, refuge)
            level = max(level, math.exp(-((distance / REFUGE_RADIUS) ** 2)))
        return clamp(level, 0.0, 1.0)

    def hazard_exposure(self, agent):
        exposure = 0.0
        for position, strength in zip(self.hazard_positions, self.hazard_strength):
            distance = _torus_distance(agent.pos, position)
            if distance < HAZARD_RADIUS + BODY_RADIUS:
                exposure += float(strength) * (
                    1.0 - distance / (HAZARD_RADIUS + BODY_RADIUS)
                )
        return clamp(exposure, 0.0, 1.5)

    def toxin_exposure(self, agent):
        return self.hazard_exposure(agent)

    def repulsion(self, observer):
        vector = np.zeros(2, dtype=float)
        for agent in self.agents:
            if agent is observer or not agent.alive:
                continue
            delta = wrapped_delta(agent.pos, observer.pos)
            distance = _norm(delta)
            if 1e-6 < distance < 0.046:
                vector += delta / distance * (0.046 - distance) / 0.046
        return np.clip(vector, -1.0, 1.0)

    def consume(self, agent, dt, digestion, uptake_scale=1.0):
        digestion = np.asarray(digestion, dtype=float)
        deltas = self.patch_positions - np.asarray(agent.pos)[None, :]
        deltas = (deltas + 0.5) % 1.0 - 0.5
        distances = np.linalg.norm(deltas, axis=1)
        candidates = np.flatnonzero(distances < RESOURCE_RADIUS + BODY_RADIUS)
        if candidates.size == 0:
            return 0.0, 0.0, -1
        efficiency = 0.24 + 1.36 * digestion[self.patch_types[candidates]]
        desirability = self.patch_biomass[candidates] * efficiency
        index = int(candidates[int(np.argmax(desirability))])
        resource_type = int(self.patch_types[index])
        reserve = float(self.patch_seed_reserve[index])
        harvestable = max(0.0, float(self.patch_biomass[index]) - reserve)
        usable_capacity = max(float(self.patch_capacity[index]) - reserve, 1e-9)
        availability = clamp(harvestable / usable_capacity, 0.0, 1.0)
        # Harvest slows continuously near depletion instead of removing the
        # last propagules in one frame.
        rate_scale = 0.25 + 0.75 * math.sqrt(availability)
        take = min(
            harvestable,
            float(dt) * RESOURCE_UPTAKE_RATE
            * clamp(float(uptake_scale), 0.35, 1.85)
            * rate_scale,
        )
        self.patch_biomass[index] -= take
        potential_gain = take * float(0.24 + 1.36 * digestion[resource_type])
        self.consumed_biomass += take
        return potential_gain, take, resource_type

    def add_death_detritus(self, residual_energy):
        residual_energy = max(0.0, float(residual_energy))
        returned = 0.34 * residual_energy
        self.detritus += returned
        self.death_energy_returned += returned
        self.death_dissipation += residual_energy - returned


class EcoLatentCodec7R(soma5r.LatentCodec):
    def world_channels(self, core):
        channels = []
        for resource_type in range(RESOURCE_TYPES):
            gradient, density = core.world.resource_field(core.pos, resource_type)
            channels.extend([
                gradient[0], gradient[1], density * 2.0 - 1.0
            ])
        ambient, t_gradient = core.world.temperature_field(core.pos)
        channels.extend([
            ambient * 2.0 - 1.0, t_gradient[0], t_gradient[1]
        ])
        return np.asarray(channels, dtype=float)


# -----------------------------------------------------------------------------
# Organism
# -----------------------------------------------------------------------------


class SomaSevenRAgent(soma6r.SomaSixRAgent):
    def __init__(
        self,
        seed=None,
        world=None,
        agent_id=0,
        genome=None,
        parent_ids=(-1, -1),
        generation=0,
        lineage=0,
        heritage=None,
        communication_enabled=True,
        full_brain=False,
        **kwargs
    ):
        local_rng = np.random.default_rng((101 if seed is None else int(seed)) + 70017)
        if genome is None:
            genome = EcoGenome.random(local_rng, founder=lineage)
        elif not isinstance(genome, EcoGenome):
            genome = EcoGenome(genome)
        # Phenotype must exist before base construction because dynamic dispatch
        # may enter make_sensor/temperature methods during initialization.
        self.genome = genome
        self.phenotype = genome.phenotype()
        self.parent_ids = (int(parent_ids[0]), int(parent_ids[1]))
        self.cluster_id = -1
        self.birth_age_world = float(world.age if world is not None else 0.0)
        self.last_reproduction_age = -1e9
        self.resource_intake = np.zeros(RESOURCE_TYPES, dtype=float)
        self.resource_contacts = np.zeros(RESOURCE_TYPES, dtype=np.int64)
        self.last_consumed_type = -1
        self.lifetime_metabolic_cost = 0.0
        self.lifetime_food_energy = 0.0
        self.lifetime_reproductive_contribution = 0.0
        self.mating_events = 0
        super().__init__(
            seed=seed,
            world=world,
            agent_id=agent_id,
            parent_id=int(parent_ids[0]),
            generation=generation,
            lineage=lineage,
            heritage=heritage,
            communication_enabled=communication_enabled,
            full_brain=full_brain,
            **kwargs
        )
        self.latent_codec = EcoLatentCodec7R()
        self.last_latent = self._encode_latent()

    def body_debt(self):
        debt = np.asarray(super().body_debt(), dtype=float).copy()
        target = float(self.phenotype['thermal_target'])
        debt[1] = clamp(abs(float(self.temperature) - target) / 0.43, 0.0, 1.0)
        return debt

    def communication_range(self):
        return 0.075 + 0.30 * math.sqrt(max(self.phenotype['social'], 0.0))

    def communication_reliability(self):
        return clamp(0.45 + 0.95 * self.phenotype['social'], 0.45, 0.96)

    def reproduction_threshold(self):
        return 0.73 - 0.18 * self.phenotype['reproduction']

    def _resource_channel(self, resource_type):
        gradient, density = self.world.resource_field(self.pos, resource_type)
        sensor_investment = self.phenotype['sensor']
        morphology_sensor, _, _ = self.morphology.effective_arrays()
        modality = min(int(resource_type), morphology_sensor.shape[1] - 1)
        morphology_quality = clamp(
            float(np.mean(morphology_sensor[:, modality])), 0.02, 1.0
        )
        quality = clamp(0.25 + 0.92 * sensor_investment + 0.28 * morphology_quality, 0.12, 1.0)
        noise = 0.006 + 0.030 * (1.0 - quality)
        gradient = np.asarray(gradient, dtype=float) * quality
        gradient += self.rng.normal(0.0, noise, 2)
        density = float(density) + float(self.rng.normal(0.0, 0.55 * noise))
        return np.clip(gradient, -1.0, 1.0), clamp(density, 0.0, 1.0)

    def make_sensor(self):
        if self.world is None:
            return super().make_sensor()
        resource_channels = []
        for resource_type in range(RESOURCE_TYPES):
            gradient, density = self._resource_channel(resource_type)
            resource_channels.extend([
                gradient[0], gradient[1], density * 2.0 - 1.0
            ])
        ambient, thermal_gradient = self.world.temperature_field(self.pos)
        thermal_quality = clamp(0.25 + 1.00 * self.phenotype['sensor'], 0.15, 1.0)
        thermal_gradient = np.asarray(thermal_gradient) * thermal_quality
        thermal_gradient += self.rng.normal(
            0.0, 0.007 + 0.025 * (1.0 - thermal_quality), 2
        )
        social_gradient, social_density = self.world.social_field(self)
        social_quality = clamp(0.15 + 1.20 * self.phenotype['social'], 0.12, 1.0)
        social_gradient = np.asarray(social_gradient) * social_quality
        social_gradient += self.rng.normal(
            0.0, 0.008 + 0.030 * (1.0 - social_quality), 2
        )
        values = resource_channels + [
            ambient * 2.0 - 1.0,
            thermal_gradient[0], thermal_gradient[1],
            self.energy * 2.0 - 1.0,
            (self.temperature - 0.50) * 2.0,
            self.integrity * 2.0 - 1.0,
            self.fatigue * 2.0 - 1.0,
            self.vel[0] / MAX_SPEED,
            self.vel[1] / MAX_SPEED,
            self.last_action[0], self.last_action[1],
            self.pain * 2.0 - 1.0,
            social_gradient[0], social_gradient[1],
            clamp(social_density, 0.0, 1.0) * 2.0 - 1.0,
        ]
        return np.clip(np.asarray(values, dtype=float), -1.0, 1.0)

    def _apply_body_and_world(self, action, dt):
        if self.world is None:
            return super()._apply_body_and_world(action, dt)
        action = np.clip(np.asarray(action, dtype=float), -1.0, 1.0)
        shaped_action = self.morphology.transform_action(action)
        shaped_action += 0.055 * self.world.repulsion(self)
        # Exploration is useful but not free: it is weak and only expressed
        # when the planner is uncertain.
        uncertainty = clamp(float(self.planner.current_confidence), 0.0, 1.0)
        exploratory_scale = 0.006 * self.phenotype['exploration'] * (1.0 - uncertainty)
        shaped_action += self.rng.normal(0.0, exploratory_scale, 2)
        shaped_action = np.clip(shaped_action, -1.0, 1.0)

        motor_investment = self.phenotype['motor']
        pace = self.phenotype['pace']
        speed_factor = (0.48 + 1.22 * motor_investment) * pace
        target_velocity = shaped_action * MAX_SPEED * speed_factor
        response = 1.0 - math.exp(-(2.6 + 2.7 * motor_investment) * pace * dt)
        self.vel += (target_velocity - self.vel) * response
        displacement = self.vel * dt
        self.pos = (self.pos + displacement) % 1.0
        self.distance_travelled += _norm(displacement)

        movement = float(np.dot(shaped_action, shaped_action))
        neural = self.brain.neural_cost()
        shelter = self.world.refuge_level(self.pos)
        ambient, _ = self.world.temperature_field(self.pos)
        self.last_ambient = ambient
        self.last_shelter = shelter
        sensor_mean, fin_mean, shell_mean = self.morphology.organ_means()
        armour = self.phenotype['armour']
        insulation = clamp(0.25 * shell_mean + 0.40 * armour, 0.0, 0.48)
        thermal_coupling = (0.15 + 0.92 * shelter) * (1.0 - insulation)
        self.temperature += (
            (ambient - self.temperature) * thermal_coupling * dt
            + 0.020 * movement * pace * dt
        )
        self.temperature = clamp(self.temperature, 0.0, 1.0)
        thermal_target = self.phenotype['thermal_target']
        thermal_stress = clamp(abs(self.temperature - thermal_target) / 0.42, 0.0, 1.0)

        locomotor_efficiency = 0.62 + 1.00 * motor_investment + 0.45 * fin_mean
        structural_mass = (
            0.90 + 0.55 * armour + 0.22 * shell_mean
            + 0.12 * sensor_mean
        )
        self.fatigue += (
            0.067 * movement * structural_mass * pace ** 1.25 / locomotor_efficiency
            + 0.018 * neural * pace
        ) * dt
        rest_fraction = max(0.0, 1.0 - math.sqrt(min(1.0, movement)))
        recovery = (0.010 + 0.145 * shelter) * rest_fraction * (1.10 - 0.35 * pace)
        self.fatigue = clamp(self.fatigue - recovery * dt, 0.0, 1.0)

        structure_cost = self.morphology.construction_and_maintenance_cost()
        allocation_cost = (
            0.00034 * self.phenotype['sensor']
            + 0.00038 * motor_investment
            + 0.00042 * armour
            + 0.00038 * self.phenotype['social']
        )
        cost = (
            0.00160
            + 0.00235 * movement * structural_mass * pace ** 2.0 / locomotor_efficiency
            + 0.00092 * neural * pace
            + 0.00125 * thermal_stress
            + 0.00092 * self.fatigue
            + structure_cost
            + allocation_cost
        ) * dt
        self.energy -= cost
        self.lifetime_metabolic_cost += cost
        self.world.metabolic_dissipation += cost

        if thermal_stress > 0.70:
            protection = clamp(0.18 * shell_mean + 0.52 * armour, 0.0, 0.64)
            damage = 0.0095 * (thermal_stress - 0.70) / 0.30 * (1.0 - protection) * dt
            self.integrity -= damage
            self.pain = min(1.0, self.pain + damage * 20.0)
        if self.fatigue > 0.90:
            damage = 0.0055 * (self.fatigue - 0.90) / 0.10 * dt
            self.integrity -= damage
            self.pain = min(1.0, self.pain + damage * 20.0)
        repair_budget = 1.0 - 0.48 * self.phenotype['reproduction']
        if self.energy > 0.52 and self.fatigue < 0.60 and thermal_stress < 0.60:
            heal_rate = (
                0.00175 * repair_budget * (self.energy - 0.52) / 0.48
                * (1.0 - self.fatigue)
            )
            healing = min(heal_rate * dt, 1.0 - self.integrity)
            self.integrity += healing
            repair_cost = healing * 0.35
            self.energy -= repair_cost
            self.world.metabolic_dissipation += repair_cost
            self.lifetime_metabolic_cost += repair_cost

        potential_gain, biomass, resource_type = self.world.consume(
            self,
            dt,
            digestion=self.phenotype['digestion'],
            uptake_scale=0.75 + 0.75 * self.phenotype['sensor'],
        )
        if potential_gain > 0.0:
            actual_gain = min(potential_gain, max(0.0, 1.0 - self.energy))
            self.energy += actual_gain
            self.world.assimilated_energy += actual_gain
            self.world.unassimilated_food_loss += potential_gain - actual_gain
            self.lifetime_food_energy += actual_gain
            self.resource_intake[resource_type] += biomass
            self.resource_contacts[resource_type] += 1
            self.last_consumed_type = int(resource_type)
            self.food_event_accumulator += actual_gain
            while self.food_event_accumulator >= 0.035:
                self.food_event_accumulator -= 0.035
                self.eaten += 1
            if resource_type == 0:
                self.source_a_contacts += 1
            elif resource_type == 1:
                self.source_b_contacts += 1

        exposure = self.world.hazard_exposure(self)
        self.toxin_event_cooldown = max(0.0, self.toxin_event_cooldown - dt)
        if exposure > 0.0:
            protection = clamp(0.20 * shell_mean + 0.68 * armour, 0.0, 0.72)
            damage = 0.055 * exposure * (1.0 - protection) * dt
            toxin_energy = 0.009 * exposure * dt
            self.integrity -= damage
            self.energy -= toxin_energy
            self.world.metabolic_dissipation += toxin_energy
            self.lifetime_metabolic_cost += toxin_energy
            self.pain = min(1.0, self.pain + damage * 18.0)
            if self.toxin_event_cooldown <= 0.0:
                self.poisoned += 1
                self.toxin_event_cooldown = 0.8

        self.pain *= math.exp(-2.3 * dt)
        self.energy = clamp(self.energy, 0.0, 1.0)
        self.integrity = clamp(self.integrity, 0.0, 1.0)

    def diagnostics7r(self):
        data = self.diagnostics6r()
        data.update({
            'cluster_id': int(self.cluster_id),
            'parent_a': int(self.parent_ids[0]),
            'parent_b': int(self.parent_ids[1]),
            'resource_intake_0': float(self.resource_intake[0]),
            'resource_intake_1': float(self.resource_intake[1]),
            'resource_intake_2': float(self.resource_intake[2]),
            'pace': float(self.phenotype['pace']),
            'sensor_investment': float(self.phenotype['sensor']),
            'motor_investment': float(self.phenotype['motor']),
            'armour_investment': float(self.phenotype['armour']),
            'social_investment': float(self.phenotype['social']),
            'reproduction_investment': float(self.phenotype['reproduction']),
            'metabolic_cost': float(self.lifetime_metabolic_cost),
            'food_energy': float(self.lifetime_food_energy),
            'reproductive_contribution': float(self.lifetime_reproductive_contribution),
        })
        return data


# -----------------------------------------------------------------------------
# Ecosystem, reproduction, culture, lineages
# -----------------------------------------------------------------------------


class SomaSevenREcosystem(object):
    def __init__(
        self,
        seed=101,
        initial=6,
        capacity=DEFAULT_CAPACITY,
        culture_enabled=True,
        evolution_enabled=True,
        sexual_reproduction=True,
        full_brain=False,
    ):
        self.seed = int(seed)
        self.rng = np.random.default_rng(self.seed + 7201)
        self.world = EcoWorld7R(self.seed)
        self.capacity = int(max(2, capacity))
        self.culture_enabled = bool(culture_enabled)
        self.evolution_enabled = bool(evolution_enabled)
        self.sexual_reproduction = bool(sexual_reproduction)
        self.full_brain = bool(full_brain)
        self.next_agent_id = 0
        self.agents = []
        self.age = 0.0
        self.births = 0
        self.sexual_births = 0
        self.asexual_births = 0
        self.deaths = 0
        self.transmissions = 0
        self.communication_rounds = 0
        self.last_signals = []
        self.last_births = []
        self.next_communication_age = 0.9
        self.next_reproduction_age = 4.0
        self.next_cluster_age = 0.0
        self.cluster_count = 0
        self.lineage_records = {}
        self.extinct_lineages = 0

        founder_genomes = [
            EcoGenome.random(self.rng, founder=0),
            EcoGenome.random(self.rng, founder=1),
        ]
        for index in range(int(initial)):
            founder = index % len(founder_genomes)
            genome = EcoGenome(
                founder_genomes[founder].values
                + self.rng.normal(0.0, 0.08, GENOME_DIM)
            )
            agent = self._new_agent(
                genome=genome,
                parents=(-1, -1),
                generation=0,
                lineage=founder,
                heritage=None,
                seed=self.seed + 131 * index,
            )
            # Spread founders near different resource types but not directly on
            # patches; they still need to sense and move.
            type_positions = self.world.patch_positions[
                self.world.patch_types == founder % RESOURCE_TYPES
            ]
            anchor = type_positions[index % len(type_positions)]
            agent.pos = (anchor + self.rng.normal(0.0, 0.12, 2)) % 1.0
            agent.energy = 0.74
            self.agents.append(agent)
        self.world.agents = self.agents
        self.recompute_genetic_clusters()

    def _new_agent(
        self,
        genome,
        parents,
        generation,
        lineage,
        heritage,
        seed,
    ):
        agent_id = self.next_agent_id
        self.next_agent_id += 1
        agent = SomaSevenRAgent(
            seed=int(seed),
            world=self.world,
            agent_id=agent_id,
            genome=genome,
            parent_ids=parents,
            generation=int(generation),
            lineage=int(lineage),
            heritage=heritage,
            communication_enabled=self.culture_enabled,
            full_brain=self.full_brain,
            planning_interval=0.68,
            max_rollout_depth=4,
        )
        self.lineage_records[agent_id] = {
            'agent_id': int(agent_id),
            'parent_a': int(parents[0]),
            'parent_b': int(parents[1]),
            'generation': int(generation),
            'lineage': int(lineage),
            'birth_age': float(self.age),
            'death_age': None,
            'genome': agent.genome.values.copy(),
        }
        return agent

    def step(self, dt=1.0 / SIM_HZ):
        dt = clamp(float(dt), 1.0 / 240.0, 0.12)
        self.age += dt
        self.world.step(dt)
        self.world.agents = self.agents
        if self.agents:
            order = self.rng.permutation(len(self.agents))
            for index in order:
                agent = self.agents[int(index)]
                if agent.alive:
                    agent.step(dt)
        self._remove_dead()
        if self.age + 1e-9 >= self.next_communication_age:
            self._communicate()
            self.next_communication_age += COMMUNICATION_INTERVAL
        if self.age + 1e-9 >= self.next_reproduction_age:
            self._reproduce()
            self.next_reproduction_age += REPRODUCTION_INTERVAL
        if self.age + 1e-9 >= self.next_cluster_age:
            self.recompute_genetic_clusters()
            self.next_cluster_age += CLUSTER_INTERVAL
        self.last_signals = [
            signal for signal in self.last_signals
            if self.age - signal[2] < 0.9
        ]
        self.last_births = [
            birth for birth in self.last_births
            if self.age - birth[2] < 1.6
        ]

    def _communicate(self):
        self.communication_rounds += 1
        if not self.culture_enabled:
            return
        security = self.world.resource_security()
        if security < MIN_COMMUNICATION_SECURITY:
            return
        alive = [agent for agent in self.agents if agent.alive]
        for speaker in alive:
            energy_floor = 0.20 + 0.17 * (1.0 - security)
            if speaker.energy < energy_floor or speaker.fatigue > 0.88:
                continue
            # Under scarcity, expensive broadcast attempts become rarer.
            if self.rng.random() > 0.35 + 0.65 * security:
                continue
            packet = speaker.make_packet()
            if packet is None:
                continue
            radius = speaker.communication_range()
            neighbors = [
                listener for listener in alive
                if listener is not speaker
                and _torus_distance(speaker.pos, listener.pos) <= radius
            ]
            neighbors.sort(key=lambda listener: _torus_distance(
                speaker.pos, listener.pos
            ))
            max_receivers = 1 + int(speaker.phenotype['social'] > 0.30)
            accepted = 0
            for listener in neighbors[:max_receivers]:
                reliability = math.sqrt(
                    speaker.communication_reliability()
                    * listener.communication_reliability()
                )
                if self.rng.random() > reliability:
                    continue
                if listener.receive_packet(packet):
                    receiver_cost = 0.00010 + 0.00016 * listener.phenotype['social']
                    listener.energy = clamp(listener.energy - receiver_cost, 0.0, 1.0)
                    listener.communication_energy += receiver_cost
                    listener.lifetime_metabolic_cost += receiver_cost
                    self.world.metabolic_dissipation += receiver_cost
                    accepted += 1
                    self.transmissions += 1
                    self.last_signals.append((
                        speaker.agent_id, listener.agent_id, self.age
                    ))
            if accepted:
                sender_cost = (
                    0.00034 + 0.00015 * accepted
                    + 0.00018 * speaker.phenotype['social']
                )
                speaker.energy = clamp(speaker.energy - sender_cost, 0.0, 1.0)
                speaker.communication_energy += sender_cost
                speaker.lifetime_metabolic_cost += sender_cost
                self.world.metabolic_dissipation += sender_cost
                speaker.social_sent += accepted

    def _remove_dead(self):
        alive = []
        for agent in self.agents:
            if agent.alive:
                alive.append(agent)
                continue
            self.deaths += 1
            self.world.add_death_detritus(agent.energy)
            record = self.lineage_records.get(agent.agent_id)
            if record is not None:
                record['death_age'] = float(self.age)
        self.agents = alive
        self.world.agents = self.agents

    def _mating_score(self, first, second):
        distance = _torus_distance(first.pos, second.pos)
        genetic = normalized_genetic_distance(
            first.genome.values, second.genome.values
        )
        if distance > 0.24 or genetic > 1.05:
            return -1e9
        health = (
            first.energy + second.energy
            + first.integrity + second.integrity
            - 0.5 * (first.fatigue + second.fatigue)
        )
        return health - 1.7 * distance - 0.25 * genetic

    @staticmethod
    def _mixed_heritage(first, second, rng):
        first_payload = first.heritage()
        second_payload = second.heritage()
        # Start from one embodied lineage, then average only the most compact
        # continuous parts.  No packet is treated as guaranteed truth.
        payload = first_payload if rng.random() < 0.5 else second_payload
        payload = {
            key: value if isinstance(value, list) else np.array(value, copy=True)
            for key, value in payload.items()
        }
        if 'motor' in first_payload and 'motor' in second_payload:
            payload['motor'] = (
                0.5 * np.asarray(first_payload['motor'])
                + 0.5 * np.asarray(second_payload['motor'])
            )
        if 'cell_trust' in first_payload and 'cell_trust' in second_payload:
            payload['cell_trust'] = (
                0.5 * np.asarray(first_payload['cell_trust'])
                + 0.5 * np.asarray(second_payload['cell_trust'])
            )
        return payload

    def _sexual_birth(self, first, second, forced=False):
        if len(self.agents) >= self.capacity:
            return None
        if not forced:
            if self.age - first.birth_age_world < 12.0 or self.age - second.birth_age_world < 12.0:
                return None
            if self.age - first.last_reproduction_age < 16.0:
                return None
            if self.age - second.last_reproduction_age < 16.0:
                return None
            if first.energy < first.reproduction_threshold():
                return None
            if second.energy < second.reproduction_threshold():
                return None
        contribution_first = min(
            max(0.0, first.energy - 0.18),
            0.095 + 0.055 * first.phenotype['reproduction'],
        )
        contribution_second = min(
            max(0.0, second.energy - 0.18),
            0.095 + 0.055 * second.phenotype['reproduction'],
        )
        total = contribution_first + contribution_second
        if total < 0.15:
            return None
        first.energy -= contribution_first
        second.energy -= contribution_second
        first.lifetime_reproductive_contribution += contribution_first
        second.lifetime_reproductive_contribution += contribution_second
        first.last_reproduction_age = self.age
        second.last_reproduction_age = self.age
        first.mating_events += 1
        second.mating_events += 1
        efficiency = 0.78
        child_energy = total * efficiency
        self.world.reproductive_parent_energy += total
        self.world.offspring_initial_energy += child_energy
        self.world.reproductive_dissipation += total - child_energy

        if self.evolution_enabled:
            child_genome = EcoGenome.recombine(
                first.genome, second.genome, self.rng, mutation_sigma=0.09
            )
        else:
            child_genome = EcoGenome(
                0.5 * (first.genome.values + second.genome.values)
            )
        generation = max(first.generation, second.generation) + 1
        lineage = first.lineage if self.rng.random() < 0.5 else second.lineage
        heritage = self._mixed_heritage(first, second, self.rng)
        child = self._new_agent(
            genome=child_genome,
            parents=(first.agent_id, second.agent_id),
            generation=generation,
            lineage=lineage,
            heritage=heritage,
            seed=int(self.rng.integers(1, 2 ** 31 - 1)),
        )
        midpoint = (first.pos + 0.5 * wrapped_delta(first.pos, second.pos)) % 1.0
        child.pos = (midpoint + self.rng.normal(0.0, 0.022, 2)) % 1.0
        child.energy = child_energy
        child.integrity = 0.91
        self.agents.append(child)
        self.world.agents = self.agents
        self.births += 1
        self.sexual_births += 1
        self.last_births.append((first.agent_id, child.agent_id, self.age))
        return child

    def _asexual_birth(self, parent, forced=False):
        if len(self.agents) >= self.capacity:
            return None
        if not forced:
            if self.age - parent.birth_age_world < 35.0:
                return None
            if self.age - parent.last_reproduction_age < 26.0:
                return None
            if parent.energy < 0.83:
                return None
        contribution = min(max(0.0, parent.energy - 0.20), 0.28)
        if contribution < 0.22:
            return None
        parent.energy -= contribution
        parent.lifetime_reproductive_contribution += contribution
        parent.last_reproduction_age = self.age
        efficiency = 0.62
        child_energy = contribution * efficiency
        self.world.reproductive_parent_energy += contribution
        self.world.offspring_initial_energy += child_energy
        self.world.reproductive_dissipation += contribution - child_energy
        child_genome = (
            EcoGenome.recombine(parent.genome, parent.genome, self.rng, 0.12)
            if self.evolution_enabled
            else EcoGenome(parent.genome.values.copy())
        )
        child = self._new_agent(
            genome=child_genome,
            parents=(parent.agent_id, -1),
            generation=parent.generation + 1,
            lineage=parent.lineage,
            heritage=parent.heritage(),
            seed=int(self.rng.integers(1, 2 ** 31 - 1)),
        )
        child.pos = (parent.pos + self.rng.normal(0.0, 0.028, 2)) % 1.0
        child.energy = child_energy
        child.integrity = 0.90
        self.agents.append(child)
        self.world.agents = self.agents
        self.births += 1
        self.asexual_births += 1
        self.last_births.append((parent.agent_id, child.agent_id, self.age))
        return child

    def _reproduce(self):
        if len(self.agents) >= self.capacity or not self.agents:
            return
        security = self.world.resource_security()
        if security < MIN_REPRODUCTION_SECURITY:
            return
        # Capacity is a hard ceiling, not a promise that the environment can
        # support that many bodies.  The soft ceiling falls as food declines.
        sustainable_limit = int(round(
            self.capacity * (0.28 + 0.88 * security)
        ))
        sustainable_limit = max(2, min(self.capacity, sustainable_limit))
        if len(self.agents) >= sustainable_limit:
            return
        scarcity_penalty = 0.20 * max(0.0, 0.62 - security)
        candidates = [
            agent for agent in self.agents
            if agent.alive
            and agent.energy >= min(0.96, agent.reproduction_threshold() + scarcity_penalty)
            and agent.integrity > 0.62
            and agent.fatigue < 0.76
        ]
        if self.sexual_reproduction and len(candidates) >= 2:
            pairs = []
            for i, first in enumerate(candidates):
                for second in candidates[i + 1:]:
                    score = self._mating_score(first, second)
                    if score > -1e8:
                        pairs.append((score, first, second))
            pairs.sort(key=lambda item: item[0], reverse=True)
            used = set()
            for _, first, second in pairs:
                if len(self.agents) >= self.capacity:
                    break
                if first.agent_id in used or second.agent_id in used:
                    continue
                child = self._sexual_birth(first, second)
                if child is not None:
                    used.add(first.agent_id)
                    used.add(second.agent_id)
        if len(self.agents) < self.capacity:
            isolated = sorted(
                candidates,
                key=lambda agent: (
                    agent.energy + agent.integrity
                    - 0.35 * agent.fatigue
                ),
                reverse=True,
            )
            for parent in isolated:
                if len(self.agents) >= self.capacity:
                    break
                nearby = any(
                    other is not parent
                    and _torus_distance(parent.pos, other.pos) < 0.24
                    for other in candidates
                )
                if not nearby:
                    self._asexual_birth(parent)

    def force_birth_for_calibration(self, first_index=0, second_index=1):
        if len(self.agents) < 2:
            return None
        first = self.agents[int(first_index) % len(self.agents)]
        second = self.agents[int(second_index) % len(self.agents)]
        first.energy = max(first.energy, 0.82)
        second.energy = max(second.energy, 0.82)
        second.pos = (first.pos + np.array([0.03, 0.0])) % 1.0
        return self._sexual_birth(first, second, forced=True)

    def recompute_genetic_clusters(self, threshold=0.32):
        alive = [agent for agent in self.agents if agent.alive]
        if not alive:
            self.cluster_count = 0
            return {}
        unvisited = set(range(len(alive)))
        components = []
        while unvisited:
            start = min(unvisited)
            unvisited.remove(start)
            component = [start]
            stack = [start]
            while stack:
                current = stack.pop()
                neighbors = []
                for candidate in sorted(unvisited):
                    distance = normalized_genetic_distance(
                        alive[current].genome.values,
                        alive[candidate].genome.values,
                    )
                    if distance <= threshold:
                        neighbors.append(candidate)
                for candidate in neighbors:
                    unvisited.remove(candidate)
                    component.append(candidate)
                    stack.append(candidate)
            components.append(component)
        components.sort(key=lambda component: min(
            alive[index].agent_id for index in component
        ))
        mapping = {}
        for cluster_id, component in enumerate(components):
            for index in component:
                alive[index].cluster_id = int(cluster_id)
                mapping[alive[index].agent_id] = int(cluster_id)
        self.cluster_count = len(components)
        return mapping

    def genetic_diversity(self):
        alive = [agent for agent in self.agents if agent.alive]
        if len(alive) < 2:
            return 0.0
        distances = []
        for index, first in enumerate(alive):
            for second in alive[index + 1:]:
                distances.append(normalized_genetic_distance(
                    first.genome.values, second.genome.values
                ))
        return float(np.mean(distances)) if distances else 0.0

    def energy_ledger(self):
        reproduction_residual = (
            self.world.reproductive_parent_energy
            - self.world.offspring_initial_energy
            - self.world.reproductive_dissipation
        )
        return {
            'external_growth_biomass': float(self.world.external_growth_biomass),
            'detritus_recycled_biomass': float(self.world.detritus_recycled_biomass),
            'consumed_biomass': float(self.world.consumed_biomass),
            'assimilated_energy': float(self.world.assimilated_energy),
            'metabolic_dissipation': float(self.world.metabolic_dissipation),
            'reproductive_parent_energy': float(self.world.reproductive_parent_energy),
            'offspring_initial_energy': float(self.world.offspring_initial_energy),
            'reproductive_dissipation': float(self.world.reproductive_dissipation),
            'reproduction_residual': float(reproduction_residual),
            'death_energy_returned': float(self.world.death_energy_returned),
            'death_dissipation': float(self.world.death_dissipation),
            'detritus': float(self.world.detritus),
        }

    def summary(self):
        alive = [agent for agent in self.agents if agent.alive]
        if alive:
            mean_health = float(np.mean([
                1.0 - np.mean(agent.body_debt()) for agent in alive
            ]))
            max_generation_alive = max(agent.generation for agent in alive)
            accepted = sum(
                np.count_nonzero(agent.hyp_active & agent.hyp_accepted)
                for agent in alive
            )
            planning = sum(agent.planner.plans for agent in alive)
            concepts = sum(
                np.count_nonzero(agent.concepts.count >= 5.0)
                for agent in alive
            )
            mean_energy = float(np.mean([agent.energy for agent in alive]))
        else:
            mean_health = 0.0
            max_generation_alive = 0
            accepted = 0
            planning = 0
            concepts = 0
            mean_energy = 0.0
        historical_max_generation = max(
            [int(record.get('generation', 0))
             for record in self.lineage_records.values()] or [0]
        )
        return {
            'build': BUILD,
            'age': float(self.age),
            'population': len(alive),
            'capacity': int(self.capacity),
            'clusters': int(self.cluster_count),
            'births': int(self.births),
            'sexual_births': int(self.sexual_births),
            'asexual_births': int(self.asexual_births),
            'deaths': int(self.deaths),
            'max_generation': int(historical_max_generation),
            'max_generation_alive': int(max_generation_alive),
            'mean_health': float(mean_health),
            'mean_energy': float(mean_energy),
            'genetic_diversity': float(self.genetic_diversity()),
            'transmissions': int(self.transmissions),
            'accepted_hypotheses': int(accepted),
            'planning_events': int(planning),
            'active_concepts': int(concepts),
            'resource_biomass': float(np.sum(self.world.patch_biomass)),
            'detritus': float(self.world.detritus),
            'climate': float(self.world.climate),
            'food_events': int(sum(agent.eaten for agent in alive)),
            'hazard_events': int(sum(agent.poisoned for agent in alive)),
            'reproduction_residual': float(self.energy_ledger()['reproduction_residual']),
        }

    def save(self, path=SAVE_FILE):
        payload = {
            'build': BUILD,
            'version': SAVE_VERSION,
            'ecosystem': self,
        }
        temporary = path + '.tmp'
        with open(temporary, 'wb') as handle:
            pickle.dump(payload, handle, pickle.HIGHEST_PROTOCOL)
        os.replace(temporary, path)
        # Large pickle buffers are temporary; collect promptly on iOS.
        gc.collect()

    @staticmethod
    def load(path=SAVE_FILE):
        with open(path, 'rb') as handle:
            payload = pickle.load(handle)
        if (
            not isinstance(payload, dict)
            or payload.get('build') not in COMPATIBLE_SAVE_BUILDS
            or int(payload.get('version', -1)) != SAVE_VERSION
        ):
            raise ValueError('incompatible SOMA-7R save')
        ecosystem = payload['ecosystem']
        ecosystem.world.agents = ecosystem.agents
        world = ecosystem.world
        if not hasattr(world, 'patch_seed_reserve'):
            world.patch_seed_reserve = (
                np.asarray(world.patch_capacity, dtype=float)
                * RESOURCE_SEED_FRACTION
            )
        # Old saves may contain the absorbing all-zero resource state.
        world.patch_biomass = np.maximum(
            np.asarray(world.patch_biomass, dtype=float),
            world.patch_seed_reserve,
        )
        for agent in ecosystem.agents:
            agent.world = ecosystem.world
            agent.latent_codec = EcoLatentCodec7R()
            if not isinstance(agent.compiler, soma5r.ImaginationActionCompiler):
                agent.compiler.__class__ = soma5r.ImaginationActionCompiler
        ecosystem.recompute_genetic_clusters()
        return ecosystem


def run_headless_trial(
    seed=101,
    seconds=180.0,
    initial=6,
    capacity=DEFAULT_CAPACITY,
    dt=1.0 / SIM_HZ,
    **kwargs
):
    ecosystem = SomaSevenREcosystem(
        seed=seed,
        initial=initial,
        capacity=capacity,
        **kwargs
    )
    debt_integral = 0.0
    samples = 0
    for _ in range(int(max(0.0, seconds) / dt)):
        if not ecosystem.agents:
            break
        ecosystem.step(dt)
        if ecosystem.agents:
            debt_integral += float(np.mean([
                np.mean(agent.body_debt()) for agent in ecosystem.agents
            ]))
            samples += 1
    result = ecosystem.summary()
    result['seed'] = int(seed)
    result['integrated_health'] = float(
        1.0 - debt_integral / max(samples, 1)
    )
    result.update({
        'parent_energy': ecosystem.world.reproductive_parent_energy,
        'offspring_energy': ecosystem.world.offspring_initial_energy,
        'reproductive_loss': ecosystem.world.reproductive_dissipation,
    })
    return result


def generate_longrun_report(log_path=LONGRUN_LOG_FILE):
    """Generate the text/session reports when the analyzer is available."""
    try:
        import SOMA_7R_longrun_report as report_module
        report_module.analyze(log_path)
        return 'OK'
    except Exception as exc:
        print('SOMA-7R auto-report error:', exc)
        return 'ERROR'


# -----------------------------------------------------------------------------
# Pythonista Scene
# -----------------------------------------------------------------------------


def dependency_status():
    required = [
        'SOMA_1_pythonista.py',
        'SOMA_2_pythonista.py',
        'SOMA_2_1_pythonista.py',
        'SOMA_3_pythonista.py',
        'SOMA_4_pythonista.py',
        'SOMA_4_1_pythonista.py',
        'SOMA_4_2_pythonista.py',
        'SOMA_5R_pythonista.py',
        'SOMA_6R_pythonista.py',
    ]
    folder = os.path.dirname(__file__)
    missing = [name for name in required if not os.path.exists(os.path.join(folder, name))]
    return (not missing), missing


try:
    from scene import (
        Scene,
        run,
        LANDSCAPE,
        background,
        fill,
        stroke,
        stroke_weight,
        rect,
        ellipse,
        text,
        line,
    )

    class SomaSevenRScene(Scene):
        def setup(self):
            files_ok, missing = dependency_status()
            self.files_ok = files_ok
            self.missing_files = missing
            existed = os.path.exists(SAVE_FILE)
            try:
                self.ecosystem = (
                    SomaSevenREcosystem.load(SAVE_FILE)
                    if existed else SomaSevenREcosystem(
                        seed=101, initial=6, capacity=10
                    )
                )
                self.save_status = 'LOADED' if existed else 'NEW'
            except Exception as exc:
                print('SOMA-7R save ignored:', exc)
                self.ecosystem = SomaSevenREcosystem(
                    seed=101, initial=6, capacity=10
                )
                self.save_status = 'RESET'
            self.paused = False
            self.accumulator = 0.0
            self.last_save_age = self.ecosystem.age
            self.last_touch_wall = -10.0
            self.frame_fps = 0.0
            self.sim_rate = 0.0
            self.telemetry_wall = time.time()
            self.telemetry_age = float(self.ecosystem.age)
            self.telemetry_frames = 0
            self.memory_peak_mb_est = _memory_peak_mb_estimate()
            self.report_status = 'WAIT'
            self.extinction_reported = not bool(self.ecosystem.agents)
            self.logger = LongRunCSVLogger(self.ecosystem)
            self.logger.log(
                self.ecosystem,
                self.frame_fps,
                self.sim_rate,
                reason='start',
                force=True,
                memory_peak_mb_est=self.memory_peak_mb_est,
                sim_backlog_s=self.accumulator,
            )

        def _update_telemetry(self):
            self.telemetry_frames += 1
            now = time.time()
            elapsed = now - self.telemetry_wall
            if elapsed >= 1.25:
                self.frame_fps = self.telemetry_frames / max(elapsed, 1e-9)
                self.sim_rate = (
                    float(self.ecosystem.age) - self.telemetry_age
                ) / max(elapsed, 1e-9)
                self.telemetry_wall = now
                self.telemetry_age = float(self.ecosystem.age)
                self.telemetry_frames = 0
                self.memory_peak_mb_est = _memory_peak_mb_estimate()

        def update(self):
            self._update_telemetry()
            if self.paused:
                return
            frame_dt = min(max(float(getattr(self, 'dt', 1.0 / 30.0)), 0.0), 0.12)
            self.accumulator += frame_dt
            fixed = 1.0 / SIM_HZ
            loops = 0
            while self.accumulator >= fixed and loops < 3:
                self.ecosystem.step(fixed)
                self.accumulator -= fixed
                loops += 1
            if self.ecosystem.age - self.last_save_age >= AUTO_SAVE_INTERVAL:
                try:
                    self.ecosystem.save(SAVE_FILE)
                    self.save_status = 'OK'
                    self.last_save_age = self.ecosystem.age
                except Exception as exc:
                    print('SOMA-7R save error:', exc)
                    self.save_status = 'ERROR'
            if self.logger.due(self.ecosystem):
                self.logger.log(
                    self.ecosystem,
                    self.frame_fps,
                    self.sim_rate,
                    reason='interval',
                    memory_peak_mb_est=self.memory_peak_mb_est,
                    sim_backlog_s=self.accumulator,
                )
            if not self.ecosystem.agents and not self.extinction_reported:
                self.extinction_reported = True
                self.logger.log(
                    self.ecosystem, self.frame_fps, self.sim_rate,
                    reason='extinction', force=True,
                    memory_peak_mb_est=self.memory_peak_mb_est,
                    sim_backlog_s=self.accumulator,
                )
                try:
                    self.ecosystem.save(SAVE_FILE)
                    self.save_status = 'EXTINCT'
                except Exception:
                    self.save_status = 'ERROR'
                self.report_status = generate_longrun_report()

        @staticmethod
        def _screen_point(position, left, bottom, world_width, world_height):
            return (
                left + float(position[0]) * world_width,
                bottom + float(position[1]) * world_height,
            )

        def draw(self):
            background(0.020, 0.029, 0.044)
            width, height = float(self.size.w), float(self.size.h)
            # Keep all HUD text inside a conservative landscape safe area.
            hud_left = 42.0
            hud_right = width - 72.0
            left, right = 38.0, width - 38.0
            bottom, top = 88.0, height - 94.0
            world_width, world_height = right - left, top - bottom
            fill(0.045, 0.062, 0.076)
            rect(left, bottom, world_width, world_height)

            world = self.ecosystem.world
            resource_palette = (
                (0.35, 0.90, 0.38),
                (0.96, 0.72, 0.24),
                (0.30, 0.72, 0.98),
            )
            for position, kind, biomass, capacity in zip(
                world.patch_positions,
                world.patch_types,
                world.patch_biomass,
                world.patch_capacity,
            ):
                x, y = self._screen_point(
                    position, left, bottom, world_width, world_height
                )
                radius = 3.5 + 11.5 * biomass / max(capacity, 1e-9)
                fill(*resource_palette[int(kind)], 0.82)
                ellipse(x - radius, y - radius, 2 * radius, 2 * radius)
            for position in world.hazard_positions:
                x, y = self._screen_point(
                    position, left, bottom, world_width, world_height
                )
                fill(0.95, 0.24, 0.27, 0.72)
                ellipse(x - 6.5, y - 6.5, 13, 13)
            for position in world.refuge_positions:
                x, y = self._screen_point(
                    position, left, bottom, world_width, world_height
                )
                fill(0.52, 0.42, 0.93, 0.16)
                ellipse(x - 27, y - 27, 54, 54)

            by_id = {agent.agent_id: agent for agent in self.ecosystem.agents}
            for source_id, target_id, created in self.ecosystem.last_signals:
                source = by_id.get(source_id)
                target = by_id.get(target_id)
                if source is None or target is None:
                    continue
                signal_age = clamp(
                    (self.ecosystem.age - float(created)) / 0.9, 0.0, 1.0
                )
                stroke(0.98, 0.84, 0.30, 0.72 * (1.0 - signal_age))
                stroke_weight(1.1)
                for first, second in torus_line_segments(
                    source.pos, target.pos
                ):
                    sx, sy = self._screen_point(
                        first, left, bottom, world_width, world_height
                    )
                    tx, ty = self._screen_point(
                        second, left, bottom, world_width, world_height
                    )
                    line(sx, sy, tx, ty)

            recent_births = {
                int(child_id): self.ecosystem.age - float(created)
                for _, child_id, created in self.ecosystem.last_births
            }
            cluster_palette = (
                (0.25, 0.86, 0.96),
                (0.98, 0.53, 0.25),
                (0.72, 0.46, 0.98),
                (0.42, 0.91, 0.48),
                (0.96, 0.34, 0.65),
                (0.92, 0.88, 0.34),
            )
            for agent in self.ecosystem.agents:
                x, y = self._screen_point(
                    agent.pos, left, bottom, world_width, world_height
                )
                health = clamp(1.0 - float(np.mean(agent.body_debt())), 0.0, 1.0)
                radius = 7.0 + 7.0 * health
                if agent.agent_id in recent_births:
                    birth_age = clamp(recent_births[agent.agent_id] / 1.6, 0.0, 1.0)
                    halo = radius + 7.0 + 5.0 * birth_age
                    fill(0.75, 1.0, 0.62, 0.20 * (1.0 - birth_age))
                    ellipse(x - halo, y - halo, 2 * halo, 2 * halo)
                colour = cluster_palette[agent.cluster_id % len(cluster_palette)]
                fill(*colour, 0.95)
                ellipse(x - radius, y - radius, 2 * radius, 2 * radius)
                stroke(0.95, 0.98, 1.0, 0.82)
                stroke_weight(1.0)
                line(x, y, x + agent.vel[0] * 150, y + agent.vel[1] * 150)
                fill(0.95, 0.98, 1.0)
                text(
                    '#{} C{} G{}'.format(
                        agent.agent_id, agent.cluster_id, agent.generation
                    ),
                    x=x, y=y - radius - 8, font_size=8, alignment=5,
                )

            # Resource bars.
            for resource_type in range(RESOURCE_TYPES):
                mask = world.patch_types == resource_type
                ratio = float(np.sum(world.patch_biomass[mask])) / max(
                    float(np.sum(world.patch_capacity[mask])), 1e-9
                )
                x = hud_left + 116 * resource_type
                fill(0.15, 0.18, 0.23)
                rect(x, height - 67, 102, 9)
                fill(*resource_palette[resource_type])
                rect(x, height - 67, 102 * clamp(ratio, 0.0, 1.0), 9)

            summary = self.ecosystem.summary()
            fill(0.93, 0.97, 1.0)
            # Alignment follows Pythonista's numeric-keypad convention:
            # 4 = left-centred, 6 = right-centred.
            text(BUILD, x=hud_left, y=height - 24, font_size=19, alignment=4)
            fill(0.63, 0.76, 0.86)
            text(
                'SCENE ACTIVE | FILES {} | SAVE {} | LOG {} | REPORT {} | {:.1f} fps | x{:.2f}'.format(
                    'OK' if self.files_ok else 'MISSING',
                    self.save_status,
                    self.logger.status,
                    self.report_status,
                    self.frame_fps,
                    self.sim_rate,
                ),
                x=hud_right, y=height - 24, font_size=10, alignment=6,
            )
            fill(0.84, 0.91, 0.97)
            text(
                'age {:.1f}s  pop {}/{}  clusters {}  births {} deaths {}  gen {}'.format(
                    summary['age'], summary['population'], summary['capacity'],
                    summary['clusters'], summary['births'], summary['deaths'],
                    summary['max_generation'],
                ),
                x=hud_left, y=57, font_size=12, alignment=4,
            )
            text(
                'health {:.3f}  diversity {:.3f}  culture {}  biomass {:.2f}  eco {:.2f}  climate {:.2f}'.format(
                    summary['mean_health'], summary['genetic_diversity'],
                    summary['transmissions'], summary['resource_biomass'],
                    world.resource_security(), summary['climate'],
                ),
                x=hud_left, y=36, font_size=11, alignment=4,
            )
            if summary['population'] == 0:
                fill(1.0, 0.42, 0.35)
                text(
                    'EXTINCT — report {} / double tap to reseed'.format(
                        self.report_status
                    ),
                    x=width * 0.5, y=height * 0.52,
                    font_size=18, alignment=5,
                )
                fill(0.84, 0.91, 0.97)
            text(
                'tap pause | double tap reset | peak {:.1f} MB | log {} rows | ledger {:.2e}'.format(
                    self.memory_peak_mb_est if np.isfinite(self.memory_peak_mb_est) else 0.0,
                    self.logger.rows_written, summary['reproduction_residual']
                ),
                x=hud_left, y=17, font_size=9, alignment=4,
            )

        def touch_began(self, touch):
            wall = time.time()
            if wall - self.last_touch_wall < 0.42:
                self.logger.log(
                    self.ecosystem,
                    self.frame_fps,
                    self.sim_rate,
                    reason='reset',
                    force=True,
                    memory_peak_mb_est=self.memory_peak_mb_est,
                    sim_backlog_s=self.accumulator,
                )
                try:
                    if os.path.exists(SAVE_FILE):
                        os.remove(SAVE_FILE)
                except Exception:
                    pass
                self.ecosystem = SomaSevenREcosystem(
                    seed=101, initial=6, capacity=10
                )
                gc.collect()
                self.logger = LongRunCSVLogger(self.ecosystem)
                self.logger.log(
                    self.ecosystem,
                    self.frame_fps,
                    self.sim_rate,
                    reason='start',
                    force=True,
                    memory_peak_mb_est=self.memory_peak_mb_est,
                    sim_backlog_s=self.accumulator,
                )
                self.accumulator = 0.0
                self.last_save_age = 0.0
                self.save_status = 'NEW'
                self.report_status = 'WAIT'
                self.extinction_reported = False
                self.paused = False
                self.telemetry_wall = time.time()
                self.telemetry_age = 0.0
                self.telemetry_frames = 0
                self.last_touch_wall = -10.0
                return
            self.last_touch_wall = wall
            self.paused = not self.paused
            self.logger.log(
                self.ecosystem,
                self.frame_fps,
                self.sim_rate,
                reason='pause' if self.paused else 'resume',
                force=True,
                memory_peak_mb_est=self.memory_peak_mb_est,
                sim_backlog_s=self.accumulator,
            )

        def stop(self):
            try:
                self.ecosystem.save(SAVE_FILE)
            except Exception:
                pass
            self.logger.log(
                self.ecosystem,
                self.frame_fps,
                self.sim_rate,
                reason='stop',
                force=True,
                memory_peak_mb_est=self.memory_peak_mb_est,
                sim_backlog_s=self.accumulator,
            )
            self.report_status = generate_longrun_report()

except ImportError:
    Scene = None


if __name__ == '__main__':
    if Scene is None:
        print(run_headless_trial(seed=101, seconds=30.0, initial=5, capacity=8))
    else:
        run(SomaSevenRScene(), LANDSCAPE, show_fps=False)
