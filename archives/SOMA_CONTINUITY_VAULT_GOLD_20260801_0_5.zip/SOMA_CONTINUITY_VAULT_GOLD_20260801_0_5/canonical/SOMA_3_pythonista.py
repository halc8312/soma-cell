# coding: utf-8
"""
SOMA-3 — Endogenous Experimental Questions / 内生的実験問い
Pythonista 3向け

必要ファイル（同じフォルダ）
- SOMA_1_pythonista.py
- SOMA_2_pythonista.py
- SOMA_2_1_pythonista.py
- SOMA_3_pythonista.py

SOMA-2.1の可撤回因果リースに、個体自身が実験価値を計算し、可逆な
身体介入を選択・実行・中止する「問い生成器」を追加する。

問いは文章ではなく、次の形式を持つ。
    Q = (現在の身体文脈, 可逆介入, 区別したい複数仮説, 停止条件)

現在の実装では、8方向の微小運動パルスと一時休止を候補介入とする。
各介入について4つの身体負債への効果を複数仮説粒子で保持し、

    価値 = 仮説不一致 × 身体的重要性 × 意思決定感度
           / (予測危険 + 代謝費 + 文脈外挿)

が高い問いだけをABBA/BAAB交差試験する。危険が高い場合は問いを保留し、
試験中に身体状態が悪化した場合は途中中止する。得られた知識は通常行動へ
小さな「実証済み傾向」として戻る。

研究仮説を動く形にしたものであり、意識・生命・学術的新規性を証明しない。
"""

import json
import math
import os
import numpy as np

import SOMA_2_pythonista as soma2
import SOMA_2_1_pythonista as soma21
from SOMA_1_pythonista import TROPHIC_COUNT, MAX_SPEED, clamp
from SOMA_2_1_pythonista import SomaTwoOneCore, scalar_array, bool_array

SAVE_FILE = os.path.join(os.path.dirname(__file__), 'soma3_life.npz')
SAVE_VERSION = 5

QUESTION_COUNT = 9
QUESTION_MOTOR = 0
QUESTION_REST = 1
HYPOTHESIS_COUNT = 7
CONTEXT_DIM = 7


def _unit_directions():
    angles = np.arange(8, dtype=float) * (2.0 * math.pi / 8.0)
    return np.column_stack((np.cos(angles), np.sin(angles)))


class EndogenousQuestioner:
    """Chooses reversible experiments from embodied decision relevance.

    Each intervention has a small ensemble of causal-effect hypotheses. An
    experiment is proposed only when disagreement concerns a body variable that
    currently matters and the predicted downside remains inside a safety budget.
    """

    def __init__(
        self,
        seed=0,
        enabled=True,
        use_questions_for_action=True,
        safety_enabled=True,
        value_threshold=0.025,
    ):
        self.rng = np.random.default_rng(int(seed) + 93017)
        self.enabled = bool(enabled)
        self.use_questions_for_action = bool(use_questions_for_action)
        self.safety_enabled = bool(safety_enabled)
        self.value_threshold = float(value_threshold)

        self.directions = _unit_directions()
        # Effect is improvement rate in each debt; positive is beneficial.
        self.mean = np.zeros((QUESTION_COUNT, TROPHIC_COUNT), dtype=float)
        self.hypotheses = self.rng.normal(
            0.0, 0.00075,
            size=(QUESTION_COUNT, HYPOTHESIS_COUNT, TROPHIC_COUNT),
        )
        self.weight = np.full((QUESTION_COUNT, HYPOTHESIS_COUNT), 1.0 / HYPOTHESIS_COUNT)
        self.evidence = np.zeros(QUESTION_COUNT, dtype=float)
        self.last_context = np.zeros((QUESTION_COUNT, CONTEXT_DIM), dtype=float)
        self.context_weight = np.zeros(QUESTION_COUNT, dtype=float)
        self.risk_mean = np.full(QUESTION_COUNT, 0.10, dtype=float)
        self.risk_weight = np.full(QUESTION_COUNT, 0.5, dtype=float)
        self.next_allowed_age = np.zeros(QUESTION_COUNT, dtype=float)

        self.active = False
        self.question_index = -1
        self.sequence = np.zeros(4, dtype=np.int8)
        self.period_index = 0
        self.period_elapsed = 0.0
        self.period_duration = 1.35
        self.washout_duration = 0.40
        self.washout = False
        self.start_debt = np.zeros(TROPHIC_COUNT, dtype=float)
        self.period_rates = np.zeros((4, TROPHIC_COUNT), dtype=float)
        self.period_context = np.zeros((4, CONTEXT_DIM), dtype=float)
        self.period_complete = np.zeros(4, dtype=bool)
        self.period_event = np.zeros(4, dtype=np.int16)
        self.segment_context_sum = np.zeros(CONTEXT_DIM, dtype=float)
        self.segment_context_time = 0.0
        self.segment_event_mask = 0
        self.pretrial_debt = np.zeros(TROPHIC_COUNT, dtype=float)
        self.abort_debt = np.zeros(TROPHIC_COUNT, dtype=float)

        self.cooldown = 8.0
        self.completed = 0
        self.aborted = 0
        self.deferred = 0
        self.questions_considered = 0
        self.action_guidance_time = 0.0
        self.last_value = 0.0
        self.last_risk = 0.0
        self.last_effect = np.zeros(TROPHIC_COUNT, dtype=float)
        self.last_quality = 0.0
        self.last_status = 'waiting'
        self.last_question = 'none'

    @property
    def busy(self):
        return bool(self.active)

    def context(self, core, debt):
        ambient, _ = core.temperature_field()
        speed = float(np.linalg.norm(core.vel)) / max(MAX_SPEED, 1e-9)
        return np.array([
            float(debt[0]), float(debt[1]), float(debt[2]), float(debt[3]),
            clamp(speed, 0.0, 1.5), float(ambient), float(core.shelter_level()),
        ], dtype=float)

    def _context_distance(self, index, context):
        if self.context_weight[index] < 0.1:
            return 0.45
        scale = np.array([0.22, 0.22, 0.18, 0.24, 0.35, 0.22, 0.35])
        return float(np.sqrt(np.mean(((context - self.last_context[index]) / scale) ** 2)))

    def _need(self, debt):
        debt = np.asarray(debt, dtype=float)
        return np.clip((debt - 0.08) / 0.55, 0.0, 1.5)

    def _posterior_stats(self, index):
        w = self.weight[index]
        w = w / max(float(np.sum(w)), 1e-12)
        h = self.hypotheses[index]
        mean = np.sum(w[:, None] * h, axis=0)
        variance = np.sum(w[:, None] * (h - mean) ** 2, axis=0)
        return mean, variance

    def candidate_values(self, age, debt, context):
        need = self._need(debt)
        values = np.full(QUESTION_COUNT, -1e9, dtype=float)
        risks = np.zeros(QUESTION_COUNT, dtype=float)
        for q in range(QUESTION_COUNT):
            if age < self.next_allowed_age[q]:
                continue
            mean, variance = self._posterior_stats(q)
            disagreement = float(np.sum((0.08 + need) * np.sqrt(variance + 1e-10)))
            # How likely new evidence is to alter action preference, not mere surprise.
            decision_margin = float(np.sum((0.10 + need) * np.exp(-np.abs(mean) / 0.00045)))
            context_distance = self._context_distance(q, context)
            extrapolation = 0.35 + context_distance
            predicted_harm = float(np.sum((0.10 + need) * np.maximum(-mean, 0.0)))
            empirical_risk = float(self.risk_mean[q])
            intervention_cost = 0.10 if q < 8 else 0.055
            risk = 120.0 * predicted_harm + empirical_risk + intervention_cost + 0.08 * context_distance
            benefit = 120.0 * disagreement * (0.35 + decision_margin) * (0.25 + float(np.max(need)))
            value = benefit / max(risk + extrapolation, 1e-6)
            values[q] = value
            risks[q] = risk
        return values, risks

    def _question_text(self, index):
        if index == 8:
            return 'Does brief rest improve the body now?'
        labels = ('E', 'NE', 'N', 'NW', 'W', 'SW', 'S', 'SE')
        return 'Does a small {} pulse improve the body now?'.format(labels[index])

    def maybe_start(self, age, debt, context, other_busy=False, force=False):
        self.cooldown = max(0.0, self.cooldown)
        if not self.enabled or self.active or other_busy or (self.cooldown > 0.0 and not force):
            return False
        values, risks = self.candidate_values(age, debt, context)
        self.questions_considered += QUESTION_COUNT
        index = int(np.argmax(values))
        value = float(values[index])
        risk = float(risks[index])
        self.last_value = value
        self.last_risk = risk
        max_debt = float(np.max(debt))
        safety_limit = 0.62 - 0.34 * max_debt
        if self.safety_enabled and risk > safety_limit and not force:
            self.deferred += 1
            self.cooldown = 4.0
            self.last_status = 'question deferred: unsafe'
            return False
        if value < self.value_threshold and not force:
            self.deferred += 1
            self.cooldown = 5.0
            self.last_status = 'question deferred: low value'
            return False

        self.active = True
        self.question_index = index
        a = np.array([0, 1, 1, 0], dtype=np.int8)
        b = 1 - a
        self.sequence = a if self.rng.random() < 0.5 else b
        self.period_index = 0
        self.period_elapsed = 0.0
        self.washout = False
        self.period_rates[:] = 0.0
        self.period_context[:] = 0.0
        self.period_complete[:] = False
        self.period_event[:] = 0
        self.segment_context_sum[:] = 0.0
        self.segment_context_time = 0.0
        self.segment_event_mask = 0
        self.pretrial_debt = np.asarray(debt, dtype=float).copy()
        self.abort_debt = np.minimum(0.97, self.pretrial_debt + np.array([0.14, 0.13, 0.11, 0.15]))
        self.start_debt = np.asarray(debt, dtype=float).copy()
        self.last_question = self._question_text(index)
        self.last_status = 'testing question'
        return True

    def intervention_on(self):
        return bool(self.active and not self.washout and self.sequence[self.period_index] == 1)

    def alter_action(self, action, dt, experimental_only=False):
        action = np.asarray(action, dtype=float).copy()
        if self.active and self.intervention_on():
            if self.question_index < 8:
                action += 0.24 * self.directions[self.question_index]
            else:
                action *= 0.28
            return np.clip(action, -1.0, 1.0)

        if experimental_only or not self.use_questions_for_action or self.active:
            return action
        # Use only sufficiently replicated, context-relevant causal knowledge.
        scores = np.full(QUESTION_COUNT, -1e9, dtype=float)
        for q in range(QUESTION_COUNT):
            mean, variance = self._posterior_stats(q)
            confidence = 1.0 / (1.0 + 1800.0 * float(np.sqrt(np.mean(variance))))
            support = 1.0 - math.exp(-float(self.evidence[q]) / 2.5)
            scores[q] = support * confidence * float(np.max(mean))
        q = int(np.argmax(scores))
        if scores[q] > 0.000045:
            strength = clamp(900.0 * scores[q], 0.0, 0.14)
            if q < 8:
                action += strength * self.directions[q]
            else:
                action *= 1.0 - strength
            self.action_guidance_time += dt
        return np.clip(action, -1.0, 1.0)

    def observe(self, debt_before, debt_after, dt, context, event_mask=0):
        dt = float(dt)
        self.cooldown = max(0.0, self.cooldown - dt)
        if not self.active:
            return

        debt_after = np.asarray(debt_after, dtype=float)
        if self.safety_enabled and np.any(debt_after > self.abort_debt):
            self._abort('question aborted: safety boundary')
            return

        if self.washout:
            self.period_elapsed += dt
            if self.period_elapsed >= self.washout_duration:
                self.washout = False
                self.period_elapsed = 0.0
                self.start_debt = debt_after.copy()
                self.segment_context_sum[:] = 0.0
                self.segment_context_time = 0.0
                self.segment_event_mask = 0
            return

        self.period_elapsed += dt
        self.segment_context_sum += dt * np.asarray(context, dtype=float)
        self.segment_context_time += dt
        self.segment_event_mask |= int(event_mask)
        if self.period_elapsed < self.period_duration:
            return

        i = self.period_index
        self.period_rates[i] = (self.start_debt - debt_after) / max(self.period_elapsed, 1e-9)
        self.period_context[i] = self.segment_context_sum / max(self.segment_context_time, 1e-9)
        self.period_event[i] = self.segment_event_mask
        self.period_complete[i] = True
        self.period_index += 1
        if self.period_index >= 4:
            self._finish()
            return
        self.washout = True
        self.period_elapsed = 0.0

    def _finish(self):
        on = self.period_rates[self.sequence == 1]
        off = self.period_rates[self.sequence == 0]
        effect = np.median(on, axis=0) - np.median(off, axis=0)
        noise = np.median(np.abs(self.period_rates - np.median(self.period_rates, axis=0)), axis=0)
        hard = np.any((self.period_event & (soma21.EVENT_NUTRIENT | soma21.EVENT_TOXIN)) != 0)
        context_spread = float(np.mean(np.std(self.period_context, axis=0)))
        quality = math.exp(-8.0 * float(np.mean(noise)) - 2.0 * context_spread)
        if hard:
            quality *= 0.35
        quality = clamp(quality, 0.05, 1.0)
        q = self.question_index

        pred_mean, pred_var = self._posterior_stats(q)
        obs_var = 0.00020 ** 2 + noise ** 2
        # Particle likelihood update, followed by small rejuvenation to avoid collapse.
        error = self.hypotheses[q] - effect[None, :]
        log_like = -0.5 * quality * np.sum(error ** 2 / (obs_var[None, :] + 1e-12), axis=1)
        log_like -= np.max(log_like)
        w = self.weight[q] * np.exp(np.clip(log_like, -40.0, 0.0))
        if float(np.sum(w)) < 1e-12:
            w[:] = 1.0
        self.weight[q] = w / np.sum(w)
        post_mean, _ = self._posterior_stats(q)
        learning = 0.28 * quality / (1.0 + 0.22 * self.evidence[q])
        self.hypotheses[q] += learning * (effect[None, :] - self.hypotheses[q])
        self.hypotheses[q] += self.rng.normal(0.0, 0.000035 * (1.0 - quality), self.hypotheses[q].shape)
        self.mean[q] = (1.0 - learning) * self.mean[q] + learning * effect
        self.evidence[q] += quality
        context = np.mean(self.period_context, axis=0)
        cw = self.context_weight[q]
        self.last_context[q] = (cw * self.last_context[q] + quality * context) / max(cw + quality, 1e-9)
        self.context_weight[q] = cw + quality

        harmful = float(np.mean(np.maximum(-effect, 0.0)))
        rw = self.risk_weight[q]
        self.risk_mean[q] = (rw * self.risk_mean[q] + quality * clamp(600.0 * harmful, 0.0, 1.0)) / (rw + quality)
        self.risk_weight[q] = rw + quality
        self.next_allowed_age[q] += 0.0
        self.last_effect = effect
        self.last_quality = quality
        self.completed += 1
        self.active = False
        self.question_index = -1
        self.cooldown = 7.0 + 4.0 * (1.0 - quality)
        self.last_status = 'question learned'

    def _abort(self, reason):
        q = self.question_index
        if q >= 0:
            self.risk_mean[q] = clamp(0.78 * self.risk_mean[q] + 0.22, 0.0, 1.0)
            self.risk_weight[q] += 0.5
            self.next_allowed_age[q] += 12.0
        self.active = False
        self.question_index = -1
        self.aborted += 1
        self.cooldown = 10.0
        self.last_status = reason

    def cancel_active(self, reason='cancelled'):
        if self.active:
            self._abort(reason)

    def diagnostics(self, age, debt, context):
        values, risks = self.candidate_values(age, debt, context)
        valid = values[values > -1e8]
        return {
            'best_value': float(np.max(valid)) if valid.size else 0.0,
            'mean_risk': float(np.mean(risks)),
            'known': int(np.sum(self.evidence > 0.5)),
            'evidence': float(np.sum(self.evidence)),
            'completed': int(self.completed),
            'aborted': int(self.aborted),
            'deferred': int(self.deferred),
            'guided_time': float(self.action_guidance_time),
        }

    def state_dict(self):
        return {
            'q_enabled': bool_array(self.enabled),
            'q_use_action': bool_array(self.use_questions_for_action),
            'q_safety': bool_array(self.safety_enabled),
            'q_value_threshold': scalar_array(self.value_threshold),
            'q_mean': self.mean,
            'q_hypotheses': self.hypotheses,
            'q_weight': self.weight,
            'q_evidence': self.evidence,
            'q_last_context': self.last_context,
            'q_context_weight': self.context_weight,
            'q_risk_mean': self.risk_mean,
            'q_risk_weight': self.risk_weight,
            'q_next_allowed': self.next_allowed_age,
            'q_active': bool_array(self.active),
            'q_index': scalar_array(self.question_index, np.int64),
            'q_sequence': self.sequence,
            'q_period_index': scalar_array(self.period_index, np.int64),
            'q_period_elapsed': scalar_array(self.period_elapsed),
            'q_washout': bool_array(self.washout),
            'q_start_debt': self.start_debt,
            'q_period_rates': self.period_rates,
            'q_period_context': self.period_context,
            'q_period_complete': self.period_complete.astype(np.uint8),
            'q_period_event': self.period_event,
            'q_segment_context_sum': self.segment_context_sum,
            'q_segment_context_time': scalar_array(self.segment_context_time),
            'q_segment_event_mask': scalar_array(self.segment_event_mask, np.int64),
            'q_pretrial_debt': self.pretrial_debt,
            'q_abort_debt': self.abort_debt,
            'q_cooldown': scalar_array(self.cooldown),
            'q_completed': scalar_array(self.completed, np.int64),
            'q_aborted': scalar_array(self.aborted, np.int64),
            'q_deferred': scalar_array(self.deferred, np.int64),
            'q_considered': scalar_array(self.questions_considered, np.int64),
            'q_guided_time': scalar_array(self.action_guidance_time),
            'q_last_value': scalar_array(self.last_value),
            'q_last_risk': scalar_array(self.last_risk),
            'q_last_effect': self.last_effect,
            'q_last_quality': scalar_array(self.last_quality),
            'q_last_status': np.array(self.last_status),
            'q_last_question': np.array(self.last_question),
            'q_rng_state': np.array(json.dumps(self.rng.bit_generator.state)),
        }

    def load_state(self, data):
        self.enabled = bool(int(data['q_enabled']))
        self.use_questions_for_action = bool(int(data['q_use_action']))
        self.safety_enabled = bool(int(data['q_safety']))
        self.value_threshold = float(data['q_value_threshold'])
        for name, key, dtype in [
            ('mean','q_mean',float), ('hypotheses','q_hypotheses',float), ('weight','q_weight',float),
            ('evidence','q_evidence',float), ('last_context','q_last_context',float),
            ('context_weight','q_context_weight',float), ('risk_mean','q_risk_mean',float),
            ('risk_weight','q_risk_weight',float), ('next_allowed_age','q_next_allowed',float),
            ('sequence','q_sequence',np.int8), ('start_debt','q_start_debt',float),
            ('period_rates','q_period_rates',float), ('period_context','q_period_context',float),
            ('period_complete','q_period_complete',bool), ('period_event','q_period_event',np.int16),
            ('segment_context_sum','q_segment_context_sum',float), ('pretrial_debt','q_pretrial_debt',float),
            ('abort_debt','q_abort_debt',float), ('last_effect','q_last_effect',float),
        ]:
            setattr(self, name, np.array(data[key], dtype=dtype))
        self.active = bool(int(data['q_active']))
        self.question_index = int(data['q_index'])
        self.period_index = int(data['q_period_index'])
        self.period_elapsed = float(data['q_period_elapsed'])
        self.washout = bool(int(data['q_washout']))
        self.segment_context_time = float(data['q_segment_context_time'])
        self.segment_event_mask = int(data['q_segment_event_mask'])
        self.cooldown = float(data['q_cooldown'])
        self.completed = int(data['q_completed'])
        self.aborted = int(data['q_aborted'])
        self.deferred = int(data['q_deferred'])
        self.questions_considered = int(data['q_considered'])
        self.action_guidance_time = float(data['q_guided_time'])
        self.last_value = float(data['q_last_value'])
        self.last_risk = float(data['q_last_risk'])
        self.last_quality = float(data['q_last_quality'])
        self.last_status = str(np.asarray(data['q_last_status']).item())
        self.last_question = str(np.asarray(data['q_last_question']).item())
        self.rng.bit_generator.state = json.loads(
            str(np.asarray(data['q_rng_state']).item())
        )


class SomaThreeCore(SomaTwoOneCore):
    def __init__(
        self,
        seed=None,
        question_enabled=True,
        question_action_guidance=True,
        question_safety=True,
        freeze_learning_during_questions=True,
        **kwargs
    ):
        super().__init__(seed=seed, **kwargs)
        self.questioner = EndogenousQuestioner(
            seed=self.seed,
            enabled=question_enabled,
            use_questions_for_action=question_action_guidance,
            safety_enabled=question_safety,
        )
        self.freeze_learning_during_questions = bool(freeze_learning_during_questions)
        self.question_frozen_time = 0.0

    def step(self, dt=1.0 / 30.0):
        dt = clamp(float(dt), 1.0 / 240.0, 0.10)
        if not self.alive:
            return
        debt_before = self.body_debt()
        context_before = self.questioner.context(self, debt_before)

        # Existing audits and morphology retain priority when already due.
        if not self.auditor.busy and not self.morphology.busy and not self.questioner.busy:
            started = False
            # Ask only after a minimal embodied history exists.
            if self.age > 18.0 and self.questioner.cooldown <= 0.0:
                started = self.questioner.maybe_start(
                    self.age, debt_before, context_before, other_busy=False
                )
            if not started and self.morphology.review_due(self.age, debt_before):
                started = self.morphology.maybe_start(
                    self.age, debt_before, self.brain, self.auditor, audit_busy=False
                )
            if not started and self.auditor.enabled:
                started = self.auditor.maybe_start(
                    self.age, debt_before, self.brain, morphology_busy=False
                )
            if not started:
                self.morphology.maybe_start(
                    self.age, debt_before, self.brain, self.auditor, audit_busy=False
                )

        self.brain.set_audit_gate(
            self.auditor.gate() if self.auditor.enabled else np.ones((soma21.CELL_COUNT, TROPHIC_COUNT))
        )
        self.brain.set_efferent_knockout(self.auditor.current_knockout_mask())
        sensor = self.make_sensor()
        action = self.brain.act(sensor, debt_before, dt)
        action = self.questioner.alter_action(action, dt)

        eaten_before = self.eaten
        poisoned_before = self.poisoned
        shelter_before = self.shelter_level()
        ambient_before, _ = self.temperature_field()
        self._apply_body_and_world(action, dt)
        if self.eaten > eaten_before:
            self.morphology.add_material(0.070 * (self.eaten - eaten_before))

        next_sensor = self.make_sensor()
        debt_after = self.body_debt()
        event_mask = self._event_mask(eaten_before, poisoned_before, shelter_before, ambient_before)
        audit_context = self._audit_context(debt_after)
        q_context = self.questioner.context(self, debt_after)

        was_learning = self.brain.learning_enabled
        causal_snapshot = None
        freeze = self.auditor.busy or (
            self.freeze_learning_during_trials and self.morphology.busy
        ) or (self.freeze_learning_during_questions and self.questioner.busy)
        if freeze:
            self.brain.learning_enabled = False
            if self.questioner.busy:
                self.question_frozen_time += dt
            else:
                self.trial_frozen_time += dt
        if self.auditor.busy:
            causal_snapshot = self.brain.causal_estimate.copy()
        self.brain.learn(next_sensor, debt_after, dt)
        if causal_snapshot is not None:
            self.brain.causal_estimate = causal_snapshot
        self.brain.learning_enabled = was_learning
        self.brain.set_efferent_knockout(None)

        self.auditor.observe(debt_after, dt, self.age + dt, event_mask=event_mask, context=audit_context)
        self.morphology.observe(debt_before, debt_after, dt, age=self.age + dt)
        self.questioner.observe(debt_before, debt_after, dt, q_context, event_mask=event_mask)

        self.last_action = np.array(action, dtype=float)
        self.age += dt
        self.last_body_debt = debt_after
        self.viability_integral += dt * (1.0 - float(np.mean(debt_after)))
        if self.energy <= 0.0 or self.integrity <= 0.0:
            self.energy = max(0.0, self.energy)
            self.integrity = max(0.0, self.integrity)
            self.vel[:] = 0.0
            self.alive = False

    def regenerate_body(self, normalized_position=None):
        self.questioner.cancel_active('cancelled by regeneration')
        super().regenerate_body(normalized_position)

    def state_dict(self):
        state = super().state_dict()
        state['save_version'] = scalar_array(SAVE_VERSION, np.int64)
        state.update({
            'soma3_freeze_questions': bool_array(self.freeze_learning_during_questions),
            'soma3_question_frozen_time': scalar_array(self.question_frozen_time),
        })
        state.update(self.questioner.state_dict())
        return state

    def load_state(self, data):
        if int(data['save_version']) != SAVE_VERSION:
            raise ValueError('unsupported SOMA-3 save version')
        keys = list(data.files) if hasattr(data, 'files') else list(data.keys())
        base = {key: data[key] for key in keys}
        base['save_version'] = scalar_array(4, np.int64)
        super().load_state(base)
        self.freeze_learning_during_questions = bool(int(data['soma3_freeze_questions']))
        self.question_frozen_time = float(data['soma3_question_frozen_time'])
        self.questioner.load_state(data)


if soma2.IN_PYTHONISTA:
    class SomaThreeScene(soma21.SomaTwoOneScene):
        def setup(self):
            self._building_base_scene = True
            super().setup()
            self._building_base_scene = False
            self.core = SomaThreeCore()
            self.help_label.text = 'tap: relocate nutrient   endogenous questions autosave: 20 s'
            self._load_life_if_possible()
            self._sync_nodes(force_tiles=True)

        def _save_life(self):
            if getattr(self, '_building_base_scene', False):
                return
            try:
                np.savez(SAVE_FILE, **self.core.state_dict())
            except Exception as exc:
                print('SOMA-3 save failed:', exc)

        def _load_life_if_possible(self):
            if getattr(self, '_building_base_scene', False) or not os.path.exists(SAVE_FILE):
                return
            try:
                with np.load(SAVE_FILE, allow_pickle=False) as data:
                    self.core.load_state(data)
            except Exception as exc:
                print('SOMA-3 load ignored:', exc)

        def _sync_nodes(self, force_tiles=False):
            super()._sync_nodes(force_tiles=force_tiles)
            if getattr(self, '_building_base_scene', False):
                return
            q = self.core.questioner
            qd = q.diagnostics(self.core.age, self.core.body_debt(), q.context(self.core, self.core.body_debt()))
            self.info_label.text += (
                '\nQUESTION {:28s} done/abort/defer {}/{}/{} value {:.3f} risk {:.3f} q {:.2f}\n'
                '"{}" known {} evidence {:.2f} guided {:.1f}s frozen {:.1f}s'
            ).format(
                q.last_status, q.completed, q.aborted, q.deferred,
                q.last_value, q.last_risk, q.last_quality,
                q.last_question, qd['known'], qd['evidence'],
                qd['guided_time'], self.core.question_frozen_time,
            )


def run_headless_trial(
    seed=0,
    seconds=300.0,
    question_enabled=True,
    question_action_guidance=True,
    question_safety=True,
    freeze_learning_during_questions=True,
    dt=1.0/30.0,
    **kwargs
):
    core = SomaThreeCore(
        seed=seed,
        question_enabled=question_enabled,
        question_action_guidance=question_action_guidance,
        question_safety=question_safety,
        freeze_learning_during_questions=freeze_learning_during_questions,
        **kwargs
    )
    for _ in range(int(max(0.0, seconds) / dt)):
        core.step(dt)
        if not core.alive:
            break
    qd = core.questioner.diagnostics(core.age, core.body_debt(), core.questioner.context(core, core.body_debt()))
    return {
        'seed': int(seed), 'age': float(core.age), 'alive': int(core.alive),
        'health': float(core.viability_integral / max(core.age, 1e-9)),
        'energy': float(core.energy), 'temperature': float(core.temperature),
        'integrity': float(core.integrity), 'fatigue': float(core.fatigue),
        'food': int(core.eaten), 'toxin': int(core.poisoned),
        'questions_completed': qd['completed'], 'questions_aborted': qd['aborted'],
        'questions_deferred': qd['deferred'], 'question_evidence': qd['evidence'],
        'question_known': qd['known'], 'guided_time': qd['guided_time'],
        'audit_completed': int(core.auditor.completed),
        'leases_active': int(np.sum(core.morphology.lease_active)),
        'leases_revoked': int(core.morphology.leases_revoked),
        'prediction_error': float(np.mean(core.brain.prediction_error)),
    }


if __name__ == '__main__':
    if soma2.IN_PYTHONISTA:
        from scene import run, PORTRAIT
        run(SomaThreeScene(), orientation=PORTRAIT, show_fps=False)
    else:
        print(run_headless_trial(seed=101, seconds=60.0))
