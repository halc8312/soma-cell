# coding: utf-8
"""
SOMA-4.1 — Counterfactual Twin Laboratory / 反実仮想ツイン実験室
Pythonista 3 / CPython + NumPy

必要ファイル（同じフォルダ）
--------------------------------
- SOMA_1_pythonista.py
- SOMA_2_pythonista.py
- SOMA_2_1_pythonista.py
- SOMA_3_pythonista.py
- SOMA_4_pythonista.py
- SOMA_4_1_pythonista.py（このファイル）

SOMA-4までに、個体は自分の因果主張を短い身体実験へコンパイルし、反証された
神経組織を再可塑化できるようになった。しかし、機構が「動く」ことと、その機構が
個体の将来を本当に改善することは別である。

SOMA-4.1は、任意時点の個体を完全複製し、同じ身体・脳・世界・乱数状態から二つの
未来を分岐させる。違わせるのは一つの機構だけである。

    treatment : 検証対象の機構あり
    control   : それ以外は同じで、対象機構だけなし／費用整合ランダム

比較対象
--------
1. experiment_value  : 反証実験を実行する / 実行しない
2. feedback_value    : 反証後の組織再可塑化を適用 / 記録だけして適用しない
3. compiled_vs_random: コンパイル実験 / 命令数・強度・時間を揃えたランダム実験
4. lease_value       : 採択器官の差分を維持 / その差分だけ撤去

世界条件
--------
- stable             : 規則を変えない
- meaning_reversal   : 化学AとBの身体的意味を途中で反転
- body_damage        : 右側の感覚器・フィンと一部運動細胞を途中で損傷
- delayed_outcomes   : 接触結果を途中から数秒遅延

重要な実装上の工夫
------------------
普通に二つのシミュレーションを複製しても、片方だけが餌を取った瞬間に世界乱数の
消費回数がずれ、その後の感覚ノイズまで別物になる。本実装では、接触後の物体再配置を
(seed, 種類, 物体番号, 接触回数) から作る決定論的位置へ分離する。さらに、世界、脳、
監査器、形態形成、問い生成、反証コンパイラの各乱数を、(ステップ, サブシステム)で
指定される共通外乱テープから毎ステップ再同期する。

これは研究用の評価装置であり、反実仮想の完全な因果証明ではない。行動が分岐すれば
接触する物体や時刻も変わるため、世界状態そのものは当然分岐する。共有しているのは、
分岐前の完全状態と、分岐後の外生乱数系列である。
"""

import copy
import csv
import json
import math
import os

import numpy as np

import SOMA_1_pythonista as soma1
import SOMA_2_pythonista as soma2
import SOMA_2_1_pythonista as soma21
import SOMA_3_pythonista as soma3
import SOMA_4_pythonista as soma4
from SOMA_1_pythonista import (
    BODY_RADIUS,
    CELL_COUNT,
    MAX_SPEED,
    NUTRIENT_COUNT,
    NUTRIENT_RADIUS,
    SHELTER_RADIUS,
    TROPHIC_COUNT,
    TOXIN_COUNT,
    TOXIN_RADIUS,
    clamp,
    encode_rng_state,
    restore_rng_state,
    wrapped_delta,
)
from SOMA_2_pythonista import (
    MORPH_FIN,
    MORPH_MODALITY_COUNT,
    MORPH_SENSOR,
    MORPH_SHELL,
    MORPH_SLOT_COUNT,
    bool_array,
    scalar_array,
)


SAVE_FILE = os.path.join(os.path.dirname(__file__), 'soma4_1_twinlab.npz')
CORE_SAVE_VERSION = 7
LAB_SAVE_VERSION = 3

# -----------------------------------------------------------------------------
# Twin modes and world regimes
# -----------------------------------------------------------------------------

TWIN_EXPERIMENT_VALUE = 0
TWIN_FEEDBACK_VALUE = 1
TWIN_COMPILED_VS_RANDOM = 2
TWIN_LEASE_VALUE = 3
TWIN_MODE_NAMES = (
    'experiment_value',
    'feedback_value',
    'compiled_vs_random',
    'lease_value',
)

REGIME_STABLE = 0
REGIME_MEANING_REVERSAL = 1
REGIME_BODY_DAMAGE = 2
REGIME_DELAYED_OUTCOMES = 3
REGIME_NAMES = (
    'stable',
    'meaning_reversal',
    'body_damage',
    'delayed_outcomes',
)

PHASE_WARMUP = 0
PHASE_EVALUATION = 1
PHASE_DONE = 2
PHASE_FAILED = 3
PHASE_NAMES = ('warmup', 'evaluation', 'done', 'failed')

EFFECT_NUTRIENT = 1
EFFECT_TOXIN = -1
MAX_DELAYED_EVENTS = 32

DEFAULT_TWIN_MODE = TWIN_EXPERIMENT_VALUE
DEFAULT_REGIME = REGIME_MEANING_REVERSAL

DEBT_NAMES = ('energy', 'thermal', 'integrity', 'fatigue')


def mode_code(value):
    if isinstance(value, str):
        if value not in TWIN_MODE_NAMES:
            raise ValueError('unknown twin mode: ' + value)
        return TWIN_MODE_NAMES.index(value)
    value = int(value)
    if not 0 <= value < len(TWIN_MODE_NAMES):
        raise ValueError('invalid twin mode')
    return value


def regime_code(value):
    if isinstance(value, str):
        if value not in REGIME_NAMES:
            raise ValueError('unknown regime: ' + value)
        return REGIME_NAMES.index(value)
    value = int(value)
    if not 0 <= value < len(REGIME_NAMES):
        raise ValueError('invalid regime')
    return value


def _copy_state(state):
    """Deep-copy an np.savez-compatible state mapping."""
    return {key: np.array(value, copy=True) for key, value in state.items()}


def _rng_text(rng):
    return json.dumps(rng.bit_generator.state, sort_keys=True, separators=(',', ':'))


def _rngs_coupled(a, b):
    """The exogenous sensor-noise and neuronal probe streams are the key pair."""
    return (
        _rng_text(a.rng) == _rng_text(b.rng)
        and _rng_text(a.brain.rng) == _rng_text(b.brain.rng)
    )


def _component_rngs(core):
    """Independent stochastic subsystems synchronized by the twin noise tape."""
    return (
        core.rng,
        core.brain.rng,
        core.auditor.rng,
        core.morphology.rng,
        core.questioner.rng,
        core.compiler.rng,
    )


def _pcg_state(seed):
    return np.random.PCG64(int(seed) & ((1 << 64) - 1)).state


def _prefix_state(prefix, state):
    return {prefix + key: value for key, value in state.items()}


def _extract_prefixed(data, prefix):
    keys = list(data.files) if hasattr(data, 'files') else list(data.keys())
    return {key[len(prefix):]: data[key] for key in keys if key.startswith(prefix)}


def _splitmix64(value):
    mask = (1 << 64) - 1
    z = (int(value) + 0x9E3779B97F4A7C15) & mask
    z = ((z ^ (z >> 30)) * 0xBF58476D1CE4E5B9) & mask
    z = ((z ^ (z >> 27)) * 0x94D049BB133111EB) & mask
    return (z ^ (z >> 31)) & mask


def _hash_unit(seed, kind, index, count, axis):
    value = int(seed) & ((1 << 64) - 1)
    value ^= (int(kind) + 17) * 0xD6E8FEB86659FD93
    value ^= (int(index) + 31) * 0xA5A3564E27F8862D
    value ^= (int(count) + 47) * 0x9E3779B185EBCA87
    value ^= (int(axis) + 61) * 0xC2B2AE3D27D4EB4F
    hashed = _splitmix64(value)
    return float((hashed >> 11) & ((1 << 53) - 1)) / float(1 << 53)


def _deterministic_position(seed, kind, index, count):
    return np.array([
        _hash_unit(seed, kind, index, count, 0),
        _hash_unit(seed, kind, index, count, 1),
    ], dtype=float)


def _no_structural_rewire():
    """Instance override with no bound-self cycle."""
    return None


# =============================================================================
# Deferred falsification feedback
# =============================================================================

FEEDBACK_IMMEDIATE = 0
FEEDBACK_DEFER_ONCE = 1
FEEDBACK_DISCARD = 2


class TwinFalsificationCompiler(soma4.FalsificationCompiler):
    """SOMA-4 compiler with an optional one-event feedback escrow.

    SOMA-4 immediately reopens tissue after a sufficiently strong contradiction.
    For the feedback twin, the observation must be identical up to the exact
    feedback instant. This subclass stores the proposed tissue change, allows the
    whole organism to be cloned, and only then applies it to the treatment branch.
    """

    def __init__(self, *args, feedback_policy=FEEDBACK_IMMEDIATE, **kwargs):
        super().__init__(*args, **kwargs)
        self.feedback_policy = int(feedback_policy)
        self.pending_feedback = False
        self.pending_slot = -1
        self.pending_quality = 0.0
        self.pending_posterior = 0.5
        self.pending_age = -1.0
        self.feedback_deferred_count = 0
        self.feedback_applied_count = 0
        self.feedback_discarded_count = 0

    def _apply_counterexample_feedback(self, core, slot, quality, posterior):
        if self.feedback_policy == FEEDBACK_DEFER_ONCE:
            self.pending_feedback = True
            self.pending_slot = int(slot)
            self.pending_quality = float(quality)
            self.pending_posterior = float(posterior)
            self.pending_age = float(core.age)
            self.feedback_deferred_count += 1
            self.last_status = 'counterexample held in feedback escrow'
            return
        if self.feedback_policy == FEEDBACK_DISCARD:
            self.feedback_discarded_count += 1
            return
        super()._apply_counterexample_feedback(core, slot, quality, posterior)
        self.feedback_applied_count += 1

    def apply_pending(self, core):
        if not self.pending_feedback:
            return False
        slot = int(self.pending_slot)
        quality = float(self.pending_quality)
        posterior = float(self.pending_posterior)
        self.pending_feedback = False
        self.pending_slot = -1
        previous = self.feedback_policy
        self.feedback_policy = FEEDBACK_IMMEDIATE
        soma4.FalsificationCompiler._apply_counterexample_feedback(
            self, core, slot, quality, posterior
        )
        self.feedback_applied_count += 1
        self.feedback_policy = previous
        self.last_status = 'escrowed counterexample applied to tissue'
        return True

    def discard_pending(self):
        if not self.pending_feedback:
            return False
        self.pending_feedback = False
        self.pending_slot = -1
        self.feedback_discarded_count += 1
        self.last_status = 'counterexample recorded; tissue unchanged'
        return True

    def state_dict(self):
        state = super().state_dict()
        state.update({
            'twfc_feedback_policy': scalar_array(self.feedback_policy, np.int64),
            'twfc_pending': bool_array(self.pending_feedback),
            'twfc_pending_slot': scalar_array(self.pending_slot, np.int64),
            'twfc_pending_quality': scalar_array(self.pending_quality),
            'twfc_pending_posterior': scalar_array(self.pending_posterior),
            'twfc_pending_age': scalar_array(self.pending_age),
            'twfc_deferred_count': scalar_array(
                self.feedback_deferred_count, np.int64
            ),
            'twfc_applied_count': scalar_array(
                self.feedback_applied_count, np.int64
            ),
            'twfc_discarded_count': scalar_array(
                self.feedback_discarded_count, np.int64
            ),
        })
        return state

    def load_state(self, data):
        super().load_state(data)
        if 'twfc_feedback_policy' not in data:
            self.feedback_policy = FEEDBACK_IMMEDIATE
            self.pending_feedback = False
            return
        self.feedback_policy = int(data['twfc_feedback_policy'])
        self.pending_feedback = bool(int(data['twfc_pending']))
        self.pending_slot = int(data['twfc_pending_slot'])
        self.pending_quality = float(data['twfc_pending_quality'])
        self.pending_posterior = float(data['twfc_pending_posterior'])
        self.pending_age = float(data['twfc_pending_age'])
        self.feedback_deferred_count = int(data['twfc_deferred_count'])
        self.feedback_applied_count = int(data['twfc_applied_count'])
        self.feedback_discarded_count = int(data['twfc_discarded_count'])


# =============================================================================
# Counterfactual-compatible SOMA core
# =============================================================================


class CounterfactualSomaCore(soma4.SomaFourCore):
    """SOMA-4 organism with controlled nonstationarity and CRN-safe respawns."""

    def __init__(
        self,
        seed=None,
        regime=REGIME_STABLE,
        regime_switch_age=1e9,
        outcome_delay=3.0,
        compiler_feedback_policy=FEEDBACK_IMMEDIATE,
        compiler_enabled=True,
        compiler_feedback=True,
        compiler_safety=True,
        compiler_composite=True,
        compiler_random_selection=False,
        compiler_minimal_counterexample=True,
        freeze_learning_during_compiler=True,
        **kwargs
    ):
        super().__init__(
            seed=seed,
            compiler_enabled=compiler_enabled,
            compiler_feedback=compiler_feedback,
            compiler_safety=compiler_safety,
            compiler_composite=compiler_composite,
            compiler_random_selection=compiler_random_selection,
            compiler_minimal_counterexample=compiler_minimal_counterexample,
            freeze_learning_during_compiler=freeze_learning_during_compiler,
            **kwargs
        )
        # Replace the ordinary compiler before any life step occurs.
        self.compiler = TwinFalsificationCompiler(
            seed=self.seed,
            enabled=compiler_enabled,
            feedback_enabled=compiler_feedback,
            safety_enabled=compiler_safety,
            allow_composite=compiler_composite,
            random_selection=compiler_random_selection,
            minimal_counterexample=compiler_minimal_counterexample,
            feedback_policy=compiler_feedback_policy,
        )

        self.regime = regime_code(regime)
        self.regime_switch_age = float(regime_switch_age)
        self.outcome_delay = max(0.10, float(outcome_delay))
        self.regime_triggered = False
        self.regime_trigger_age = -1.0

        self.nutrient_respawn_count = np.zeros(NUTRIENT_COUNT, dtype=np.int64)
        self.toxin_respawn_count = np.zeros(TOXIN_COUNT, dtype=np.int64)
        self.source_a_contacts = 0
        self.source_b_contacts = 0

        self.pending_active = np.zeros(MAX_DELAYED_EVENTS, dtype=bool)
        self.pending_due_age = np.zeros(MAX_DELAYED_EVENTS, dtype=float)
        self.pending_effect = np.zeros(MAX_DELAYED_EVENTS, dtype=np.int8)
        self.pending_source_kind = np.zeros(MAX_DELAYED_EVENTS, dtype=np.int8)
        self.delayed_scheduled = 0
        self.delayed_delivered = 0
        self.delayed_overflow = 0

        self.damage_applied = False
        self.damage_cell_mask = np.zeros(CELL_COUNT, dtype=bool)
        self.damage_right_slots = np.zeros(MORPH_SLOT_COUNT, dtype=bool)
        self.damage_magnitude = 0.0
        self.structural_plasticity_locked = False

    def set_structural_plasticity_lock(self, enabled=True):
        self.structural_plasticity_locked = bool(enabled)
        if self.structural_plasticity_locked:
            self.brain._rewire_weak_edges = _no_structural_rewire
        else:
            # Remove only the instance-level override, revealing the class method.
            self.brain.__dict__.pop('_rewire_weak_edges', None)

    # ------------------------------------------------------------------
    # Regime utilities
    # ------------------------------------------------------------------

    def regime_is_active(self):
        return self.regime != REGIME_STABLE and self.age >= self.regime_switch_age

    def _mark_regime_trigger(self):
        if self.regime_is_active() and not self.regime_triggered:
            self.regime_triggered = True
            self.regime_trigger_age = float(self.age)

    def _apply_body_damage(self):
        if self.damage_applied:
            return
        directions = self.morphology.directions
        right = directions[:, 0] > 0.15
        self.damage_right_slots = right.copy()
        self.morphology.fin[right] *= 0.18
        self.morphology.sensor[right, 0:2] *= 0.28

        east_alignment = self.brain.motor @ np.array([1.0, 0.0])
        activity = 0.35 + np.abs(self.brain.hidden)
        score = np.abs(east_alignment) * activity
        damaged = np.argsort(score)[-6:]
        self.damage_cell_mask[:] = False
        self.damage_cell_mask[damaged] = True
        self.brain.motor[damaged] *= 0.46
        self.brain.prediction_error[damaged] = np.maximum(
            self.brain.prediction_error[damaged], 0.62
        )
        self.brain.maturity[damaged] *= 0.74

        self.integrity = max(0.0, self.integrity - 0.055)
        self.pain = max(self.pain, 0.75)
        self.damage_magnitude = float(
            np.mean(1.0 - self.morphology.fin[right] / 0.10)
        ) if np.any(right) else 0.0
        self.damage_applied = True

    def _source_effect(self, source_kind):
        reversed_now = (
            self.regime == REGIME_MEANING_REVERSAL
            and self.regime_is_active()
        )
        if int(source_kind) == 0:  # chemical A / original nutrient source
            return EFFECT_TOXIN if reversed_now else EFFECT_NUTRIENT
        return EFFECT_NUTRIENT if reversed_now else EFFECT_TOXIN

    def _respawn(self, source_kind, index):
        if int(source_kind) == 0:
            self.nutrient_respawn_count[index] += 1
            count = int(self.nutrient_respawn_count[index])
            self.nutrient_positions[index] = _deterministic_position(
                self.seed, 0, index, count
            )
        else:
            self.toxin_respawn_count[index] += 1
            count = int(self.toxin_respawn_count[index])
            self.toxin_positions[index] = _deterministic_position(
                self.seed, 1, index, count
            )

    def _apply_nutrient_effect(self):
        self.energy = min(1.0, self.energy + 0.17)
        self.eaten += 1

    def _apply_toxin_effect(self, contact_delta=None):
        if contact_delta is None:
            local_shell = float(np.mean(self.morphology.shell))
        else:
            local_shell = self.morphology.local_shell(contact_delta)
        protection = clamp(0.62 * local_shell, 0.0, 0.56)
        self.integrity = max(
            0.0, self.integrity - 0.16 * (1.0 - protection)
        )
        self.energy = max(0.0, self.energy - 0.035)
        self.pain = 1.0
        self.poisoned += 1

    def _deliver_effect(self, effect, contact_delta=None):
        if int(effect) == EFFECT_NUTRIENT:
            self._apply_nutrient_effect()
        else:
            self._apply_toxin_effect(contact_delta)

    def _schedule_effect(self, effect, source_kind):
        free = np.flatnonzero(~self.pending_active)
        if free.size:
            slot = int(free[0])
        else:
            # Capacity pressure should not silently erase a consequence. Deliver
            # the earliest one now, then reuse its slot.
            slot = int(np.argmin(self.pending_due_age))
            self._deliver_effect(int(self.pending_effect[slot]))
            self.delayed_delivered += 1
            self.delayed_overflow += 1
        self.pending_active[slot] = True
        self.pending_due_age[slot] = float(self.age) + self.outcome_delay
        self.pending_effect[slot] = int(effect)
        self.pending_source_kind[slot] = int(source_kind)
        self.delayed_scheduled += 1

    def _deliver_due_effects(self):
        due = np.flatnonzero(
            self.pending_active & (self.pending_due_age <= float(self.age) + 1e-12)
        )
        for slot in due:
            slot = int(slot)
            self._deliver_effect(int(self.pending_effect[slot]))
            self.pending_active[slot] = False
            self.delayed_delivered += 1

    def _contact_effect(self, source_kind, contact_delta):
        effect = self._source_effect(source_kind)
        delayed = (
            self.regime == REGIME_DELAYED_OUTCOMES
            and self.regime_is_active()
        )
        if delayed:
            self._schedule_effect(effect, source_kind)
        else:
            self._deliver_effect(effect, contact_delta)

    # ------------------------------------------------------------------
    # Life dynamics. This duplicates SOMA-2 body mechanics only so collision
    # randomness and nonstationary consequences can be controlled precisely.
    # ------------------------------------------------------------------

    def step(self, dt=1.0 / 30.0):
        if not self.alive:
            return
        self._mark_regime_trigger()
        if (
            self.regime == REGIME_BODY_DAMAGE
            and self.regime_is_active()
            and not self.damage_applied
        ):
            self._apply_body_damage()
        super().step(dt)

    def _apply_body_and_world(self, action, dt):
        self._deliver_due_effects()

        action = np.clip(np.asarray(action, dtype=float), -1.0, 1.0)
        shaped_action = self.morphology.transform_action(action)
        target_velocity = shaped_action * MAX_SPEED
        response = 1.0 - math.exp(-4.0 * dt)
        self.vel += (target_velocity - self.vel) * response

        displacement = self.vel * dt
        self.pos = (self.pos + displacement) % 1.0
        self.distance_travelled += float(np.linalg.norm(displacement))

        movement = float(np.dot(shaped_action, shaped_action))
        neural = self.brain.neural_cost()
        shelter = self.shelter_level()
        ambient, _ = self.temperature_field()
        self.last_ambient = ambient
        self.last_shelter = shelter

        sensor_mean, fin_mean, shell_mean = self.morphology.organ_means()
        insulation = clamp(0.44 * shell_mean, 0.0, 0.38)
        thermal_coupling = (0.16 + 0.95 * shelter) * (1.0 - insulation)
        self.temperature += (
            (ambient - self.temperature) * thermal_coupling * dt
            + 0.022 * movement * dt
        )
        self.temperature = clamp(self.temperature, 0.0, 1.0)

        thermal_stress = clamp(
            abs(self.temperature - 0.50) / 0.42, 0.0, 1.0
        )
        locomotor_efficiency = 1.0 + 0.90 * fin_mean
        structural_mass = 1.0 + 0.30 * shell_mean + 0.10 * sensor_mean

        self.fatigue += (
            0.075 * movement * structural_mass / locomotor_efficiency
            + 0.020 * neural
        ) * dt
        rest_fraction = max(0.0, 1.0 - math.sqrt(min(1.0, movement)))
        recovery = (0.008 + 0.160 * shelter) * rest_fraction
        self.fatigue -= recovery * dt
        self.fatigue = clamp(self.fatigue, 0.0, 1.0)

        structure_cost = self.morphology.construction_and_maintenance_cost()
        energy_cost = (
            0.0019
            + 0.0026 * movement * structural_mass / locomotor_efficiency
            + 0.0010 * neural
            + 0.0014 * thermal_stress
            + 0.0010 * self.fatigue
            + structure_cost
        ) * dt
        self.energy -= energy_cost

        if thermal_stress > 0.70:
            damage = (
                0.010
                * (thermal_stress - 0.70)
                / 0.30
                * (1.0 - 0.24 * shell_mean)
                * dt
            )
            self.integrity -= damage
            self.pain = min(1.0, self.pain + damage * 20.0)

        if self.fatigue > 0.90:
            damage = 0.006 * (self.fatigue - 0.90) / 0.10 * dt
            self.integrity -= damage
            self.pain = min(1.0, self.pain + damage * 20.0)

        if (
            self.energy > 0.52
            and self.fatigue < 0.58
            and thermal_stress < 0.55
        ):
            heal_rate = (
                0.0018
                * (self.energy - 0.52)
                / 0.48
                * (1.0 - self.fatigue)
            )
            healing = min(heal_rate * dt, 1.0 - self.integrity)
            self.integrity += healing
            self.energy -= healing * 0.35

        for index, nutrient in enumerate(self.nutrient_positions):
            delta = wrapped_delta(self.pos, nutrient)
            if float(np.linalg.norm(delta)) < (
                self.morphology.local_radius(delta) + NUTRIENT_RADIUS
            ):
                self.source_a_contacts += 1
                self._contact_effect(0, delta)
                self._respawn(0, index)

        for index, toxin in enumerate(self.toxin_positions):
            delta = wrapped_delta(self.pos, toxin)
            if float(np.linalg.norm(delta)) < (
                self.morphology.local_radius(delta) + TOXIN_RADIUS
            ):
                self.source_b_contacts += 1
                self._contact_effect(1, delta)
                self._respawn(1, index)

        self.pain *= math.exp(-2.3 * dt)
        self.energy = clamp(self.energy, 0.0, 1.0)
        self.integrity = clamp(self.integrity, 0.0, 1.0)

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def state_dict(self):
        state = super().state_dict()
        state['save_version'] = scalar_array(CORE_SAVE_VERSION, np.int64)
        state.update({
            'cf_regime': scalar_array(self.regime, np.int64),
            'cf_switch_age': scalar_array(self.regime_switch_age),
            'cf_outcome_delay': scalar_array(self.outcome_delay),
            'cf_regime_triggered': bool_array(self.regime_triggered),
            'cf_regime_trigger_age': scalar_array(self.regime_trigger_age),
            'cf_nutrient_respawns': self.nutrient_respawn_count,
            'cf_toxin_respawns': self.toxin_respawn_count,
            'cf_source_a_contacts': scalar_array(self.source_a_contacts, np.int64),
            'cf_source_b_contacts': scalar_array(self.source_b_contacts, np.int64),
            'cf_pending_active': self.pending_active.astype(np.uint8),
            'cf_pending_due_age': self.pending_due_age,
            'cf_pending_effect': self.pending_effect,
            'cf_pending_source_kind': self.pending_source_kind,
            'cf_delayed_scheduled': scalar_array(self.delayed_scheduled, np.int64),
            'cf_delayed_delivered': scalar_array(self.delayed_delivered, np.int64),
            'cf_delayed_overflow': scalar_array(self.delayed_overflow, np.int64),
            'cf_damage_applied': bool_array(self.damage_applied),
            'cf_damage_cell_mask': self.damage_cell_mask.astype(np.uint8),
            'cf_damage_right_slots': self.damage_right_slots.astype(np.uint8),
            'cf_damage_magnitude': scalar_array(self.damage_magnitude),
            'cf_structural_lock': bool_array(self.structural_plasticity_locked),
            # Configuration switches are ordinary Python booleans in the
            # inherited classes and therefore are not included in their
            # numerical state dictionaries.  They matter for exact twin
            # continuation, so SOMA-4.1 persists them explicitly.
            'cf_auditor_enabled': bool_array(self.auditor.enabled),
            'cf_morphology_enabled': bool_array(self.morphology.enabled),
            'cf_questioner_enabled': bool_array(self.questioner.enabled),
            'cf_brain_learning_enabled': bool_array(self.brain.learning_enabled),
            'cf_brain_scalarize_trophic': bool_array(self.brain.scalarize_trophic),
            'cf_brain_diffusion_enabled': bool_array(self.brain.diffusion_enabled),
            'cf_brain_turnover_enabled': bool_array(self.brain.turnover_enabled),
        })
        return state

    def load_state(self, data):
        if int(data['save_version']) != CORE_SAVE_VERSION:
            raise ValueError('unsupported SOMA-4.1 core save version')
        keys = list(data.files) if hasattr(data, 'files') else list(data.keys())
        base = {key: data[key] for key in keys}
        base['save_version'] = scalar_array(6, np.int64)
        super().load_state(base)

        self.regime = int(data['cf_regime'])
        self.regime_switch_age = float(data['cf_switch_age'])
        self.outcome_delay = float(data['cf_outcome_delay'])
        self.regime_triggered = bool(int(data['cf_regime_triggered']))
        self.regime_trigger_age = float(data['cf_regime_trigger_age'])
        self.nutrient_respawn_count = np.array(
            data['cf_nutrient_respawns'], dtype=np.int64
        )
        self.toxin_respawn_count = np.array(
            data['cf_toxin_respawns'], dtype=np.int64
        )
        self.source_a_contacts = int(data['cf_source_a_contacts'])
        self.source_b_contacts = int(data['cf_source_b_contacts'])
        self.pending_active = np.array(data['cf_pending_active'], dtype=bool)
        self.pending_due_age = np.array(data['cf_pending_due_age'], dtype=float)
        self.pending_effect = np.array(data['cf_pending_effect'], dtype=np.int8)
        self.pending_source_kind = np.array(
            data['cf_pending_source_kind'], dtype=np.int8
        )
        self.delayed_scheduled = int(data['cf_delayed_scheduled'])
        self.delayed_delivered = int(data['cf_delayed_delivered'])
        self.delayed_overflow = int(data['cf_delayed_overflow'])
        self.damage_applied = bool(int(data['cf_damage_applied']))
        self.damage_cell_mask = np.array(data['cf_damage_cell_mask'], dtype=bool)
        self.damage_right_slots = np.array(
            data['cf_damage_right_slots'], dtype=bool
        )
        self.damage_magnitude = float(data['cf_damage_magnitude'])

        # Restore all inherited run-time switches after the inherited loaders
        # have rebuilt their objects.  Without this, a saved quiescent control
        # can silently wake its auditor after loading and cease to be the same
        # counterfactual branch.
        self.auditor.enabled = bool(int(data['cf_auditor_enabled']))
        self.morphology.enabled = bool(int(data['cf_morphology_enabled']))
        self.questioner.enabled = bool(int(data['cf_questioner_enabled']))
        self.brain.learning_enabled = bool(int(data['cf_brain_learning_enabled']))
        self.brain.scalarize_trophic = bool(int(data['cf_brain_scalarize_trophic']))
        self.brain.diffusion_enabled = bool(int(data['cf_brain_diffusion_enabled']))
        self.brain.turnover_enabled = bool(int(data['cf_brain_turnover_enabled']))

        self.structural_plasticity_locked = bool(int(data['cf_structural_lock']))
        self.set_structural_plasticity_lock(self.structural_plasticity_locked)

        # SOMA-2's legacy component loaders restore internal trial state but
        # intentionally leave constructor policy flags untouched.  A twin-lab
        # save, however, must reproduce quiesced treatment/control branches
        # exactly.  Restore the persisted policy flags here so a resumed pair
        # differs only in the intervention being tested.
        if 'audit_enabled' in data:
            self.auditor.enabled = bool(int(data['audit_enabled']))
        if 'morph_enabled' in data:
            self.morphology.enabled = bool(int(data['morph_enabled']))
        if 'morph_require_audit' in data:
            self.morphology.require_audit = bool(int(data['morph_require_audit']))
        if 'morph_escrow_enabled' in data:
            self.morphology.escrow_enabled = bool(int(data['morph_escrow_enabled']))
        if 'morph_pareto_veto_enabled' in data:
            self.morphology.pareto_veto_enabled = bool(
                int(data['morph_pareto_veto_enabled'])
            )
        self.brain.set_audit_gate(
            self.auditor.gate()
            if self.auditor.enabled
            else np.ones((CELL_COUNT, TROPHIC_COUNT), dtype=float)
        )


def clone_core(core):
    cloned = CounterfactualSomaCore(
        seed=core.seed,
        regime=core.regime,
        regime_switch_age=core.regime_switch_age,
        outcome_delay=core.outcome_delay,
    )
    cloned.load_state(_copy_state(core.state_dict()))
    return cloned


# =============================================================================
# Trial preparation helpers
# =============================================================================


def _cancel_component(component, reason):
    if hasattr(component, 'cancel_active'):
        try:
            component.cancel_active(reason)
        except TypeError:
            component.cancel_active()


def quiesce_experimenters(core, keep_compiler_active=False):
    """Stop new high-level experiments while keeping ordinary life learning."""
    _cancel_component(core.auditor, 'twin evaluation lock')
    _cancel_component(core.morphology, 'twin evaluation lock')
    _cancel_component(core.questioner, 'twin evaluation lock')
    core.auditor.enabled = False
    core.morphology.enabled = False
    core.questioner.enabled = False
    if not keep_compiler_active:
        if core.compiler.active:
            core.compiler.active = False
            core.compiler.claim_slot = -1
            core.compiler.claim_type = -1
        core.compiler.enabled = False
    # Turnover may conditionally consume a different number of random values.
    # Rewiring remains enabled because it has a fixed call pattern at equal step counts.
    core.brain.turnover_enabled = False
    core.set_structural_plasticity_lock(True)


def neutral_cancel_compiler(core, status='counterfactual control: no experiment'):
    fc = core.compiler
    fc.active = False
    fc.claim_slot = -1
    fc.claim_type = -1
    fc.cooldown = 1e9
    fc.enabled = False
    fc.last_status = str(status)


def _preview_compiler_candidate(core):
    """Select the candidate SOMA-4 will choose without consuming randomness."""
    fc = core.compiler
    world_state = copy.deepcopy(core.rng.bit_generator.state)
    compiler_state = copy.deepcopy(fc.rng.bit_generator.state)
    try:
        context = fc.context(core, core.body_debt())
        candidates = fc.compile_candidates(core, core.body_debt(), context)
        if not candidates:
            return None
        if fc.random_selection:
            return candidates[int(fc.rng.integers(len(candidates)))]
        best_value = max(float(x['value']) for x in candidates)
        if fc.minimal_counterexample:
            near = [
                x for x in candidates
                if float(x['value']) >= 0.90 * best_value
            ]
            return min(
                near,
                key=lambda x: (
                    float(x['complexity']),
                    float(x['risk']),
                    -float(x['value']),
                ),
            )
        return max(candidates, key=lambda x: float(x['value']))
    finally:
        core.rng.bit_generator.state = world_state
        fc.rng.bit_generator.state = compiler_state


def force_compiler_start(core):
    _cancel_component(core.auditor, 'compiler branch preparation')
    _cancel_component(core.morphology, 'compiler branch preparation')
    _cancel_component(core.questioner, 'compiler branch preparation')
    core.compiler.enabled = True
    core.compiler.cooldown = 0.0
    candidate = _preview_compiler_candidate(core)
    context = core.compiler.context(core, core.body_debt())
    started = core.compiler.maybe_start(
        core, core.body_debt(), context, other_busy=False, force=True
    )
    return candidate if started else None


def _program_argument_maps(programs, rng):
    motor_values = set()
    sensor_values = set()
    organ_pairs = set()
    for program in programs:
        for i in range(soma4.MAX_PROGRAM_STEPS):
            op = int(program['opcode'][i])
            if op == soma4.OP_MOTOR:
                motor_values.add(int(program['arg0'][i]) % 8)
            elif op == soma4.OP_SENSOR_MASK:
                sensor_values.add(int(program['arg0'][i]))
            elif op in (soma4.OP_ORGAN_DAMP, soma4.OP_ORGAN_BOOST):
                organ_pairs.add((int(program['arg0'][i]), int(program['arg1'][i])))
    motor_map = {
        value: (value + int(rng.integers(1, 8))) % 8 for value in motor_values
    }
    sensor_map = {
        value: (value + int(rng.integers(1, len(soma4.SENSOR_GROUPS))))
        % len(soma4.SENSOR_GROUPS)
        for value in sensor_values
    }
    organ_map = {}
    for kind, slot in organ_pairs:
        new_kind = int(rng.integers(3))
        new_slot = (slot + int(rng.integers(1, MORPH_SLOT_COUNT))) % MORPH_SLOT_COUNT
        organ_map[(kind, slot)] = (new_kind, new_slot)
    return motor_map, sensor_map, organ_map


def randomize_active_compiler(core, rng):
    """Create a cost/length-matched but structurally irrelevant program pair."""
    fc = core.compiler
    if not fc.active:
        return False
    motor_map, sensor_map, organ_map = _program_argument_maps(
        (fc.reference, fc.challenge), rng
    )
    for program in (fc.reference, fc.challenge):
        for i in range(soma4.MAX_PROGRAM_STEPS):
            op = int(program['opcode'][i])
            if op == soma4.OP_MOTOR:
                old = int(program['arg0'][i]) % 8
                program['arg0'][i] = motor_map[old]
            elif op == soma4.OP_SENSOR_MASK:
                old = int(program['arg0'][i])
                program['arg0'][i] = sensor_map[old]
            elif op in (soma4.OP_ORGAN_DAMP, soma4.OP_ORGAN_BOOST):
                old = (int(program['arg0'][i]), int(program['arg1'][i]))
                new_kind, new_slot = organ_map[old]
                program['arg0'][i] = new_kind
                program['arg1'][i] = new_slot

    members = np.flatnonzero(fc.coalition_mask)
    count = max(1, int(members.size))
    chosen = rng.choice(CELL_COUNT, size=count, replace=False)
    fc.coalition_mask[:] = False
    fc.coalition_mask[chosen] = True
    # Keep signature magnitudes but attach them to unrelated cells.
    old_values = np.sort(fc.claim_signature[fc.claim_slot])[::-1][:count]
    fc.claim_signature[fc.claim_slot] = 0.0
    fc.claim_signature[fc.claim_slot, chosen] = old_values
    fc.last_claim_text = 'cost-matched random challenge to the same claim'
    fc.last_reference_text = soma4._program_text(fc.reference)
    fc.last_challenge_text = soma4._program_text(fc.challenge)
    return True


def seed_probe_lease(core):
    """Create one accountable lease when natural morphogenesis has none.

    This is used only by the lease-value evaluator. The change is registered as
    instrumented rather than falsely reported as naturally selected.
    """
    morph = core.morphology
    active = morph.active_lease_indices()
    if active.size:
        trust = np.array([
            morph.effective_lease_trust(int(i), core.age, core.body_debt())
            for i in active
        ])
        return int(active[int(np.argmax(trust))]), False

    debt = core.body_debt()
    target = int(np.argmax(debt))
    if target == 0:
        kind = MORPH_SENSOR
        modality = 0
        sensor = core.make_sensor()
        vector = sensor[0:2]
        slot = int(np.argmax(morph.directions @ vector)) if np.linalg.norm(vector) > 1e-8 else 0
        current = float(morph.sensor[slot, modality])
    elif target == 1:
        kind = MORPH_SHELL
        modality = 0
        slot = int(np.argmax(morph.shell))
        current = float(morph.shell[slot])
    elif target == 2:
        kind = MORPH_SHELL
        modality = 0
        sensor = core.make_sensor()
        vector = -sensor[3:5]
        slot = int(np.argmax(morph.directions @ vector)) if np.linalg.norm(vector) > 1e-8 else 0
        current = float(morph.shell[slot])
    else:
        kind = MORPH_FIN
        modality = 0
        direction = -core.vel if np.linalg.norm(core.vel) > 1e-6 else np.array([1.0, 0.0])
        slot = int(np.argmax(morph.directions @ direction))
        current = float(morph.fin[slot])

    delta = min(0.13, max(0.055, 0.34 * (1.0 - current)))
    morph.kind = int(kind)
    morph.slot = int(slot)
    morph.modality = int(modality)
    morph.delta = float(delta)
    morph.target_currency = int(target)
    morph.current_age = float(core.age)
    morph.last_effect[:] = 0.0
    morph.last_effect[target] = 0.00018
    morph.last_votes[:] = 0
    morph.last_votes[target] = 1
    morph.last_z[:] = 0.0
    morph.last_z[target] = 1.0
    morph._apply_permanent_delta(kind, slot, modality, delta)
    index = morph._register_current_change(
        core.age, core.body_debt(), immediate=False
    )
    morph.last_status = 'instrumented lease for counterfactual evaluation'
    return int(index), True


def withdraw_lease_without_trial(core, index):
    morph = core.morphology
    index = int(index)
    if index < 0 or not morph.lease_active[index]:
        return False
    kind = int(morph.lease_kind[index])
    slot = int(morph.lease_slot[index])
    modality = int(morph.lease_modality[index])
    delta = float(morph.lease_delta[index])
    morph._apply_permanent_delta(kind, slot, modality, -delta)
    morph.lease_active[index] = False
    morph.last_status = 'counterfactual branch: lease delta withdrawn'
    return True


# =============================================================================
# Paired evaluation manager
# =============================================================================


class CounterfactualTwinLab:
    """Manages one paired, common-random-numbers evaluation."""

    def __init__(
        self,
        seed=101,
        mode=DEFAULT_TWIN_MODE,
        regime=DEFAULT_REGIME,
        warmup_age=30.0,
        max_warmup_age=150.0,
        horizon=72.0,
        shock_delay=8.0,
        outcome_delay=3.0,
        dt=1.0 / 30.0,
    ):
        self.seed = int(seed)
        self.mode = mode_code(mode)
        self.regime = regime_code(regime)
        self.warmup_age = float(warmup_age)
        self.max_warmup_age = float(max_warmup_age)
        self.horizon = float(horizon)
        self.shock_delay = float(shock_delay)
        self.outcome_delay = float(outcome_delay)
        self.dt = float(dt)
        self.rng = np.random.default_rng(self.seed ^ 0x41C0FFEE)
        self.noise_tape_seed = _splitmix64(self.seed ^ 0xC0FFEE41A55A5AA5)
        self.noise_tape_step = 0

        feedback_policy = (
            FEEDBACK_DEFER_ONCE
            if self.mode == TWIN_FEEDBACK_VALUE
            else FEEDBACK_IMMEDIATE
        )
        compiler_enabled = self.mode == TWIN_FEEDBACK_VALUE
        self.source = CounterfactualSomaCore(
            seed=self.seed,
            regime=self.regime,
            regime_switch_age=1e9,
            outcome_delay=self.outcome_delay,
            compiler_feedback_policy=feedback_policy,
            compiler_enabled=compiler_enabled,
        )
        if self.mode != TWIN_FEEDBACK_VALUE:
            self.source.compiler.enabled = False
        self.treatment = None
        self.control = None

        self.phase = PHASE_WARMUP
        self.failure_reason = ''
        self.branch_reason = ''
        self.branch_age = -1.0
        self.eval_elapsed = 0.0
        self.eval_steps = 0
        self.intervention_finished = self.mode in (
            TWIN_FEEDBACK_VALUE, TWIN_LEASE_VALUE
        )
        self.intervention_end_elapsed = 0.0 if self.intervention_finished else -1.0
        self.seeded_lease = False
        self.lease_index = -1

        self.debt_integral_treatment = np.zeros(TROPHIC_COUNT, dtype=float)
        self.debt_integral_control = np.zeros(TROPHIC_COUNT, dtype=float)
        self.cost_integral = np.zeros(TROPHIC_COUNT, dtype=float)
        self.benefit_integral = np.zeros(TROPHIC_COUNT, dtype=float)
        self.branch_debt = np.zeros(TROPHIC_COUNT, dtype=float)
        self.predicted_gain = np.zeros(TROPHIC_COUNT, dtype=float)
        self.prediction_target = -1
        self.claim_prior_effect = float('nan')
        self.claim_expected_sign = 1.0

        self.shock_seen = False
        self.shock_elapsed = -1.0
        self.pre_shock_mean = np.zeros(2, dtype=float)
        self.pre_shock_samples = np.zeros(2, dtype=np.int64)
        self.adapt_streak = np.zeros(2, dtype=float)
        self.adaptation_time = np.full(2, -1.0, dtype=float)
        self.post_shock_peak = np.zeros(2, dtype=float)

        # Currency-resolved recovery clocks.  A single mean-debt score can hide
        # a trade-off (for example, energy improves while integrity worsens),
        # so every homeostatic debt also receives its own recovery estimate.
        self.pre_shock_debt_mean = np.zeros(
            (2, TROPHIC_COUNT), dtype=float
        )
        self.post_shock_debt_peak = np.zeros(
            (2, TROPHIC_COUNT), dtype=float
        )
        self.adapt_streak_by_debt = np.zeros(
            (2, TROPHIC_COUNT), dtype=float
        )
        self.adaptation_time_by_debt = np.full(
            (2, TROPHIC_COUNT), -1.0, dtype=float
        )

        self.treatment_claim_slot = -1
        self.control_claim_slot = -1
        self.rng_sync_steps = 0
        self.rng_checked_steps = 0
        self.rng_poststep_coupled_steps = 0
        self.exact_until_divergence_steps = 0
        self.divergence_seen = False
        self.warmup_regenerations = 0
        self.feedback_fallback = False

    @property
    def done(self):
        return self.phase in (PHASE_DONE, PHASE_FAILED)

    @property
    def mode_name(self):
        return TWIN_MODE_NAMES[self.mode]

    @property
    def regime_name(self):
        return REGIME_NAMES[self.regime]

    def _warmup_step(self, dt):
        if not self.source.alive:
            self.source.regenerate_body(np.array([0.5, 0.5]))
            self.warmup_regenerations += 1

        # Feedback trials need real counterexamples. Once mature enough, remove
        # idle gaps so several natural compiled tests can occur before the limit.
        if self.mode == TWIN_FEEDBACK_VALUE and self.source.age > self.warmup_age:
            if (
                not self.source.compiler.active
                and not self.source.auditor.busy
                and not self.source.morphology.busy
                and not self.source.questioner.busy
            ):
                self.source.compiler.cooldown = min(
                    self.source.compiler.cooldown, 0.0
                )

        self.source.step(dt)

        if self.mode == TWIN_FEEDBACK_VALUE:
            if self.source.compiler.pending_feedback:
                self._branch_feedback()
                return
            if self.source.age >= self.max_warmup_age:
                self._feedback_fallback_branch()
                return
        elif self.source.age >= self.warmup_age:
            if self.mode == TWIN_EXPERIMENT_VALUE:
                self._branch_experiment()
            elif self.mode == TWIN_COMPILED_VS_RANDOM:
                self._branch_compiled_random()
            else:
                self._branch_lease()

    def _set_regime_clock(self, core):
        core.regime = self.regime
        core.regime_switch_age = (
            1e9 if self.regime == REGIME_STABLE
            else float(core.age) + self.shock_delay
        )
        core.regime_triggered = False
        core.regime_trigger_age = -1.0

    def _finalize_branch(self, reason):
        if self.treatment is None or self.control is None:
            self.phase = PHASE_FAILED
            self.failure_reason = 'internal branch construction failed'
            return
        self.branch_reason = str(reason)
        self.branch_age = float(self.treatment.age)
        self.branch_debt = 0.5 * (
            self.treatment.body_debt() + self.control.body_debt()
        )
        self._set_regime_clock(self.treatment)
        self._set_regime_clock(self.control)
        self.source = None
        self.phase = PHASE_EVALUATION
        self.eval_elapsed = 0.0
        self.eval_steps = 0

    def _branch_experiment(self):
        candidate = force_compiler_start(self.source)
        if candidate is None:
            self.phase = PHASE_FAILED
            self.failure_reason = 'no compiler candidate at branch'
            return
        self.treatment = clone_core(self.source)
        self.control = clone_core(self.source)
        self.treatment_claim_slot = int(self.treatment.compiler.claim_slot)
        self.control_claim_slot = int(self.control.compiler.claim_slot)
        quiesce_experimenters(self.treatment, keep_compiler_active=True)
        quiesce_experimenters(self.control, keep_compiler_active=False)
        neutral_cancel_compiler(self.control)
        target = int(self.treatment.compiler.target_currency)
        self.prediction_target = target
        self.claim_prior_effect = float(candidate['prior_effect'])
        self.claim_expected_sign = float(candidate.get('expected_sign', 1.0))
        self.predicted_gain[target] = max(
            0.0005,
            0.004 * float(self.treatment.compiler.last_value)
        )
        self._finalize_branch('compiled experiment versus ordinary continuation')

    def _branch_compiled_random(self):
        candidate = force_compiler_start(self.source)
        if candidate is None:
            self.phase = PHASE_FAILED
            self.failure_reason = 'no compiler candidate at branch'
            return
        self.treatment = clone_core(self.source)
        self.control = clone_core(self.source)
        self.treatment_claim_slot = int(self.treatment.compiler.claim_slot)
        self.control_claim_slot = int(self.control.compiler.claim_slot)
        quiesce_experimenters(self.treatment, keep_compiler_active=True)
        quiesce_experimenters(self.control, keep_compiler_active=True)
        randomize_active_compiler(self.control, self.rng)
        target = int(self.treatment.compiler.target_currency)
        self.prediction_target = target
        self.claim_prior_effect = float(candidate['prior_effect'])
        self.claim_expected_sign = float(candidate.get('expected_sign', 1.0))
        self.predicted_gain[target] = max(
            0.0005,
            0.0035 * float(self.treatment.compiler.last_value)
        )
        self._finalize_branch('compiled counterexample versus cost-matched random program')

    def _branch_feedback(self):
        self.treatment = clone_core(self.source)
        self.control = clone_core(self.source)
        slot = int(self.treatment.compiler.pending_slot)
        self.treatment_claim_slot = slot
        self.control_claim_slot = slot
        target = (
            int(self.treatment.compiler.claim_key[slot, 1])
            if slot >= 0 else 0
        )
        quality = float(self.treatment.compiler.pending_quality)
        posterior = float(self.treatment.compiler.pending_posterior)
        self.treatment.compiler.apply_pending(self.treatment)
        self.control.compiler.discard_pending()
        self.control.compiler.feedback_enabled = False
        self.control.compiler.feedback_policy = FEEDBACK_DISCARD
        quiesce_experimenters(self.treatment, keep_compiler_active=False)
        quiesce_experimenters(self.control, keep_compiler_active=False)
        self.prediction_target = target
        self.claim_prior_effect = float('nan')
        self.claim_expected_sign = float(self.treatment.compiler.expected_sign)
        self.predicted_gain[target] = 0.012 * quality * (1.0 - posterior)
        self._finalize_branch('same falsification history; tissue feedback applied only to treatment')

    def _feedback_fallback_branch(self):
        """Use the least trusted tested claim if no hard contradiction arrived.

        The row is marked as fallback so it is never confused with a naturally
        triggered explicit falsification event.
        """
        fc = self.source.compiler
        tested = np.flatnonzero(fc.claim_used & (fc.claim_trials > 0))
        if tested.size == 0:
            self.phase = PHASE_FAILED
            self.failure_reason = 'no tested claim before feedback warmup limit'
            return
        posterior = fc.claim_alpha[tested] / (
            fc.claim_alpha[tested] + fc.claim_beta[tested]
        )
        slot = int(tested[int(np.argmin(posterior))])
        fc.pending_feedback = True
        fc.pending_slot = slot
        fc.pending_quality = max(0.20, float(fc.last_quality))
        fc.pending_posterior = float(np.min(posterior))
        fc.pending_age = float(self.source.age)
        self.feedback_fallback = True
        self._branch_feedback()
        self.branch_reason += ' (fallback: least-trusted tested claim)'

    def _branch_lease(self):
        index, seeded = seed_probe_lease(self.source)
        if index < 0:
            self.phase = PHASE_FAILED
            self.failure_reason = 'unable to obtain a causal lease'
            return
        self.seeded_lease = bool(seeded)
        self.lease_index = int(index)
        self.treatment = clone_core(self.source)
        self.control = clone_core(self.source)
        withdraw_lease_without_trial(self.control, index)
        quiesce_experimenters(self.treatment, keep_compiler_active=False)
        quiesce_experimenters(self.control, keep_compiler_active=False)
        target = int(self.treatment.morphology.lease_target_currency[index])
        self.prediction_target = target
        mean_effect = float(
            self.treatment.morphology.lease_effect_mean[index, target]
        )
        self.claim_prior_effect = mean_effect
        self.claim_expected_sign = 1.0
        self.predicted_gain[target] = max(0.0002, mean_effect * self.horizon)
        reason = 'retained organ lease versus exact lease-delta withdrawal'
        if seeded:
            reason += ' (instrumented lease)'
        self._finalize_branch(reason)

    def _current_intervention_busy(self):
        if self.mode == TWIN_EXPERIMENT_VALUE:
            return bool(self.treatment.compiler.active)
        if self.mode == TWIN_COMPILED_VS_RANDOM:
            return bool(
                self.treatment.compiler.active or self.control.compiler.active
            )
        return False

    def _update_adaptation(self, debts_t, debts_c, dt):
        if self.regime == REGIME_STABLE:
            return
        switch_elapsed = self.shock_delay
        debts = (np.asarray(debts_t, dtype=float),
                 np.asarray(debts_c, dtype=float))
        if self.eval_elapsed < switch_elapsed:
            for i, debt in enumerate(debts):
                self.pre_shock_mean[i] += float(np.mean(debt))
                self.pre_shock_debt_mean[i] += debt
                self.pre_shock_samples[i] += 1
            return
        if not self.shock_seen:
            self.shock_seen = True
            self.shock_elapsed = float(self.eval_elapsed)
            for i in range(2):
                count = max(1, int(self.pre_shock_samples[i]))
                self.pre_shock_mean[i] /= count
                self.pre_shock_debt_mean[i] /= count
                self.post_shock_peak[i] = self.pre_shock_mean[i]
                self.post_shock_debt_peak[i] = self.pre_shock_debt_mean[i]

        recovery_hold = 3.0
        for i, debt in enumerate(debts):
            # Overall recovery remains useful as a compact diagnostic.
            if self.adaptation_time[i] < 0.0:
                current = float(np.mean(debt))
                self.post_shock_peak[i] = max(self.post_shock_peak[i], current)
                excursion = self.post_shock_peak[i] - self.pre_shock_mean[i]
                if excursion < 0.025:
                    self.adapt_streak[i] = 0.0
                else:
                    threshold = self.pre_shock_mean[i] + 0.35 * excursion
                    if current <= threshold:
                        self.adapt_streak[i] += dt
                    else:
                        self.adapt_streak[i] = 0.0
                    if self.adapt_streak[i] >= recovery_hold:
                        self.adaptation_time[i] = max(
                            0.0,
                            self.eval_elapsed - switch_elapsed - recovery_hold,
                        )

            # Resolve recovery separately for energy, thermal, integrity and
            # fatigue debt.  A currency is considered disrupted only after an
            # excursion of at least 0.03, then recovered after remaining within
            # 35% of that excursion for the same three-second hold window.
            for k in range(TROPHIC_COUNT):
                if self.adaptation_time_by_debt[i, k] >= 0.0:
                    continue
                current_k = float(debt[k])
                self.post_shock_debt_peak[i, k] = max(
                    self.post_shock_debt_peak[i, k], current_k
                )
                excursion_k = (
                    self.post_shock_debt_peak[i, k]
                    - self.pre_shock_debt_mean[i, k]
                )
                if excursion_k < 0.03:
                    self.adapt_streak_by_debt[i, k] = 0.0
                    continue
                threshold_k = (
                    self.pre_shock_debt_mean[i, k] + 0.35 * excursion_k
                )
                if current_k <= threshold_k:
                    self.adapt_streak_by_debt[i, k] += dt
                else:
                    self.adapt_streak_by_debt[i, k] = 0.0
                if self.adapt_streak_by_debt[i, k] >= recovery_hold:
                    self.adaptation_time_by_debt[i, k] = max(
                        0.0,
                        self.eval_elapsed - switch_elapsed - recovery_hold,
                    )

    def _synchronize_noise_tape(self):
        """Give corresponding subsystems identical innovations this step.

        Conditional plasticity or a collision can make two branches consume a
        different number of random values. Merely cloning an RNG once therefore
        does not preserve common random numbers for long. A counter-indexed tape
        restarts each subsystem from a shared per-step state, while embodied
        hidden states (including smooth neural probes) continue normally.
        """
        root = _splitmix64(
            self.noise_tape_seed
            ^ (self.noise_tape_step + 1) * 0x9E3779B185EBCA87
        )
        for stream, (left, right) in enumerate(zip(
            _component_rngs(self.treatment),
            _component_rngs(self.control),
        )):
            seed = _splitmix64(
                root ^ (stream + 1) * 0xD1B54A32D192ED03
            )
            state = _pcg_state(seed)
            left.bit_generator.state = copy.deepcopy(state)
            right.bit_generator.state = copy.deepcopy(state)
        self.noise_tape_step += 1
        self.rng_sync_steps += 1

    def _evaluation_step(self, dt):
        if self.eval_elapsed >= self.horizon:
            self.phase = PHASE_DONE
            return

        debt_t_before = self.treatment.body_debt()
        debt_c_before = self.control.body_debt()
        busy_before = self._current_intervention_busy()

        self._synchronize_noise_tape()
        self.treatment.step(dt)
        self.control.step(dt)

        debt_t = self.treatment.body_debt()
        debt_c = self.control.body_debt()
        mean_t = 0.5 * (debt_t_before + debt_t)
        mean_c = 0.5 * (debt_c_before + debt_c)
        self.debt_integral_treatment += dt * mean_t
        self.debt_integral_control += dt * mean_c

        if busy_before or self._current_intervention_busy():
            self.cost_integral += dt * (mean_t - mean_c)
        else:
            if not self.intervention_finished:
                self.intervention_finished = True
                self.intervention_end_elapsed = float(self.eval_elapsed)
                # No further high-level compiler experiments after the target one.
                self.treatment.compiler.enabled = False
                self.control.compiler.enabled = False
            self.benefit_integral += dt * (mean_c - mean_t)

        self._update_adaptation(debt_t, debt_c, dt)

        self.rng_checked_steps += 1
        if _rngs_coupled(self.treatment, self.control):
            self.rng_poststep_coupled_steps += 1
        states_equal = (
            np.array_equal(self.treatment.pos, self.control.pos)
            and np.array_equal(self.treatment.brain.hidden, self.control.brain.hidden)
            and np.array_equal(debt_t, debt_c)
        )
        if not self.divergence_seen and states_equal:
            self.exact_until_divergence_steps += 1
        else:
            self.divergence_seen = True

        self.eval_elapsed += dt
        self.eval_steps += 1
        if self.eval_elapsed >= self.horizon or (
            not self.treatment.alive and not self.control.alive
        ):
            self.phase = PHASE_DONE

    def step(self, dt=None):
        if dt is None:
            dt = self.dt
        dt = clamp(float(dt), 1.0 / 240.0, 0.10)
        if self.phase == PHASE_WARMUP:
            self._warmup_step(dt)
        elif self.phase == PHASE_EVALUATION:
            self._evaluation_step(dt)

    def active_cores(self):
        if self.phase == PHASE_WARMUP:
            return self.source, self.source
        return self.treatment, self.control

    def metrics(self):
        if self.phase == PHASE_FAILED:
            return {
                'seed': self.seed,
                'mode': self.mode_name,
                'regime': self.regime_name,
                'branch_success': 0,
                'failure_reason': self.failure_reason,
            }
        if self.phase == PHASE_WARMUP:
            return {
                'seed': self.seed,
                'mode': self.mode_name,
                'regime': self.regime_name,
                'branch_success': 0,
                'failure_reason': 'warmup incomplete',
            }

        elapsed = max(self.eval_elapsed, 1e-9)
        gain = self.debt_integral_control - self.debt_integral_treatment
        health_t = 1.0 - float(np.mean(self.debt_integral_treatment / elapsed))
        health_c = 1.0 - float(np.mean(self.debt_integral_control / elapsed))
        net_gain = self.benefit_integral - self.cost_integral
        target = max(0, int(self.prediction_target))
        predicted = float(self.predicted_gain[target]) if self.prediction_target >= 0 else 0.0
        actual = float(gain[target]) if self.prediction_target >= 0 else 0.0
        sign_correct = int(
            self.prediction_target >= 0
            and (abs(predicted) < 1e-12 or predicted * actual > 0.0)
        )
        rng_fraction = self.rng_sync_steps / max(self.rng_checked_steps, 1)
        rng_post_fraction = (
            self.rng_poststep_coupled_steps / max(self.rng_checked_steps, 1)
        )

        ft = self.treatment.compiler
        fc = self.control.compiler
        claim_observed = float('nan')
        if self.prediction_target >= 0:
            if self.mode in (
                TWIN_EXPERIMENT_VALUE,
                TWIN_FEEDBACK_VALUE,
                TWIN_COMPILED_VS_RANDOM,
            ):
                claim_observed = self.claim_expected_sign * float(
                    ft.last_effect[self.prediction_target]
                )
            elif self.mode == TWIN_LEASE_VALUE:
                claim_observed = float(gain[self.prediction_target] / elapsed)
        if np.isfinite(self.claim_prior_effect) and np.isfinite(claim_observed):
            claim_sign_correct = int(
                abs(self.claim_prior_effect) < 1e-12
                or self.claim_prior_effect * claim_observed > 0.0
            )
            claim_abs_error = abs(self.claim_prior_effect - claim_observed)
        else:
            claim_sign_correct = -1
            claim_abs_error = float('nan')
        entropy_t = 0.0
        entropy_c = 0.0
        if self.treatment_claim_slot >= 0:
            slot = int(self.treatment_claim_slot)
            p = float(ft.claim_alpha[slot] / (
                ft.claim_alpha[slot] + ft.claim_beta[slot]
            ))
            entropy_t = -(p * math.log(max(p, 1e-12)) + (1.0 - p) * math.log(max(1.0 - p, 1e-12)))
        if self.control_claim_slot >= 0:
            slot = int(self.control_claim_slot)
            p = float(fc.claim_alpha[slot] / (
                fc.claim_alpha[slot] + fc.claim_beta[slot]
            ))
            entropy_c = -(p * math.log(max(p, 1e-12)) + (1.0 - p) * math.log(max(1.0 - p, 1e-12)))

        result = {
            'seed': int(self.seed),
            'mode': self.mode_name,
            'regime': self.regime_name,
            'branch_success': 1,
            'failure_reason': '',
            'branch_reason': self.branch_reason,
            'branch_age': float(self.branch_age),
            'eval_elapsed': float(self.eval_elapsed),
            'treatment_alive': int(self.treatment.alive),
            'control_alive': int(self.control.alive),
            'treatment_health': health_t,
            'control_health': health_c,
            'health_gain': health_t - health_c,
            'energy_debt_gain': float(gain[0]),
            'thermal_debt_gain': float(gain[1]),
            'integrity_debt_gain': float(gain[2]),
            'fatigue_debt_gain': float(gain[3]),
            'mean_debt_gain': float(np.mean(gain)),
            'energy_experiment_cost': float(self.cost_integral[0]),
            'thermal_experiment_cost': float(self.cost_integral[1]),
            'integrity_experiment_cost': float(self.cost_integral[2]),
            'fatigue_experiment_cost': float(self.cost_integral[3]),
            'energy_post_benefit': float(self.benefit_integral[0]),
            'thermal_post_benefit': float(self.benefit_integral[1]),
            'integrity_post_benefit': float(self.benefit_integral[2]),
            'fatigue_post_benefit': float(self.benefit_integral[3]),
            'energy_net_knowledge_gain': float(net_gain[0]),
            'thermal_net_knowledge_gain': float(net_gain[1]),
            'integrity_net_knowledge_gain': float(net_gain[2]),
            'fatigue_net_knowledge_gain': float(net_gain[3]),
            'mean_net_knowledge_gain': float(np.mean(net_gain)),
            'knowledge_payback': int(float(np.mean(net_gain)) > 0.0),
            'intervention_end_elapsed': float(self.intervention_end_elapsed),
            'adaptation_time_treatment': float(self.adaptation_time[0]),
            'adaptation_time_control': float(self.adaptation_time[1]),
            'adaptation_time_gain': (
                float(self.adaptation_time[1] - self.adaptation_time[0])
                if np.all(self.adaptation_time >= 0.0) else 0.0
            ),
            'adaptation_time_energy_treatment': float(
                self.adaptation_time_by_debt[0, 0]
            ),
            'adaptation_time_energy_control': float(
                self.adaptation_time_by_debt[1, 0]
            ),
            'adaptation_time_thermal_treatment': float(
                self.adaptation_time_by_debt[0, 1]
            ),
            'adaptation_time_thermal_control': float(
                self.adaptation_time_by_debt[1, 1]
            ),
            'adaptation_time_integrity_treatment': float(
                self.adaptation_time_by_debt[0, 2]
            ),
            'adaptation_time_integrity_control': float(
                self.adaptation_time_by_debt[1, 2]
            ),
            'adaptation_time_fatigue_treatment': float(
                self.adaptation_time_by_debt[0, 3]
            ),
            'adaptation_time_fatigue_control': float(
                self.adaptation_time_by_debt[1, 3]
            ),
            'rng_sync_fraction': float(rng_fraction),
            'rng_poststep_coupled_fraction': float(rng_post_fraction),
            'exact_shared_steps': int(self.exact_until_divergence_steps),
            'prediction_target': int(self.prediction_target),
            'predicted_target_gain': predicted,
            'actual_target_gain': actual,
            'prediction_sign_correct': sign_correct,
            'prediction_abs_error': abs(predicted - actual),
            'claim_prior_effect': float(self.claim_prior_effect),
            'claim_expected_sign': float(self.claim_expected_sign),
            'claim_observed_effect': float(claim_observed),
            'claim_prediction_sign_correct': int(claim_sign_correct),
            'claim_prediction_abs_error': float(claim_abs_error),
            'feedback_fallback': int(self.feedback_fallback),
            'seeded_lease': int(self.seeded_lease),
            'treatment_food': int(self.treatment.eaten),
            'control_food': int(self.control.eaten),
            'treatment_toxin': int(self.treatment.poisoned),
            'control_toxin': int(self.control.poisoned),
            'treatment_compiler_completed': int(ft.completed),
            'control_compiler_completed': int(fc.completed),
            'treatment_compiler_contradicted': int(ft.contradicted),
            'control_compiler_contradicted': int(fc.contradicted),
            'treatment_reopened_cells': int(ft.reopened_cells),
            'control_reopened_cells': int(fc.reopened_cells),
            'compiler_entropy_treatment': float(entropy_t),
            'compiler_entropy_control': float(entropy_c),
            'treatment_damage_applied': int(self.treatment.damage_applied),
            'control_damage_applied': int(self.control.damage_applied),
            'treatment_delayed_delivered': int(self.treatment.delayed_delivered),
            'control_delayed_delivered': int(self.control.delayed_delivered),
        }
        return result

    # ------------------------------------------------------------------
    # Persistence of a paired trial
    # ------------------------------------------------------------------

    def state_dict(self):
        state = {
            'lab_save_version': scalar_array(LAB_SAVE_VERSION, np.int64),
            'lab_seed': scalar_array(self.seed, np.int64),
            'lab_mode': scalar_array(self.mode, np.int64),
            'lab_regime': scalar_array(self.regime, np.int64),
            'lab_warmup_age': scalar_array(self.warmup_age),
            'lab_max_warmup_age': scalar_array(self.max_warmup_age),
            'lab_horizon': scalar_array(self.horizon),
            'lab_shock_delay': scalar_array(self.shock_delay),
            'lab_outcome_delay': scalar_array(self.outcome_delay),
            'lab_dt': scalar_array(self.dt),
            'lab_rng_state': encode_rng_state(self.rng),
            'lab_noise_tape_seed': np.array(str(self.noise_tape_seed)),
            'lab_noise_tape_step': scalar_array(self.noise_tape_step, np.int64),
            'lab_phase': scalar_array(self.phase, np.int64),
            'lab_failure_reason': np.array(self.failure_reason),
            'lab_branch_reason': np.array(self.branch_reason),
            'lab_branch_age': scalar_array(self.branch_age),
            'lab_eval_elapsed': scalar_array(self.eval_elapsed),
            'lab_eval_steps': scalar_array(self.eval_steps, np.int64),
            'lab_intervention_finished': bool_array(self.intervention_finished),
            'lab_intervention_end': scalar_array(self.intervention_end_elapsed),
            'lab_seeded_lease': bool_array(self.seeded_lease),
            'lab_lease_index': scalar_array(self.lease_index, np.int64),
            'lab_debt_integral_t': self.debt_integral_treatment,
            'lab_debt_integral_c': self.debt_integral_control,
            'lab_cost_integral': self.cost_integral,
            'lab_benefit_integral': self.benefit_integral,
            'lab_branch_debt': self.branch_debt,
            'lab_predicted_gain': self.predicted_gain,
            'lab_prediction_target': scalar_array(self.prediction_target, np.int64),
            'lab_claim_prior_effect': scalar_array(self.claim_prior_effect),
            'lab_claim_expected_sign': scalar_array(self.claim_expected_sign),
            'lab_shock_seen': bool_array(self.shock_seen),
            'lab_shock_elapsed': scalar_array(self.shock_elapsed),
            'lab_pre_shock_mean': self.pre_shock_mean,
            'lab_pre_shock_samples': self.pre_shock_samples,
            'lab_adapt_streak': self.adapt_streak,
            'lab_adaptation_time': self.adaptation_time,
            'lab_post_shock_peak': self.post_shock_peak,
            'lab_pre_shock_debt_mean': self.pre_shock_debt_mean,
            'lab_post_shock_debt_peak': self.post_shock_debt_peak,
            'lab_adapt_streak_by_debt': self.adapt_streak_by_debt,
            'lab_adaptation_time_by_debt': self.adaptation_time_by_debt,
            'lab_treatment_claim_slot': scalar_array(self.treatment_claim_slot, np.int64),
            'lab_control_claim_slot': scalar_array(self.control_claim_slot, np.int64),
            'lab_rng_sync_steps': scalar_array(self.rng_sync_steps, np.int64),
            'lab_rng_checked_steps': scalar_array(self.rng_checked_steps, np.int64),
            'lab_rng_poststep_steps': scalar_array(
                self.rng_poststep_coupled_steps, np.int64
            ),
            'lab_exact_steps': scalar_array(self.exact_until_divergence_steps, np.int64),
            'lab_divergence_seen': bool_array(self.divergence_seen),
            'lab_warmup_regenerations': scalar_array(
                self.warmup_regenerations, np.int64
            ),
            'lab_feedback_fallback': bool_array(self.feedback_fallback),
            'lab_has_source': bool_array(self.source is not None),
            'lab_has_treatment': bool_array(self.treatment is not None),
            'lab_has_control': bool_array(self.control is not None),
        }
        if self.source is not None:
            state.update(_prefix_state('source__', self.source.state_dict()))
        if self.treatment is not None:
            state.update(_prefix_state('treat__', self.treatment.state_dict()))
        if self.control is not None:
            state.update(_prefix_state('control__', self.control.state_dict()))
        return state

    @classmethod
    def from_state(cls, data):
        if int(data['lab_save_version']) != LAB_SAVE_VERSION:
            raise ValueError('unsupported twin-lab save version')
        lab = cls(
            seed=int(data['lab_seed']),
            mode=int(data['lab_mode']),
            regime=int(data['lab_regime']),
            warmup_age=float(data['lab_warmup_age']),
            max_warmup_age=float(data['lab_max_warmup_age']),
            horizon=float(data['lab_horizon']),
            shock_delay=float(data['lab_shock_delay']),
            outcome_delay=float(data['lab_outcome_delay']),
            dt=float(data['lab_dt']),
        )
        restore_rng_state(lab.rng, data['lab_rng_state'])
        lab.noise_tape_seed = int(
            str(np.asarray(data['lab_noise_tape_seed']).item())
        )
        lab.noise_tape_step = int(data['lab_noise_tape_step'])
        lab.phase = int(data['lab_phase'])
        lab.failure_reason = str(np.asarray(data['lab_failure_reason']).item())
        lab.branch_reason = str(np.asarray(data['lab_branch_reason']).item())
        lab.branch_age = float(data['lab_branch_age'])
        lab.eval_elapsed = float(data['lab_eval_elapsed'])
        lab.eval_steps = int(data['lab_eval_steps'])
        lab.intervention_finished = bool(int(data['lab_intervention_finished']))
        lab.intervention_end_elapsed = float(data['lab_intervention_end'])
        lab.seeded_lease = bool(int(data['lab_seeded_lease']))
        lab.lease_index = int(data['lab_lease_index'])
        lab.debt_integral_treatment = np.array(data['lab_debt_integral_t'], dtype=float)
        lab.debt_integral_control = np.array(data['lab_debt_integral_c'], dtype=float)
        lab.cost_integral = np.array(data['lab_cost_integral'], dtype=float)
        lab.benefit_integral = np.array(data['lab_benefit_integral'], dtype=float)
        lab.branch_debt = np.array(data['lab_branch_debt'], dtype=float)
        lab.predicted_gain = np.array(data['lab_predicted_gain'], dtype=float)
        lab.prediction_target = int(data['lab_prediction_target'])
        lab.claim_prior_effect = float(data['lab_claim_prior_effect'])
        lab.claim_expected_sign = float(data['lab_claim_expected_sign'])
        lab.shock_seen = bool(int(data['lab_shock_seen']))
        lab.shock_elapsed = float(data['lab_shock_elapsed'])
        lab.pre_shock_mean = np.array(data['lab_pre_shock_mean'], dtype=float)
        lab.pre_shock_samples = np.array(data['lab_pre_shock_samples'], dtype=np.int64)
        lab.adapt_streak = np.array(data['lab_adapt_streak'], dtype=float)
        lab.adaptation_time = np.array(data['lab_adaptation_time'], dtype=float)
        lab.post_shock_peak = np.array(data['lab_post_shock_peak'], dtype=float)
        lab.pre_shock_debt_mean = np.array(
            data['lab_pre_shock_debt_mean'], dtype=float
        )
        lab.post_shock_debt_peak = np.array(
            data['lab_post_shock_debt_peak'], dtype=float
        )
        lab.adapt_streak_by_debt = np.array(
            data['lab_adapt_streak_by_debt'], dtype=float
        )
        lab.adaptation_time_by_debt = np.array(
            data['lab_adaptation_time_by_debt'], dtype=float
        )
        lab.treatment_claim_slot = int(data['lab_treatment_claim_slot'])
        lab.control_claim_slot = int(data['lab_control_claim_slot'])
        lab.rng_sync_steps = int(data['lab_rng_sync_steps'])
        lab.rng_checked_steps = int(data['lab_rng_checked_steps'])
        lab.rng_poststep_coupled_steps = int(data['lab_rng_poststep_steps'])
        lab.exact_until_divergence_steps = int(data['lab_exact_steps'])
        lab.divergence_seen = bool(int(data['lab_divergence_seen']))
        lab.warmup_regenerations = int(data['lab_warmup_regenerations'])
        lab.feedback_fallback = bool(int(data['lab_feedback_fallback']))

        lab.source = None
        lab.treatment = None
        lab.control = None
        for flag, prefix, attr in (
            ('lab_has_source', 'source__', 'source'),
            ('lab_has_treatment', 'treat__', 'treatment'),
            ('lab_has_control', 'control__', 'control'),
        ):
            if bool(int(data[flag])):
                core_state = _extract_prefixed(data, prefix)
                core = CounterfactualSomaCore(seed=lab.seed)
                core.load_state(core_state)
                setattr(lab, attr, core)
        return lab


# =============================================================================
# Headless API
# =============================================================================


def run_twin_trial(
    seed=101,
    mode=DEFAULT_TWIN_MODE,
    regime=DEFAULT_REGIME,
    warmup_age=30.0,
    max_warmup_age=150.0,
    horizon=72.0,
    shock_delay=8.0,
    outcome_delay=3.0,
    dt=1.0 / 30.0,
):
    lab = CounterfactualTwinLab(
        seed=seed,
        mode=mode,
        regime=regime,
        warmup_age=warmup_age,
        max_warmup_age=max_warmup_age,
        horizon=horizon,
        shock_delay=shock_delay,
        outcome_delay=outcome_delay,
        dt=dt,
    )
    maximum = max_warmup_age + horizon + 8.0
    for _ in range(int(maximum / dt) + 5):
        lab.step(dt)
        if lab.done:
            break
    if not lab.done:
        lab.phase = PHASE_FAILED
        lab.failure_reason = 'trial exceeded deterministic step budget'
    return lab.metrics()


# =============================================================================
# Pythonista side-by-side scene
# =============================================================================


if soma2.IN_PYTHONISTA:
    import ui
    from scene import Scene, LabelNode, SpriteNode, run, LANDSCAPE

    class SomaFourOneScene(Scene):
        PRESETS = (
            (TWIN_EXPERIMENT_VALUE, REGIME_MEANING_REVERSAL),
            (TWIN_FEEDBACK_VALUE, REGIME_BODY_DAMAGE),
            (TWIN_COMPILED_VS_RANDOM, REGIME_DELAYED_OUTCOMES),
            (TWIN_LEASE_VALUE, REGIME_BODY_DAMAGE),
            (TWIN_EXPERIMENT_VALUE, REGIME_STABLE),
        )

        def setup(self):
            self.background_color = '#071014'
            self.preset_index = 0
            self.paused = False
            self.lab = CounterfactualTwinLab(
                seed=101,
                mode=self.PRESETS[0][0],
                regime=self.PRESETS[0][1],
                warmup_age=28.0,
                horizon=72.0,
            )
            self._load_if_possible()

            self.title = LabelNode('', font=('Menlo-Bold', 10), parent=self)
            self.title.anchor_point = (0.5, 1.0)
            self.title.color = '#E9F7F6'
            self.left_info = LabelNode('', font=('Menlo', 8), parent=self)
            self.right_info = LabelNode('', font=('Menlo', 8), parent=self)
            for label in (self.left_info, self.right_info):
                label.anchor_point = (0.0, 1.0)
                label.color = '#CFE3E3'

            self.divider = SpriteNode(
                texture=None, color='#42616B', size=(1.0, 100.0), parent=self
            )
            self.divider.alpha = 0.65

            self.panels = [self._make_panel(), self._make_panel()]
            self.last_save_time = 0.0
            self.last_tile_time = -100.0
            self._layout()
            self._sync(force_tiles=True)

        def _make_panel(self):
            panel = {
                'tiles': [], 'nutrients': [], 'toxins': [], 'shelters': [],
                'cells': [],
            }
            for _ in range(6 * 4):
                tile = SpriteNode(
                    texture=None, color='#152A38', size=(10, 10), parent=self
                )
                tile.alpha = 0.55
                tile.z_position = -20
                panel['tiles'].append(tile)
            panel['nutrients'] = [
                soma2.circle_node(5.0, '#FFD15A', '#FFF1B0', parent=self)
                for _ in range(NUTRIENT_COUNT)
            ]
            panel['toxins'] = [
                soma2.diamond_node(5.5, '#E45B68', '#FFC0C6', parent=self)
                for _ in range(TOXIN_COUNT)
            ]
            panel['shelters'] = [
                soma2.circle_node(14.0, '#355D76', '#73A6C4', parent=self)
                for _ in range(3)
            ]
            panel['body'] = soma2.circle_node(
                13.0, '#54E3BD', '#C5FFF1', parent=self
            )
            panel['body'].z_position = 10
            panel['core'] = soma2.circle_node(
                4.2, '#F2FFFB', 'clear', parent=panel['body']
            )
            for i in range(16):
                angle = 2.0 * math.pi * i / 16.0
                node = soma2.circle_node(
                    1.15, '#DFFFF7', 'clear', parent=panel['body']
                )
                node.position = (7.5 * math.cos(angle), 7.5 * math.sin(angle))
                panel['cells'].append(node)
            return panel

        @property
        def hud_height(self):
            return 112.0

        @property
        def play_height(self):
            return max(120.0, float(self.size.h) - self.hud_height - 7.0)

        def _layout(self):
            width = float(self.size.w)
            height = float(self.size.h)
            half = width * 0.5
            self.title.position = (half, height - 5.0)
            self.left_info.position = (7.0, height - 24.0)
            self.right_info.position = (half + 7.0, height - 24.0)
            self.divider.position = (half, 7.0 + self.play_height * 0.5)
            self.divider.size = (1.0, self.play_height)
            for p, panel in enumerate(self.panels):
                x0 = p * half
                tile_w = half / 6.0
                tile_h = self.play_height / 4.0
                for row in range(4):
                    for col in range(6):
                        tile = panel['tiles'][row * 6 + col]
                        tile.size = (tile_w + 1.0, tile_h + 1.0)
                        tile.position = (
                            x0 + (col + 0.5) * tile_w,
                            7.0 + (row + 0.5) * tile_h,
                        )

        def did_change_size(self):
            if hasattr(self, 'panels'):
                self._layout()
                self._sync(force_tiles=True)

        def _screen(self, normalized, panel_index):
            half = float(self.size.w) * 0.5
            return (
                panel_index * half + float(normalized[0]) * half,
                7.0 + float(normalized[1]) * self.play_height,
            )

        def _sync_panel(self, panel, core, panel_index, force_tiles=False):
            if core is None:
                return
            if force_tiles or self.t - self.last_tile_time >= 1.0:
                for row in range(4):
                    for col in range(6):
                        position = np.array([
                            (col + 0.5) / 6.0,
                            (row + 0.5) / 4.0,
                        ])
                        value, _ = core.temperature_field(position)
                        panel['tiles'][row * 6 + col].color = soma2.temperature_color(value)
            for node, position in zip(panel['nutrients'], core.nutrient_positions):
                node.position = self._screen(position, panel_index)
            for node, position in zip(panel['toxins'], core.toxin_positions):
                node.position = self._screen(position, panel_index)
            for node, position in zip(panel['shelters'], core.shelter_positions):
                node.position = self._screen(position, panel_index)
            panel['body'].position = self._screen(core.pos, panel_index)
            panel['body'].alpha = 1.0 if core.alive else 0.22
            panel['core'].alpha = 0.20 + 0.40 * core.energy + 0.40 * core.integrity
            sample = np.linspace(0, CELL_COUNT - 1, len(panel['cells'])).astype(int)
            for node, index in zip(panel['cells'], sample):
                node.alpha = 0.15 + 0.85 * clamp(
                    abs(float(core.brain.hidden[index])), 0.0, 1.0
                )

        def _core_text(self, name, core):
            if core is None:
                return name + ': unavailable'
            debt = core.body_debt()
            return (
                '{} age {:5.1f} E {:.2f} T {:.2f} I {:.2f} F {:.2f}\n'
                'debt {:.2f}/{:.2f}/{:.2f}/{:.2f} food {} toxin {}\n'
                'compile done/F {}/{} pred {:.3f}'
            ).format(
                name, core.age, core.energy, core.temperature,
                core.integrity, core.fatigue,
                debt[0], debt[1], debt[2], debt[3],
                core.eaten, core.poisoned,
                core.compiler.completed, core.compiler.contradicted,
                float(np.mean(core.brain.prediction_error)),
            )

        def _sync(self, force_tiles=False):
            left, right = self.lab.active_cores()
            self._sync_panel(self.panels[0], left, 0, force_tiles)
            self._sync_panel(self.panels[1], right, 1, force_tiles)
            self.last_tile_time = self.t if force_tiles or self.t - self.last_tile_time >= 1.0 else self.last_tile_time

            phase = PHASE_NAMES[self.lab.phase]
            pause = ' PAUSED' if self.paused else ''
            self.title.text = (
                'SOMA-4.1  {} / {}  {}{}  tap: pause; completed tap: next preset'
            ).format(self.lab.mode_name, self.lab.regime_name, phase, pause)
            self.left_info.text = self._core_text('TREATMENT', left)
            self.right_info.text = self._core_text('CONTROL', right)
            if self.lab.phase == PHASE_EVALUATION:
                gain = (
                    self.lab.debt_integral_control
                    - self.lab.debt_integral_treatment
                )
                suffix = (
                    '\npaired gain E/T/I/F {:.3f}/{:.3f}/{:.3f}/{:.3f}  CRN {:.1%}'
                ).format(
                    gain[0], gain[1], gain[2], gain[3],
                    self.lab.rng_sync_steps / max(self.lab.rng_checked_steps, 1),
                )
                self.left_info.text += suffix
                self.right_info.text += '\nbranch: ' + self.lab.branch_reason[:54]
            elif self.lab.phase == PHASE_FAILED:
                self.left_info.text += '\nFAILED: ' + self.lab.failure_reason

        def update(self):
            if not self.paused and not self.lab.done:
                self.lab.step(clamp(float(self.dt), 1.0 / 120.0, 1.0 / 15.0))
            self._sync(force_tiles=False)
            if self.t - self.last_save_time >= 20.0:
                self._save()
                self.last_save_time = self.t

        def touch_began(self, touch):
            if self.lab.done:
                self.preset_index = (self.preset_index + 1) % len(self.PRESETS)
                mode, regime = self.PRESETS[self.preset_index]
                self.lab = CounterfactualTwinLab(
                    seed=101 + 110 * self.preset_index,
                    mode=mode,
                    regime=regime,
                    warmup_age=28.0,
                    horizon=72.0,
                )
                self.paused = False
            else:
                self.paused = not self.paused

        def _save(self):
            try:
                np.savez(SAVE_FILE, **self.lab.state_dict())
            except Exception as exc:
                print('SOMA-4.1 save failed:', exc)

        def _load_if_possible(self):
            if not os.path.exists(SAVE_FILE):
                return
            try:
                with np.load(SAVE_FILE, allow_pickle=False) as data:
                    self.lab = CounterfactualTwinLab.from_state(data)
            except Exception as exc:
                print('SOMA-4.1 load ignored:', exc)


if __name__ == '__main__':
    if soma2.IN_PYTHONISTA:
        run(SomaFourOneScene(), orientation=LANDSCAPE, show_fps=False)
    else:
        print(run_twin_trial(
            seed=101,
            mode=TWIN_EXPERIMENT_VALUE,
            regime=REGIME_MEANING_REVERSAL,
            warmup_age=28.0,
            horizon=45.0,
        ))
