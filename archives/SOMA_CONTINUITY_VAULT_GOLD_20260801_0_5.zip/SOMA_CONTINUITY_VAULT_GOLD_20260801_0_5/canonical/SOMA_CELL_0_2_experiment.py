# coding: utf-8
"""Controlled SOMA-CELL 0.2 physical and evolutionary comparisons.

Two experiment classes are intentionally separated:

1. ``physical`` runs the full membrane / matter / genome world.
2. ``accelerated_evolution`` uses the same genome grammar and mutation
   operators in a controlled population assay.  It is not a substitute for
   multi-generation evolution in the physical world.
"""
from __future__ import division

import csv
import gc
import os
import statistics
import time

import SOMA_CELL_0_2_pythonista as soma

BASE_DIR = os.path.dirname(__file__)
RESULTS_PATH = os.path.join(BASE_DIR, 'soma_cell_0_2_experiment_results.csv')
SUMMARY_PATH = os.path.join(BASE_DIR, 'soma_cell_0_2_experiment_summary.csv')

PHYSICAL_SEEDS = (101, 202, 303)
EVOLUTION_SEEDS = (101, 202, 303, 404, 505)
RESUME_COMPLETED = True


def physical_conditions():
    return (
        ('full_material_heredity', soma.GeneticConfig(), 320.0),
        ('genome_replication_off', soma.GeneticConfig(genome_replication=False), 320.0),
        ('composition_inheritance_off', soma.GeneticConfig(composition_inheritance=False), 360.0),
        ('mutation_off_fixed_length', soma.GeneticConfig(
            mutation=False, variable_length=False, gene_duplication=False
        ), 320.0),
    )


def evolutionary_conditions():
    return (
        ('full_variable_mutation', True, True, True),
        ('mutation_off', False, True, True),
        ('gene_duplication_off', True, True, False),
        ('fixed_length', True, False, False),
    )


def mean(values):
    values = list(values)
    return float(statistics.mean(values)) if values else 0.0


def _load_existing():
    if not RESUME_COMPLETED or not os.path.exists(RESULTS_PATH):
        return []
    with open(RESULTS_PATH, newline='', encoding='utf-8') as handle:
        return list(csv.DictReader(handle))


def _key(row):
    return (str(row['experiment_type']), str(row['condition']), int(row['seed']))


def _write_results(rows):
    if not rows:
        return
    fields = list(rows[0].keys())
    with open(RESULTS_PATH, 'w', newline='', encoding='utf-8') as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def run_all():
    rows = _load_existing()
    completed = {_key(row) for row in rows}

    for condition, config, seconds in physical_conditions():
        for seed in PHYSICAL_SEEDS:
            if ('physical', condition, int(seed)) in completed:
                continue
            start = time.time()
            result = soma.run_headless_trial(
                seed=seed, seconds=seconds, initial_cells=1, config=config
            )
            row = {
                'experiment_type': 'physical',
                'condition': condition,
                'seed': seed,
                'duration_or_generations': seconds,
                'population': 1,
                'cells': result['cells'],
                'divisions': result['divisions'],
                'deaths': result['deaths'],
                'max_generation': result['max_generation'],
                'genome_copies': result['genome_copies'],
                'genome_types': result['genome_types'],
                'mean_genome_length': result['mean_genome_length'],
                'max_genome_length': result['max_genome_length'],
                'mean_gene_count': result['mean_gene_count'],
                'replication_cycles': result['replication_cycles'],
                'mutation_total': result['mutation_total'],
                'novel_path_cells': result['novel_path_cells'],
                'first_novel_generation': '',
                'final_novel_frequency': '',
                'initial_mean_fitness': '',
                'final_mean_fitness': '',
                'best_fitness': '',
                'knockout_fitness': '',
                'knockout_drop': '',
                'best_length': '',
                'best_gene_count': '',
                'matter_residual': result['matter_residual'],
                'division_residual': result['division_residual'],
                'wall_seconds': time.time() - start,
            }
            rows.append(row)
            completed.add(_key(row))
            _write_results(rows)
            gc.collect()
            print('physical', condition, seed, 'cells', row['cells'], 'G', row['max_generation'])

    for condition, mutation, variable_length, duplication in evolutionary_conditions():
        for seed in EVOLUTION_SEEDS:
            if ('accelerated_evolution', condition, int(seed)) in completed:
                continue
            start = time.time()
            result = soma.run_evolution_assay(
                seed=seed,
                generations=80,
                population=96,
                mutation=mutation,
                variable_length=variable_length,
                duplication=duplication,
            )
            row = {
                'experiment_type': 'accelerated_evolution',
                'condition': condition,
                'seed': seed,
                'duration_or_generations': 80,
                'population': 96,
                'cells': '',
                'divisions': '',
                'deaths': '',
                'max_generation': '',
                'genome_copies': '',
                'genome_types': result['history'][-1]['genome_types'],
                'mean_genome_length': result['history'][-1]['mean_length'],
                'max_genome_length': '',
                'mean_gene_count': '',
                'replication_cycles': '',
                'mutation_total': '',
                'novel_path_cells': '',
                'first_novel_generation': (
                    '' if result['first_novel_generation'] is None
                    else result['first_novel_generation']
                ),
                'final_novel_frequency': result['final_novel_frequency'],
                'initial_mean_fitness': result['initial_mean_fitness'],
                'final_mean_fitness': result['final_mean_fitness'],
                'best_fitness': result['best_fitness'],
                'knockout_fitness': result['knockout_fitness'],
                'knockout_drop': result['best_fitness'] - result['knockout_fitness'],
                'best_length': result['best_length'],
                'best_gene_count': result['best_gene_count'],
                'matter_residual': '',
                'division_residual': '',
                'wall_seconds': time.time() - start,
            }
            rows.append(row)
            completed.add(_key(row))
            _write_results(rows)
            gc.collect()
            print(
                'evolution', condition, seed,
                'first', row['first_novel_generation'],
                'freq', '{:.3f}'.format(row['final_novel_frequency'])
            )

    _write_results(rows)

    summaries = []
    for experiment_type in ('physical', 'accelerated_evolution'):
        conditions = sorted({
            row['condition'] for row in rows if row['experiment_type'] == experiment_type
        })
        for condition in conditions:
            subset = [
                row for row in rows
                if row['experiment_type'] == experiment_type and row['condition'] == condition
            ]
            if experiment_type == 'physical':
                summaries.append({
                    'experiment_type': experiment_type,
                    'condition': condition,
                    'runs': len(subset),
                    'successful_novelty_runs': '',
                    'surviving_runs': sum(int(row['cells']) > 0 for row in subset),
                    'mean_cells': mean(float(row['cells']) for row in subset),
                    'mean_divisions': mean(float(row['divisions']) for row in subset),
                    'mean_deaths': mean(float(row['deaths']) for row in subset),
                    'mean_max_generation': mean(float(row['max_generation']) for row in subset),
                    'mean_genome_types': mean(float(row['genome_types']) for row in subset),
                    'mean_genome_length': mean(float(row['mean_genome_length']) for row in subset),
                    'mean_mutation_total': mean(float(row['mutation_total']) for row in subset),
                    'mean_final_novel_frequency': '',
                    'mean_initial_fitness': '',
                    'mean_final_fitness': '',
                    'mean_best_fitness': '',
                    'mean_knockout_drop': '',
                    'mean_abs_matter_residual': mean(abs(float(row['matter_residual'])) for row in subset),
                    'mean_wall_seconds': mean(float(row['wall_seconds']) for row in subset),
                })
            else:
                novelty_runs = sum(row['first_novel_generation'] != '' for row in subset)
                summaries.append({
                    'experiment_type': experiment_type,
                    'condition': condition,
                    'runs': len(subset),
                    'successful_novelty_runs': novelty_runs,
                    'surviving_runs': '',
                    'mean_cells': '',
                    'mean_divisions': '',
                    'mean_deaths': '',
                    'mean_max_generation': '',
                    'mean_genome_types': mean(float(row['genome_types']) for row in subset),
                    'mean_genome_length': mean(float(row['mean_genome_length']) for row in subset),
                    'mean_mutation_total': '',
                    'mean_final_novel_frequency': mean(float(row['final_novel_frequency']) for row in subset),
                    'mean_initial_fitness': mean(float(row['initial_mean_fitness']) for row in subset),
                    'mean_final_fitness': mean(float(row['final_mean_fitness']) for row in subset),
                    'mean_best_fitness': mean(float(row['best_fitness']) for row in subset),
                    'mean_knockout_drop': mean(float(row['knockout_drop']) for row in subset),
                    'mean_abs_matter_residual': '',
                    'mean_wall_seconds': mean(float(row['wall_seconds']) for row in subset),
                })

    summary_fields = list(summaries[0].keys())
    with open(SUMMARY_PATH, 'w', newline='', encoding='utf-8') as handle:
        writer = csv.DictWriter(handle, fieldnames=summary_fields)
        writer.writeheader()
        writer.writerows(summaries)

    return rows, summaries


if __name__ == '__main__':
    result_rows, summary_rows = run_all()
    print('wrote', RESULTS_PATH)
    print('wrote', SUMMARY_PATH)
