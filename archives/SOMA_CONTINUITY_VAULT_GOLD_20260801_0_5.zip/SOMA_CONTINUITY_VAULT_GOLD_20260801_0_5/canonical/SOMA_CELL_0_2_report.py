# coding: utf-8
"""Generate SOMA-CELL 0.2 long-run TXT and session CSV from the log."""
from __future__ import print_function

import SOMA_CELL_0_2_pythonista as soma


if __name__ == '__main__':
    status = soma.generate_report()
    print('report:', status)
    print(soma.REPORT_FILE)
    print(soma.SESSION_FILE)
