# coding: utf-8
"""Controlled comparisons for SOMA-CELL 0.4.

The official run uses the same three seeds for each condition.  Behavioural
trials disable division to isolate within-lifetime sensing, movement and
plasticity.  A separate first-division mode verifies that the full material
lineage still reproduces after paying for the sensorimotor apparatus.

This is a small mechanism study, not a statistical proof of broad superiority.
On iPhone, reduce SEEDS or BEHAVIOUR_SECONDS for a quick smoke test.
"""
from __future__ import division

import csv
import gc
import os
import time

import numpy as np

import SOMA_CELL_0_4_pythonista as soma

BASE_DIR = os.path.dirname(__file__)
RESULTS_PATH = os.path.join(BASE_DIR, 'soma_cell_0_4_experiment_results.csv')
SUMMARY_PATH = os.path.join(BASE_DIR, 'soma_cell_0_4_experiment_summary.csv')
SEEDS = (101, 202, 303)
BEHAVIOUR_SECONDS = 100.0
SWITCH_AGE = 45.0
RESUME_COMPLETED = True


def behaviour_conditions():
    return (
        ('patchy_adaptive', soma.SensorimotorConfig(
            environment_mode='patchy', division=False,
        )),
        ('patchy_no_motion', soma.SensorimotorConfig(
            environment_mode='patchy', division=False,
            active_motion=False, transporter_polarity=False,
        )),
        ('patchy_no_plasticity', soma.SensorimotorConfig(
            environment_mode='patchy', division=False,
            plasticity=False, causal_perturbation=False,
        )),
        ('patchy_fixed_reflex', soma.SensorimotorConfig(
            environment_mode='patchy', division=False,
            fixed_reflex=True, plasticity=False, causal_perturbation=False,
        )),
        ('patchy_no_sensorimotor', soma.SensorimotorConfig(
            environment_mode='patchy', division=False,
            sensorimotor=False,
        )),
        ('uniform_adaptive', soma.SensorimotorConfig(
            environment_mode='uniform', division=False,
        )),
        ('reversal_adaptive', soma.SensorimotorConfig(
            environment_mode='reversal', switch_age=SWITCH_AGE,
            division=False,
        )),
        ('reversal_no_plasticity', soma.SensorimotorConfig(
            environment_mode='reversal', switch_age=SWITCH_AGE,
            division=False, plasticity=False, causal_perturbation=False,
        )),
        ('reversal_fixed_reflex', soma.SensorimotorConfig(
            environment_mode='reversal', switch_age=SWITCH_AGE,
            division=False, fixed_reflex=True,
            plasticity=False, causal_perturbation=False,
        )),
        ('reversal_no_motion', soma.SensorimotorConfig(
            environment_mode='reversal', switch_age=SWITCH_AGE,
            division=False, active_motion=False, transporter_polarity=False,
        )),
    )


def _existing_keys():
    if not RESUME_COMPLETED or not os.path.exists(RESULTS_PATH):
        return set()
    keys = set()
    try:
        with open(RESULTS_PATH, 'r', encoding='utf-8', newline='') as handle:
            for row in csv.DictReader(handle):
                keys.add((row.get('mode', ''), row.get('condition', ''), int(row.get('seed', -1))))
    except Exception:
        return set()
    return keys


def _write_results(rows):
    if not rows:
        return
    fields = sorted(set().union(*(row.keys() for row in rows)))
    with open(RESULTS_PATH, 'w', encoding='utf-8', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction='ignore')
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key, '') for key in fields})


def run_behaviour(condition, seed, config):
    started = time.time()
    result = soma.run_headless_trial(
        seed=seed, seconds=BEHAVIOUR_SECONDS,
        initial_cells=1, config=config,
    )
    row = {
        'mode': 'behaviour',
        'condition': condition,
        'seed': int(seed),
        'wall_seconds': float(time.time() - started),
    }
    keep = (
        'requested_seconds', 'completed_seconds', 'cells', 'deaths',
        'mean_margin_over_life', 'margin_integral', 'post_switch_mean_margin',
        'mean_fuel_patch_distance', 'mean_alt_patch_distance',
        'distance_fuel_patch', 'distance_alt_patch', 'distance_waste_patch',
        'mean_autopoietic_margin', 'mean_atp', 'mean_closure', 'mean_loop',
        'mean_damage', 'mean_proteostasis', 'mean_motor_force',
        'meaning_fuel', 'meaning_alt', 'meaning_waste',
        'confidence_fuel', 'confidence_alt',
        'control_fuel', 'control_alt', 'control_waste',
        'fuel_uptake_total', 'mineral_uptake_total', 'alt_uptake_total',
        'waste_ingress_total', 'fuel_contamination_total',
        'sensor_atp_total', 'motor_atp_total', 'polarity_atp_total',
        'plasticity_atp_total', 'controller_updates', 'meaning_reversals',
        'active_distance_total', 'matter_residual', 'finite',
    )
    for key in keep:
        if key == 'finite':
            row[key] = 1
        elif key in result:
            row[key] = result[key]
    return row


def run_first_division(seed):
    config = soma.SensorimotorConfig(environment_mode='patchy')
    world = soma.SensorimotorWorld(seed=seed, initial_cells=1, config=config)
    dt = 1.0 / soma.SIM_HZ
    started = time.time()
    max_abs_residual = 0.0
    first_division_age = ''
    for _ in range(int(260.0 * soma.SIM_HZ)):
        world.step(dt)
        max_abs_residual = max(
            max_abs_residual, abs(float(world.summary()['matter_residual']))
        )
        if world.divisions:
            first_division_age = float(world.age)
            break
        if not world.living_cells():
            break
    summary = world.summary()
    return {
        'mode': 'division',
        'condition': 'physical_first_division',
        'seed': int(seed),
        'wall_seconds': float(time.time() - started),
        'requested_seconds': 260.0,
        'completed_seconds': float(world.age),
        'cells': int(summary['cells']),
        'deaths': int(summary['deaths']),
        'divisions': int(summary['divisions']),
        'max_generation': int(summary['max_generation']),
        'first_division_age': first_division_age,
        'division_residual': float(summary['division_residual']),
        'matter_residual': float(summary['matter_residual']),
        'max_abs_matter_residual': float(max_abs_residual),
        'mean_autopoietic_margin': float(summary['mean_autopoietic_margin']),
        'mean_damage': float(summary['mean_damage']),
        'mean_atp': float(summary['mean_atp']),
        'finite': int(world.finite()),
    }


def _num(rows, key):
    values = []
    for row in rows:
        value = row.get(key, '')
        if value in ('', None):
            continue
        try:
            values.append(float(value))
        except (TypeError, ValueError):
            pass
    return np.asarray(values, dtype=float)


def build_summary(rows):
    groups = {}
    for row in rows:
        groups.setdefault((row['mode'], row['condition']), []).append(row)
    summary_rows = []
    metrics = (
        'completed_seconds', 'cells', 'deaths', 'divisions',
        'first_division_age', 'mean_margin_over_life',
        'post_switch_mean_margin', 'mean_fuel_patch_distance',
        'mean_alt_patch_distance', 'fuel_contamination_total',
        'fuel_uptake_total', 'alt_uptake_total',
        'sensor_atp_total', 'motor_atp_total', 'polarity_atp_total',
        'plasticity_atp_total', 'controller_updates',
        'meaning_fuel', 'meaning_alt', 'meaning_waste',
        'control_fuel', 'control_alt', 'control_waste',
        'mean_damage', 'mean_atp', 'division_residual',
        'max_abs_matter_residual', 'wall_seconds',
    )
    for (mode, condition), items in sorted(groups.items()):
        row = {
            'mode': mode,
            'condition': condition,
            'n': len(items),
            'survived': int(sum(float(item.get('cells', 0)) > 0 for item in items)),
            'finite': int(sum(int(float(item.get('finite', 0))) for item in items)),
        }
        for key in metrics:
            values = _num(items, key)
            if values.size:
                row[key + '_mean'] = float(np.mean(values))
                row[key + '_sd'] = float(np.std(values))
                row[key + '_min'] = float(np.min(values))
                row[key + '_max'] = float(np.max(values))
        summary_rows.append(row)
    fields = sorted(set().union(*(row.keys() for row in summary_rows)))
    with open(SUMMARY_PATH, 'w', encoding='utf-8', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(summary_rows)
    return summary_rows


def run_experiment():
    existing = _existing_keys()
    rows = []
    if os.path.exists(RESULTS_PATH) and RESUME_COMPLETED:
        with open(RESULTS_PATH, 'r', encoding='utf-8', newline='') as handle:
            rows.extend(list(csv.DictReader(handle)))

    for condition, config in behaviour_conditions():
        for seed in SEEDS:
            key = ('behaviour', condition, int(seed))
            if key in existing:
                continue
            print('RUN', key, flush=True)
            row = run_behaviour(condition, seed, config)
            rows.append(row)
            _write_results(rows)
            gc.collect()
            print(
                '  margin={:.5f} post={:.5f} cells={} wall={:.2f}s'.format(
                    float(row.get('mean_margin_over_life', 0.0)),
                    float(row.get('post_switch_mean_margin', 0.0)),
                    int(float(row.get('cells', 0))),
                    float(row.get('wall_seconds', 0.0)),
                ),
                flush=True,
            )

    for seed in SEEDS:
        key = ('division', 'physical_first_division', int(seed))
        if key in existing:
            continue
        print('RUN', key, flush=True)
        row = run_first_division(seed)
        rows.append(row)
        _write_results(rows)
        gc.collect()
        print(
            '  division_age={} cells={} residual={:.3e}'.format(
                row.get('first_division_age', ''), row.get('cells'),
                float(row.get('division_residual', 0.0)),
            ),
            flush=True,
        )

    summary = build_summary(rows)
    print('wrote', RESULTS_PATH)
    print('wrote', SUMMARY_PATH)
    for row in summary:
        if row['mode'] == 'behaviour':
            print(
                '{:28s} n={} margin={:.5f} post={:.5f}'.format(
                    row['condition'], row['n'],
                    float(row.get('mean_margin_over_life_mean', 0.0)),
                    float(row.get('post_switch_mean_margin_mean', 0.0)),
                )
            )
    return rows, summary


if __name__ == '__main__':
    run_experiment()
