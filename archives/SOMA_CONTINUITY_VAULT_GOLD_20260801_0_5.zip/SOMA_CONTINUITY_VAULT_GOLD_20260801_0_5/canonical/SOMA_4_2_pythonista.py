# coding: utf-8
"""
SOMA-4.2 — Change-Sensitive Causal Calibration
変化感受性ゲート＋因果校正

Pythonista 3 / CPython + NumPy

必要ファイル（同じフォルダ）
--------------------------------
- SOMA_1_pythonista.py
- SOMA_2_pythonista.py
- SOMA_2_1_pythonista.py
- SOMA_3_pythonista.py
- SOMA_4_pythonista.py
- SOMA_4_1_pythonista.py
- SOMA_4_2_pythonista.py（このファイル）

SOMA-4では、反証された説明に関係する神経組織を再び可塑的にした。しかし、
安定した世界で測定ノイズのたびに脳を開き直すと、獲得済み機能まで壊しやすい。
SOMA-4.2は「説明が反証された強さ」と「世界または身体の規則が変化した確率」を
分離し、両者がそろったときだけ強く学び直す。

    再可塑化強度
      = 反証強度 × 変化確率 × 因果説明の校正信頼度

変化時刻や変更内容は個体へ通知しない。速い記憶と遅い記憶を比較し、身体負債、
予測誤差、運動命令と実速度の対応、化学源接触後の身体結果、自身の器官・運動構造
からオンラインに変化確率を推定する。

さらに、実験前の因果予測と実験で観測した効果を、主張族×身体通貨ごとに校正する。
これは固定データセットからの教師あり学習ではなく、個体自身の身体介入から
「いつ学び直すか」と「自分の説明をどれだけ信用するか」を学ぶ小型人工生命である。
"""

import math
import os

import numpy as np

import SOMA_1_pythonista as soma1
import SOMA_2_pythonista as soma2
import SOMA_2_1_pythonista as soma21
import SOMA_3_pythonista as soma3
import SOMA_4_pythonista as soma4
import SOMA_4_1_pythonista as soma41

from SOMA_1_pythonista import CELL_COUNT, MAX_SPEED, TROPHIC_COUNT, clamp
from SOMA_2_pythonista import bool_array, scalar_array


SAVE_FILE = os.path.join(os.path.dirname(__file__), 'soma4_2_life.npz')
SAVE_VERSION = 8

CLAIM_TYPE_COUNT = len(soma4.CLAIM_NAMES)
FEATURE_COUNT = 20
FEATURE_NAMES = (
    'dE_rate', 'dT_rate', 'dI_rate', 'dF_rate',
    'pred_E', 'pred_T', 'pred_I', 'pred_F',
    'motor_gain', 'motor_lateral',
    'A_dE', 'A_dT', 'A_dI', 'A_dF',
    'B_dE', 'B_dT', 'B_dI', 'B_dF',
    'right_organ_capacity', 'motor_map_capacity',
)
CHANGE_SOURCE_NAMES = (
    'body', 'prediction', 'mechanics', 'source semantics', 'body structure'
)


def _sigmoid(x):
    x = clamp(float(x), -30.0, 30.0)
    return 1.0 / (1.0 + math.exp(-x))


def _copy_state(state):
    return {key: np.array(value, copy=True) for key, value in state.items()}


class ChangeSentinel:
    """Masked, multi-timescale online change detector.

    Dense features are sampled every step. Source-contact results are sparse and
    are updated only when that source was actually touched; absence of a contact
    is therefore not treated as a zero-valued outcome. The detector learns an
    ontogenetic baseline before arming, preventing normal early maturation from
    being mistaken for a regime shift.
    """

    def __init__(self, enabled=True, minimum_baseline_time=18.0):
        self.enabled = bool(enabled)
        self.minimum_baseline_time = float(minimum_baseline_time)
        self.fast_mean = np.zeros(FEATURE_COUNT, dtype=float)
        self.slow_mean = np.zeros(FEATURE_COUNT, dtype=float)
        self.slow_var = np.ones(FEATURE_COUNT, dtype=float) * 1e-3
        self.count = np.zeros(FEATURE_COUNT, dtype=float)
        self.last_feature = np.zeros(FEATURE_COUNT, dtype=float)
        self.last_mask = np.zeros(FEATURE_COUNT, dtype=bool)
        self.last_z = np.zeros(FEATURE_COUNT, dtype=float)
        self.last_feature_evidence = np.zeros(FEATURE_COUNT, dtype=float)
        self.last_evidence = np.zeros(TROPHIC_COUNT, dtype=float)
        self.accumulator = np.zeros(TROPHIC_COUNT, dtype=float)
        self.currency_probability = np.full(TROPHIC_COUNT, 0.006, dtype=float)
        self.global_probability = float(1.0 - (1.0 - 0.006) ** TROPHIC_COUNT)
        self.source_probability = np.full(len(CHANGE_SOURCE_NAMES), 0.006, dtype=float)
        self.last_cross_age = -1e9
        self.change_events = 0
        self.above_threshold = False
        self.eligible_time = 0.0
        self.excluded_time = 0.0
        self.max_probability = self.global_probability
        self.armed = False
        self.baseline_ready = False

        # Feature-specific irreducible noise floors.
        self.floor = np.array(
            [0.008] * 4
            + [0.026] * 4
            + [0.050, 0.050]
            + [0.018] * 8
            + [0.018, 0.018],
            dtype=float,
        )

        # Feature-to-body-currency attribution.
        self.feature_currency = np.zeros((FEATURE_COUNT, TROPHIC_COUNT), dtype=float)
        for k in range(TROPHIC_COUNT):
            self.feature_currency[k, k] = 0.82
            self.feature_currency[4 + k, k] = 0.56
            self.feature_currency[10 + k, k] = 0.94
            self.feature_currency[14 + k, k] = 0.94
        self.feature_currency[8] = np.array([0.32, 0.08, 0.24, 0.62])
        self.feature_currency[9] = np.array([0.18, 0.08, 0.34, 0.42])
        self.feature_currency[18] = np.array([0.28, 0.14, 0.52, 0.48])
        self.feature_currency[19] = np.array([0.28, 0.06, 0.34, 0.58])

    def _decay_only(self, dt):
        fall = 1.0 - math.exp(-float(dt) / 9.0)
        self.currency_probability += fall * (0.006 - self.currency_probability)
        self.accumulator *= math.exp(-float(dt) / 4.5)
        self.global_probability = float(
            1.0 - np.prod(1.0 - np.clip(self.currency_probability, 0.0, 0.995))
        )
        self.source_probability += fall * (0.006 - self.source_probability)

    def _arm_if_ready(self):
        dense_ready = np.count_nonzero(self.count[:10] >= 40.0) >= 8
        structure_ready = np.count_nonzero(self.count[18:20] >= 40.0) >= 2
        ready = bool(
            self.eligible_time >= self.minimum_baseline_time
            and dense_ready and structure_ready
        )
        self.baseline_ready = ready
        if ready and not self.armed:
            self.armed = True
            # Remove developmental lag between the fast and slow memories at the
            # exact arming instant. Future separation must be newly generated.
            self.slow_mean = self.fast_mean.copy()
            self.accumulator[:] = 0.0
            self.currency_probability[:] = 0.006
            self.source_probability[:] = 0.006
            self.global_probability = float(1.0 - (1.0 - 0.006) ** TROPHIC_COUNT)
        return self.armed

    def observe(self, feature, mask, dt, age, eligible=True):
        feature = np.asarray(feature, dtype=float)
        mask = np.asarray(mask, dtype=bool)
        dt = clamp(float(dt), 1.0 / 240.0, 0.25)
        if feature.shape != (FEATURE_COUNT,) or mask.shape != (FEATURE_COUNT,):
            raise ValueError('invalid ChangeSentinel feature shape')
        self.last_feature = feature.copy()
        self.last_mask = mask.copy()
        if eligible:
            self.eligible_time += dt
        else:
            self.excluded_time += dt
        if not self.enabled:
            self._decay_only(dt)
            return self.global_probability

        active = np.flatnonzero(mask & np.isfinite(feature))
        if active.size == 0:
            self._decay_only(dt)
            return self.global_probability

        # Fast memory tracks the current regime; slow memory represents the
        # established regime. Robust clipping prevents one contact from exploding
        # the variance estimate and making the detector permanently blind.
        fast_alpha = 1.0 - math.exp(-dt / 0.85)
        slow_alpha = 1.0 - math.exp(-dt / 19.0)
        var_alpha = 1.0 - math.exp(-dt / 25.0)
        z = np.zeros(FEATURE_COUNT, dtype=float)
        for j in active:
            j = int(j)
            x = float(feature[j])
            if self.count[j] < 1.0:
                self.fast_mean[j] = x
                self.slow_mean[j] = x
                self.slow_var[j] = self.floor[j] ** 2
                self.count[j] = 1.0
                continue
            residual = x - self.slow_mean[j]
            sparse_event = 10 <= j < 18
            fa = 0.55 if sparse_event else fast_alpha
            sa = 0.085 if sparse_event else slow_alpha
            va = 0.10 if sparse_event else var_alpha
            cap = 36.0 * (self.slow_var[j] + self.floor[j] ** 2)
            residual2 = min(residual * residual, cap)
            self.slow_var[j] = (
                (1.0 - va) * self.slow_var[j] + va * residual2
            )
            self.fast_mean[j] += fa * (x - self.fast_mean[j])
            self.slow_mean[j] += sa * residual
            self.count[j] += 1.0
            if self.count[j] >= 5.0:
                scale = math.sqrt(max(self.slow_var[j], 0.0)) + self.floor[j]
                z[j] = abs(self.fast_mean[j] - self.slow_mean[j]) / scale
        self.last_z = z

        if not self._arm_if_ready():
            self._decay_only(dt)
            return self.global_probability

        ev = np.zeros(FEATURE_COUNT, dtype=float)
        # Dense body/prediction signals are conservative; mechanics and explicit
        # body-structure changes can be sharper; sparse source semantics use a
        # lower threshold but require repeated baseline contacts.
        ev[0:8] = np.clip((z[0:8] - 2.25) / 2.85, 0.0, 1.0)
        ev[8:10] = np.clip((z[8:10] - 1.25) / 2.00, 0.0, 1.0)
        ev[10:18] = np.clip((z[10:18] - 0.55) / 1.45, 0.0, 1.0)
        ev[18:20] = np.clip((z[18:20] - 0.55) / 1.45, 0.0, 1.0)

        # A source needs several historical encounters before a changed outcome
        # can be distinguished from an unknown first encounter.
        sparse = np.arange(FEATURE_COUNT) >= 10
        sparse &= np.arange(FEATURE_COUNT) < 18
        ev[sparse & (self.count < 4.0)] = 0.0

        if not eligible:
            # Self-generated experiments perturb ordinary dynamics. Do not erase
            # persistent external changes, but discount channels most easily
            # produced by the intervention itself.
            ev[0:4] *= 0.20
            ev[4:8] *= 0.30
            ev[8:10] *= 0.58
            ev[10:18] *= 0.86
            ev[18:20] *= 0.92
        self.last_feature_evidence = ev.copy()

        evidence = np.zeros(TROPHIC_COUNT, dtype=float)
        for k in range(TROPHIC_COUNT):
            weighted = np.clip(ev * self.feature_currency[:, k], 0.0, 0.98)
            evidence[k] = 1.0 - float(np.prod(1.0 - weighted))
        self.last_evidence = evidence

        decay = math.exp(-dt / 4.2)
        self.accumulator = np.maximum(
            0.0, decay * self.accumulator + dt * (2.45 * evidence - 0.17)
        )
        # Sparse encounters are events rather than continuously sampled values.
        # Give each informative encounter a fixed evidence mass so detector
        # sensitivity does not depend on the display frame rate.
        source_active = bool(np.any(mask[10:18]))
        if source_active:
            source_weighted = np.zeros(TROPHIC_COUNT, dtype=float)
            for k in range(TROPHIC_COUNT):
                w = np.clip(ev[10:18] * self.feature_currency[10:18, k], 0.0, 0.98)
                source_weighted[k] = 1.0 - float(np.prod(1.0 - w))
            self.accumulator += 0.86 * source_weighted
        persistent = 1.0 - np.exp(-3.3 * self.accumulator)
        instant = np.clip((evidence - 0.13) / 0.68, 0.0, 1.0)
        target = np.maximum(persistent, 0.006 + 0.87 * instant)
        for k in range(TROPHIC_COUNT):
            if source_active and target[k] > self.currency_probability[k]:
                alpha = 0.56
            else:
                tau = 0.52 if target[k] > self.currency_probability[k] else 8.8
                alpha = 1.0 - math.exp(-dt / tau)
            self.currency_probability[k] += alpha * (
                target[k] - self.currency_probability[k]
            )
        np.clip(self.currency_probability, 0.006, 0.995, out=self.currency_probability)
        self.global_probability = float(
            1.0 - np.prod(1.0 - self.currency_probability)
        )

        groups = (
            ev[0:4], ev[4:8], ev[8:10], ev[10:18], ev[18:20]
        )
        for i, group in enumerate(groups):
            group_target = float(np.max(group)) if group.size else 0.0
            tau = 0.55 if group_target > self.source_probability[i] else 8.8
            alpha = 1.0 - math.exp(-dt / tau)
            self.source_probability[i] += alpha * (
                group_target - self.source_probability[i]
            )
        np.clip(self.source_probability, 0.006, 0.995, out=self.source_probability)

        self.max_probability = max(self.max_probability, self.global_probability)
        if self.global_probability >= 0.67 and not self.above_threshold:
            self.change_events += 1
            self.last_cross_age = float(age)
            self.above_threshold = True
        elif self.global_probability < 0.42:
            self.above_threshold = False
        return self.global_probability

    def diagnostics(self):
        source = int(np.argmax(self.source_probability))
        return {
            'global_probability': float(self.global_probability),
            'currency_probability': self.currency_probability.copy(),
            'source_probability': self.source_probability.copy(),
            'dominant_source': CHANGE_SOURCE_NAMES[source],
            'events': int(self.change_events),
            'max_probability': float(self.max_probability),
            'baseline_ready': bool(self.baseline_ready),
            'armed': bool(self.armed),
        }

    def state_dict(self):
        return {
            'cs_enabled': bool_array(self.enabled),
            'cs_minimum_baseline_time': scalar_array(self.minimum_baseline_time),
            'cs_fast': self.fast_mean,
            'cs_slow': self.slow_mean,
            'cs_var': self.slow_var,
            'cs_count': self.count,
            'cs_last_feature': self.last_feature,
            'cs_last_mask': self.last_mask.astype(np.uint8),
            'cs_last_z': self.last_z,
            'cs_last_feature_evidence': self.last_feature_evidence,
            'cs_last_evidence': self.last_evidence,
            'cs_accumulator': self.accumulator,
            'cs_currency_probability': self.currency_probability,
            'cs_global_probability': scalar_array(self.global_probability),
            'cs_source_probability': self.source_probability,
            'cs_last_cross_age': scalar_array(self.last_cross_age),
            'cs_change_events': scalar_array(self.change_events, np.int64),
            'cs_above_threshold': bool_array(self.above_threshold),
            'cs_eligible_time': scalar_array(self.eligible_time),
            'cs_excluded_time': scalar_array(self.excluded_time),
            'cs_max_probability': scalar_array(self.max_probability),
            'cs_armed': bool_array(self.armed),
            'cs_baseline_ready': bool_array(self.baseline_ready),
        }

    def load_state(self, data):
        self.enabled = bool(int(data['cs_enabled']))
        self.minimum_baseline_time = float(data['cs_minimum_baseline_time'])
        self.fast_mean = np.array(data['cs_fast'], dtype=float)
        self.slow_mean = np.array(data['cs_slow'], dtype=float)
        self.slow_var = np.array(data['cs_var'], dtype=float)
        self.count = np.array(data['cs_count'], dtype=float)
        self.last_feature = np.array(data['cs_last_feature'], dtype=float)
        self.last_mask = np.array(data['cs_last_mask'], dtype=bool)
        self.last_z = np.array(data['cs_last_z'], dtype=float)
        self.last_feature_evidence = np.array(data['cs_last_feature_evidence'], dtype=float)
        self.last_evidence = np.array(data['cs_last_evidence'], dtype=float)
        self.accumulator = np.array(data['cs_accumulator'], dtype=float)
        self.currency_probability = np.array(data['cs_currency_probability'], dtype=float)
        self.global_probability = float(data['cs_global_probability'])
        self.source_probability = np.array(data['cs_source_probability'], dtype=float)
        self.last_cross_age = float(data['cs_last_cross_age'])
        self.change_events = int(data['cs_change_events'])
        self.above_threshold = bool(int(data['cs_above_threshold'])) if 'cs_above_threshold' in data else self.global_probability >= 0.67
        self.eligible_time = float(data['cs_eligible_time'])
        self.excluded_time = float(data['cs_excluded_time'])
        self.max_probability = float(data['cs_max_probability'])
        self.armed = bool(int(data['cs_armed']))
        self.baseline_ready = bool(int(data['cs_baseline_ready']))


class CausalCalibrationLedger:
    """Online calibration of embodied intervention forecasts.

    Calibration is stored by claim family and bodily currency, then projected
    onto the cells participating in that claim. The only targets are the results
    of the organism's own reversible A/B experiments.
    """

    def __init__(self, enabled=True):
        self.enabled = bool(enabled)
        shape = (CLAIM_TYPE_COUNT, TROPHIC_COUNT)
        self.weight = np.zeros(shape, dtype=float)
        self.mean_effect = np.zeros(shape, dtype=float)
        self.m2_effect = np.zeros(shape, dtype=float)
        self.error_ema = np.full(shape, 0.0015, dtype=float)
        self.raw_error_ema = np.full(shape, 0.0015, dtype=float)
        self.sign_hits = np.zeros(shape, dtype=float)
        self.sign_trials = np.zeros(shape, dtype=float)
        self.cell_trust = np.full((CELL_COUNT, TROPHIC_COUNT), 0.58, dtype=float)
        self.cell_evidence = np.zeros((CELL_COUNT, TROPHIC_COUNT), dtype=float)
        self.updates = 0
        self.sign_flips = 0
        self.last_raw_prediction = 0.0
        self.last_calibrated_prediction = 0.0
        self.last_observed = 0.0
        self.last_raw_error = 0.0
        self.last_calibrated_error = 0.0
        self.last_reliability = 0.5

    def _coverage(self, claim_type, currency):
        w = float(self.weight[int(claim_type), int(currency)])
        return 1.0 - math.exp(-w / 2.2)

    def reliability(self, claim_type, currency):
        t, k = int(claim_type), int(currency)
        coverage = self._coverage(t, k)
        calibrated = float(self.error_ema[t, k])
        raw = float(self.raw_error_ema[t, k])
        relative = raw / max(raw + calibrated, 1e-9)
        sign_accuracy = (
            self.sign_hits[t, k] / max(self.sign_trials[t, k], 1e-9)
            if self.sign_trials[t, k] > 0.0 else 0.5
        )
        return clamp(
            0.28 + 0.38 * coverage + 0.20 * relative + 0.14 * sign_accuracy,
            0.15, 1.0,
        )

    def forecast(self, claim_type, currency, raw_prediction, original_sign=1.0):
        raw = max(1e-7, abs(float(raw_prediction)))
        t, k = int(claim_type), int(currency)
        if not self.enabled:
            return raw, float(original_sign), raw, 0.5
        coverage = self._coverage(t, k)
        empirical = float(self.mean_effect[t, k])
        signed_forecast = (1.0 - coverage) * raw + coverage * empirical
        reliability = self.reliability(t, k)
        sign = float(original_sign)
        # Reversing a claim's sign requires repeated evidence and a margin.
        if coverage > 0.60 and signed_forecast < -max(0.00008, 0.30 * raw):
            sign = -sign
            self.sign_flips += 1
        magnitude = clamp(abs(signed_forecast), 0.00004, 0.030)
        return magnitude, sign, signed_forecast, reliability

    def signature_trust(self, signature, currency):
        signature = np.clip(np.asarray(signature, dtype=float), 0.0, 1.0)
        denom = max(float(np.sum(signature)), 1e-9)
        return float(
            np.sum(signature * self.cell_trust[:, int(currency)]) / denom
        )

    def cell_gate(self):
        coverage = 1.0 - np.exp(-self.cell_evidence / 1.6)
        gate = 1.0 - 0.62 * coverage * (1.0 - self.cell_trust)
        return np.clip(gate, 0.28, 1.0)

    def update(
        self,
        claim_type,
        currency,
        raw_prediction,
        calibrated_prediction,
        observed_original,
        quality,
        signature,
        brain=None,
    ):
        t, k = int(claim_type), int(currency)
        q = clamp(float(quality), 0.03, 1.0)
        raw = float(raw_prediction)
        calibrated = float(calibrated_prediction)
        observed = clamp(float(observed_original), -0.08, 0.08)
        self.last_raw_prediction = raw
        self.last_calibrated_prediction = calibrated
        self.last_observed = observed
        self.last_raw_error = observed - raw
        self.last_calibrated_error = observed - calibrated
        self.last_reliability = self.reliability(t, k)
        if not self.enabled:
            return

        old_w = float(self.weight[t, k])
        new_w = old_w + q
        delta = observed - self.mean_effect[t, k]
        self.mean_effect[t, k] += q * delta / max(new_w, 1e-9)
        delta2 = observed - self.mean_effect[t, k]
        self.m2_effect[t, k] += q * delta * delta2
        self.weight[t, k] = new_w
        alpha = 0.12 * q
        self.error_ema[t, k] += alpha * (
            abs(observed - calibrated) - self.error_ema[t, k]
        )
        self.raw_error_ema[t, k] += alpha * (
            abs(observed - raw) - self.raw_error_ema[t, k]
        )
        sign_ok = (
            abs(observed) < 0.00005
            or abs(calibrated) < 0.00005
            or observed * calibrated > 0.0
        )
        self.sign_trials[t, k] += q
        self.sign_hits[t, k] += q * float(sign_ok)

        sig = np.clip(np.asarray(signature, dtype=float), 0.0, 1.0)
        scale = 0.00025 + abs(observed) + abs(calibrated)
        accuracy = math.exp(-abs(observed - calibrated) / max(scale, 1e-9))
        target_trust = (
            0.58 + 0.42 * accuracy if sign_ok else 0.08 + 0.28 * accuracy
        )
        lr = np.clip(0.22 * q * sig, 0.0, 0.28)
        self.cell_trust[:, k] += lr * (target_trust - self.cell_trust[:, k])
        self.cell_evidence[:, k] += q * sig
        np.clip(self.cell_trust, 0.05, 1.0, out=self.cell_trust)
        np.clip(self.cell_evidence, 0.0, 20.0, out=self.cell_evidence)

        if brain is not None:
            # Correct the causal self-description before destroying the pathway.
            if observed <= 0.0:
                shrink = np.clip(0.30 * q * sig, 0.0, 0.34)
                brain.causal_estimate[:, k] *= 1.0 - shrink
            else:
                target = clamp(observed / 0.020, 0.0, 1.0)
                brain.causal_estimate[:, k] += (
                    0.012 * q * sig * (target - brain.causal_estimate[:, k])
                )
            np.clip(brain.causal_estimate, -2.0, 2.0, out=brain.causal_estimate)
        self.updates += 1

    def diagnostics(self):
        used = self.weight > 0.0
        if np.any(used):
            calibrated_mae = float(np.mean(self.error_ema[used]))
            raw_mae = float(np.mean(self.raw_error_ema[used]))
            sign_accuracy = float(
                np.sum(self.sign_hits[used]) / max(np.sum(self.sign_trials[used]), 1e-9)
            )
        else:
            calibrated_mae = float('nan')
            raw_mae = float('nan')
            sign_accuracy = float('nan')
        return {
            'updates': int(self.updates),
            'calibrated_mae': calibrated_mae,
            'raw_mae': raw_mae,
            'sign_accuracy': sign_accuracy,
            'mean_cell_trust': float(np.mean(self.cell_trust)),
            'last_reliability': float(self.last_reliability),
        }

    def state_dict(self):
        return {
            'cc_enabled': bool_array(self.enabled),
            'cc_weight': self.weight,
            'cc_mean_effect': self.mean_effect,
            'cc_m2_effect': self.m2_effect,
            'cc_error_ema': self.error_ema,
            'cc_raw_error_ema': self.raw_error_ema,
            'cc_sign_hits': self.sign_hits,
            'cc_sign_trials': self.sign_trials,
            'cc_cell_trust': self.cell_trust,
            'cc_cell_evidence': self.cell_evidence,
            'cc_updates': scalar_array(self.updates, np.int64),
            'cc_sign_flips': scalar_array(self.sign_flips, np.int64),
            'cc_last_raw_prediction': scalar_array(self.last_raw_prediction),
            'cc_last_calibrated_prediction': scalar_array(self.last_calibrated_prediction),
            'cc_last_observed': scalar_array(self.last_observed),
            'cc_last_raw_error': scalar_array(self.last_raw_error),
            'cc_last_calibrated_error': scalar_array(self.last_calibrated_error),
            'cc_last_reliability': scalar_array(self.last_reliability),
        }

    def load_state(self, data):
        self.enabled = bool(int(data['cc_enabled']))
        self.weight = np.array(data['cc_weight'], dtype=float)
        self.mean_effect = np.array(data['cc_mean_effect'], dtype=float)
        self.m2_effect = np.array(data['cc_m2_effect'], dtype=float)
        self.error_ema = np.array(data['cc_error_ema'], dtype=float)
        self.raw_error_ema = np.array(data['cc_raw_error_ema'], dtype=float)
        self.sign_hits = np.array(data['cc_sign_hits'], dtype=float)
        self.sign_trials = np.array(data['cc_sign_trials'], dtype=float)
        self.cell_trust = np.array(data['cc_cell_trust'], dtype=float)
        self.cell_evidence = np.array(data['cc_cell_evidence'], dtype=float)
        self.updates = int(data['cc_updates'])
        self.sign_flips = int(data['cc_sign_flips'])
        self.last_raw_prediction = float(data['cc_last_raw_prediction'])
        self.last_calibrated_prediction = float(data['cc_last_calibrated_prediction'])
        self.last_observed = float(data['cc_last_observed'])
        self.last_raw_error = float(data['cc_last_raw_error'])
        self.last_calibrated_error = float(data['cc_last_calibrated_error'])
        self.last_reliability = float(data['cc_last_reliability'])


class AdaptiveTwinFalsificationCompiler(soma41.TwinFalsificationCompiler):
    """SOMA-4 compiler with online causal calibration and gated feedback."""

    def __init__(
        self,
        *args,
        gated_feedback=True,
        calibration_enabled=True,
        **kwargs
    ):
        super().__init__(*args, **kwargs)
        self.gated_feedback = bool(gated_feedback)
        self.calibration_enabled = bool(calibration_enabled)
        self._candidate_meta = {}
        self.active_raw_prediction = 0.0
        self.active_original_sign = 1.0
        self.active_calibrated_signed = 0.0
        self.active_calibration_reliability = 0.5
        self.last_raw_prediction = 0.0
        self.last_calibrated_prediction = 0.0
        self.last_observed_original = 0.0
        self.last_feedback_gate = 1.0
        self.last_change_probability = 0.0
        self.gated_feedback_events = 0
        self.suppressed_feedback_events = 0
        self._cached_calibration_gate = None

    def compile_candidates(self, core, debt, context):
        candidates = super().compile_candidates(core, debt, context)
        self._candidate_meta = {}
        ledger = getattr(core, 'causal_calibrator', None)
        for candidate in candidates:
            claim_type = int(candidate['claim_type'])
            currency = int(candidate['target'])
            raw = max(1e-7, abs(float(candidate['prior_effect'])))
            original_sign = float(candidate.get('expected_sign', 1.0))
            if ledger is not None and self.calibration_enabled:
                magnitude, sign, signed_forecast, reliability = ledger.forecast(
                    claim_type, currency, raw, original_sign
                )
                trust = ledger.signature_trust(candidate['signature'], currency)
            else:
                magnitude, sign, signed_forecast, reliability = raw, original_sign, raw, 0.5
                trust = 0.58
            ratio = clamp(magnitude / max(raw, 1e-7), 0.35, 2.5)
            candidate['prior_effect'] = magnitude
            candidate['expected_sign'] = sign
            candidate['value'] *= (
                (0.58 + 0.58 * reliability)
                * (0.58 + 0.72 * trust)
                * math.sqrt(ratio)
            )
            if sign != original_sign:
                candidate['description'] = 'calibrated inversion: ' + str(candidate['description'])
            key = tuple(int(x) for x in candidate['key'])
            self._candidate_meta[key] = {
                'raw': raw,
                'original_sign': original_sign,
                'signed_forecast': signed_forecast,
                'reliability': reliability,
            }
        return candidates

    def maybe_start(self, core, debt, context, other_busy=False, force=False):
        started = super().maybe_start(
            core, debt, context, other_busy=other_busy, force=force
        )
        if started and self.claim_slot >= 0:
            key = tuple(int(x) for x in self.claim_key[self.claim_slot])
            meta = self._candidate_meta.get(key)
            if meta is None:
                raw = max(1e-7, abs(float(self.last_effect[self.target_currency])))
                meta = {
                    'raw': raw,
                    'original_sign': float(self.expected_sign),
                    'signed_forecast': raw,
                    'reliability': 0.5,
                }
            self.active_raw_prediction = float(meta['raw'])
            self.active_original_sign = float(meta['original_sign'])
            self.active_calibrated_signed = float(meta['signed_forecast'])
            self.active_calibration_reliability = float(meta['reliability'])
        return started

    def _feedback_gate(self, core, currency):
        sentinel = getattr(core, 'change_sentinel', None)
        if sentinel is None:
            change_p = 0.0
        else:
            change_p = max(
                float(sentinel.global_probability),
                float(sentinel.currency_probability[int(currency)]),
            )
        reliability = float(self.active_calibration_reliability)
        if not self.gated_feedback:
            gate = 1.0
        else:
            # Stable worlds retain a small correction floor. Abrupt, well-supported
            # changes open the gate nonlinearly.
            normalized = clamp((change_p - 0.30) / 0.70, 0.0, 1.0)
            change_term = normalized ** 1.15
            gate = (0.075 + 0.925 * change_term) * (0.72 + 0.38 * reliability)
            gate = clamp(gate, 0.055, 1.12)
        self.last_feedback_gate = gate
        self.last_change_probability = change_p
        return gate

    def _perform_gated_feedback(self, core, slot, quality, posterior):
        if not self.feedback_enabled:
            return
        currency = int(self.claim_key[int(slot), 1])
        gate = self._feedback_gate(core, currency)
        if gate < 0.35:
            self.suppressed_feedback_events += 1
        self.gated_feedback_events += 1
        signature = np.asarray(self.claim_signature[int(slot)], dtype=float)
        affected = signature > 0.18
        magnitude = float(quality) * (1.0 - float(posterior)) * gate
        if np.any(affected):
            core.brain.maturity[affected] *= 1.0 - 0.22 * magnitude
            core.brain.prediction_error[affected] = np.clip(
                core.brain.prediction_error[affected] + 0.09 * magnitude,
                0.0, 1.0,
            )
            if hasattr(core, 'reopen_reserve'):
                core.reopen_reserve += 0.70 * magnitude * np.clip(signature, 0.0, 1.0)
                np.clip(core.reopen_reserve, 0.0, 1.4, out=core.reopen_reserve)
            self.reopened_cells += int(np.count_nonzero(affected))
            self.feedback_events += 1

        key = self.claim_key[int(slot)]
        if int(key[0]) in (soma4.CLAIM_ORGAN_MEDIATION, soma4.CLAIM_ORGAN_DOSE):
            kind, organ_slot, modality = int(key[2]), int(key[3]), int(key[4])
            morph = core.morphology
            matches = (
                morph.lease_active
                & (morph.lease_kind == kind)
                & (morph.lease_slot == organ_slot)
                & (morph.lease_modality == modality)
            )
            for index in np.flatnonzero(matches):
                morph.lease_trust[index] *= 1.0 - 0.28 * magnitude
                morph.lease_next_review_age[index] = min(
                    float(morph.lease_next_review_age[index]),
                    float(core.age) + 5.0 + 8.0 * (1.0 - self.last_change_probability),
                )

    def _apply_counterexample_feedback(self, core, slot, quality, posterior):
        # Preserve SOMA-4.1's exact one-event feedback escrow semantics.
        if self.feedback_policy == soma41.FEEDBACK_DEFER_ONCE:
            self.pending_feedback = True
            self.pending_slot = int(slot)
            self.pending_quality = float(quality)
            self.pending_posterior = float(posterior)
            self.pending_age = float(core.age)
            self.feedback_deferred_count += 1
            self.last_status = 'counterexample held in gated feedback escrow'
            return
        if self.feedback_policy == soma41.FEEDBACK_DISCARD:
            self.feedback_discarded_count += 1
            return
        self._perform_gated_feedback(core, slot, quality, posterior)
        self.feedback_applied_count += 1

    def apply_pending(self, core):
        if not self.pending_feedback:
            return False
        slot = int(self.pending_slot)
        quality = float(self.pending_quality)
        posterior = float(self.pending_posterior)
        self.pending_feedback = False
        self.pending_slot = -1
        self._perform_gated_feedback(core, slot, quality, posterior)
        self.feedback_applied_count += 1
        self.last_status = 'escrowed counterexample applied through change gate'
        return True

    def _finish(self, core):
        claim_type = int(self.claim_type)
        currency = int(self.target_currency)
        slot_before = int(self.claim_slot)
        signature = (
            np.asarray(self.claim_signature[slot_before], dtype=float).copy()
            if slot_before >= 0 else np.zeros(CELL_COUNT, dtype=float)
        )
        raw = float(self.active_raw_prediction)
        original_sign = float(self.active_original_sign)
        calibrated_signed = float(self.active_calibrated_signed)
        completed_before = int(self.completed)
        super()._finish(core)
        if int(self.completed) <= completed_before:
            return
        observed_original = original_sign * float(self.last_effect[currency])
        self.last_raw_prediction = raw
        self.last_calibrated_prediction = calibrated_signed
        self.last_observed_original = observed_original
        ledger = getattr(core, 'causal_calibrator', None)
        if ledger is not None:
            ledger.update(
                claim_type=claim_type,
                currency=currency,
                raw_prediction=raw,
                calibrated_prediction=calibrated_signed,
                observed_original=observed_original,
                quality=self.last_quality,
                signature=signature,
                brain=core.brain,
            )

    def cell_gate(self, brain, age, context):
        gate = super().cell_gate(brain, age, context)
        if self._cached_calibration_gate is not None and self.calibration_enabled:
            gate *= self._cached_calibration_gate
        return np.clip(gate, 0.12, 1.0)

    def state_dict(self):
        state = super().state_dict()
        state.update({
            'afc_gated_feedback': bool_array(self.gated_feedback),
            'afc_calibration_enabled': bool_array(self.calibration_enabled),
            'afc_active_raw_prediction': scalar_array(self.active_raw_prediction),
            'afc_active_original_sign': scalar_array(self.active_original_sign),
            'afc_active_calibrated_signed': scalar_array(self.active_calibrated_signed),
            'afc_active_reliability': scalar_array(self.active_calibration_reliability),
            'afc_last_raw_prediction': scalar_array(self.last_raw_prediction),
            'afc_last_calibrated_prediction': scalar_array(self.last_calibrated_prediction),
            'afc_last_observed_original': scalar_array(self.last_observed_original),
            'afc_last_feedback_gate': scalar_array(self.last_feedback_gate),
            'afc_last_change_probability': scalar_array(self.last_change_probability),
            'afc_gated_feedback_events': scalar_array(self.gated_feedback_events, np.int64),
            'afc_suppressed_feedback_events': scalar_array(self.suppressed_feedback_events, np.int64),
        })
        return state

    def load_state(self, data):
        super().load_state(data)
        if 'afc_gated_feedback' not in data:
            return
        self.gated_feedback = bool(int(data['afc_gated_feedback']))
        self.calibration_enabled = bool(int(data['afc_calibration_enabled']))
        self.active_raw_prediction = float(data['afc_active_raw_prediction'])
        self.active_original_sign = float(data['afc_active_original_sign'])
        self.active_calibrated_signed = float(data['afc_active_calibrated_signed'])
        self.active_calibration_reliability = float(data['afc_active_reliability'])
        self.last_raw_prediction = float(data['afc_last_raw_prediction'])
        self.last_calibrated_prediction = float(data['afc_last_calibrated_prediction'])
        self.last_observed_original = float(data['afc_last_observed_original'])
        self.last_feedback_gate = float(data['afc_last_feedback_gate'])
        self.last_change_probability = float(data['afc_last_change_probability'])
        self.gated_feedback_events = int(data['afc_gated_feedback_events'])
        self.suppressed_feedback_events = int(data['afc_suppressed_feedback_events'])
        self._candidate_meta = {}
        self._cached_calibration_gate = None


class SomaFourTwoCore(soma41.CounterfactualSomaCore):
    """SOMA-4.1 organism with endogenous change gating and causal calibration."""

    def __init__(
        self,
        seed=None,
        change_detection_enabled=True,
        gated_feedback=True,
        calibration_enabled=True,
        general_change_reopening=True,
        **kwargs
    ):
        super().__init__(seed=seed, **kwargs)
        old = self.compiler
        self.change_sentinel = ChangeSentinel(enabled=change_detection_enabled)
        self.causal_calibrator = CausalCalibrationLedger(enabled=calibration_enabled)
        self.compiler = AdaptiveTwinFalsificationCompiler(
            seed=self.seed,
            enabled=old.enabled,
            feedback_enabled=old.feedback_enabled,
            safety_enabled=old.safety_enabled,
            allow_composite=old.allow_composite,
            random_selection=old.random_selection,
            minimal_counterexample=old.minimal_counterexample,
            value_threshold=old.value_threshold,
            feedback_policy=old.feedback_policy,
            gated_feedback=gated_feedback,
            calibration_enabled=calibration_enabled,
        )
        self.general_change_reopening = bool(general_change_reopening)
        self.reopen_reserve = np.zeros(CELL_COUNT, dtype=float)
        self.change_reopening_time = 0.0
        self.last_change_feature = np.zeros(FEATURE_COUNT, dtype=float)
        self.last_change_mask = np.zeros(FEATURE_COUNT, dtype=bool)
        self.last_detector_eligible = True
        self.last_structure = self._structure_signature()

    def _prediction_error_by_currency(self):
        profile = np.asarray(self.brain.metabolic_profile, dtype=float)
        weight = np.maximum(profile, 1e-6)
        numerator = np.sum(weight * self.brain.prediction_error[:, None], axis=0)
        return numerator / np.maximum(np.sum(weight, axis=0), 1e-9)

    def _structure_signature(self):
        directions = np.asarray(self.morphology.directions, dtype=float)
        right = directions[:, 0] > 0.15
        if np.any(right):
            organ = 0.55 * float(np.mean(self.morphology.fin[right]))
            organ += 0.45 * float(np.mean(self.morphology.sensor[right, 0:2]))
        else:
            organ = float(np.mean(self.morphology.fin))
        motor = np.asarray(self.brain.motor, dtype=float)
        motor_capacity = 0.55 * float(np.mean(np.linalg.norm(motor, axis=1)))
        motor_capacity += 0.45 * float(np.mean(np.abs(motor[:, 0])))
        return np.array([organ, motor_capacity], dtype=float)

    def _change_feature(
        self,
        debt_before,
        debt_after,
        action,
        source_a_delta,
        source_b_delta,
        dt,
    ):
        feature = np.zeros(FEATURE_COUNT, dtype=float)
        mask = np.ones(FEATURE_COUNT, dtype=bool)
        improvement = np.asarray(debt_before, dtype=float) - np.asarray(debt_after, dtype=float)
        feature[0:4] = np.clip(improvement / max(dt, 1e-9), -0.80, 0.80)
        feature[4:8] = np.clip(self._prediction_error_by_currency(), 0.0, 1.0)

        action = np.asarray(action, dtype=float)
        action_norm2 = float(np.dot(action, action))
        if action_norm2 < 1e-4:
            mask[8:10] = False
        else:
            denom = MAX_SPEED * (action_norm2 + 0.05)
            feature[8] = clamp(float(np.dot(self.vel, action)) / denom, -2.0, 2.0)
            feature[9] = clamp(
                float(action[0] * self.vel[1] - action[1] * self.vel[0]) / denom,
                -2.0, 2.0,
            )

        mask[10:18] = False
        per_contact = np.clip(improvement, -0.45, 0.45)
        if source_a_delta > 0:
            feature[10:14] = per_contact / max(int(source_a_delta), 1)
            mask[10:14] = True
        if source_b_delta > 0:
            feature[14:18] = per_contact / max(int(source_b_delta), 1)
            mask[14:18] = True
        feature[18:20] = self._structure_signature()
        return feature, mask

    def _apply_change_metaplasticity(self, dt):
        self.reopen_reserve *= math.exp(-float(dt) / 16.0)
        if self.general_change_reopening and self.change_sentinel.enabled:
            p = self.change_sentinel.currency_probability
            if float(np.max(p)) > 0.32:
                causal = np.abs(self.brain.causal_estimate)
                denom = np.maximum(np.max(causal, axis=0, keepdims=True), 1e-6)
                relevance = 0.60 * (causal / denom) + 0.40 * self.brain.metabolic_profile
                drive = np.max(relevance * p[None, :], axis=1)
                self.reopen_reserve += (
                    float(dt) * 0.058 * np.maximum(drive - 0.25, 0.0)
                )
                self.change_reopening_time += float(dt)
        np.clip(self.reopen_reserve, 0.0, 1.4, out=self.reopen_reserve)
        self.brain.maturity -= float(dt) * 0.008 * self.reopen_reserve
        self.brain.prediction_error += float(dt) * 0.014 * self.reopen_reserve
        np.clip(self.brain.maturity, 0.0, 1.0, out=self.brain.maturity)
        np.clip(self.brain.prediction_error, 0.0, 1.0, out=self.brain.prediction_error)

    def step(self, dt=1.0 / 30.0):
        dt = clamp(float(dt), 1.0 / 240.0, 0.10)
        if not self.alive:
            return
        debt_before = self.body_debt().copy()
        source_a_before = int(self.source_a_contacts)
        source_b_before = int(self.source_b_contacts)
        busy_before = bool(
            self.compiler.busy or self.auditor.busy
            or self.morphology.busy or self.questioner.busy
        )
        self.compiler._cached_calibration_gate = self.causal_calibrator.cell_gate()
        super().step(dt)
        debt_after = self.body_debt().copy()
        busy_after = bool(
            self.compiler.busy or self.auditor.busy
            or self.morphology.busy or self.questioner.busy
        )
        feature, mask = self._change_feature(
            debt_before=debt_before,
            debt_after=debt_after,
            action=self.last_action,
            source_a_delta=int(self.source_a_contacts) - source_a_before,
            source_b_delta=int(self.source_b_contacts) - source_b_before,
            dt=dt,
        )
        eligible = not (busy_before or busy_after)
        self.last_change_feature = feature.copy()
        self.last_change_mask = mask.copy()
        self.last_detector_eligible = bool(eligible)
        self.change_sentinel.observe(feature, mask, dt, self.age, eligible=eligible)
        self._apply_change_metaplasticity(dt)
        self.last_structure = feature[18:20].copy()

    def apply_instrumented_contradiction(
        self,
        currency=None,
        quality=0.82,
        posterior=0.16,
        claim_type=soma4.CLAIM_NEURAL_MEDIATION,
    ):
        """Apply an inspectable contradiction for paired mechanism tests."""
        if currency is None:
            currency = int(np.argmax(self.change_sentinel.currency_probability))
        verified = self.compiler._verified_matrix(self)
        mask, signature, direction, _ = self.compiler._coalition_for_currency(
            self, int(currency), verified
        )
        key = (int(claim_type), int(currency), int(direction), 0, 0)
        slot = self.compiler._allocate_slot(key, signature, self.age)
        self.compiler.claim_alpha[slot] = 1.2
        self.compiler.claim_beta[slot] = 5.8
        self.compiler.claim_trials[slot] = max(1, int(self.compiler.claim_trials[slot]))
        self.compiler.claim_signature[slot] = signature
        self.compiler.active_calibration_reliability = self.causal_calibrator.reliability(
            int(claim_type), int(currency)
        )
        self.compiler._apply_counterexample_feedback(
            self, slot, float(quality), float(posterior)
        )
        self.compiler.last_status = 'instrumented contradiction applied'
        return {
            'slot': int(slot),
            'currency': int(currency),
            'cells': int(np.count_nonzero(mask)),
            'gate': float(self.compiler.last_feedback_gate),
            'change_probability': float(self.compiler.last_change_probability),
        }

    def diagnostics42(self):
        change = self.change_sentinel.diagnostics()
        calibration = self.causal_calibrator.diagnostics()
        return {
            'change_probability': change['global_probability'],
            'change_currency': change['currency_probability'],
            'change_source': change['dominant_source'],
            'change_events': change['events'],
            'detector_armed': change['armed'],
            'calibration_updates': calibration['updates'],
            'calibrated_mae': calibration['calibrated_mae'],
            'raw_mae': calibration['raw_mae'],
            'calibration_sign_accuracy': calibration['sign_accuracy'],
            'cell_trust': calibration['mean_cell_trust'],
            'feedback_gate': float(self.compiler.last_feedback_gate),
            'reopen_reserve': float(np.mean(self.reopen_reserve)),
        }

    def state_dict(self):
        state = super().state_dict()
        state['save_version'] = scalar_array(SAVE_VERSION, np.int64)
        state.update(self.change_sentinel.state_dict())
        state.update(self.causal_calibrator.state_dict())
        state.update({
            'soma42_general_reopening': bool_array(self.general_change_reopening),
            'soma42_reopen_reserve': self.reopen_reserve,
            'soma42_change_reopening_time': scalar_array(self.change_reopening_time),
            'soma42_last_change_feature': self.last_change_feature,
            'soma42_last_change_mask': self.last_change_mask.astype(np.uint8),
            'soma42_last_detector_eligible': bool_array(self.last_detector_eligible),
            'soma42_last_structure': self.last_structure,
        })
        return state

    def load_state(self, data):
        version = int(data['save_version'])
        if version not in (soma41.CORE_SAVE_VERSION, SAVE_VERSION):
            raise ValueError('unsupported SOMA-4.2 save version')
        keys = list(data.files) if hasattr(data, 'files') else list(data.keys())
        base = {key: data[key] for key in keys}
        base['save_version'] = scalar_array(soma41.CORE_SAVE_VERSION, np.int64)
        super().load_state(base)
        if version == soma41.CORE_SAVE_VERSION or 'cs_enabled' not in data:
            return
        self.change_sentinel.load_state(data)
        self.causal_calibrator.load_state(data)
        self.general_change_reopening = bool(int(data['soma42_general_reopening']))
        self.reopen_reserve = np.array(data['soma42_reopen_reserve'], dtype=float)
        self.change_reopening_time = float(data['soma42_change_reopening_time'])
        self.last_change_feature = np.array(data['soma42_last_change_feature'], dtype=float)
        self.last_change_mask = np.array(data['soma42_last_change_mask'], dtype=bool)
        self.last_detector_eligible = bool(int(data['soma42_last_detector_eligible']))
        self.last_structure = np.array(data['soma42_last_structure'], dtype=float)


def clone_core(core, **overrides):
    cloned = SomaFourTwoCore(seed=core.seed)
    cloned.load_state(_copy_state(core.state_dict()))
    for name, value in overrides.items():
        setattr(cloned, name, value)
    return cloned


def run_headless_trial(
    seed=101,
    seconds=180.0,
    regime=soma41.REGIME_STABLE,
    regime_switch_age=45.0,
    change_detection_enabled=True,
    gated_feedback=True,
    calibration_enabled=True,
    general_change_reopening=True,
    dt=1.0 / 30.0,
    **kwargs
):
    core = SomaFourTwoCore(
        seed=seed,
        regime=regime,
        regime_switch_age=regime_switch_age,
        change_detection_enabled=change_detection_enabled,
        gated_feedback=gated_feedback,
        calibration_enabled=calibration_enabled,
        general_change_reopening=general_change_reopening,
        **kwargs
    )
    debt_integral = np.zeros(TROPHIC_COUNT, dtype=float)
    detector_cross = -1.0
    pre_shift_max = 0.0
    for _ in range(int(float(seconds) / dt)):
        if not core.alive:
            break
        before = core.body_debt().copy()
        core.step(dt)
        after = core.body_debt().copy()
        debt_integral += dt * 0.5 * (before + after)
        if core.age < regime_switch_age:
            pre_shift_max = max(pre_shift_max, core.change_sentinel.global_probability)
        elif detector_cross < 0.0 and core.change_sentinel.global_probability >= 0.67:
            detector_cross = core.age - regime_switch_age
    elapsed = max(core.age, 1e-9)
    d = core.diagnostics42()
    return {
        'seed': int(seed),
        'regime': soma41.REGIME_NAMES[int(soma41.regime_code(regime))],
        'age': float(core.age),
        'alive': int(core.alive),
        'health': 1.0 - float(np.mean(debt_integral / elapsed)),
        'food': int(core.eaten),
        'toxin': int(core.poisoned),
        'change_probability': float(d['change_probability']),
        'change_events': int(d['change_events']),
        'detector_delay': float(detector_cross),
        'pre_shift_max_probability': float(pre_shift_max),
        'calibration_updates': int(d['calibration_updates']),
        'calibrated_mae': float(d['calibrated_mae']),
        'raw_mae': float(d['raw_mae']),
        'calibration_sign_accuracy': float(d['calibration_sign_accuracy']),
        'mean_cell_trust': float(d['cell_trust']),
        'last_feedback_gate': float(d['feedback_gate']),
        'mean_reopen_reserve': float(d['reopen_reserve']),
        'energy_debt_integral': float(debt_integral[0]),
        'thermal_debt_integral': float(debt_integral[1]),
        'integrity_debt_integral': float(debt_integral[2]),
        'fatigue_debt_integral': float(debt_integral[3]),
    }


if soma2.IN_PYTHONISTA:
    class SomaFourTwoScene(soma4.SomaFourScene):
        def setup(self):
            self._building_42 = True
            super().setup()
            self._building_42 = False
            self.core = SomaFourTwoCore()
            self.help_label.text = (
                'tap: relocate nutrient   SOMA-4.2 change gate + causal calibration'
            )
            self._load_life_if_possible()
            self._sync_nodes(force_tiles=True)

        def _save_life(self):
            if getattr(self, '_building_42', False):
                return
            try:
                np.savez(SAVE_FILE, **self.core.state_dict())
            except Exception as exc:
                print('SOMA-4.2 save failed:', exc)

        def _load_life_if_possible(self):
            if getattr(self, '_building_42', False) or not os.path.exists(SAVE_FILE):
                return
            try:
                with np.load(SAVE_FILE, allow_pickle=False) as data:
                    self.core.load_state(data)
            except Exception as exc:
                print('SOMA-4.2 load ignored:', exc)

        def _sync_nodes(self, force_tiles=False):
            super()._sync_nodes(force_tiles=force_tiles)
            if getattr(self, '_building_42', False):
                return
            d = self.core.diagnostics42()
            p = d['change_currency']
            cal = self.core.causal_calibrator
            self.info_label.text += (
                '\nCHANGE p {:.2f}  E/T/I/F {:.2f}/{:.2f}/{:.2f}/{:.2f}  {}  events {}\n'
                'GATE {:.2f} reserve {:.3f}  CAL n {} trust {:.2f}\n'
                'raw→cal→obs {:+.4f} → {:+.4f} → {:+.4f}'
            ).format(
                d['change_probability'], p[0], p[1], p[2], p[3],
                d['change_source'], d['change_events'], d['feedback_gate'],
                d['reopen_reserve'], d['calibration_updates'], d['cell_trust'],
                cal.last_raw_prediction, cal.last_calibrated_prediction,
                cal.last_observed,
            )


if __name__ == '__main__':
    if soma2.IN_PYTHONISTA:
        from scene import run, LANDSCAPE
        run(SomaFourTwoScene(), orientation=LANDSCAPE, show_fps=False)
    else:
        print(run_headless_trial(seed=101, seconds=90.0))
