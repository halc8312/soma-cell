# coding: utf-8
"""Generate the SOMA-CELL 0.3 long-run TXT and session CSV from the log."""
from SOMA_CELL_0_3_pythonista import generate_report


if __name__ == '__main__':
    print(generate_report())
