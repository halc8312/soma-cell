# coding: utf-8
"""SOMA-CELL 0.2 deterministic mechanism validation.

This script tests material heredity, mutation operators, internally maintained
replication, physical division, causal novelty in the accelerated assay, and
save/restore determinism.  It writes a machine-readable CSV and a concise TXT
report beside this file.
"""
from __future__ import division

import csv
import difflib
import math
import os
import pickle
import tempfile

import numpy as np

import SOMA_CELL_0_2_pythonista as soma

BASE_DIR = os.path.dirname(__file__)
CSV_PATH = os.path.join(BASE_DIR, 'soma_cell_0_2_validation.csv')
TXT_PATH = os.path.join(BASE_DIR, 'SOMA_CELL_0_2_VALIDATION_RESULTS.txt')


def _fmt(value):
    if isinstance(value, float):
        return '{:.12g}'.format(value)
    return str(value)


def _sequence_similarity(a, b):
    return difflib.SequenceMatcher(None, list(map(int, a)), list(map(int, b))).ratio()


def _state_equal(a, b):
    if isinstance(a, np.ndarray) or isinstance(b, np.ndarray):
        try:
            return np.array_equal(np.asarray(a), np.asarray(b))
        except Exception:
            return False
    if isinstance(a, dict) and isinstance(b, dict):
        if set(a) != set(b):
            return False
        return all(_state_equal(a[key], b[key]) for key in a)
    if isinstance(a, (list, tuple)) and isinstance(b, (list, tuple)):
        return len(a) == len(b) and all(_state_equal(x, y) for x, y in zip(a, b))
    if isinstance(a, (float, np.floating)) or isinstance(b, (float, np.floating)):
        return bool(float(a) == float(b))
    return a == b


def _remove_role(cell, role):
    for fingerprint in list(cell.proteins):
        spec = cell.gene_specs.get(fingerprint)
        if spec is not None and spec['role'] == role:
            del cell.proteins[fingerprint]
    cell._sync_protein_pool()


def _record(rows, name, passed, observed, criterion):
    rows.append({
        'test': name,
        'pass': 'PASS' if passed else 'FAIL',
        'observed': _fmt(observed),
        'criterion': criterion,
    })


def run_validation():
    rows = []

    founder = soma.founding_genome()
    founder_genes = soma.parse_genes(founder)
    _record(
        rows,
        'founder_has_no_novel_path',
        len(founder) == 128 and len(founder_genes) == 8 and not soma.sequence_has_novel_path(founder),
        'length={}, genes={}, novel={}'.format(
            len(founder), len(founder_genes), soma.sequence_has_novel_path(founder)
        ),
        '128 symbols, 8 genes, and no complete alt-substrate pathway',
    )

    # Genome polymer contributes explicit matter.
    rng = np.random.default_rng(11)
    cell = soma.GeneticProtoCell(0, rng, bootstrap=True)
    before = cell.material_mass()
    cell.genomes.append(founder.copy())
    cell._refresh_gene_cache()
    after = cell.material_mass()
    expected = len(founder) * soma.MONOMER_MASS
    delta = after - before
    _record(
        rows,
        'genome_polymer_is_in_material_ledger',
        abs(delta - expected) < 1e-12,
        'delta={:.12g}, expected={:.12g}'.format(delta, expected),
        'adding one genome raises material mass by exactly length × monomer mass',
    )

    # The mutator must be capable of every declared operation while respecting bounds.
    mutation_rng = np.random.default_rng(12345)
    mutation_config = soma.GeneticConfig(
        mutation=True,
        variable_length=True,
        gene_duplication=True,
        mutation_rate=0.05,
        structural_rate=1.0,
    )
    totals = {
        'substitution': 0,
        'insertion': 0,
        'deletion': 0,
        'duplication': 0,
        'inversion': 0,
        'transposition': 0,
    }
    lengths_ok = True
    for _ in range(300):
        mutated, _, events = soma.mutate_sequence(
            founder, mutation_rng, mutation_config, nucleotide_budget=soma.MAX_GENOME_LENGTH
        )
        lengths_ok = lengths_ok and soma.MIN_GENOME_LENGTH <= len(mutated) <= soma.MAX_GENOME_LENGTH
        for key in totals:
            totals[key] += int(events[key])
    all_ops = lengths_ok and all(value > 0 for value in totals.values())
    _record(
        rows,
        'all_six_mutation_operations_are_reachable',
        all_ops,
        json_like(totals),
        'substitution, insertion, deletion, duplication, inversion, and transposition all occur',
    )

    # Replication should stop without internally present replicase, and restart only
    # under the explicit external-assistance ablation.
    def replication_probe(external):
        cfg = soma.GeneticConfig(
            gene_expression=False,
            genome_replication=True,
            mutation=False,
            variable_length=False,
            gene_duplication=False,
            environmental_damage=False,
            external_replicase=external,
        )
        world = soma.GeneticWorld(seed=31, initial_cells=1, config=cfg)
        probe = world.cells[0]
        _remove_role(probe, soma.ROLE_REPLICASE)
        probe.pools[soma.POOL_ATP] = 1.25
        probe.pools[soma.POOL_NUCLEOTIDE] = 0.80
        for _ in range(2600):
            probe._replicate_genome(world, 0.05, cfg)
            if len(probe.genomes) >= 2:
                break
        return len(probe.genomes)

    internal_absent_copies = replication_probe(False)
    external_assisted_copies = replication_probe(True)
    _record(
        rows,
        'genome_copying_requires_replicase_activity',
        internal_absent_copies == 1 and external_assisted_copies >= 2,
        'without={}, explicit_external_ablation={}'.format(
            internal_absent_copies, external_assisted_copies
        ),
        'no copy without replicase; explicit external-assistance ablation can rescue copying',
    )

    # Physical material world: one lineage must copy information and split without
    # external protein assistance.  Track the largest ledger error over the run.
    physical = soma.GeneticWorld(seed=303, initial_cells=1)
    dt = 1.0 / soma.SIM_HZ
    max_abs_ledger = 0.0
    first_division_age = None
    for _ in range(int(330 * soma.SIM_HZ)):
        physical.step(dt)
        max_abs_ledger = max(max_abs_ledger, abs(physical.matter_ledger_residual()))
        if physical.divisions and first_division_age is None:
            first_division_age = physical.age
            break
    alive = physical.living_cells()
    partition_ok = (
        physical.divisions >= 1
        and len(alive) == 2
        and all(cell.generation == 1 and len(cell.genomes) >= 1 for cell in alive)
        and abs(physical.division_residual) < 1e-10
        and physical.external_protein_assistance == 0.0
    )
    _record(
        rows,
        'material_information_loop_reaches_physical_division',
        partition_ok,
        'age={}, cells={}, G={}, genome_copies={}, division_residual={:.3e}'.format(
            _fmt(first_division_age), len(alive),
            max([cell.generation for cell in alive]) if alive else -1,
            sum(len(cell.genomes) for cell in alive), physical.division_residual,
        ),
        'one parent becomes two G1 daughters, each with a genome, without external protein assistance',
    )

    similarities = []
    for daughter in alive:
        similarities.append(max(_sequence_similarity(founder, genome) for genome in daughter.genomes))
    min_similarity = min(similarities) if similarities else 0.0
    _record(
        rows,
        'daughter_genomes_retain_parental_sequence_information',
        min_similarity > 0.85,
        'daughter best similarities={}'.format(','.join('{:.4f}'.format(x) for x in similarities)),
        'each daughter receives at least one sequence strongly correlated with the founder',
    )

    _record(
        rows,
        'physical_run_is_finite_and_material_residual_is_small',
        physical.finite() and max_abs_ledger < 1e-4,
        'finite={}, max_abs_ledger={:.3e}'.format(physical.finite(), max_abs_ledger),
        'all numerical states finite and max absolute material residual < 1e-4',
    )

    # Disabling genome copying must block physical division over the same horizon.
    no_rep = soma.GeneticWorld(
        seed=101,
        initial_cells=1,
        config=soma.GeneticConfig(genome_replication=False),
    )
    for _ in range(int(320 * soma.SIM_HZ)):
        no_rep.step(dt)
    no_rep_summary = no_rep.summary()
    _record(
        rows,
        'genome_replication_ablation_blocks_division',
        no_rep_summary['divisions'] == 0 and no_rep_summary['genome_copies'] == 1,
        'divisions={}, genome_copies={}'.format(
            no_rep_summary['divisions'], no_rep_summary['genome_copies']
        ),
        'no physical division and only the founding genome remains after 320 s',
    )

    # Removing protein composition at fission should not break matter accounting;
    # it does, however, remove the short-term catalytic bootstrap and causes collapse.
    no_comp = soma.GeneticWorld(
        seed=101,
        initial_cells=1,
        config=soma.GeneticConfig(composition_inheritance=False),
    )
    for _ in range(int(360 * soma.SIM_HZ)):
        no_comp.step(dt)
    no_comp_summary = no_comp.summary()
    _record(
        rows,
        'composition_inheritance_ablation_preserves_matter_but_loses_lineage',
        (
            no_comp_summary['divisions'] >= 1
            and no_comp_summary['cells'] == 0
            and abs(no_comp_summary['matter_residual']) < 1e-4
        ),
        'divisions={}, cells={}, deaths={}, residual={:.3e}'.format(
            no_comp_summary['divisions'], no_comp_summary['cells'],
            no_comp_summary['deaths'], no_comp_summary['matter_residual'],
        ),
        'protein matter is hydrolysed rather than deleted; daughters then collapse without compositional bootstrap',
    )

    # Accelerated selection assay.  This is deliberately separate from the full
    # material world and tests causal novelty using the same genome grammar/mutator.
    no_mut = soma.run_evolution_assay(
        seed=404, generations=80, population=96,
        mutation=False, variable_length=True, duplication=True,
    )
    _record(
        rows,
        'no_mutation_control_cannot_create_the_missing_path',
        (
            no_mut['first_novel_generation'] is None
            and no_mut['final_novel_frequency'] == 0.0
            and abs(no_mut['final_mean_fitness'] - no_mut['initial_mean_fitness']) < 1e-12
        ),
        'first={}, frequency={:.3f}, fitness_delta={:.3e}'.format(
            no_mut['first_novel_generation'], no_mut['final_novel_frequency'],
            no_mut['final_mean_fitness'] - no_mut['initial_mean_fitness'],
        ),
        'without copying errors, the absent reaction edge and fitness gain do not appear',
    )

    evolved = soma.run_evolution_assay(
        seed=404, generations=80, population=96,
        mutation=True, variable_length=True, duplication=True,
    )
    _record(
        rows,
        'new_reaction_path_can_arise_and_spread_under_selection',
        (
            evolved['first_novel_generation'] is not None
            and evolved['final_novel_frequency'] > 0.50
            and evolved['best_fitness'] > evolved['initial_mean_fitness'] + 0.50
        ),
        'first_G={}, final_frequency={:.3f}, initial={:.3f}, best={:.3f}'.format(
            evolved['first_novel_generation'], evolved['final_novel_frequency'],
            evolved['initial_mean_fitness'], evolved['best_fitness'],
        ),
        'the initially absent complete pathway appears, becomes common, and raises assay fitness',
    )

    knockout_drop = evolved['best_fitness'] - evolved['knockout_fitness']
    _record(
        rows,
        'knockout_of_evolved_edge_removes_its_advantage',
        knockout_drop > 0.50,
        'best={:.3f}, knockout={:.3f}, drop={:.3f}'.format(
            evolved['best_fitness'], evolved['knockout_fitness'], knockout_drop
        ),
        'changing only the evolved intermediate→waste edge reduces fitness by > 0.5',
    )

    # Save/load should preserve the exact future, including RNG and partially copied DNA.
    original = soma.GeneticWorld(seed=707, initial_cells=1)
    for _ in range(900):
        original.step(dt)
    with tempfile.TemporaryDirectory() as temporary:
        path = os.path.join(temporary, 'state.pkl')
        original.save(path)
        restored = soma.GeneticWorld.load(path)
        for _ in range(240):
            original.step(dt)
            restored.step(dt)
        equal = _state_equal(original.state_dict(), restored.state_dict())
    _record(
        rows,
        'save_restore_continues_bit_exact_future',
        equal,
        'state_equal={}'.format(equal),
        'after file save/load, 240 further steps produce exactly equal complete states',
    )

    passed = sum(row['pass'] == 'PASS' for row in rows)
    with open(CSV_PATH, 'w', newline='', encoding='utf-8') as handle:
        writer = csv.DictWriter(handle, fieldnames=('test', 'pass', 'observed', 'criterion'))
        writer.writeheader()
        writer.writerows(rows)

    lines = [
        'SOMA-CELL 0.2 VALIDATION',
        'build: {}'.format(soma.BUILD),
        'result: {}/{} PASS'.format(passed, len(rows)),
        '',
    ]
    for row in rows:
        lines.append('[{}] {}'.format(row['pass'], row['test']))
        lines.append('  observed: {}'.format(row['observed']))
        lines.append('  criterion: {}'.format(row['criterion']))
    with open(TXT_PATH, 'w', encoding='utf-8') as handle:
        handle.write('\n'.join(lines) + '\n')

    return rows


def json_like(mapping):
    return '{' + ', '.join('{}:{}'.format(key, mapping[key]) for key in sorted(mapping)) + '}'


if __name__ == '__main__':
    validation_rows = run_validation()
    pass_count = sum(row['pass'] == 'PASS' for row in validation_rows)
    print('{}/{} PASS'.format(pass_count, len(validation_rows)))
    for row in validation_rows:
        print(row['pass'], row['test'], '-', row['observed'])
