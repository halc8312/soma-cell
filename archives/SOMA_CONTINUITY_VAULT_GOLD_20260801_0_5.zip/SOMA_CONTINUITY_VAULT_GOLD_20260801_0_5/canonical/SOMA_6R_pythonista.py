# coding: utf-8
"""
SOMA-6R — Shared Embodied Culture / 共有世界・文化検証版

Pythonista 3 / CPython + NumPy.  Requires SOMA_1 ... SOMA_4_2 and
SOMA_5R_pythonista.py in the same folder.

Unlike the SOMA-6 alpha, every organism in this module occupies the same
physical world, competes for the same biomass, senses nearby conspecifics, and
pays for communication.  Cultural packets are not copied directly into the
brain.  They are stored as hypotheses and influence action only after the
receiver's own embodied observations support them.
"""

from __future__ import division

import math
import os
import pickle
import time

import numpy as np

import SOMA_1_pythonista as soma1
import SOMA_2_pythonista as soma2
import SOMA_5R_pythonista as soma5r

from SOMA_1_pythonista import (
    BODY_RADIUS,
    CELL_COUNT,
    MAX_SPEED,
    TROPHIC_COUNT,
    clamp,
    wrapped_delta,
)


BUILD = 'SOMA-6R 1.0.0'
SAVE_VERSION = 1
SAVE_FILE = os.path.join(os.path.dirname(__file__), 'soma6r_colony.pkl')
SIM_HZ = 15.0

NUTRIENT_PATCHES = 12
TOXIN_PATCHES = 7
REFUGE_PATCHES = 4
HYPOTHESIS_CAPACITY = 12

NUTRIENT_RADIUS = 0.042
TOXIN_RADIUS = 0.032
REFUGE_RADIUS = 0.095
COMMUNICATION_BASE_RANGE = 0.24


def _norm(value):
    return float(np.linalg.norm(np.asarray(value, dtype=float)))


def _torus_distance(a, b):
    return _norm(wrapped_delta(a, b))


def _field_components(position, sources, weights, scale):
    sources = np.asarray(sources, dtype=float)
    if sources.size == 0:
        return np.zeros(2, dtype=float), 0.0
    weights = np.asarray(weights, dtype=float)
    deltas = sources - np.asarray(position, dtype=float)[None, :]
    deltas = (deltas + 0.5) % 1.0 - 0.5
    distances = np.linalg.norm(deltas, axis=1)
    concentration = np.exp(-distances / max(float(scale), 1e-6)) * weights
    total = float(np.sum(concentration))
    if total <= 1e-12:
        gradient = np.zeros(2, dtype=float)
    else:
        gradient = np.sum(
            deltas / (distances[:, None] + 0.03) * concentration[:, None],
            axis=0,
        ) / total
    density = 1.0 - math.exp(-0.65 * total)
    return np.clip(gradient, -1.0, 1.0), clamp(density, 0.0, 1.0)


class SharedWorld6R(object):
    """One toroidal world shared by every colony member."""

    def __init__(self, seed=101):
        self.seed = int(seed)
        self.rng = np.random.default_rng(self.seed + 6101)
        self.age = 0.0
        self.nutrient_positions = self.rng.random((NUTRIENT_PATCHES, 2))
        self.nutrient_capacity = self.rng.uniform(
            0.65, 1.0, NUTRIENT_PATCHES
        )
        self.nutrient_biomass = self.nutrient_capacity * self.rng.uniform(
            0.55, 0.95, NUTRIENT_PATCHES
        )
        self.toxin_positions = self.rng.random((TOXIN_PATCHES, 2))
        self.toxin_strength = self.rng.uniform(0.55, 1.0, TOXIN_PATCHES)
        self.refuge_positions = self.rng.random((REFUGE_PATCHES, 2))
        self.agents = []
        self.external_growth = 0.0
        self.consumed_biomass = 0.0
        self.energy_assimilated = 0.0
        self.reproductive_parent_energy = 0.0
        self.offspring_initial_energy = 0.0
        self.reproductive_dissipation = 0.0
        self.last_climate = 0.50

    def step(self, dt):
        dt = float(dt)
        self.age += dt
        climate = 0.50 + 0.16 * math.sin(self.age / 41.0)
        self.last_climate = climate
        climate_factor = 0.72 + 0.28 * math.cos((climate - 0.5) * math.pi)
        growth = (
            0.020
            * climate_factor
            * self.nutrient_biomass
            * (1.0 - self.nutrient_biomass / self.nutrient_capacity)
            * dt
        )
        self.nutrient_biomass += growth
        np.minimum(
            self.nutrient_biomass,
            self.nutrient_capacity,
            out=self.nutrient_biomass,
        )
        self.external_growth += float(np.sum(growth))

    def nutrient_field(self, position):
        weights = self.nutrient_biomass / np.maximum(
            self.nutrient_capacity, 1e-9
        )
        return _field_components(
            position, self.nutrient_positions, weights, 0.18
        )

    def toxin_field(self, position):
        return _field_components(
            position, self.toxin_positions, self.toxin_strength, 0.15
        )

    def social_field(self, observer):
        positions = []
        weights = []
        for agent in self.agents:
            if agent is observer or not agent.alive:
                continue
            positions.append(agent.pos)
            health = 1.0 - float(np.mean(agent.body_debt()))
            weights.append(0.25 + 0.75 * clamp(health, 0.0, 1.0))
        if not positions:
            return np.zeros(2, dtype=float), 0.0
        return _field_components(
            observer.pos, np.asarray(positions), np.asarray(weights), 0.20
        )

    def temperature_field(self, position, at_time=None):
        if at_time is None:
            at_time = self.age
        x, y = map(float, np.asarray(position, dtype=float))
        phase = 0.05 * math.sin(float(at_time) * 0.013)
        ax = 2.0 * math.pi * (x + phase)
        by = 2.0 * math.pi * (y - 0.62 * phase)
        value = (
            0.50
            + 0.22 * math.sin(ax)
            + 0.12 * math.cos(by)
            + 0.05 * math.sin(ax + by)
        )
        value = clamp(value, 0.05, 0.95)
        gx = (
            0.22 * 2.0 * math.pi * math.cos(ax)
            + 0.05 * 2.0 * math.pi * math.cos(ax + by)
        ) / 2.1
        gy = (
            -0.12 * 2.0 * math.pi * math.sin(by)
            + 0.05 * 2.0 * math.pi * math.cos(ax + by)
        ) / 2.1
        return value, np.clip(np.array([gx, gy]), -1.0, 1.0)

    def refuge_level(self, position):
        level = 0.0
        for refuge in self.refuge_positions:
            distance = _torus_distance(position, refuge)
            level = max(level, math.exp(-((distance / REFUGE_RADIUS) ** 2)))
        return clamp(level, 0.0, 1.0)

    def consume(self, agent, dt, uptake_scale=1.0):
        deltas = self.nutrient_positions - np.asarray(agent.pos)[None, :]
        deltas = (deltas + 0.5) % 1.0 - 0.5
        distances = np.linalg.norm(deltas, axis=1)
        candidates = np.flatnonzero(distances < NUTRIENT_RADIUS + BODY_RADIUS)
        if candidates.size == 0:
            return 0.0, 0.0
        index = int(candidates[np.argmax(self.nutrient_biomass[candidates])])
        take = min(
            float(self.nutrient_biomass[index]),
            float(dt) * 0.070 * clamp(float(uptake_scale), 0.4, 1.8),
        )
        self.nutrient_biomass[index] -= take
        gain = 0.76 * take
        self.consumed_biomass += take
        self.energy_assimilated += gain
        return gain, take

    def toxin_exposure(self, agent):
        exposure = 0.0
        for position, strength in zip(
            self.toxin_positions, self.toxin_strength
        ):
            distance = _torus_distance(agent.pos, position)
            if distance < TOXIN_RADIUS + BODY_RADIUS:
                exposure += float(strength) * (
                    1.0 - distance / (TOXIN_RADIUS + BODY_RADIUS)
                )
        return clamp(exposure, 0.0, 1.5)

    def repulsion(self, observer):
        vector = np.zeros(2, dtype=float)
        for agent in self.agents:
            if agent is observer or not agent.alive:
                continue
            delta = wrapped_delta(agent.pos, observer.pos)
            distance = _norm(delta)
            if 1e-6 < distance < 0.045:
                vector += delta / distance * (0.045 - distance) / 0.045
        return np.clip(vector, -1.0, 1.0)

    def nearest_neighbor_distance(self, observer):
        distances = [
            _torus_distance(observer.pos, agent.pos)
            for agent in self.agents
            if agent is not observer and agent.alive
        ]
        return min(distances) if distances else 1.0


class SharedLatentCodec6R(soma5r.LatentCodec):
    def world_channels(self, core):
        world = core.world
        a_grad, a_density = world.nutrient_field(core.pos)
        b_grad, b_density = world.toxin_field(core.pos)
        c_grad, c_density = world.social_field(core)
        ambient, t_grad = world.temperature_field(core.pos)
        return np.array([
            a_grad[0], a_grad[1], a_density * 2.0 - 1.0,
            b_grad[0], b_grad[1], b_density * 2.0 - 1.0,
            c_grad[0], c_grad[1], c_density * 2.0 - 1.0,
            ambient * 2.0 - 1.0, t_grad[0], t_grad[1],
        ], dtype=float)


class GroundedCulturalPacket(object):
    def __init__(
        self,
        sender_id,
        context,
        action,
        effect,
        uncertainty,
        confidence,
        created_age,
    ):
        self.sender_id = int(sender_id)
        self.context = np.asarray(context, dtype=float).copy()
        self.action = np.asarray(action, dtype=float).copy()
        self.effect = np.asarray(effect, dtype=float).copy()
        self.uncertainty = np.asarray(uncertainty, dtype=float).copy()
        self.confidence = float(confidence)
        self.created_age = float(created_age)


class SomaSixRAgent(soma5r.SomaFiveRCore):
    """SOMA-5R agent grounded in one shared world."""

    def __init__(
        self,
        seed=None,
        world=None,
        agent_id=0,
        parent_id=-1,
        generation=0,
        lineage=0,
        heritage=None,
        communication_enabled=True,
        full_brain=False,
        **kwargs
    ):
        # Set the shared world before the base constructor.  SOMA-5R
        # encodes an initial latent state during construction; dynamic dispatch
        # can therefore reach our shared-world temperature/shelter overrides.
        self.world = world
        kwargs.setdefault('lightweight', not bool(full_brain))
        kwargs.setdefault('planning_interval', 0.55)
        kwargs.setdefault('max_rollout_depth', 5)
        super().__init__(seed=seed, **kwargs)
        self.latent_codec = SharedLatentCodec6R()
        self.agent_id = int(agent_id)
        self.parent_id = int(parent_id)
        self.generation = int(generation)
        self.lineage = int(lineage)
        self.communication_enabled = bool(communication_enabled)
        self.social_sent = 0
        self.social_received = 0
        self.social_verified = 0
        self.social_rejected = 0
        self.social_assimilated = 0
        self.communication_energy = 0.0
        self.food_event_accumulator = 0.0
        self.toxin_event_cooldown = 0.0
        self.births = 0

        self.trust_alpha = {}
        self.trust_beta = {}
        self.hyp_active = np.zeros(HYPOTHESIS_CAPACITY, dtype=bool)
        self.hyp_sender = np.full(HYPOTHESIS_CAPACITY, -1, dtype=np.int64)
        self.hyp_context = np.zeros(
            (HYPOTHESIS_CAPACITY, soma5r.LATENT_DIM), dtype=float
        )
        self.hyp_action = np.zeros((HYPOTHESIS_CAPACITY, 2), dtype=float)
        self.hyp_effect = np.zeros(
            (HYPOTHESIS_CAPACITY, TROPHIC_COUNT), dtype=float
        )
        self.hyp_uncertainty = np.ones_like(self.hyp_effect) * 0.10
        self.hyp_confidence = np.zeros(HYPOTHESIS_CAPACITY, dtype=float)
        self.hyp_evidence = np.zeros(HYPOTHESIS_CAPACITY, dtype=float)
        self.hyp_error = np.zeros(HYPOTHESIS_CAPACITY, dtype=float)
        self.hyp_accepted = np.zeros(HYPOTHESIS_CAPACITY, dtype=bool)
        self.hyp_age = np.zeros(HYPOTHESIS_CAPACITY, dtype=float)
        if heritage is not None:
            self.absorb_heritage(heritage)

    # ------------------------------------------------------------------
    # Shared sensing and body mechanics
    # ------------------------------------------------------------------

    def temperature_field(self, position=None, at_time=None):
        if position is None:
            position = self.pos
        if self.world is None:
            return super().temperature_field(position, at_time)
        return self.world.temperature_field(position, at_time)

    def shelter_level(self):
        if self.world is None:
            return super().shelter_level()
        return self.world.refuge_level(self.pos)

    def _noisy_shared_channel(self, gradient, density, modality):
        sensor, _, _ = self.morphology.effective_arrays()
        quality = clamp(float(np.mean(sensor[:, modality])), 0.02, 1.0)
        gain = 0.20 + 0.80 * quality
        noise = 0.010 + 0.024 * (1.0 - quality)
        gradient = np.asarray(gradient, dtype=float) * gain
        gradient += self.rng.normal(0.0, noise, 2)
        density = float(density) + float(self.rng.normal(0.0, 0.55 * noise))
        return np.clip(gradient, -1.0, 1.0), clamp(density, 0.0, 1.0)

    def make_sensor(self):
        if self.world is None:
            return super().make_sensor()
        a_grad, a_density = self._noisy_shared_channel(
            *self.world.nutrient_field(self.pos), modality=0
        )
        b_grad, b_density = self._noisy_shared_channel(
            *self.world.toxin_field(self.pos), modality=1
        )
        c_grad, c_density = self._noisy_shared_channel(
            *self.world.social_field(self), modality=2
        )
        ambient, thermal_gradient = self.world.temperature_field(self.pos)
        sensor, _, _ = self.morphology.effective_arrays()
        thermal_quality = clamp(float(np.mean(sensor[:, 3])), 0.02, 1.0)
        thermal_gradient = np.asarray(thermal_gradient) * (
            0.20 + 0.80 * thermal_quality
        )
        thermal_gradient += self.rng.normal(
            0.0, 0.010 + 0.020 * (1.0 - thermal_quality), 2
        )
        tissue_distress = 1.0 - float(np.mean(self.brain.vitality))
        prediction_uncertainty = float(np.mean(self.brain.prediction_error))
        return np.clip(np.array([
            a_grad[0], a_grad[1], a_density * 2.0 - 1.0,
            b_grad[0], b_grad[1], b_density * 2.0 - 1.0,
            c_grad[0], c_grad[1], c_density * 2.0 - 1.0,
            ambient * 2.0 - 1.0,
            thermal_gradient[0], thermal_gradient[1],
            self.energy * 2.0 - 1.0,
            (self.temperature - 0.50) * 2.0,
            self.integrity * 2.0 - 1.0,
            self.fatigue * 2.0 - 1.0,
            self.vel[0] / MAX_SPEED,
            self.vel[1] / MAX_SPEED,
            self.last_action[0], self.last_action[1],
            self.pain * 2.0 - 1.0,
            tissue_distress * 2.0 - 1.0,
            clamp(prediction_uncertainty, 0.0, 1.0) * 2.0 - 1.0,
            1.0,
        ], dtype=float), -1.0, 1.0)

    def _apply_body_and_world(self, action, dt):
        if self.world is None:
            return super()._apply_body_and_world(action, dt)
        action = np.clip(np.asarray(action, dtype=float), -1.0, 1.0)
        shaped_action = self.morphology.transform_action(action)
        shaped_action += 0.06 * self.world.repulsion(self)
        shaped_action = np.clip(shaped_action, -1.0, 1.0)
        target_velocity = shaped_action * MAX_SPEED
        response = 1.0 - math.exp(-4.0 * dt)
        self.vel += (target_velocity - self.vel) * response
        displacement = self.vel * dt
        self.pos = (self.pos + displacement) % 1.0
        self.distance_travelled += _norm(displacement)

        movement = float(np.dot(shaped_action, shaped_action))
        neural = self.brain.neural_cost()
        shelter = self.shelter_level()
        ambient, _ = self.temperature_field()
        self.last_ambient = ambient
        self.last_shelter = shelter
        sensor_mean, fin_mean, shell_mean = self.morphology.organ_means()
        insulation = clamp(0.44 * shell_mean, 0.0, 0.38)
        thermal_coupling = (0.16 + 0.95 * shelter) * (1.0 - insulation)
        self.temperature += (
            (ambient - self.temperature) * thermal_coupling * dt
            + 0.022 * movement * dt
        )
        self.temperature = clamp(self.temperature, 0.0, 1.0)
        thermal_stress = clamp(
            abs(self.temperature - 0.50) / 0.42, 0.0, 1.0
        )
        locomotor_efficiency = 1.0 + 0.90 * fin_mean
        structural_mass = 1.0 + 0.30 * shell_mean + 0.10 * sensor_mean
        self.fatigue += (
            0.075 * movement * structural_mass / locomotor_efficiency
            + 0.020 * neural
        ) * dt
        rest_fraction = max(0.0, 1.0 - math.sqrt(min(1.0, movement)))
        recovery = (0.008 + 0.160 * shelter) * rest_fraction
        self.fatigue = clamp(self.fatigue - recovery * dt, 0.0, 1.0)
        structure_cost = self.morphology.construction_and_maintenance_cost()
        self.energy -= (
            0.0019
            + 0.0026 * movement * structural_mass / locomotor_efficiency
            + 0.0010 * neural
            + 0.0014 * thermal_stress
            + 0.0010 * self.fatigue
            + structure_cost
        ) * dt

        if thermal_stress > 0.70:
            damage = (
                0.010 * (thermal_stress - 0.70) / 0.30
                * (1.0 - 0.24 * shell_mean) * dt
            )
            self.integrity -= damage
            self.pain = min(1.0, self.pain + damage * 20.0)
        if self.fatigue > 0.90:
            damage = 0.006 * (self.fatigue - 0.90) / 0.10 * dt
            self.integrity -= damage
            self.pain = min(1.0, self.pain + damage * 20.0)
        if self.energy > 0.52 and self.fatigue < 0.58 and thermal_stress < 0.55:
            heal_rate = (
                0.0018 * (self.energy - 0.52) / 0.48
                * (1.0 - self.fatigue)
            )
            healing = min(heal_rate * dt, 1.0 - self.integrity)
            self.integrity += healing
            self.energy -= healing * 0.35

        gain, biomass = self.world.consume(self, dt)
        if gain > 0.0:
            self.energy = min(1.0, self.energy + gain)
            self.food_event_accumulator += gain
            while self.food_event_accumulator >= 0.035:
                self.food_event_accumulator -= 0.035
                self.eaten += 1
                self.source_a_contacts += 1

        exposure = self.world.toxin_exposure(self)
        self.toxin_event_cooldown = max(0.0, self.toxin_event_cooldown - dt)
        if exposure > 0.0:
            protection = clamp(0.62 * float(np.mean(self.morphology.shell)), 0.0, 0.56)
            damage = 0.060 * exposure * (1.0 - protection) * dt
            self.integrity -= damage
            self.energy -= 0.010 * exposure * dt
            self.pain = min(1.0, self.pain + damage * 18.0)
            if self.toxin_event_cooldown <= 0.0:
                self.poisoned += 1
                self.source_b_contacts += 1
                self.toxin_event_cooldown = 0.8

        self.pain *= math.exp(-2.3 * dt)
        self.energy = clamp(self.energy, 0.0, 1.0)
        self.integrity = clamp(self.integrity, 0.0, 1.0)

    # ------------------------------------------------------------------
    # Grounded culture
    # ------------------------------------------------------------------

    def sender_trust(self, sender_id):
        sender_id = int(sender_id)
        alpha = float(self.trust_alpha.get(sender_id, 1.5))
        beta = float(self.trust_beta.get(sender_id, 1.5))
        return alpha / max(alpha + beta, 1e-9)

    def _update_sender_trust(self, sender_id, success, weight=1.0):
        sender_id = int(sender_id)
        self.trust_alpha.setdefault(sender_id, 1.5)
        self.trust_beta.setdefault(sender_id, 1.5)
        if success:
            self.trust_alpha[sender_id] += float(weight)
        else:
            self.trust_beta[sender_id] += float(weight)

    def make_packet(self):
        score = (
            self.concepts.utility
            * np.log1p(self.concepts.count)
            / (0.05 + np.mean(np.sqrt(self.concepts.effect_var), axis=1))
        )
        if float(np.max(score)) <= 1e-8:
            return None
        index = int(np.argmax(score))
        confidence = (
            clamp(self.concepts.count[index] / 45.0, 0.0, 1.0)
            * math.exp(-2.0 * float(np.mean(np.sqrt(self.concepts.effect_var[index]))))
        )
        confidence = clamp(confidence, 0.0, 1.0)
        if confidence < 0.06:
            return None
        return GroundedCulturalPacket(
            sender_id=self.agent_id,
            context=self.concepts.context[index, :soma5r.LATENT_DIM],
            action=self.concepts.action_mean[index],
            effect=self.concepts.effect[index],
            uncertainty=np.sqrt(self.concepts.effect_var[index]),
            confidence=confidence,
            created_age=self.age,
        )

    def receive_packet(self, packet):
        if not self.communication_enabled or packet is None:
            return False
        trust = self.sender_trust(packet.sender_id)
        if packet.confidence * (0.35 + 0.65 * trust) < 0.035:
            return False
        free = np.flatnonzero(~self.hyp_active)
        if free.size:
            slot = int(free[0])
        else:
            value = (
                self.hyp_confidence
                * (0.3 + 0.7 * self.hyp_accepted.astype(float))
                / (1.0 + self.hyp_age)
            )
            slot = int(np.argmin(value))
        self.hyp_active[slot] = True
        self.hyp_sender[slot] = int(packet.sender_id)
        self.hyp_context[slot] = packet.context
        self.hyp_action[slot] = np.clip(packet.action, -1.0, 1.0)
        self.hyp_effect[slot] = np.clip(packet.effect, -0.5, 0.5)
        self.hyp_uncertainty[slot] = np.clip(packet.uncertainty, 0.005, 0.5)
        self.hyp_confidence[slot] = float(packet.confidence)
        self.hyp_evidence[slot] = 0.0
        self.hyp_error[slot] = 0.0
        self.hyp_accepted[slot] = False
        self.hyp_age[slot] = 0.0
        self.social_received += 1
        return True

    def additional_planning_prior(self):
        if not np.any(self.hyp_active & self.hyp_accepted):
            return np.zeros(2, dtype=float), 0.0
        latent = self._encode_latent()
        action = np.zeros(2, dtype=float)
        total = 0.0
        for slot in np.flatnonzero(self.hyp_active & self.hyp_accepted):
            slot = int(slot)
            delta = self.hyp_context[slot] - latent
            delta[0:2] = (delta[0:2] + 0.5) % 1.0 - 0.5
            distance = float(np.mean(delta * delta))
            context = math.exp(-3.0 * min(distance, 2.0))
            trust = self.sender_trust(self.hyp_sender[slot])
            weight = (
                context * trust * self.hyp_confidence[slot]
                * clamp(self.hyp_evidence[slot] / 4.0, 0.0, 1.0)
            )
            action += weight * self.hyp_action[slot]
            total += weight
        if total <= 1e-8:
            return np.zeros(2, dtype=float), 0.0
        action /= total
        norm = _norm(action)
        if norm > 1.0:
            action /= norm
        return action, clamp(total / 2.0, 0.0, 0.85)

    def _verify_hypotheses(self, latent_before, action, improvement, dt):
        for slot in np.flatnonzero(self.hyp_active):
            slot = int(slot)
            self.hyp_age[slot] += float(dt)
            if self.hyp_age[slot] > 90.0:
                self.hyp_active[slot] = False
                continue
            context_delta = self.hyp_context[slot] - latent_before
            context_delta[0:2] = (context_delta[0:2] + 0.5) % 1.0 - 0.5
            context_distance = float(np.mean(context_delta * context_delta))
            if context_distance > 0.20:
                continue
            a = np.asarray(action, dtype=float)
            h = self.hyp_action[slot]
            if _norm(h) < 0.08:
                action_match = clamp(1.0 - _norm(a) / 0.45, 0.0, 1.0)
            else:
                action_match = clamp(
                    float(np.dot(a, h)) / ((_norm(a) + 0.05) * (_norm(h) + 0.05)),
                    0.0,
                    1.0,
                )
            if action_match < 0.45:
                continue
            observed = np.asarray(improvement, dtype=float)
            error = float(np.mean(np.abs(observed - self.hyp_effect[slot])))
            tolerance = 0.025 + float(np.mean(self.hyp_uncertainty[slot]))
            sign_mask = np.abs(self.hyp_effect[slot]) > 0.008
            if np.any(sign_mask):
                sign_ok = float(np.mean(
                    np.sign(observed[sign_mask])
                    == np.sign(self.hyp_effect[slot, sign_mask])
                ))
            else:
                sign_ok = 1.0
            success = error <= tolerance and sign_ok >= 0.5
            weight = 0.4 + 0.6 * action_match
            self._update_sender_trust(
                self.hyp_sender[slot], success, weight=weight
            )
            self.hyp_evidence[slot] += weight
            self.hyp_error[slot] += weight * error
            if success:
                self.social_verified += 1
            else:
                self.social_rejected += 1

            mean_error = self.hyp_error[slot] / max(self.hyp_evidence[slot], 1e-9)
            trust = self.sender_trust(self.hyp_sender[slot])
            if (
                self.hyp_evidence[slot] >= 2.4
                and mean_error < 0.085
                and trust > 0.52
            ):
                if not self.hyp_accepted[slot]:
                    self.social_assimilated += 1
                self.hyp_accepted[slot] = True
                # Only after own evidence: weakly seed a matching concept.
                index, _, _ = self.concepts.assign(
                    latent_before, self.hyp_action[slot]
                )
                blend = 0.008 * trust
                self.concepts.effect[index] += blend * (
                    self.hyp_effect[slot] - self.concepts.effect[index]
                )
                self.concepts.action_mean[index] += blend * (
                    self.hyp_action[slot] - self.concepts.action_mean[index]
                )
            if self.hyp_evidence[slot] >= 4.0 and (
                mean_error > 0.16 or trust < 0.30
            ):
                self.hyp_active[slot] = False

    def step(self, dt=1.0 / SIM_HZ):
        if not self.alive:
            return
        latent_before = self._encode_latent()
        debt_before = self.body_debt().copy()
        super().step(dt)
        improvement = debt_before - self.body_debt()
        self._verify_hypotheses(
            latent_before, self.last_action, improvement, dt
        )

    # ------------------------------------------------------------------
    # Inheritance
    # ------------------------------------------------------------------

    def heritage(self):
        concept_score = self.concepts.utility * np.log1p(self.concepts.count)
        concept_indices = np.argsort(concept_score)[-4:]
        model_payload = []
        for member in range(soma5r.MODEL_MEMBERS):
            score = (
                self.world_model.utility[member]
                * np.log1p(self.world_model.count[member])
            )
            indices = np.argsort(score)[-3:]
            model_payload.append({
                'center': self.world_model.center[member, indices].copy(),
                'scale': self.world_model.scale[member, indices].copy(),
                'mean': self.world_model.mean[member, indices].copy(),
                'var': self.world_model.var[member, indices].copy(),
            })
        return {
            'concept_context': self.concepts.context[concept_indices].copy(),
            'concept_effect': self.concepts.effect[concept_indices].copy(),
            'concept_var': self.concepts.effect_var[concept_indices].copy(),
            'concept_action': self.concepts.action_mean[concept_indices].copy(),
            'model': model_payload,
            'motor': self.brain.motor.copy(),
            'cell_trust': self.causal_calibrator.cell_trust.copy(),
        }

    def absorb_heritage(self, heritage):
        if heritage is None:
            return
        n = min(4, len(heritage.get('concept_context', [])))
        if n:
            self.concepts.context[:n] = np.asarray(
                heritage['concept_context'][:n], dtype=float
            ) + self.rng.normal(0.0, 0.012, (n, soma5r.CONCEPT_CONTEXT_DIM))
            self.concepts.context[:n, 0:2] %= 1.0
            self.concepts.effect[:n] = heritage['concept_effect'][:n]
            self.concepts.effect_var[:n] = np.maximum(
                heritage['concept_var'][:n], 0.035
            )
            self.concepts.action_mean[:n] = heritage['concept_action'][:n]
            self.concepts.count[:n] = 4.0
            self.concepts.utility[:n] = 0.015
        for member, payload in enumerate(heritage.get('model', [])):
            count = min(3, len(payload['center']))
            self.world_model.center[member, :count] = payload['center'][:count]
            self.world_model.scale[member, :count] = payload['scale'][:count]
            self.world_model.mean[member, :count] = payload['mean'][:count]
            self.world_model.var[member, :count] = np.maximum(
                payload['var'][:count], 0.04
            )
            self.world_model.count[member, :count] = 3.0
        if 'motor' in heritage:
            self.brain.motor = (
                0.95 * self.brain.motor
                + 0.05 * np.asarray(heritage['motor'], dtype=float)
            )
        if 'cell_trust' in heritage:
            self.causal_calibrator.cell_trust = (
                0.94 * self.causal_calibrator.cell_trust
                + 0.06 * np.asarray(heritage['cell_trust'], dtype=float)
            )

    def diagnostics6r(self):
        d = self.diagnostics5r()
        d.update({
            'agent_id': int(self.agent_id),
            'parent_id': int(self.parent_id),
            'generation': int(self.generation),
            'lineage': int(self.lineage),
            'social_sent': int(self.social_sent),
            'social_received': int(self.social_received),
            'social_verified': int(self.social_verified),
            'social_rejected': int(self.social_rejected),
            'social_assimilated': int(self.social_assimilated),
            'accepted_hypotheses': int(np.count_nonzero(
                self.hyp_active & self.hyp_accepted
            )),
            'mean_sender_trust': float(np.mean([
                self.sender_trust(sender) for sender in self.trust_alpha
            ])) if self.trust_alpha else 0.5,
            'communication_energy': float(self.communication_energy),
        })
        return d


class SomaSixRColony(object):
    def __init__(
        self,
        n=4,
        seed=101,
        culture_enabled=True,
        inheritance_enabled=True,
        full_brain=False,
        target_population=None,
    ):
        self.seed = int(seed)
        self.rng = np.random.default_rng(self.seed + 6201)
        self.world = SharedWorld6R(self.seed)
        self.culture_enabled = bool(culture_enabled)
        self.inheritance_enabled = bool(inheritance_enabled)
        self.full_brain = bool(full_brain)
        self.target_population = int(target_population or n)
        self.next_agent_id = 0
        self.agents = []
        for index in range(int(n)):
            self.agents.append(self._new_agent(
                seed=self.seed + 101 * index,
                parent=None,
                generation=0,
                lineage=index,
            ))
        self.world.agents = self.agents
        self.age = 0.0
        self.transmissions = 0
        self.births = 0
        self.deaths = 0
        self.communication_rounds = 0
        self.next_communication_age = 0.8
        self.next_birth_age = 2.0
        self.last_signals = []
        self.last_birth = None

    def _new_agent(self, seed, parent=None, generation=0, lineage=0):
        agent_id = self.next_agent_id
        self.next_agent_id += 1
        heritage = (
            parent.heritage()
            if parent is not None and self.inheritance_enabled
            else None
        )
        agent = SomaSixRAgent(
            seed=int(seed),
            world=self.world,
            agent_id=agent_id,
            parent_id=parent.agent_id if parent is not None else -1,
            generation=int(generation),
            lineage=int(lineage),
            heritage=heritage,
            communication_enabled=self.culture_enabled,
            full_brain=self.full_brain,
        )
        if parent is not None:
            agent.pos = (parent.pos + self.rng.normal(0.0, 0.035, 2)) % 1.0
            agent.energy = 0.14
            agent.integrity = 0.92
        return agent

    def step(self, dt=1.0 / SIM_HZ):
        dt = clamp(float(dt), 1.0 / 240.0, 0.10)
        self.age += dt
        self.world.step(dt)
        self.world.agents = self.agents
        if self.agents:
            order = self.rng.permutation(len(self.agents))
            for index in order:
                agent = self.agents[int(index)]
                if agent.alive:
                    agent.step(dt)
        self._remove_dead()
        if self.age + 1e-9 >= self.next_communication_age:
            self._communicate()
            self.next_communication_age += 0.8
        if self.age + 1e-9 >= self.next_birth_age:
            self._replace_population()
            self.next_birth_age += 2.0
        self.last_signals = [
            signal for signal in self.last_signals
            if self.age - signal[2] < 0.8
        ]

    def _communicate(self):
        self.communication_rounds += 1
        if not self.culture_enabled:
            return
        alive = [agent for agent in self.agents if agent.alive]
        for speaker in alive:
            if speaker.energy < 0.19 or speaker.fatigue > 0.88:
                continue
            packet = speaker.make_packet()
            if packet is None:
                continue
            neighbors = [
                listener for listener in alive
                if listener is not speaker
                and _torus_distance(speaker.pos, listener.pos)
                <= COMMUNICATION_BASE_RANGE
            ]
            if not neighbors:
                continue
            # At most two receivers per round keeps communication local and costly.
            neighbors.sort(key=lambda listener: _torus_distance(
                speaker.pos, listener.pos
            ))
            neighbors = neighbors[:2]
            accepted = 0
            for listener in neighbors:
                if listener.receive_packet(packet):
                    listener_cost = 0.00012
                    listener.energy = clamp(
                        listener.energy - listener_cost, 0.0, 1.0
                    )
                    listener.communication_energy += listener_cost
                    accepted += 1
                    self.transmissions += 1
                    self.last_signals.append((
                        speaker.agent_id, listener.agent_id, self.age
                    ))
            if accepted:
                cost = 0.00045 + 0.00018 * accepted
                speaker.energy = clamp(speaker.energy - cost, 0.0, 1.0)
                speaker.communication_energy += cost
                speaker.social_sent += accepted

    def _remove_dead(self):
        alive = []
        for agent in self.agents:
            if agent.alive:
                alive.append(agent)
            else:
                self.deaths += 1
        self.agents = alive
        self.world.agents = self.agents

    def _replace_population(self):
        if len(self.agents) >= self.target_population or not self.agents:
            return
        candidates = [
            agent for agent in self.agents
            if agent.energy > 0.48 and agent.integrity > 0.58
        ]
        if not candidates:
            return
        parent = max(
            candidates,
            key=lambda agent: (
                agent.energy + agent.integrity
                - 0.35 * agent.fatigue
                + 0.02 * np.sum(agent.concepts.utility)
            ),
        )
        contribution = 0.18
        if parent.energy <= contribution + 0.08:
            return
        parent.energy -= contribution
        self.world.reproductive_parent_energy += contribution
        child = self._new_agent(
            seed=int(self.rng.integers(1, 2 ** 31 - 1)),
            parent=parent,
            generation=parent.generation + 1,
            lineage=parent.lineage,
        )
        # 0.14 reaches the child; 0.04 is reproductive dissipation.
        child.energy = 0.14
        self.world.offspring_initial_energy += child.energy
        self.world.reproductive_dissipation += contribution - child.energy
        parent.births += 1
        self.agents.append(child)
        self.world.agents = self.agents
        self.births += 1
        self.last_birth = (parent.agent_id, child.agent_id, self.age)

    def force_birth_for_calibration(self, parent_index=0):
        if not self.agents:
            return None
        parent = self.agents[int(parent_index) % len(self.agents)]
        parent.energy = max(parent.energy, 0.75)
        old_target = self.target_population
        before_count = len(self.agents)
        self.target_population = max(old_target, before_count + 1)
        self._replace_population()
        self.target_population = old_target
        return self.agents[-1] if len(self.agents) > before_count else None

    def agent_by_id(self, agent_id):
        for agent in self.agents:
            if agent.agent_id == int(agent_id):
                return agent
        return None

    def save(self, path=SAVE_FILE):
        payload = {'build': BUILD, 'version': SAVE_VERSION, 'colony': self}
        with open(path, 'wb') as handle:
            pickle.dump(payload, handle, pickle.HIGHEST_PROTOCOL)

    @staticmethod
    def load(path=SAVE_FILE):
        with open(path, 'rb') as handle:
            payload = pickle.load(handle)
        if not isinstance(payload, dict) or payload.get('build') != BUILD:
            raise ValueError('incompatible SOMA-6R save')
        colony = payload['colony']
        colony.world.agents = colony.agents
        for agent in colony.agents:
            agent.world = colony.world
            agent.latent_codec = SharedLatentCodec6R()
            if not isinstance(agent.compiler, soma5r.ImaginationActionCompiler):
                agent.compiler.__class__ = soma5r.ImaginationActionCompiler
        return colony

    def summary(self):
        alive = [agent for agent in self.agents if agent.alive]
        if alive:
            mean_health = float(np.mean([
                1.0 - np.mean(agent.body_debt()) for agent in alive
            ]))
            generations = max(agent.generation for agent in alive)
            accepted = sum(
                np.count_nonzero(agent.hyp_active & agent.hyp_accepted)
                for agent in alive
            )
            planning = sum(agent.planner.plans for agent in alive)
        else:
            mean_health = 0.0
            generations = 0
            accepted = 0
            planning = 0
        return {
            'age': float(self.age),
            'population': len(alive),
            'mean_health': mean_health,
            'food_events': int(sum(agent.eaten for agent in self.agents)),
            'toxin_events': int(sum(agent.poisoned for agent in self.agents)),
            'transmissions': int(self.transmissions),
            'accepted_hypotheses': int(accepted),
            'births': int(self.births),
            'deaths': int(self.deaths),
            'max_generation': int(generations),
            'planning_events': int(planning),
            'biomass': float(np.sum(self.world.nutrient_biomass)),
            'external_growth': float(self.world.external_growth),
            'consumed_biomass': float(self.world.consumed_biomass),
            'reproductive_parent_energy': float(
                self.world.reproductive_parent_energy
            ),
            'offspring_initial_energy': float(
                self.world.offspring_initial_energy
            ),
            'reproductive_dissipation': float(
                self.world.reproductive_dissipation
            ),
            'reproduction_residual': float(
                self.world.reproductive_parent_energy
                - self.world.offspring_initial_energy
                - self.world.reproductive_dissipation
            ),
        }


def run_headless_trial(
    seed=101,
    seconds=90.0,
    n=4,
    dt=1.0 / SIM_HZ,
    **kwargs
):
    colony = SomaSixRColony(n=n, seed=seed, **kwargs)
    debt_integral = 0.0
    samples = 0
    for _ in range(int(max(0.0, seconds) / dt)):
        if not colony.agents:
            break
        colony.step(dt)
        if colony.agents:
            debt_integral += float(np.mean([
                np.mean(agent.body_debt()) for agent in colony.agents
            ]))
            samples += 1
    summary = colony.summary()
    summary['seed'] = int(seed)
    summary['integrated_health'] = float(
        1.0 - debt_integral / max(samples, 1)
    )
    return summary


# -----------------------------------------------------------------------------
# Pythonista Scene
# -----------------------------------------------------------------------------

try:
    from scene import (
        Scene,
        run,
        LANDSCAPE,
        background,
        fill,
        stroke,
        stroke_weight,
        rect,
        ellipse,
        text,
        line,
    )

    class SomaSixRScene(Scene):
        def setup(self):
            try:
                self.colony = (
                    SomaSixRColony.load(SAVE_FILE)
                    if os.path.exists(SAVE_FILE)
                    else SomaSixRColony(n=4, seed=101)
                )
                self.save_status = 'LOADED' if os.path.exists(SAVE_FILE) else 'NEW'
            except Exception as exc:
                print('SOMA-6R save ignored:', exc)
                self.colony = SomaSixRColony(n=4, seed=101)
                self.save_status = 'RESET'
            self.paused = False
            self.accumulator = 0.0
            self.last_save_age = self.colony.age
            self.last_touch_wall = -10.0

        def update(self):
            if self.paused:
                return
            frame_dt = min(max(float(getattr(self, 'dt', 1.0 / 30.0)), 0.0), 0.12)
            self.accumulator += frame_dt
            fixed = 1.0 / SIM_HZ
            loops = 0
            while self.accumulator >= fixed and loops < 3:
                self.colony.step(fixed)
                self.accumulator -= fixed
                loops += 1
            if self.colony.age - self.last_save_age >= 20.0:
                try:
                    self.colony.save(SAVE_FILE)
                    self.save_status = 'OK'
                    self.last_save_age = self.colony.age
                except Exception:
                    self.save_status = 'ERROR'

        def draw(self):
            background(0.025, 0.035, 0.052)
            width, height = float(self.size.w), float(self.size.h)
            left, right = 18.0, width - 18.0
            bottom, top = 78.0, height - 82.0
            fill(0.05, 0.07, 0.09)
            rect(left, bottom, right - left, top - bottom)

            world = self.colony.world
            for position, biomass, capacity in zip(
                world.nutrient_positions,
                world.nutrient_biomass,
                world.nutrient_capacity,
            ):
                x = left + position[0] * (right - left)
                y = bottom + position[1] * (top - bottom)
                radius = 4.0 + 11.0 * biomass / max(capacity, 1e-9)
                fill(0.30, 0.82, 0.35, 0.82)
                ellipse(x - radius, y - radius, 2 * radius, 2 * radius)
            for position in world.toxin_positions:
                x = left + position[0] * (right - left)
                y = bottom + position[1] * (top - bottom)
                fill(0.92, 0.26, 0.24, 0.74)
                ellipse(x - 7, y - 7, 14, 14)
            for position in world.refuge_positions:
                x = left + position[0] * (right - left)
                y = bottom + position[1] * (top - bottom)
                fill(0.20, 0.48, 0.92, 0.18)
                ellipse(x - 28, y - 28, 56, 56)

            by_id = {agent.agent_id: agent for agent in self.colony.agents}
            for source_id, target_id, created in self.colony.last_signals:
                source = by_id.get(source_id)
                target = by_id.get(target_id)
                if source is None or target is None:
                    continue
                sx = left + source.pos[0] * (right - left)
                sy = bottom + source.pos[1] * (top - bottom)
                tx = left + target.pos[0] * (right - left)
                ty = bottom + target.pos[1] * (top - bottom)
                stroke(0.95, 0.82, 0.28, 0.70)
                stroke_weight(1.2)
                line(sx, sy, tx, ty)

            palette = (
                (0.25, 0.84, 0.95),
                (0.98, 0.58, 0.26),
                (0.70, 0.47, 0.98),
                (0.42, 0.90, 0.48),
                (0.96, 0.35, 0.62),
            )
            for agent in self.colony.agents:
                x = left + agent.pos[0] * (right - left)
                y = bottom + agent.pos[1] * (top - bottom)
                health = clamp(1.0 - float(np.mean(agent.body_debt())), 0.0, 1.0)
                radius = 8.0 + 6.0 * health
                fill(*palette[agent.lineage % len(palette)])
                ellipse(x - radius, y - radius, 2 * radius, 2 * radius)
                stroke(0.95, 0.98, 1.0, 0.8)
                stroke_weight(1.1)
                line(x, y, x + agent.vel[0] * 150, y + agent.vel[1] * 150)
                fill(0.95, 0.98, 1.0)
                text(
                    '#{} G{}'.format(agent.agent_id, agent.generation),
                    x=x, y=y - radius - 8, font_size=8, alignment=5,
                )

            summary = self.colony.summary()
            fill(0.92, 0.96, 1.0)
            text(BUILD, x=18, y=height - 24, font_size=19, alignment=5)
            fill(0.62, 0.74, 0.84)
            text(
                '{}  SAVE {}'.format(
                    'PAUSED' if self.paused else 'RUNNING', self.save_status
                ),
                x=width - 18, y=height - 24, font_size=12, alignment=3,
            )
            fill(0.84, 0.90, 0.96)
            text(
                'age {:.1f}s  pop {}  health {:.3f}  births {} deaths {}  gen {}'.format(
                    summary['age'], summary['population'], summary['mean_health'],
                    summary['births'], summary['deaths'], summary['max_generation'],
                ),
                x=18, y=49, font_size=12, alignment=5,
            )
            text(
                'culture {} accepted {} biomass {:.2f}  tap pause / double tap reset'.format(
                    summary['transmissions'], summary['accepted_hypotheses'],
                    summary['biomass'],
                ),
                x=18, y=28, font_size=11, alignment=5,
            )

        def touch_began(self, touch):
            wall = time.time()
            if wall - self.last_touch_wall < 0.42:
                try:
                    if os.path.exists(SAVE_FILE):
                        os.remove(SAVE_FILE)
                except Exception:
                    pass
                self.colony = SomaSixRColony(n=4, seed=101)
                self.accumulator = 0.0
                self.last_save_age = 0.0
                self.save_status = 'NEW'
                self.paused = False
                self.last_touch_wall = -10.0
                return
            self.last_touch_wall = wall
            self.paused = not self.paused

        def stop(self):
            try:
                self.colony.save(SAVE_FILE)
            except Exception:
                pass

except ImportError:
    Scene = None


if __name__ == '__main__':
    if Scene is None:
        print(run_headless_trial(seed=101, seconds=20.0, n=3))
    else:
        run(SomaSixRScene(), LANDSCAPE, show_fps=False)
