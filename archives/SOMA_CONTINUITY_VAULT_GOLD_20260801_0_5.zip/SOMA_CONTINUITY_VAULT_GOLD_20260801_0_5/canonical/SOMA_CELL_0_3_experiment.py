# coding: utf-8
"""Controlled comparisons for SOMA-CELL 0.3.

Two complementary experiment families are written into one CSV:

1. Spatial chemistry: one physically simulated lineage is followed under
   stable/pulsed/chronic stress, repair ablations, and first-division damage
   partition controls.
2. Accelerated life-history assay: the same material-genome grammar and mutator
   are selected over generations to test heritable repair allocation without
   claiming that every spatial membrane step was simulated for every lineage.

The distributed CSV contains the official 3-seed run.  On iPhone, reduce SEEDS
or durations near the top for a quick smoke test.
"""
from __future__ import division

import csv
import json
import os
import time

import numpy as np

import SOMA_CELL_0_3_pythonista as soma

BASE_DIR = os.path.dirname(__file__)
RESULTS_PATH = os.path.join(BASE_DIR, 'soma_cell_0_3_experiment_results.csv')
SUMMARY_PATH = os.path.join(BASE_DIR, 'soma_cell_0_3_experiment_summary.csv')

SEEDS = (101, 202, 303)
RESUME_COMPLETED = True


def _spatial_conditions():
    return (
        (
            'stable_full_lineage', 240.0, False,
            soma.LifeHistoryConfig(stress_mode='stable', division=False),
        ),
        (
            'pulsed_full_lineage', 240.0, False,
            soma.LifeHistoryConfig(stress_mode='pulsed', division=False),
        ),
        (
            'chronic_full_lineage', 320.0, False,
            soma.LifeHistoryConfig(stress_mode='chronic', division=False),
        ),
        (
            'chronic_no_repair', 320.0, False,
            soma.LifeHistoryConfig(
                stress_mode='chronic', division=False,
                protein_repair=False, genome_repair=False,
                membrane_repair=False,
            ),
        ),
        (
            'pulsed_no_quiescence', 240.0, False,
            soma.LifeHistoryConfig(
                stress_mode='pulsed', division=False, quiescence=False,
            ),
        ),
        (
            'first_division_asymmetric', 260.0, True,
            soma.LifeHistoryConfig(
                stress_mode='pulsed', forced_symmetric_damage=False,
            ),
        ),
        (
            'first_division_symmetric', 260.0, True,
            soma.LifeHistoryConfig(
                stress_mode='pulsed', forced_symmetric_damage=True,
            ),
        ),
    )


def _assay_conditions():
    return (
        ('stable_evolving', 'stable', True, True),
        ('stable_no_mutation', 'stable', False, True),
        ('pulsed_evolving', 'pulsed', True, True),
        ('pulsed_no_mutation', 'pulsed', False, True),
        ('pulsed_symmetric_partition', 'pulsed', True, False),
        ('chronic_evolving', 'chronic', True, True),
        ('chronic_no_mutation', 'chronic', False, True),
    )


def _existing_keys():
    if not RESUME_COMPLETED or not os.path.exists(RESULTS_PATH):
        return set()
    keys = set()
    try:
        with open(RESULTS_PATH, 'r', encoding='utf-8', newline='') as handle:
            for row in csv.DictReader(handle):
                keys.add((row.get('mode', ''), row.get('condition', ''), int(row.get('seed', -1))))
    except Exception:
        return set()
    return keys


def _append_rows(rows):
    if not rows:
        return
    fields = sorted(set().union(*(row.keys() for row in rows)))
    existing = []
    if os.path.exists(RESULTS_PATH) and os.path.getsize(RESULTS_PATH) > 0:
        with open(RESULTS_PATH, 'r', encoding='utf-8', newline='') as handle:
            reader = csv.DictReader(handle)
            existing = list(reader)
            fields = sorted(set(fields).union(reader.fieldnames or []))
    with open(RESULTS_PATH, 'w', encoding='utf-8', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction='ignore')
        writer.writeheader()
        for row in existing + rows:
            writer.writerow({key: row.get(key, '') for key in fields})


def run_spatial(condition, seed, seconds, stop_on_division, config):
    world = soma.DamageWorld(seed=seed, initial_cells=1, config=config)
    dt = 1.0 / soma.SIM_HZ
    max_damage = 0.0
    max_abs_ledger = 0.0
    first_division = None
    started = time.time()
    for _ in range(int(seconds * soma.SIM_HZ)):
        world.step(dt)
        summary = world.summary()
        max_damage = max(max_damage, float(summary['max_damage']))
        max_abs_ledger = max(max_abs_ledger, abs(float(summary['matter_residual'])))
        if world.divisions and first_division is None:
            first_division = float(world.age)
            if stop_on_division:
                break
        if not world.living_cells():
            break
    summary = world.summary()
    pair = summary.get('last_damage_partition')
    if pair is None:
        dirty = clean = gap = ''
    else:
        dirty, clean = float(pair[0]), float(pair[1])
        gap = abs(dirty - clean)
    return {
        'mode': 'spatial',
        'condition': condition,
        'seed': int(seed),
        'requested_seconds': float(seconds),
        'simulated_seconds': float(world.age),
        'wall_seconds': float(time.time() - started),
        'alive_cells': int(summary['cells']),
        'divisions': int(summary['divisions']),
        'deaths': int(summary['deaths']),
        'max_generation': int(summary['max_generation']),
        'first_division_age': '' if first_division is None else first_division,
        'mean_damage': float(summary['mean_damage']),
        'max_damage_during_run': float(max_damage),
        'mean_proteostasis': float(summary['mean_proteostasis']),
        'mean_genome_lesion': float(summary['mean_genome_lesion']),
        'mean_membrane_oxidation': float(summary['mean_membrane_oxidation']),
        'mean_reactive': float(summary['mean_reactive']),
        'mean_aggregate': float(summary['mean_aggregate']),
        'mean_atp': float(summary['mean_atp']),
        'mean_closure': float(summary['mean_closure']),
        'repair_atp_total': float(summary['repair_atp_total']),
        'stress_pulses': int(summary['stress_pulses']),
        'segregation_events': int(summary['damage_segregation_events']),
        'rejuvenation_events': int(summary['rejuvenation_events']),
        'dirty_daughter_damage': dirty,
        'clean_daughter_damage': clean,
        'daughter_damage_gap': gap,
        'division_residual': float(summary['division_residual']),
        'max_abs_matter_residual': float(max_abs_ledger),
        'finite': int(world.finite()),
        'death_reason': '' if not world.last_deaths else str(world.last_deaths[-1][2]),
    }


def run_assay(condition, seed, environment, mutation, segregation):
    started = time.time()
    result = soma.run_life_history_assay(
        seed=seed,
        generations=60,
        population=72,
        environment=environment,
        mutation=mutation,
        variable_length=True,
        damage_segregation=segregation,
    )
    return {
        'mode': 'assay',
        'condition': condition,
        'seed': int(seed),
        'wall_seconds': float(time.time() - started),
        'environment': environment,
        'mutation': int(bool(mutation)),
        'segregation_enabled': int(bool(segregation)),
        'generations': int(result['generations']),
        'population': int(result['population']),
        'final_mean_fitness': float(result['final_mean_fitness']),
        'final_best_fitness': float(result['final_best_fitness']),
        'final_mean_repair_trait': float(result['final_mean_repair_trait']),
        'final_mean_segregation_trait': float(result['final_mean_segregation_trait']),
        'final_mean_proofreading_trait': float(result['final_mean_proofreading_trait']),
        'best_repair_trait': float(result['best_repair_trait']),
        'best_segregation_trait': float(result['best_segregation_trait']),
        'best_proofreading_trait': float(result['best_proofreading_trait']),
        'best_quiescence_trait': float(result['best_quiescence_trait']),
        'best_genome_length': int(result['best_genome_length']),
        'best_hash': result['best_hash'],
        'first_adaptive_generation': (
            '' if result['first_adaptive_generation'] is None
            else int(result['first_adaptive_generation'])
        ),
    }


def _numeric(rows, key):
    values = []
    for row in rows:
        value = row.get(key, '')
        if value in ('', None):
            continue
        try:
            values.append(float(value))
        except Exception:
            pass
    return np.asarray(values, dtype=float)


def write_summary():
    if not os.path.exists(RESULTS_PATH):
        return []
    with open(RESULTS_PATH, 'r', encoding='utf-8', newline='') as handle:
        rows = list(csv.DictReader(handle))
    groups = {}
    for row in rows:
        groups.setdefault((row['mode'], row['condition']), []).append(row)
    summary_rows = []
    metrics = (
        'simulated_seconds', 'alive_cells', 'divisions', 'deaths',
        'first_division_age', 'mean_damage', 'max_damage_during_run',
        'mean_proteostasis', 'mean_genome_lesion', 'mean_membrane_oxidation',
        'mean_atp', 'mean_closure', 'repair_atp_total', 'segregation_events',
        'rejuvenation_events', 'daughter_damage_gap', 'division_residual',
        'max_abs_matter_residual', 'final_mean_fitness', 'final_best_fitness',
        'final_mean_repair_trait', 'final_mean_segregation_trait',
        'final_mean_proofreading_trait', 'best_repair_trait',
        'best_segregation_trait', 'best_proofreading_trait',
        'best_quiescence_trait', 'best_genome_length',
    )
    for (mode, condition), group in sorted(groups.items()):
        out = {'mode': mode, 'condition': condition, 'n': len(group)}
        for metric in metrics:
            values = _numeric(group, metric)
            if values.size:
                out[metric + '_mean'] = float(np.mean(values))
                out[metric + '_sd'] = float(np.std(values))
        if mode == 'spatial':
            out['survival_fraction'] = float(np.mean([
                float(row.get('alive_cells', 0) or 0) > 0 for row in group
            ]))
            out['division_fraction'] = float(np.mean([
                float(row.get('divisions', 0) or 0) > 0 for row in group
            ]))
        summary_rows.append(out)
    fields = sorted(set().union(*(row.keys() for row in summary_rows)))
    with open(SUMMARY_PATH, 'w', encoding='utf-8', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(summary_rows)
    return summary_rows


def run_all():
    done = _existing_keys()
    new_rows = []
    for seed in SEEDS:
        for condition, seconds, stop, config in _spatial_conditions():
            key = ('spatial', condition, int(seed))
            if key in done:
                continue
            print('spatial', condition, seed)
            row = run_spatial(condition, seed, seconds, stop, config)
            new_rows.append(row)
            _append_rows([row])
            done.add(key)
        for condition, environment, mutation, segregation in _assay_conditions():
            key = ('assay', condition, int(seed))
            if key in done:
                continue
            print('assay', condition, seed)
            row = run_assay(condition, seed, environment, mutation, segregation)
            new_rows.append(row)
            _append_rows([row])
            done.add(key)
    summary = write_summary()
    return new_rows, summary


if __name__ == '__main__':
    rows, summary = run_all()
    print('new rows:', len(rows))
    for row in summary:
        print(row)
