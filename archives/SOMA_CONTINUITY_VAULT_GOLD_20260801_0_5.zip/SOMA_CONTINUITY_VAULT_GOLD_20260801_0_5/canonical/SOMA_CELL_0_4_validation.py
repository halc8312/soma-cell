# coding: utf-8
"""Deterministic mechanism validation for SOMA-CELL 0.4.

The suite distinguishes mechanism checks from broad claims about life or
adaptive superiority.  It tests materially encoded receptors/effectors,
membrane-local sensing, ATP-paid motion and transporter relocation, local
three-factor plasticity driven by realised self-production, physical division,
labile inheritance, exact save/restore continuation, and material accounting.
"""
from __future__ import division

import csv
import gc
import os
import tempfile

import numpy as np

import SOMA_CELL_0_4_pythonista as soma

BASE_DIR = os.path.dirname(__file__)
CSV_PATH = os.path.join(BASE_DIR, 'soma_cell_0_4_validation.csv')
TXT_PATH = os.path.join(BASE_DIR, 'SOMA_CELL_0_4_VALIDATION_RESULTS.txt')


def _fmt(value):
    if isinstance(value, (float, np.floating)):
        return '{:.12g}'.format(float(value))
    return str(value)


def _record(rows, name, passed, observed, criterion):
    print('[{}] {}'.format('PASS' if bool(passed) else 'FAIL', name), flush=True)
    rows.append({
        'test': name,
        'pass': 'PASS' if bool(passed) else 'FAIL',
        'observed': _fmt(observed),
        'criterion': str(criterion),
    })


def _state_equal(a, b):
    if isinstance(a, np.ndarray) or isinstance(b, np.ndarray):
        try:
            return np.array_equal(np.asarray(a), np.asarray(b))
        except Exception:
            return False
    if isinstance(a, dict) and isinstance(b, dict):
        return set(a) == set(b) and all(_state_equal(a[key], b[key]) for key in a)
    if isinstance(a, (list, tuple)) and isinstance(b, (list, tuple)):
        return len(a) == len(b) and all(_state_equal(x, y) for x, y in zip(a, b))
    if isinstance(a, (float, np.floating)) or isinstance(b, (float, np.floating)):
        return float(a) == float(b)
    return a == b


def _sensor_fingerprint(cell, ligand):
    for fingerprint, spec in cell.sensor_specs():
        if int(spec['parameter']) % soma.LIGAND_COUNT == int(ligand):
            return fingerprint
    raise AssertionError('sensor not found')


def _clear_field(field):
    field.pos = np.zeros((0, 2), dtype=float)
    field.kind = np.zeros((0,), dtype=np.int16)
    field.amount = np.zeros((0,), dtype=float)


def run_validation():
    rows = []

    # 1. The material genome really encodes sensors and effectors.
    sequence = soma.founding_genome_04()
    sensors, effectors = soma.sensorimotor_gene_counts(sequence)
    apparatus_ok = bool(
        len(sequence) <= soma.g2.MAX_GENOME_LENGTH
        and sensors[soma.LIGAND_FUEL] >= 1
        and sensors[soma.LIGAND_ALT] >= 1
        and sensors[soma.LIGAND_WASTE] >= 1
        and sensors[soma.LIGAND_ATP_DEFICIT] >= 1
        and effectors[soma.EFFECT_MOTOR] >= 1
        and effectors[soma.EFFECT_TRANSPORT_POLARITY] >= 1
        and effectors[soma.EFFECT_QUIESCENCE] >= 1
    )
    _record(
        rows, 'material_genome_encodes_sensorimotor_apparatus', apparatus_ok,
        'length={}, sensors={}, effectors={}'.format(
            len(sequence), sensors.tolist(), effectors.tolist()
        ),
        'the finite material genome contains the required receptor and effector genes',
    )

    # 2. External ligand receptors start with the same weak prior; names carry no valence.
    parsed = soma.g2.parse_genes(sequence)
    priors = {}
    for spec in parsed:
        if spec['role'] == soma.ROLE_REGULATOR and spec['localisation'] == soma.LOC_SENSOR:
            ligand = int(spec['parameter']) % soma.LIGAND_COUNT
            if ligand in (soma.LIGAND_FUEL, soma.LIGAND_ALT, soma.LIGAND_WASTE):
                priors[ligand] = soma._sensor_parameters(spec)[0]
    prior_values = [priors[key] for key in sorted(priors)]
    _record(
        rows, 'external_ligands_have_identical_inherited_prior',
        len(prior_values) == 3 and max(prior_values) - min(prior_values) < 1e-15,
        prior_values,
        'fuel, alternative substrate, and waste do not receive different built-in good/bad signs',
    )

    # 3. An east-side fuel cloud creates an east-pointing membrane-local signal.
    gradient_world = soma.SensorimotorWorld(
        seed=4, initial_cells=1,
        config=soma.SensorimotorConfig(
            division=False, receptor_adaptation=False,
            causal_perturbation=False, sensor_cost=False,
        ),
    )
    gradient_cell = gradient_world.cells[0]
    _clear_field(gradient_world.field)
    for y in np.linspace(-0.018, 0.018, 9):
        gradient_world.field.add_particle(
            soma.PARTICLE_FUEL,
            (gradient_cell.pos + np.array([gradient_cell.radius + 0.075, y])) % 1.0,
            0.035,
            count_as_injection=False,
        )
    gradient_cell.sense_environment(gradient_world, 0.1, gradient_world.config)
    ligand_gradient = gradient_cell.last_ligand_gradients[soma.LIGAND_FUEL]
    control_gradient = gradient_cell.last_control_vectors[soma.CONTROL_MOTOR]
    gradient_ok = bool(
        ligand_gradient[0] > 0.01
        and ligand_gradient[0] > 3.0 * abs(ligand_gradient[1])
        and control_gradient[0] > 0.0
    )
    _record(
        rows, 'membrane_receptors_recover_local_patch_direction', gradient_ok,
        'ligand=({}, {}), control=({}, {})'.format(
            ligand_gradient[0], ligand_gradient[1],
            control_gradient[0], control_gradient[1],
        ),
        'an east-side material cloud produces an eastward receptor and controller vector',
    )

    # 4. Removing receptors removes controller drive from the same material world.
    no_receptor = soma.SensorimotorWorld(
        seed=4, initial_cells=1,
        config=soma.SensorimotorConfig(
            division=False, receptors=False, causal_perturbation=False,
        ),
    )
    _clear_field(no_receptor.field)
    for y in np.linspace(-0.018, 0.018, 9):
        no_receptor.field.add_particle(
            soma.PARTICLE_FUEL,
            (no_receptor.cells[0].pos + np.array([
                no_receptor.cells[0].radius + 0.075, y
            ])) % 1.0,
            0.035,
            count_as_injection=False,
        )
    no_receptor.cells[0].sense_environment(no_receptor, 0.1, no_receptor.config)
    no_receptor_norm = float(np.linalg.norm(
        no_receptor.cells[0].last_control_vectors[soma.CONTROL_MOTOR]
    ))
    _record(
        rows, 'receptor_ablation_blocks_chemical_control', no_receptor_norm == 0.0,
        no_receptor_norm,
        'with receptors disabled the same external material produces no controller vector',
    )

    # 5. Contractile motion is directed and ATP-paid.
    motor_world = soma.SensorimotorWorld(
        seed=8, initial_cells=1,
        config=soma.SensorimotorConfig(
            division=False, transporter_polarity=False,
            causal_perturbation=False,
        ),
    )
    motor = motor_world.cells[0]
    motor.pools[soma.POOL_ATP] = 0.75
    motor.last_control_vectors[soma.CONTROL_MOTOR] = np.array([1.0, 0.0])
    atp_before = float(motor.pools[soma.POOL_ATP])
    motor.apply_effectors(motor_world, 0.5, motor_world.config)
    atp_after = float(motor.pools[soma.POOL_ATP])
    _record(
        rows, 'contractile_motion_is_directional_and_paid',
        motor.last_motor_force > 0.0 and motor.surface_flux[0] > 0.0 and atp_after < atp_before,
        'force={:.7g}, flux_x={:.7g}, ATP {:.7g}->{:.7g}'.format(
            motor.last_motor_force, motor.surface_flux[0], atp_before, atp_after
        ),
        'a positive motor command creates positive-x cortical flux while consuming ATP',
    )

    # 6. Motor ablation leaves the command but removes active force and its cost.
    motor_off_world = soma.SensorimotorWorld(
        seed=8, initial_cells=1,
        config=soma.SensorimotorConfig(
            division=False, active_motion=False, transporter_polarity=False,
            causal_perturbation=False,
        ),
    )
    motor_off = motor_off_world.cells[0]
    motor_off.pools[soma.POOL_ATP] = 0.75
    motor_off.last_control_vectors[soma.CONTROL_MOTOR] = np.array([1.0, 0.0])
    off_atp = float(motor_off.pools[soma.POOL_ATP])
    motor_off.apply_effectors(motor_off_world, 0.5, motor_off_world.config)
    _record(
        rows, 'motor_ablation_removes_active_force',
        motor_off.last_motor_force == 0.0
        and motor_off.last_motor_atp == 0.0
        and motor_off.pools[soma.POOL_ATP] == off_atp,
        'force={}, motor_ATP={}'.format(
            motor_off.last_motor_force, motor_off.last_motor_atp
        ),
        'disabling active motion prevents force and motor ATP expenditure',
    )

    # 7. Transporter polarisation redistributes existing protein without creating it.
    polarity_world = soma.SensorimotorWorld(seed=10, initial_cells=1)
    polarity = polarity_world.cells[0]
    polarity.pools[soma.POOL_ATP] = 0.90
    polarity.transporters[:] = np.mean(polarity.transporters, axis=0)[None, :]
    total_before = polarity.transporters.copy().sum(axis=0)
    polarity._apply_transporter_polarity(
        polarity_world, 1.0, polarity_world.config, np.array([1.0, 0.0])
    )
    total_after = polarity.transporters.sum(axis=0)
    angles = 2.0 * np.pi * (np.arange(soma.MEMBRANE_SEGMENTS) + 0.5) / soma.MEMBRANE_SEGMENTS
    front = np.cos(angles) > 0.0
    fuel_front = float(np.mean(polarity.transporters[front, soma.CHANNEL_FUEL]))
    fuel_rear = float(np.mean(polarity.transporters[~front, soma.CHANNEL_FUEL]))
    polarity_ok = bool(
        np.max(np.abs(total_after - total_before)) < 1e-12
        and fuel_front > fuel_rear
        and polarity.last_polarity_atp > 0.0
    )
    _record(
        rows, 'transporter_polarity_is_conservative_and_paid', polarity_ok,
        'mass residual={:.3e}, front/rear={:.6g}/{:.6g}, ATP={:.6g}'.format(
            np.max(np.abs(total_after - total_before)),
            fuel_front, fuel_rear, polarity.last_polarity_atp,
        ),
        'existing transporter mass shifts toward the commanded side with ATP cost',
    )

    # 8. Sensing itself has an energetic cost, isolated from random perturbations.
    sensor_template = soma.SensorimotorWorld(
        seed=12, initial_cells=1,
        config=soma.SensorimotorConfig(
            division=False, causal_perturbation=False,
            receptor_adaptation=False,
        ),
    )
    paid_world = sensor_template.clone()
    free_world = sensor_template.clone()
    paid_world.config.sensor_cost = True
    free_world.config.sensor_cost = False
    paid_before = float(paid_world.cells[0].pools[soma.POOL_ATP])
    free_before = float(free_world.cells[0].pools[soma.POOL_ATP])
    paid_world.cells[0].sense_environment(paid_world, 0.5, paid_world.config)
    free_world.cells[0].sense_environment(free_world, 0.5, free_world.config)
    paid_drop = paid_before - paid_world.cells[0].pools[soma.POOL_ATP]
    free_drop = free_before - free_world.cells[0].pools[soma.POOL_ATP]
    _record(
        rows, 'receptor_signalling_has_real_ATP_cost',
        paid_drop > 0.0 and abs(free_drop) < 1e-15,
        'paid_drop={:.8g}, free_drop={:.8g}'.format(paid_drop, free_drop),
        'the same receptor calculation consumes ATP only when signalling cost is enabled',
    )

    # 9. Identical local eligibility is reinforced or weakened by realised margin change.
    template = soma.SensorimotorWorld(
        seed=14, initial_cells=1,
        config=soma.SensorimotorConfig(
            division=False, causal_perturbation=False,
            learning_rate_scale=2.0,
        ),
    )
    positive = template.clone()
    negative = template.clone()
    fp = _sensor_fingerprint(positive.cells[0], soma.LIGAND_FUEL)
    for world, sign in ((positive, 1.0), (negative, -1.0)):
        cell = world.cells[0]
        cell.pools[soma.POOL_ATP] = 1.0
        cell.controller_eligibility[fp] = 1.0
        cell.expected_margin_drift = 0.0
        current = cell.autopoietic_margin()
        cell.previous_autopoietic_margin = current - sign * 0.015
    p0 = positive.cells[0].controller_phosphorylation[fp]
    n0 = negative.cells[0].controller_phosphorylation[fp]
    positive.cells[0]._update_sensorimotor_learning(positive, 0.1, positive.config)
    negative.cells[0]._update_sensorimotor_learning(negative, 0.1, negative.config)
    pd = positive.cells[0].controller_phosphorylation[fp] - p0
    nd = negative.cells[0].controller_phosphorylation[fp] - n0
    _record(
        rows, 'realised_self_production_drives_opposite_local_updates',
        pd > 0.0 and nd < 0.0,
        'positive_delta={:.9g}, negative_delta={:.9g}'.format(pd, nd),
        'the same local trace is reinforced by improvement and weakened by deterioration',
    )

    # 10. The same ligand can acquire opposite functional meaning from opposite outcomes.
    meaning_positive = template.clone()
    meaning_negative = template.clone()
    for world, sign in ((meaning_positive, 1.0), (meaning_negative, -1.0)):
        cell = world.cells[0]
        cell.pools[soma.POOL_ATP] = 1.0
        cell.meaning_trace[soma.LIGAND_FUEL] = 0.8
        cell.uptake_trace[soma.LIGAND_FUEL] = 0.8
        cell.expected_margin_drift = 0.0
        current = cell.autopoietic_margin()
        cell.previous_autopoietic_margin = current - sign * 0.015
        cell._update_sensorimotor_learning(world, 0.2, world.config)
    positive_meaning = meaning_positive.cells[0].meaning_mean[soma.LIGAND_FUEL]
    negative_meaning = meaning_negative.cells[0].meaning_mean[soma.LIGAND_FUEL]
    _record(
        rows, 'functional_meaning_depends_on_outcome_not_ligand_name',
        positive_meaning > 0.0 and negative_meaning < 0.0,
        'positive={:.9g}, negative={:.9g}'.format(
            positive_meaning, negative_meaning
        ),
        'identical fuel sensing obtains opposite signs under opposite self-production changes',
    )

    # 11. In a patchy world active sensorimotor control beats the no-motion twin.
    adaptive_60 = soma.run_headless_trial(
        seed=101, seconds=60.0,
        config=soma.SensorimotorConfig(environment_mode='patchy', division=False),
    )
    no_motion_60 = soma.run_headless_trial(
        seed=101, seconds=60.0,
        config=soma.SensorimotorConfig(
            environment_mode='patchy', division=False,
            active_motion=False, transporter_polarity=False,
        ),
    )
    _record(
        rows, 'active_control_improves_patch_access_in_controlled_seed',
        adaptive_60['mean_fuel_patch_distance'] < no_motion_60['mean_fuel_patch_distance'] * 0.75
        and adaptive_60['mean_margin_over_life'] > no_motion_60['mean_margin_over_life'],
        'distance {:.6f} vs {:.6f}; margin {:.6f} vs {:.6f}'.format(
            adaptive_60['mean_fuel_patch_distance'], no_motion_60['mean_fuel_patch_distance'],
            adaptive_60['mean_margin_over_life'], no_motion_60['mean_margin_over_life'],
        ),
        'with identical seed, active control approaches fuel and sustains a larger margin',
    )

    # 12. Plasticity gives a smaller but measurable advantage in the same patchy seed.
    no_plasticity_60 = soma.run_headless_trial(
        seed=101, seconds=60.0,
        config=soma.SensorimotorConfig(
            environment_mode='patchy', division=False,
            plasticity=False, causal_perturbation=False,
        ),
    )
    _record(
        rows, 'lifetime_plasticity_improves_controlled_patchy_trial',
        adaptive_60['mean_margin_over_life'] > no_plasticity_60['mean_margin_over_life']
        and adaptive_60['controller_updates'] > 0,
        'margin {:.6f} vs {:.6f}; updates={}'.format(
            adaptive_60['mean_margin_over_life'],
            no_plasticity_60['mean_margin_over_life'],
            adaptive_60['controller_updates'],
        ),
        'the adaptive twin has a higher integrated margin and performs local updates',
    )

    # 13. After chemistry reversal, plasticity reduces toxic fuel exposure in this seed.
    reversal = soma.run_headless_trial(
        seed=101, seconds=80.0,
        config=soma.SensorimotorConfig(
            environment_mode='reversal', switch_age=45.0, division=False,
        ),
    )
    reversal_fixed = soma.run_headless_trial(
        seed=101, seconds=80.0,
        config=soma.SensorimotorConfig(
            environment_mode='reversal', switch_age=45.0, division=False,
            plasticity=False, causal_perturbation=False,
        ),
    )
    _record(
        rows, 'plasticity_reduces_contamination_after_reversal_in_controlled_seed',
        reversal['fuel_contamination_total'] < reversal_fixed['fuel_contamination_total'] * 0.80
        and reversal['mean_margin_over_life'] > reversal_fixed['mean_margin_over_life'],
        'contamination {:.6f} vs {:.6f}; margin {:.6f} vs {:.6f}'.format(
            reversal['fuel_contamination_total'], reversal_fixed['fuel_contamination_total'],
            reversal['mean_margin_over_life'], reversal_fixed['mean_margin_over_life'],
        ),
        'the adaptive cell receives less newly harmful fuel and retains more self-production',
    )

    # 14. Full physical chemistry still reaches a material first division.
    division_world = soma.SensorimotorWorld(
        seed=101, initial_cells=1,
        config=soma.SensorimotorConfig(environment_mode='patchy'),
    )
    dt = 1.0 / soma.SIM_HZ
    first_division_age = None
    for _ in range(int(190.0 * soma.SIM_HZ)):
        division_world.step(dt)
        if division_world.divisions:
            first_division_age = division_world.age
            break
    division_summary = division_world.summary()
    division_ok = bool(
        first_division_age is not None
        and division_summary['cells'] == 2
        and division_summary['max_generation'] >= 1
        and abs(division_summary['division_residual']) < 1e-12
        and all(len(cell.genomes) >= 1 for cell in division_world.living_cells())
    )
    _record(
        rows, 'full_spatial_chemistry_reaches_conservative_G1_division', division_ok,
        'age={}, cells={}, G={}, residual={:.3e}'.format(
            first_division_age, division_summary['cells'],
            division_summary['max_generation'], division_summary['division_residual'],
        ),
        'one founder yields two G1 daughters with genomes and zero division ledger error',
    )

    # 15. Labile controller state is inherited only in attenuated material form.
    inherited_values = []
    if division_world.divisions:
        # Natural parent values are unavailable after replacement, so perform a
        # controlled material split with a marked phosphorylation state.
        marked_world = soma.SensorimotorWorld(seed=19, initial_cells=1)
        marked = marked_world.cells[0]
        marked_fp = _sensor_fingerprint(marked, soma.LIGAND_FUEL)
        marked.controller_phosphorylation[marked_fp] = 1.0
        marked.meaning_mean[soma.LIGAND_FUEL] = 0.8
        marked.genomes.append(marked.genomes[0].copy())
        marked.genome_lesions.append(0.0)
        marked.division_progress = 1.0
        marked.septum_mass = 0.12
        daughters = marked.split(marked_world)
        if daughters is not None:
            inherited_values = [
                daughter.controller_phosphorylation.get(marked_fp, 0.0)
                for daughter in daughters
            ]
    _record(
        rows, 'controller_state_inheritance_is_attenuated_not_free_weight_copy',
        len(inherited_values) == 2
        and all(0.0 < value < 1.0 for value in inherited_values)
        and max(abs(value - 0.58) for value in inherited_values) < 1e-12,
        inherited_values,
        'daughters inherit 58% of parental protein phosphorylation rather than a full abstract weight',
    )

    # 16. Two complete genomes suppress a gratuitous third copy before division.
    copy_world = soma.SensorimotorWorld(seed=21, initial_cells=1)
    copy_cell = copy_world.cells[0]
    copy_cell.genomes.append(copy_cell.genomes[0].copy())
    copy_cell.genome_lesions.append(0.0)
    copy_cell.replication_template = None
    before_copies = len(copy_cell.genomes)
    for _ in range(40):
        copy_cell._replicate_genome(copy_world, 0.1, copy_world.config)
    _record(
        rows, 'division_checkpoint_prevents_free_third_genome_copy',
        len(copy_cell.genomes) == before_copies and copy_cell.replication_template is None,
        'copies={}, template={}'.format(
            len(copy_cell.genomes), copy_cell.replication_template is not None
        ),
        'with two complete material genomes the replicator waits for division',
    )

    # 17. Exact file save/restore continuation includes the labile controller state.
    persistence = soma.SensorimotorWorld(
        seed=23, initial_cells=1,
        config=soma.SensorimotorConfig(environment_mode='reversal', switch_age=18.0),
    )
    for _ in range(220):
        persistence.step(dt)
    with tempfile.NamedTemporaryFile(suffix='.pkl', delete=False) as handle:
        path = handle.name
    try:
        persistence.save(path)
        restored = soma.SensorimotorWorld.load(path)
        for _ in range(160):
            persistence.step(dt)
            restored.step(dt)
        equal = _state_equal(persistence.state_dict(), restored.state_dict())
    finally:
        try:
            os.remove(path)
        except OSError:
            pass
    _record(
        rows, 'save_restore_continues_bit_exactly', equal,
        'equal={}'.format(equal),
        'after file restoration all material, genome, receptor, controller and RNG states match',
    )

    # 18. A fresh finite run keeps the cumulative material ledger within tolerance.
    gc.collect()
    ledger_world = soma.SensorimotorWorld(
        seed=29, initial_cells=1,
        config=soma.SensorimotorConfig(environment_mode='patchy', division=False),
    )
    max_residual = 0.0
    for _ in range(int(30.0 * soma.SIM_HZ)):
        ledger_world.step(dt)
        max_residual = max(
            max_residual, abs(float(ledger_world.summary()['matter_residual']))
        )
    _record(
        rows, 'sensorimotor_world_remains_finite_and_materially_accounted',
        ledger_world.finite() and max_residual < 3.0e-5,
        'finite={}, max_abs_residual={:.3e}'.format(
            ledger_world.finite(), max_residual
        ),
        'all state remains finite and the coarse material ledger stays below 3e-5',
    )

    fields = ('test', 'pass', 'observed', 'criterion')
    with open(CSV_PATH, 'w', encoding='utf-8', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

    passed = sum(row['pass'] == 'PASS' for row in rows)
    lines = [
        'SOMA-CELL 0.4 VALIDATION',
        '========================',
        '',
        'Result: {}/{} PASS'.format(passed, len(rows)),
        '',
    ]
    for row in rows:
        lines.extend([
            '[{}] {}'.format(row['pass'], row['test']),
            '  observed: {}'.format(row['observed']),
            '  criterion: {}'.format(row['criterion']),
        ])
    with open(TXT_PATH, 'w', encoding='utf-8') as handle:
        handle.write('\n'.join(lines) + '\n')

    print('\n'.join(lines))
    if passed != len(rows):
        raise SystemExit('validation failed: {}/{} PASS'.format(passed, len(rows)))
    return rows


if __name__ == '__main__':
    run_validation()
