# coding: utf-8
"""Mechanism validation for SOMA-CELL 0.1.

The checks are intentionally causal / ablation-oriented.  They do not prove
that the model is life; they test that the claimed material mechanisms are
actually necessary for the behaviours attributed to them.
"""

from __future__ import print_function

import csv
import math
import os
import tempfile

import numpy as np

import SOMA_CELL_0_1_pythonista as cellmod


OUT_CSV = os.path.join(os.path.dirname(__file__), 'soma_cell_0_1_validation.csv')
OUT_TXT = os.path.join(os.path.dirname(__file__), 'SOMA_CELL_0_1_VALIDATION_RESULTS.txt')
DT = 1.0 / cellmod.SIM_HZ


def advance(world, seconds, periodic_puncture=False):
    steps = int(round(float(seconds) * cellmod.SIM_HZ))
    for step in range(steps):
        if (
            periodic_puncture
            and step > 0
            and step % int(30 * cellmod.SIM_HZ) == 0
            and world.living_cells()
        ):
            target = world.living_cells()[0]
            angle = (step / 137.0) % (2.0 * math.pi)
            removed = target.puncture(angle, severity=0.80)
            world.field.add_particle(
                cellmod.PARTICLE_WASTE,
                target.pos,
                removed,
                count_as_injection=False,
            )
        world.step(DT)
        if not world.living_cells():
            break
    return world


def max_state_difference(first, second):
    difference = abs(first.age - second.age)
    if len(first.cells) != len(second.cells):
        return float('inf')
    if first.field.pos.shape != second.field.pos.shape:
        return float('inf')
    if not np.array_equal(first.field.kind, second.field.kind):
        return float('inf')
    if len(first.field.amount):
        difference = max(
            difference,
            float(np.max(np.abs(first.field.pos - second.field.pos))),
            float(np.max(np.abs(first.field.amount - second.field.amount))),
        )
    for a, b in zip(first.cells, second.cells):
        if (a.cell_id, a.generation, a.alive) != (b.cell_id, b.generation, b.alive):
            return float('inf')
        for x, y in (
            (a.pos, b.pos),
            (a.vel, b.vel),
            (a.membrane, b.membrane),
            (a.transporters, b.transporters),
            (a.pools, b.pools),
            (a.contact_trace, b.contact_trace),
            (a.damage_trace, b.damage_trace),
        ):
            difference = max(difference, float(np.max(np.abs(x - y))))
        difference = max(
            difference,
            abs(a.radius - b.radius),
            abs(a.division_progress - b.division_progress),
            abs(a.septum_mass - b.septum_mass),
        )
    return difference


def record(rows, name, passed, **metrics):
    row = {'test': name, 'pass': bool(passed)}
    row.update(metrics)
    rows.append(row)
    status = 'PASS' if passed else 'FAIL'
    metric_text = ', '.join('{}={}'.format(key, value) for key, value in metrics.items())
    print('{:<5} {:<46} {}'.format(status, name, metric_text))


def run_validation():
    rows = []

    # 1. There is no fixed scalar health/integrity state to repair by fiat.
    inspection = cellmod.SomaCellWorld(seed=7, initial_cells=1)
    inspected_cell = inspection.cells[0]
    no_scalar_health = not hasattr(inspected_cell, 'health') and not hasattr(inspected_cell, 'integrity')
    record(
        rows,
        'no fixed scalar health/integrity variable',
        no_scalar_health,
        has_health=int(hasattr(inspected_cell, 'health')),
        has_integrity=int(hasattr(inspected_cell, 'integrity')),
    )

    # 2. Intact membrane excludes matter without a transporter; a physical gap
    # permits a small passive crossing of the same molecule.
    boundary_cfg = cellmod.CellConfig(
        transport=False,
        external_inflow=False,
        environmental_damage=False,
        division=False,
    )
    intact = cellmod.SomaCellWorld(seed=9, initial_cells=1, config=boundary_cfg)
    punctured = intact.clone()
    for world in (intact, punctured):
        world.field.pos = np.empty((0, 2), dtype=float)
        world.field.kind = np.empty((0,), dtype=np.int16)
        world.field.amount = np.empty((0,), dtype=float)
        world.cells[0].pools[cellmod.POOL_FUEL] = 0.0
        world.cells[0].pools[cellmod.POOL_ATP] = 0.0
    removed_boundary = punctured.cells[0].puncture(0.0, severity=0.86)
    punctured.field.add_particle(
        cellmod.PARTICLE_WASTE, punctured.cells[0].pos, removed_boundary
    )
    for world in (intact, punctured):
        cell = world.cells[0]
        surface = (cell.pos + np.array([cell.radius, 0.0])) % 1.0
        world.field.add_particle(cellmod.PARTICLE_FUEL, surface, 0.20)
        # This is a deliberately constructed boundary assay, so establish its
        # own ledger baseline after arranging the molecules.
        world.initial_total_material = world.total_material()
        world.field.injected_material = 0.0
        world.field.dissipated_material = 0.0
    intact.cells[0].surface_exchange(intact.field, 1.0, intact.config)
    punctured.cells[0].surface_exchange(punctured.field, 1.0, punctured.config)
    intact_crossing = float(intact.cells[0].pools[cellmod.POOL_FUEL])
    gap_crossing = float(punctured.cells[0].pools[cellmod.POOL_FUEL])
    record(
        rows,
        'dynamic boundary creates inside/outside asymmetry',
        intact_crossing < 1e-12 and gap_crossing > 1e-4,
        intact_crossing='%.3e' % intact_crossing,
        gap_crossing='%.3e' % gap_crossing,
    )

    # 3. Material is preferentially assembled at a damaged segment rather than
    # merely increasing every segment equally.
    base = cellmod.SomaCellWorld(
        seed=111,
        initial_cells=1,
        config=cellmod.CellConfig(environmental_damage=False),
    )
    advance(base, 80.0)
    targeted = base.clone()
    uniform = base.clone()
    targeted.config.targeted_repair = True
    uniform.config.targeted_repair = False
    for world in (targeted, uniform):
        removed = world.cells[0].puncture(0.0, severity=0.72)
        world.field.add_particle(cellmod.PARTICLE_WASTE, world.cells[0].pos, removed)
    advance(targeted, 2.0)
    advance(uniform, 2.0)
    targeted_mass = float(targeted.cells[0].membrane[0])
    uniform_mass = float(uniform.cells[0].membrane[0])
    record(
        rows,
        'local membrane repair targets the puncture',
        targeted_mass > uniform_mass + 0.003,
        targeted_segment='%.6f' % targeted_mass,
        uniform_segment='%.6f' % uniform_mass,
    )

    # 4-5. In a favourable chemistry, the complete loop builds enough new
    # boundary and catalyst to divide; material is conserved through the split.
    full = cellmod.SomaCellWorld(
        seed=101,
        initial_cells=1,
        config=cellmod.CellConfig(environmental_damage=False),
    )
    first_division_age = None
    for _ in range(int(360 * cellmod.SIM_HZ)):
        full.step(DT)
        if full.divisions > 0:
            first_division_age = full.age
            break
    full_summary = full.summary()
    record(
        rows,
        'complete catalytic-boundary loop divides',
        full.divisions >= 1 and full_summary['cells'] >= 2,
        division_age='%.2f' % (first_division_age or -1.0),
        cells=full_summary['cells'],
        generation=full_summary['max_generation'],
    )
    record(
        rows,
        'division conserves material',
        abs(full.division_residual) < 1e-10,
        division_residual='%.3e' % full.division_residual,
        matter_residual='%.3e' % full.matter_ledger_residual(),
    )

    # 6. A closed membrane without transporters cannot replenish fuel.  The
    # catalytic loop goes quiescent and division is absent.
    no_transport = cellmod.SomaCellWorld(
        seed=101,
        initial_cells=1,
        config=cellmod.CellConfig(
            transport=False,
            environmental_damage=False,
        ),
    )
    advance(no_transport, 300.0)
    no_transport_summary = no_transport.summary()
    record(
        rows,
        'membrane transport is required for sustained closure',
        no_transport.divisions == 0 and no_transport_summary['mean_loop'] < 0.05,
        divisions=no_transport.divisions,
        loop='%.5f' % no_transport_summary['mean_loop'],
        atp='%.5f' % no_transport_summary['mean_atp'],
    )

    # 7. Existing catalysts can persist for a while, but without autocatalytic
    # replacement the reproduction threshold is not reached.
    no_catalyst_replication = cellmod.SomaCellWorld(
        seed=101,
        initial_cells=1,
        config=cellmod.CellConfig(
            catalyst_synthesis=False,
            environmental_damage=False,
        ),
    )
    advance(no_catalyst_replication, 360.0)
    nc_summary = no_catalyst_replication.summary()
    record(
        rows,
        'autocatalytic catalyst replacement is required for reproduction',
        no_catalyst_replication.divisions == 0 and nc_summary['mean_catalyst'] < 0.30,
        divisions=no_catalyst_replication.divisions,
        catalyst='%.5f' % nc_summary['mean_catalyst'],
        membrane='%.5f' % nc_summary['mean_membrane'],
    )

    # 8. Metabolic waste is not a cosmetic variable.  Preventing export causes
    # self-poisoning and eventual dissolution under the same external supply.
    no_export = cellmod.SomaCellWorld(
        seed=101,
        initial_cells=1,
        config=cellmod.CellConfig(
            waste_export=False,
            environmental_damage=False,
        ),
    )
    advance(no_export, 430.0)
    ne_summary = no_export.summary()
    record(
        rows,
        'waste export is required for long-lived metabolism',
        ne_summary['cells'] == 0 and no_export.deaths >= 1,
        extinction_age='%.2f' % no_export.age,
        deaths=no_export.deaths,
        external_waste='%.5f' % ne_summary['external_waste'],
    )

    # 9. A membrane that cannot be manufactured may temporarily shrink and
    # redistribute lipids, but repeated punctures ultimately destroy closure.
    damaged_full = cellmod.SomaCellWorld(
        seed=101,
        initial_cells=1,
        config=cellmod.CellConfig(environmental_damage=False),
    )
    damaged_no_membrane = cellmod.SomaCellWorld(
        seed=101,
        initial_cells=1,
        config=cellmod.CellConfig(
            membrane_synthesis=False,
            environmental_damage=False,
        ),
    )
    advance(damaged_full, 420.0, periodic_puncture=True)
    advance(damaged_no_membrane, 420.0, periodic_puncture=True)
    record(
        rows,
        'new membrane material is required under repeated injury',
        bool(damaged_full.living_cells()) and not damaged_no_membrane.living_cells(),
        full_cells=len(damaged_full.living_cells()),
        no_synthesis_cells=len(damaged_no_membrane.living_cells()),
        full_closure='%.4f' % damaged_full.summary()['mean_closure'],
        no_synthesis_age='%.2f' % damaged_no_membrane.age,
    )

    # 10. When a cell dissolves, its matter returns to the external chemistry;
    # only ATP is dissipated as energy.
    record(
        rows,
        'lysis returns material to the environment',
        (
            not no_export.living_cells()
            and no_export.summary()['cell_material'] == 0.0
            and abs(no_export.matter_ledger_residual()) < 1e-4
        ),
        external_material='%.6f' % no_export.summary()['external_material'],
        ledger_residual='%.3e' % no_export.matter_ledger_residual(),
    )

    # 11. Loading is a true continuation, including the RNG stream.
    deterministic = cellmod.SomaCellWorld(seed=123, initial_cells=1)
    advance(deterministic, 50.0)
    save_path = os.path.join(tempfile.gettempdir(), 'soma_cell_validation_save.pkl')
    try:
        deterministic.save(save_path)
        restored = cellmod.SomaCellWorld.load(save_path)
    finally:
        try:
            os.remove(save_path)
        except Exception:
            pass
    for _ in range(300):
        deterministic.step(DT)
        restored.step(DT)
    deterministic_difference = max_state_difference(deterministic, restored)
    record(
        rows,
        'save/restore preserves the exact future trajectory',
        deterministic_difference == 0.0,
        max_difference='%.3e' % deterministic_difference,
    )

    # 12. Instrumentation must not consume the organism/world RNG or perturb the
    # trajectory it is meant to measure.
    logger_a = cellmod.SomaCellWorld(seed=321, initial_cells=1)
    logger_b = logger_a.clone()
    temporary_path = os.path.join(tempfile.gettempdir(), 'soma_cell_logger_neutrality.csv')
    try:
        if os.path.exists(temporary_path):
            os.remove(temporary_path)
        logger = cellmod.LongRunLogger(logger_a, path=temporary_path)
        logger.log(logger_a, reason='validation', force=True)
        for _ in range(200):
            logger_a.step(DT)
            logger_b.step(DT)
        logger_difference = max_state_difference(logger_a, logger_b)
    finally:
        try:
            os.remove(temporary_path)
        except Exception:
            pass
    record(
        rows,
        'long-run logger does not alter the simulated future',
        logger_difference == 0.0,
        max_difference='%.3e' % logger_difference,
    )

    # 13. Across all tests, every numerical state remains finite and material
    # ledger error stays tiny relative to the total material handled.
    worlds = [
        inspection, intact, punctured, targeted, uniform, full,
        no_transport, no_catalyst_replication, no_export,
        damaged_full, damaged_no_membrane, deterministic, restored,
        logger_a, logger_b,
    ]
    all_finite = all(world.finite() for world in worlds)
    max_ledger = max(abs(world.matter_ledger_residual()) for world in worlds)
    record(
        rows,
        'finite numerics and bounded material-ledger error',
        all_finite and max_ledger < 1e-4,
        all_finite=int(all_finite),
        max_abs_ledger='%.3e' % max_ledger,
    )

    # CSV with a stable union of all metric columns.
    fieldnames = ['test', 'pass']
    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)
    with open(OUT_CSV, 'w', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    passed = sum(bool(row['pass']) for row in rows)
    lines = [
        'SOMA-CELL 0.1 validation',
        'result: {}/{} PASS'.format(passed, len(rows)),
        '',
    ]
    for row in rows:
        metrics = [
            '{}={}'.format(key, value)
            for key, value in row.items()
            if key not in ('test', 'pass') and value not in ('', None)
        ]
        lines.append(
            '{}  {}{}'.format(
                'PASS' if row['pass'] else 'FAIL',
                row['test'],
                ('  ' + ', '.join(metrics)) if metrics else '',
            )
        )
    lines.extend([
        '',
        'These checks validate implementation claims, not a philosophical or',
        'biological proof that the simulated system is life.',
    ])
    with open(OUT_TXT, 'w', encoding='utf-8') as handle:
        handle.write('\n'.join(lines) + '\n')

    return passed, len(rows), rows


if __name__ == '__main__':
    passed, total, _ = run_validation()
    if passed != total:
        raise SystemExit('validation failed: {}/{} passed'.format(passed, total))
