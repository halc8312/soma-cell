# coding: utf-8
"""
SOMA-2 — Causal Escrow Morphogenesis / 因果エスクロー形態形成
Pythonista 3向け・単体人工生命の第3段階

依存ファイル
------------
同じフォルダに SOMA_1_pythonista.py を置いてください。
SOMA-1の因果栄養組織を継承し、次の二つを加えます。

1. 因果監査（causal audit）
   細胞が「身体維持に役立った」と推定しただけでは信用しません。
   推定上位の細胞群と、運動影響量をそろえた対照群を短時間ずつ
   出力遮断し、身体負債の悪化差を測ります。これは生涯内の小さな
   無作為化介入試験です。

2. 器官仮説（organ hypothesis）
   監査を通った細胞群だけが、8方向の身体スロットへ
   - 化学・温度センサー
   - 推進フィン
   - 防護・断熱シェル
   の成長／縮小案を提案します。候補器官はすぐ固定せず、オン／オフを
   ランダムに切り替える交差試験に置きます。4種類の身体負債が独立に
   賛否を出し、少なくとも一つの必要な次元を改善し、他の次元から
   拒否票が出ないときだけ定着します。

普通のニューラルネットワークとの違い
------------------------------------
- 固定された入力器・出力器を前提にしない。
- 相関的なクレジットを、実介入で監査する。
- 形態変更を最適化変数ではなく、身体が実際に試す反証可能な仮説にする。
- 単一報酬で器官を採択せず、身体の各維持系に拒否権を残す。

注意
----
研究仮説を動く形にした実験モデルです。意識・本物の生命・学術的新規性を
証明するものではありません。既知のnode perturbation、self-modeling、
developmental robotics、adaptive morphologyを踏まえた、新しい組み合わせの
候補です。

操作
----
- 画面タップ: 最寄りの黄色い栄養体をタップ位置へ移動
- 死亡後にタップ: 学習・監査・形態を維持したまま身体を再生
- 完全な新生個体: soma2_life.npz を削除
"""

import json
import math
import os
import time

import numpy as np

from SOMA_1_pythonista import (
    ACTION_COUNT,
    ARENA_BOTTOM,
    BODY_RADIUS,
    CELL_COUNT,
    HUD_HEIGHT,
    IN_PYTHONISTA,
    LANDSCAPE,
    MAX_SPEED,
    NUTRIENT_COUNT,
    NUTRIENT_RADIUS,
    SENSOR_COUNT,
    SHELTER_COUNT,
    SHELTER_RADIUS,
    TROPHIC_COUNT,
    TOXIN_COUNT,
    TOXIN_RADIUS,
    CausalTrophicTissue,
    SomaOneCore,
    clamp,
    encode_rng_state,
    restore_rng_state,
    stable_softmax,
    wrapped_delta,
)

if IN_PYTHONISTA:
    import ui
    from scene import Scene, ShapeNode, SpriteNode, LabelNode, run
else:
    ui = None
    Scene = object
    ShapeNode = SpriteNode = LabelNode = None
    run = None


SAVE_FILE = os.path.join(os.path.dirname(__file__), 'soma2_life.npz')
SAVE_VERSION = 3

MORPH_SLOT_COUNT = 8
MORPH_MODALITY_COUNT = 4
TRIAL_EPOCH_COUNT = 8

MORPH_SENSOR = 0
MORPH_FIN = 1
MORPH_SHELL = 2
MORPH_KIND_NAMES = ('sensor', 'fin', 'shell')
MORPH_MODALITY_NAMES = ('chemical-A', 'chemical-B', 'chemical-C', 'thermal')


# =============================================================================
# Small utilities
# =============================================================================


def scalar_array(value, dtype=float):
    return np.array(value, dtype=dtype)


def bool_array(value):
    return np.array(1 if value else 0, dtype=np.uint8)


def safe_float(value, default=0.0):
    try:
        result = float(value)
    except (TypeError, ValueError):
        return float(default)
    return result if np.isfinite(result) else float(default)


def circular_slot(vector, slot_count=MORPH_SLOT_COUNT, rng=None):
    vector = np.asarray(vector, dtype=float)
    length = float(np.linalg.norm(vector))
    if length < 1e-8:
        if rng is None:
            return 0
        return int(rng.integers(slot_count))
    angle = math.atan2(float(vector[1]), float(vector[0])) % (2.0 * math.pi)
    return int(round(angle / (2.0 * math.pi) * slot_count)) % slot_count


# =============================================================================
# Audited causal trophic tissue
# =============================================================================


class AuditedCausalTissue(CausalTrophicTissue):
    """SOMA-1 tissue with an externally supplied causal verification gate.

    The inherited correlational estimate remains available for exploration.
    Trophic allocation, however, is attenuated until independent knockout
    audits have supported the claim. The intervention is an efferent knockout:
    selected cells keep their internal state but cannot cast motor votes.
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.audit_gate = np.zeros((self.n_cell, self.n_trophic), dtype=float)
        self.efferent_gate = np.ones(self.n_cell, dtype=float)
        self.verified_strength = 0.0

    def set_audit_gate(self, gate):
        gate = np.asarray(gate, dtype=float)
        if gate.shape != (self.n_cell, self.n_trophic):
            raise ValueError('audit gate has incompatible shape')
        self.audit_gate = np.clip(gate, 0.0, 1.0)
        verified = np.maximum(self.causal_estimate, 0.0) * self.audit_gate
        self.verified_strength = float(np.mean(verified))

    def set_efferent_knockout(self, mask=None):
        self.efferent_gate[:] = 1.0
        if mask is not None:
            mask = np.asarray(mask, dtype=bool)
            if mask.shape != (self.n_cell,):
                raise ValueError('knockout mask has incompatible shape')
            self.efferent_gate[mask] = 0.0

    def act(self, sensor, body_debt, dt):
        # Let SOMA-1 update all recurrent states and local traces first.
        action = super().act(sensor, body_debt, dt)
        if np.all(self.efferent_gate > 0.999):
            return action

        # Recompute only the body-facing motor vote with the audited gate.
        self.vitality = self._cell_vitality()
        influence = 0.45 + 0.55 * np.sqrt(self.vitality)
        effective_motor = (
            self.motor
            + self.last_motor_sigma[:, None] * self.motor_probe
        )
        effective_hidden = self.hidden * self.efferent_gate
        raw_action = np.sum(
            influence[:, None]
            * effective_hidden[:, None]
            * effective_motor,
            axis=0,
        ) / math.sqrt(self.n_cell)
        action = np.tanh(3.8 * raw_action)
        self.last_action = action.copy()

        # The local predictor must receive the action that the body actually saw.
        self.last_predict_feature[:, 1] = action[0]
        self.last_predict_feature[:, 2] = action[1]
        self.prediction = np.tanh(
            np.sum(self.predict_w * self.last_predict_feature, axis=1)
        )
        return action

    def _update_trophic_economy(self, next_debt, advantage, local_need, dt):
        # Keep a small exploratory floor; otherwise the first audit could never
        # accumulate enough viable tissue to be run. Above the floor, bodily
        # currency follows independently verified evidence.
        raw_estimate = self.causal_estimate
        gated_estimate = raw_estimate * (0.10 + 0.90 * self.audit_gate)
        self.causal_estimate = gated_estimate
        try:
            super()._update_trophic_economy(
                next_debt=next_debt,
                advantage=advantage,
                local_need=local_need,
                dt=dt,
            )
        finally:
            self.causal_estimate = raw_estimate

    def diagnostics(self):
        result = super().diagnostics()
        result['verified_strength'] = float(self.verified_strength)
        result['verified_coverage'] = float(np.mean(self.audit_gate))
        return result


# =============================================================================
# Causal audit: top-claim knockout versus matched sham knockout
# =============================================================================


class CausalAuditor:
    """Runs small within-life randomized intervention audits.

    One audit compares two arms:
    - claimed cells: strongest positive causal claim for one currency
    - sham cells: similar current motor influence, weak claim

    Each arm receives a neutral baseline followed by an efferent knockout.
    Arm order is randomized. A positive audit effect means that knocking out
    the claimed group worsened the target debt more than knocking out the sham.
    """

    STAGE_BASELINE = 0
    STAGE_KNOCKOUT = 1
    STAGE_WASHOUT = 2

    def __init__(self, seed=0, enabled=True, group_size=5):
        self.rng = np.random.default_rng(int(seed) ^ 0xC0A51A7)
        self.enabled = bool(enabled)
        self.group_size = int(group_size)

        shape = (CELL_COUNT, TROPHIC_COUNT)
        self.effect_mean = np.zeros(shape, dtype=float)
        self.effect_m2 = np.zeros(shape, dtype=float)
        self.effect_count = np.zeros(shape, dtype=np.int64)

        self.active = False
        self.currency = 0
        self.claimed_mask = np.zeros(CELL_COUNT, dtype=bool)
        self.sham_mask = np.zeros(CELL_COUNT, dtype=bool)
        self.arm_order = np.array([0, 1], dtype=np.int8)  # 0 claimed, 1 sham
        self.arm_index = 0
        self.stage = self.STAGE_BASELINE
        self.stage_elapsed = 0.0
        self.stage_duration = 1.8
        self.stage_start_debt = np.zeros(TROPHIC_COUNT, dtype=float)
        self.baseline_slope = np.zeros((2, TROPHIC_COUNT), dtype=float)
        self.knockout_slope = np.zeros((2, TROPHIC_COUNT), dtype=float)
        self.cooldown = 8.0
        self.last_started_age = -1e9
        self.last_finished_age = -1e9

        self.completed = 0
        self.passed = 0
        self.failed = 0
        self.last_effect = np.zeros(TROPHIC_COUNT, dtype=float)
        self.last_target_effect = 0.0
        self.last_claim_strength = 0.0
        self.last_status = 'unverified'
        self._currency_cursor = -1

    # ------------------------------------------------------------------
    # Evidence and selection
    # ------------------------------------------------------------------

    def gate(self):
        count = self.effect_count.astype(float)
        variance = np.zeros_like(self.effect_mean)
        valid = count > 1.0
        variance[valid] = self.effect_m2[valid] / np.maximum(
            count[valid] - 1.0, 1.0
        )
        standard_error = np.sqrt(np.maximum(variance, 0.0)) / np.sqrt(
            np.maximum(count, 1.0)
        )
        signal = self.effect_mean / (0.00045 + standard_error)
        confidence = 0.5 + 0.5 * np.tanh(signal)
        coverage = 1.0 - np.exp(-count / 2.5)
        gate = coverage * confidence
        # Negative measured effects should close the gate quickly.
        gate[self.effect_mean < -0.00025] *= 0.10
        return np.clip(gate, 0.0, 1.0)

    def verified_matrix(self, brain):
        return np.maximum(brain.causal_estimate, 0.0) * self.gate()

    def _choose_currency(self, brain, debt):
        self._currency_cursor = (self._currency_cursor + 1) % TROPHIC_COUNT
        claim = np.mean(np.maximum(brain.causal_estimate, 0.0), axis=0)
        urgency = 0.25 + np.asarray(debt, dtype=float)
        fairness = np.full(TROPHIC_COUNT, 0.04)
        fairness[self._currency_cursor] += 0.10
        score = claim * urgency + fairness
        return int(np.argmax(score))

    def _select_groups(self, brain, currency):
        motor_norm = np.linalg.norm(brain.motor, axis=1)
        live_influence = (
            np.abs(brain.hidden)
            * (0.20 + motor_norm)
            * (0.35 + 0.65 * brain.vitality)
        )
        claim = np.maximum(brain.causal_estimate[:, currency], 0.0)
        claimed_score = claim * (0.15 + live_influence)
        claimed_indices = np.argsort(claimed_score)[-self.group_size:]

        claimed = np.zeros(CELL_COUNT, dtype=bool)
        claimed[claimed_indices] = True

        # Match each claimed cell to a weak-claim cell with similar current
        # motor influence. This reduces the trivial explanation that any group
        # with larger output magnitude would have a larger knockout effect.
        candidate = ~claimed
        weak_threshold = float(np.quantile(claim, 0.60))
        candidate &= claim <= weak_threshold + 1e-12
        available = list(np.flatnonzero(candidate))
        sham_indices = []
        for source in claimed_indices:
            if not available:
                break
            source_influence = live_influence[source]
            distances = np.array([
                abs(float(live_influence[index]) - float(source_influence))
                + 0.02 * self.rng.random()
                for index in available
            ])
            pick_pos = int(np.argmin(distances))
            sham_indices.append(available.pop(pick_pos))

        if len(sham_indices) < self.group_size:
            remainder = [
                index for index in np.argsort(claim)
                if not claimed[index] and index not in sham_indices
            ]
            sham_indices.extend(
                remainder[:self.group_size - len(sham_indices)]
            )

        sham = np.zeros(CELL_COUNT, dtype=bool)
        sham[np.asarray(sham_indices[:self.group_size], dtype=int)] = True
        return claimed, sham, float(np.mean(claim[claimed]))

    # ------------------------------------------------------------------
    # State machine
    # ------------------------------------------------------------------

    @property
    def busy(self):
        return bool(self.active)

    def maybe_start(self, age, debt, brain, morphology_busy=False, force=False):
        if not self.enabled or self.active or morphology_busy:
            return False
        if not force:
            if self.cooldown > 0.0 or age < 18.0:
                return False
            # Do not deliberately disable motor output during acute crisis.
            if float(np.max(debt)) > 0.78:
                return False

        self.currency = self._choose_currency(brain, debt)
        (
            self.claimed_mask,
            self.sham_mask,
            self.last_claim_strength,
        ) = self._select_groups(brain, self.currency)
        if not np.any(self.claimed_mask) or not np.any(self.sham_mask):
            self.cooldown = 4.0
            return False

        self.arm_order = self.rng.permutation(np.array([0, 1], dtype=np.int8))
        self.arm_index = 0
        self.stage = self.STAGE_BASELINE
        self.stage_elapsed = 0.0
        self.stage_start_debt = np.asarray(debt, dtype=float).copy()
        self.baseline_slope[:] = 0.0
        self.knockout_slope[:] = 0.0
        self.active = True
        self.last_started_age = float(age)
        self.last_status = 'running'
        return True

    def current_knockout_mask(self):
        if not self.active or self.stage != self.STAGE_KNOCKOUT:
            return None
        arm = int(self.arm_order[self.arm_index])
        return self.claimed_mask if arm == 0 else self.sham_mask

    def tick_cooldown(self, dt):
        if not self.active:
            self.cooldown = max(0.0, self.cooldown - float(dt))

    def observe(self, debt_after, dt, age):
        if not self.active:
            self.tick_cooldown(dt)
            return False

        dt = float(dt)
        self.stage_elapsed += dt
        if self.stage_elapsed + 1e-12 < self.stage_duration:
            return False

        debt_after = np.asarray(debt_after, dtype=float)
        slope = (debt_after - self.stage_start_debt) / max(
            self.stage_elapsed, 1e-9
        )
        arm = int(self.arm_order[self.arm_index])

        if self.stage == self.STAGE_BASELINE:
            self.baseline_slope[arm] = slope
            self.stage = self.STAGE_KNOCKOUT
            self.stage_elapsed = 0.0
            self.stage_start_debt = debt_after.copy()
            return False

        if self.stage == self.STAGE_KNOCKOUT:
            self.knockout_slope[arm] = slope
            if self.arm_index == 0:
                self.stage = self.STAGE_WASHOUT
                self.stage_duration = 1.2
                self.stage_elapsed = 0.0
                self.stage_start_debt = debt_after.copy()
                return False
            self._finish(age)
            return True

        # Washout separates the two intervention arms.
        self.arm_index = 1
        self.stage = self.STAGE_BASELINE
        self.stage_duration = 1.8
        self.stage_elapsed = 0.0
        self.stage_start_debt = debt_after.copy()
        return False

    def _finish(self, age):
        adjusted_claimed = self.knockout_slope[0] - self.baseline_slope[0]
        adjusted_sham = self.knockout_slope[1] - self.baseline_slope[1]
        effect = adjusted_claimed - adjusted_sham
        self.last_effect = effect.copy()
        target_effect = float(effect[self.currency])
        self.last_target_effect = target_effect

        indices = np.flatnonzero(self.claimed_mask)
        for index in indices:
            count = int(self.effect_count[index, self.currency]) + 1
            old_mean = float(self.effect_mean[index, self.currency])
            delta = target_effect - old_mean
            new_mean = old_mean + delta / count
            delta2 = target_effect - new_mean
            self.effect_mean[index, self.currency] = new_mean
            self.effect_m2[index, self.currency] += delta * delta2
            self.effect_count[index, self.currency] = count

        self.completed += 1
        if target_effect > 0.00020:
            self.passed += 1
            self.last_status = 'supported'
        elif target_effect < -0.00020:
            self.failed += 1
            self.last_status = 'contradicted'
        else:
            self.last_status = 'inconclusive'

        self.active = False
        self.stage_duration = 1.8
        self.cooldown = 9.0
        self.last_finished_age = float(age)

    def status_text(self):
        if not self.enabled:
            return 'audit off'
        if not self.active:
            return self.last_status
        arm = int(self.arm_order[self.arm_index])
        arm_name = 'claim' if arm == 0 else 'sham'
        stage_name = {
            self.STAGE_BASELINE: 'base',
            self.STAGE_KNOCKOUT: 'KO',
            self.STAGE_WASHOUT: 'wash',
        }[self.stage]
        return '{}-{} k{}'.format(arm_name, stage_name, self.currency)

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def state_dict(self):
        return {
            'audit_rng_state': encode_rng_state(self.rng),
            'audit_enabled': bool_array(self.enabled),
            'audit_effect_mean': self.effect_mean,
            'audit_effect_m2': self.effect_m2,
            'audit_effect_count': self.effect_count,
            'audit_active': bool_array(self.active),
            'audit_currency': scalar_array(self.currency, np.int64),
            'audit_claimed_mask': self.claimed_mask.astype(np.uint8),
            'audit_sham_mask': self.sham_mask.astype(np.uint8),
            'audit_arm_order': self.arm_order,
            'audit_arm_index': scalar_array(self.arm_index, np.int64),
            'audit_stage': scalar_array(self.stage, np.int64),
            'audit_stage_elapsed': scalar_array(self.stage_elapsed),
            'audit_stage_duration': scalar_array(self.stage_duration),
            'audit_stage_start_debt': self.stage_start_debt,
            'audit_baseline_slope': self.baseline_slope,
            'audit_knockout_slope': self.knockout_slope,
            'audit_cooldown': scalar_array(self.cooldown),
            'audit_last_started_age': scalar_array(self.last_started_age),
            'audit_last_finished_age': scalar_array(self.last_finished_age),
            'audit_completed': scalar_array(self.completed, np.int64),
            'audit_passed': scalar_array(self.passed, np.int64),
            'audit_failed': scalar_array(self.failed, np.int64),
            'audit_last_effect': self.last_effect,
            'audit_last_target_effect': scalar_array(self.last_target_effect),
            'audit_last_claim_strength': scalar_array(self.last_claim_strength),
            'audit_currency_cursor': scalar_array(self._currency_cursor, np.int64),
            'audit_last_status': np.array(self.last_status),
        }

    def load_state(self, data):
        self.effect_mean = np.array(data['audit_effect_mean'], dtype=float)
        self.effect_m2 = np.array(data['audit_effect_m2'], dtype=float)
        self.effect_count = np.array(data['audit_effect_count'], dtype=np.int64)
        self.active = bool(int(data['audit_active']))
        self.currency = int(data['audit_currency'])
        self.claimed_mask = np.array(data['audit_claimed_mask'], dtype=bool)
        self.sham_mask = np.array(data['audit_sham_mask'], dtype=bool)
        self.arm_order = np.array(data['audit_arm_order'], dtype=np.int8)
        self.arm_index = int(data['audit_arm_index'])
        self.stage = int(data['audit_stage'])
        self.stage_elapsed = float(data['audit_stage_elapsed'])
        self.stage_duration = float(data['audit_stage_duration'])
        self.stage_start_debt = np.array(
            data['audit_stage_start_debt'], dtype=float
        )
        self.baseline_slope = np.array(data['audit_baseline_slope'], dtype=float)
        self.knockout_slope = np.array(data['audit_knockout_slope'], dtype=float)
        self.cooldown = float(data['audit_cooldown'])
        self.last_started_age = float(data['audit_last_started_age'])
        self.last_finished_age = float(data['audit_last_finished_age'])
        self.completed = int(data['audit_completed'])
        self.passed = int(data['audit_passed'])
        self.failed = int(data['audit_failed'])
        self.last_effect = np.array(data['audit_last_effect'], dtype=float)
        self.last_target_effect = float(data['audit_last_target_effect'])
        self.last_claim_strength = float(data['audit_last_claim_strength'])
        self._currency_cursor = int(data['audit_currency_cursor'])
        self.last_status = str(np.asarray(data['audit_last_status']).item())
        restore_rng_state(self.rng, data['audit_rng_state'])


# =============================================================================
# Escrow morphology: reversible organ trials with independent vetoes
# =============================================================================


class EscrowMorphology:
    """A body whose organs are hypotheses rather than fixed architecture."""

    def __init__(
        self,
        seed=0,
        enabled=True,
        require_audit=True,
        escrow_enabled=True,
        pareto_veto_enabled=True,
    ):
        self.rng = np.random.default_rng(int(seed) ^ 0xB0D1E5)
        self.enabled = bool(enabled)
        self.require_audit = bool(require_audit)
        self.escrow_enabled = bool(escrow_enabled)
        self.pareto_veto_enabled = bool(pareto_veto_enabled)

        self.slot_angles = np.linspace(
            0.0, 2.0 * math.pi, MORPH_SLOT_COUNT, endpoint=False
        )
        self.directions = np.column_stack((
            np.cos(self.slot_angles), np.sin(self.slot_angles)
        ))

        # A newborn has weak distributed receptors and small undifferentiated
        # fins/shell plates. Development can strengthen, relocate, or prune them.
        self.sensor = np.clip(
            self.rng.normal(
                0.16, 0.025, (MORPH_SLOT_COUNT, MORPH_MODALITY_COUNT)
            ),
            0.08,
            0.24,
        )
        self.fin = np.clip(
            self.rng.normal(0.10, 0.018, MORPH_SLOT_COUNT), 0.05, 0.18
        )
        self.shell = np.clip(
            self.rng.normal(0.07, 0.015, MORPH_SLOT_COUNT), 0.02, 0.14
        )
        self.material = 0.34

        self.active = False
        self.kind = MORPH_SENSOR
        self.slot = 0
        self.modality = 0
        self.delta = 0.0
        self.target_currency = 0
        self.reserve = 0.0
        self.sequence = np.zeros(TRIAL_EPOCH_COUNT, dtype=np.int8)
        self.epoch_index = 0
        self.epoch_elapsed = 0.0
        self.epoch_duration = 3.0
        self.epoch_improvement = np.zeros(TROPHIC_COUNT, dtype=float)
        self.epoch_rates = np.zeros(
            (TRIAL_EPOCH_COUNT, TROPHIC_COUNT), dtype=float
        )
        self.epoch_complete = np.zeros(TRIAL_EPOCH_COUNT, dtype=bool)
        self.trial_need_sum = np.zeros(TROPHIC_COUNT, dtype=float)
        self.trial_elapsed = 0.0
        self.cooldown = 14.0

        self.proposals = 0
        self.accepted = 0
        self.rejected = 0
        self.last_accepted = False
        self.last_effect = np.zeros(TROPHIC_COUNT, dtype=float)
        self.last_z = np.zeros(TROPHIC_COUNT, dtype=float)
        self.last_votes = np.zeros(TROPHIC_COUNT, dtype=np.int8)
        self.last_status = 'juvenile'
        self.last_proposal = 'none'

        # Memory lets rejected organ hypotheses become less likely without
        # forbidding retests after the body or environment has changed.
        # Sensor candidates use four modality channels; fin/shell use channel 0.
        self.hypothesis_mean = np.zeros(
            (3, MORPH_SLOT_COUNT, MORPH_MODALITY_COUNT, TROPHIC_COUNT),
            dtype=float,
        )
        self.hypothesis_count = np.zeros(
            (3, MORPH_SLOT_COUNT, MORPH_MODALITY_COUNT), dtype=np.int64
        )

    # ------------------------------------------------------------------
    # Effective phenotype
    # ------------------------------------------------------------------

    @property
    def busy(self):
        return bool(self.active)

    @property
    def treatment_on(self):
        return bool(
            self.active
            and 0 <= self.epoch_index < TRIAL_EPOCH_COUNT
            and self.sequence[self.epoch_index] == 1
        )

    def _candidate_channel(self):
        return int(self.modality) if self.kind == MORPH_SENSOR else 0

    def effective_arrays(self):
        sensor = self.sensor
        fin = self.fin
        shell = self.shell
        if not self.treatment_on:
            return sensor, fin, shell

        if self.kind == MORPH_SENSOR:
            sensor = self.sensor.copy()
            sensor[self.slot, self.modality] = clamp(
                sensor[self.slot, self.modality] + self.delta, 0.0, 1.0
            )
        elif self.kind == MORPH_FIN:
            fin = self.fin.copy()
            fin[self.slot] = clamp(fin[self.slot] + self.delta, 0.0, 1.0)
        else:
            shell = self.shell.copy()
            shell[self.slot] = clamp(
                shell[self.slot] + self.delta, 0.0, 1.0
            )
        return sensor, fin, shell

    def complexity(self):
        return float(
            0.50 * np.mean(self.sensor)
            + 0.28 * np.mean(self.fin)
            + 0.22 * np.mean(self.shell)
        )

    def organ_means(self):
        sensor, fin, shell = self.effective_arrays()
        return (
            float(np.mean(sensor)),
            float(np.mean(fin)),
            float(np.mean(shell)),
        )

    def construction_and_maintenance_cost(self):
        sensor, fin, shell = self.effective_arrays()
        sensor_cost = 0.00010 * float(np.sum(sensor))
        fin_cost = 0.00016 * float(np.sum(fin))
        shell_cost = 0.00013 * float(np.sum(shell))
        prototype = 0.00030 if self.treatment_on else 0.0
        return sensor_cost + fin_cost + shell_cost + prototype

    def local_shell(self, direction):
        _, _, shell = self.effective_arrays()
        direction = np.asarray(direction, dtype=float)
        length = float(np.linalg.norm(direction))
        if length < 1e-9:
            return float(np.mean(shell))
        unit = direction / length
        alignment = np.maximum(self.directions @ unit, 0.0) ** 3
        total = float(np.sum(alignment))
        if total < 1e-9:
            return float(np.mean(shell))
        return float(np.sum(alignment * shell) / total)

    def local_radius(self, direction):
        sensor, fin, shell = self.effective_arrays()
        direction = np.asarray(direction, dtype=float)
        length = float(np.linalg.norm(direction))
        if length < 1e-9:
            local_sensor = float(np.mean(sensor))
            local_fin = float(np.mean(fin))
            local_shell = float(np.mean(shell))
        else:
            unit = direction / length
            alignment = np.maximum(self.directions @ unit, 0.0) ** 4
            total = max(float(np.sum(alignment)), 1e-9)
            local_sensor = float(
                np.sum(alignment * np.mean(sensor, axis=1)) / total
            )
            local_fin = float(np.sum(alignment * fin) / total)
            local_shell = float(np.sum(alignment * shell) / total)
        return BODY_RADIUS * (
            1.0 + 0.08 * local_sensor + 0.10 * local_fin + 0.42 * local_shell
        )

    def transform_action(self, action):
        action = np.asarray(action, dtype=float)
        _, fin, shell = self.effective_arrays()
        mobility = 0.88 * np.eye(2)
        for strength, direction in zip(fin, self.directions):
            mobility += 0.42 * float(strength) * np.outer(direction, direction)
        raw = mobility @ action
        mass = 1.0 + 0.28 * float(np.mean(shell)) + 0.10 * self.complexity()
        raw /= mass
        length = float(np.linalg.norm(raw))
        if length > 1.15:
            raw *= 1.15 / length
        return raw

    # ------------------------------------------------------------------
    # Proposal generation
    # ------------------------------------------------------------------

    def _verified_claim(self, brain, auditor):
        if self.require_audit:
            return auditor.verified_matrix(brain)
        return np.maximum(brain.causal_estimate, 0.0)

    def _choose_target_currency(self, brain, auditor, debt):
        verified = self._verified_claim(brain, auditor)
        strength = np.sum(verified, axis=0)
        score = (0.20 + np.asarray(debt, dtype=float)) * (strength + 1e-4)
        if float(np.max(score)) <= 2e-4:
            return int(np.argmax(debt))
        return int(np.argmax(score))

    def _choose_coalition(self, brain, auditor, currency):
        verified = self._verified_claim(brain, auditor)[:, currency]
        if float(np.max(verified)) <= 1e-10:
            verified = np.maximum(brain.causal_estimate[:, currency], 0.0)
        score = verified * (
            0.20 + np.abs(brain.hidden) + 0.20 * np.linalg.norm(brain.motor, axis=1)
        )
        return np.argsort(score)[-6:]

    def _choose_kind(self, brain, coalition, debt, target_currency):
        prediction_need = float(np.mean(brain.prediction_error[coalition]))
        motor_coherence = float(np.linalg.norm(np.mean(brain.motor[coalition], axis=0)))
        shell_need = float(debt[1] + debt[2])
        scores = np.array([
            0.55 + 1.10 * prediction_need,
            0.48 + 0.75 * motor_coherence,
            0.30 + 0.75 * shell_need,
        ])
        scores += self.rng.normal(0.0, 0.12, 3)
        return int(np.argmax(scores))

    def _choose_modality(self, brain, coalition):
        groups = ((0, 3), (3, 6), (6, 9), (9, 12))
        scores = []
        for start, stop in groups:
            receptor_weight = np.mean(np.abs(brain.w_sensor[coalition, start:stop]))
            uncertainty = np.mean(brain.prediction_error[coalition])
            scores.append(float(receptor_weight * (0.25 + uncertainty)))
        scores = np.asarray(scores) + self.rng.normal(0.0, 0.015, 4)
        return int(np.argmax(scores))

    def _proposal_direction(self, brain, coalition):
        motor_vector = np.mean(brain.motor[coalition], axis=0)
        if self.rng.random() < 0.25:
            return int(self.rng.integers(MORPH_SLOT_COUNT))
        return circular_slot(motor_vector, rng=self.rng)

    def _choose_delta(self, current_value):
        # Growth dominates early life; high-complexity organs occasionally face
        # a pruning trial. Small reversible steps keep noisy evidence from
        # causing a catastrophic one-shot redesign.
        prune_probability = 0.10 + 0.28 * max(0.0, current_value - 0.50)
        sign = -1.0 if self.rng.random() < prune_probability else 1.0
        magnitude = float(self.rng.uniform(0.10, 0.18))
        if sign > 0.0 and current_value > 0.92:
            sign = -1.0
        if sign < 0.0 and current_value < 0.08:
            sign = 1.0
        return sign * magnitude

    def maybe_start(self, age, debt, brain, auditor, audit_busy=False, force=False):
        if not self.enabled or self.active or audit_busy:
            return False
        if not force:
            if self.cooldown > 0.0 or age < 24.0 or self.material < 0.055:
                return False
            if self.require_audit and auditor.completed < 2:
                return False
            if self.require_audit and float(np.max(auditor.gate())) < 0.08:
                return False
            if float(np.max(debt)) > 0.82:
                return False

        self.target_currency = self._choose_target_currency(
            brain, auditor, debt
        )
        coalition = self._choose_coalition(
            brain, auditor, self.target_currency
        )
        self.kind = self._choose_kind(
            brain, coalition, debt, self.target_currency
        )
        self.slot = self._proposal_direction(brain, coalition)
        self.modality = (
            self._choose_modality(brain, coalition)
            if self.kind == MORPH_SENSOR else 0
        )

        if self.kind == MORPH_SENSOR:
            current = float(self.sensor[self.slot, self.modality])
        elif self.kind == MORPH_FIN:
            current = float(self.fin[self.slot])
        else:
            current = float(self.shell[self.slot])
        self.delta = self._choose_delta(current)
        bounded = clamp(current + self.delta, 0.0, 1.0)
        self.delta = bounded - current
        if abs(self.delta) < 0.025:
            self.cooldown = 3.0
            return False

        self.reserve = 0.030 + 0.080 * abs(self.delta)
        if self.material < self.reserve:
            self.cooldown = 5.0
            return False
        self.material -= self.reserve

        self.proposals += 1
        self.last_proposal = self.description()
        if not self.escrow_enabled:
            self._commit_candidate()
            self.accepted += 1
            self.last_accepted = True
            self.last_status = 'immediate commit'
            self.cooldown = 12.0
            self.reserve = 0.0
            return True

        sequence = np.array([0, 0, 0, 0, 1, 1, 1, 1], dtype=np.int8)
        self.sequence = self.rng.permutation(sequence)
        self.epoch_index = 0
        self.epoch_elapsed = 0.0
        self.epoch_improvement[:] = 0.0
        self.epoch_rates[:] = 0.0
        self.epoch_complete[:] = False
        self.trial_need_sum[:] = 0.0
        self.trial_elapsed = 0.0
        self.active = True
        self.last_status = 'escrow trial'
        return True

    # ------------------------------------------------------------------
    # Trial and independent constitutional votes
    # ------------------------------------------------------------------

    def tick_cooldown(self, dt):
        if not self.active:
            self.cooldown = max(0.0, self.cooldown - float(dt))

    def observe(self, debt_before, debt_after, dt):
        if not self.active:
            self.tick_cooldown(dt)
            return False

        dt = float(dt)
        debt_before = np.asarray(debt_before, dtype=float)
        debt_after = np.asarray(debt_after, dtype=float)
        self.epoch_improvement += debt_before - debt_after
        self.trial_need_sum += 0.5 * (debt_before + debt_after) * dt
        self.epoch_elapsed += dt
        self.trial_elapsed += dt

        if self.epoch_elapsed + 1e-12 < self.epoch_duration:
            return False

        self.epoch_rates[self.epoch_index] = (
            self.epoch_improvement / max(self.epoch_elapsed, 1e-9)
        )
        self.epoch_complete[self.epoch_index] = True
        self.epoch_index += 1
        self.epoch_elapsed = 0.0
        self.epoch_improvement[:] = 0.0

        if self.epoch_index < TRIAL_EPOCH_COUNT:
            return False

        self._finish_trial()
        return True

    @staticmethod
    def _median_and_mad(values):
        median = np.median(values, axis=0)
        mad = np.median(np.abs(values - median[None, :]), axis=0)
        return median, 1.4826 * mad

    def _finish_trial(self):
        if not bool(np.all(self.epoch_complete)):
            raise RuntimeError('organ trial finished with incomplete epochs')
        treatment = self.epoch_rates[(self.sequence == 1) & self.epoch_complete]
        control = self.epoch_rates[(self.sequence == 0) & self.epoch_complete]
        treatment_median, treatment_mad = self._median_and_mad(treatment)
        control_median, control_mad = self._median_and_mad(control)
        effect = treatment_median - control_median
        standard_error = (
            treatment_mad / math.sqrt(max(1, treatment.shape[0]))
            + control_mad / math.sqrt(max(1, control.shape[0]))
            + 0.00020
        )
        z = effect / standard_error
        need = self.trial_need_sum / max(self.trial_elapsed, 1e-9)

        yes = (
            (need > 0.10)
            & (effect > 0.00012)
            & (z > 0.20)
        )
        veto = (effect < -0.00035) & (z < -0.35)

        votes = np.zeros(TROPHIC_COUNT, dtype=np.int8)
        votes[yes] = 1
        votes[veto] = -1
        self.last_effect = effect.copy()
        self.last_z = z.copy()
        self.last_votes = votes

        if self.pareto_veto_enabled:
            accepted = bool(np.any(yes) and not np.any(veto))
        else:
            # Ablation only: collapse the four constitutional votes to one
            # need-weighted scalar, removing independent veto power.
            weights = 0.05 + need
            scalar_effect = float(np.sum(weights * effect) / np.sum(weights))
            scalar_z = float(np.sum(weights * z) / np.sum(weights))
            accepted = scalar_effect > 0.00008 and scalar_z > 0.10

        channel = self._candidate_channel()
        old_count = int(self.hypothesis_count[self.kind, self.slot, channel])
        new_count = old_count + 1
        old_mean = self.hypothesis_mean[
            self.kind, self.slot, channel
        ].copy()
        self.hypothesis_mean[self.kind, self.slot, channel] = (
            old_mean + (effect - old_mean) / new_count
        )
        self.hypothesis_count[self.kind, self.slot, channel] = new_count

        if accepted:
            self._commit_candidate()
            self.accepted += 1
            self.last_accepted = True
            self.last_status = 'accepted'
            # Escrow is consumed by permanent tissue.
        else:
            self.rejected += 1
            self.last_accepted = False
            self.last_status = 'rejected'
            # A rejected prototype can be partly recycled, but experimentation
            # is not free.
            self.material = min(1.0, self.material + 0.30 * self.reserve)

        self.reserve = 0.0
        self.active = False
        self.cooldown = 12.0

    def _commit_candidate(self):
        if self.kind == MORPH_SENSOR:
            self.sensor[self.slot, self.modality] = clamp(
                self.sensor[self.slot, self.modality] + self.delta, 0.0, 1.0
            )
        elif self.kind == MORPH_FIN:
            self.fin[self.slot] = clamp(
                self.fin[self.slot] + self.delta, 0.0, 1.0
            )
        else:
            self.shell[self.slot] = clamp(
                self.shell[self.slot] + self.delta, 0.0, 1.0
            )

    def add_material(self, amount):
        self.material = clamp(self.material + float(amount), 0.0, 1.0)

    def description(self):
        sign = '+' if self.delta >= 0.0 else ''
        if self.kind == MORPH_SENSOR:
            detail = MORPH_MODALITY_NAMES[self.modality]
        else:
            detail = MORPH_KIND_NAMES[self.kind]
        return '{}@{} {}{:.2f}'.format(
            detail, self.slot, sign, self.delta
        )

    def status_text(self):
        if not self.enabled:
            return 'fixed body'
        if not self.active:
            return self.last_status
        arm = 'ON' if self.treatment_on else 'OFF'
        return '{} {}/{} {}'.format(
            arm, self.epoch_index + 1, TRIAL_EPOCH_COUNT, self.description()
        )

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def state_dict(self):
        return {
            'morph_rng_state': encode_rng_state(self.rng),
            'morph_enabled': bool_array(self.enabled),
            'morph_require_audit': bool_array(self.require_audit),
            'morph_escrow_enabled': bool_array(self.escrow_enabled),
            'morph_pareto_veto_enabled': bool_array(self.pareto_veto_enabled),
            'morph_sensor': self.sensor,
            'morph_fin': self.fin,
            'morph_shell': self.shell,
            'morph_material': scalar_array(self.material),
            'morph_active': bool_array(self.active),
            'morph_kind': scalar_array(self.kind, np.int64),
            'morph_slot': scalar_array(self.slot, np.int64),
            'morph_modality': scalar_array(self.modality, np.int64),
            'morph_delta': scalar_array(self.delta),
            'morph_target_currency': scalar_array(self.target_currency, np.int64),
            'morph_reserve': scalar_array(self.reserve),
            'morph_sequence': self.sequence,
            'morph_epoch_index': scalar_array(self.epoch_index, np.int64),
            'morph_epoch_elapsed': scalar_array(self.epoch_elapsed),
            'morph_epoch_duration': scalar_array(self.epoch_duration),
            'morph_epoch_improvement': self.epoch_improvement,
            'morph_epoch_rates': self.epoch_rates,
            'morph_epoch_complete': self.epoch_complete.astype(np.uint8),
            'morph_trial_need_sum': self.trial_need_sum,
            'morph_trial_elapsed': scalar_array(self.trial_elapsed),
            'morph_cooldown': scalar_array(self.cooldown),
            'morph_proposals': scalar_array(self.proposals, np.int64),
            'morph_accepted': scalar_array(self.accepted, np.int64),
            'morph_rejected': scalar_array(self.rejected, np.int64),
            'morph_last_accepted': bool_array(self.last_accepted),
            'morph_last_effect': self.last_effect,
            'morph_last_z': self.last_z,
            'morph_last_votes': self.last_votes,
            'morph_last_status': np.array(self.last_status),
            'morph_last_proposal': np.array(self.last_proposal),
            'morph_hypothesis_mean': self.hypothesis_mean,
            'morph_hypothesis_count': self.hypothesis_count,
        }

    def load_state(self, data):
        self.sensor = np.array(data['morph_sensor'], dtype=float)
        self.fin = np.array(data['morph_fin'], dtype=float)
        self.shell = np.array(data['morph_shell'], dtype=float)
        self.material = float(data['morph_material'])
        self.active = bool(int(data['morph_active']))
        self.kind = int(data['morph_kind'])
        self.slot = int(data['morph_slot'])
        self.modality = int(data['morph_modality'])
        self.delta = float(data['morph_delta'])
        self.target_currency = int(data['morph_target_currency'])
        self.reserve = float(data['morph_reserve'])
        self.sequence = np.array(data['morph_sequence'], dtype=np.int8)
        self.epoch_index = int(data['morph_epoch_index'])
        self.epoch_elapsed = float(data['morph_epoch_elapsed'])
        self.epoch_duration = float(data['morph_epoch_duration'])
        self.epoch_improvement = np.array(
            data['morph_epoch_improvement'], dtype=float
        )
        self.epoch_rates = np.array(data['morph_epoch_rates'], dtype=float)
        self.epoch_complete = np.array(
            data['morph_epoch_complete'], dtype=bool
        )
        self.trial_need_sum = np.array(
            data['morph_trial_need_sum'], dtype=float
        )
        self.trial_elapsed = float(data['morph_trial_elapsed'])
        self.cooldown = float(data['morph_cooldown'])
        self.proposals = int(data['morph_proposals'])
        self.accepted = int(data['morph_accepted'])
        self.rejected = int(data['morph_rejected'])
        self.last_accepted = bool(int(data['morph_last_accepted']))
        self.last_effect = np.array(data['morph_last_effect'], dtype=float)
        self.last_z = np.array(data['morph_last_z'], dtype=float)
        self.last_votes = np.array(data['morph_last_votes'], dtype=np.int8)
        self.last_status = str(np.asarray(data['morph_last_status']).item())
        self.last_proposal = str(np.asarray(data['morph_last_proposal']).item())
        self.hypothesis_mean = np.array(
            data['morph_hypothesis_mean'], dtype=float
        )
        self.hypothesis_count = np.array(
            data['morph_hypothesis_count'], dtype=np.int64
        )
        restore_rng_state(self.rng, data['morph_rng_state'])


# =============================================================================
# Embodied SOMA-2 core
# =============================================================================


class SomaTwoCore(SomaOneCore):
    def __init__(
        self,
        seed=None,
        learning_enabled=True,
        scalarize_trophic=False,
        diffusion_enabled=True,
        turnover_enabled=True,
        audit_enabled=True,
        morphogenesis_enabled=True,
        require_audit=True,
        escrow_enabled=True,
        pareto_veto_enabled=True,
    ):
        if seed is None:
            seed = int(time.time() * 1000.0) & 0xFFFFFFFF
        self._brain_settings = dict(
            learning_enabled=learning_enabled,
            scalarize_trophic=scalarize_trophic,
            diffusion_enabled=diffusion_enabled,
            turnover_enabled=turnover_enabled,
        )
        super().__init__(
            seed=seed,
            learning_enabled=learning_enabled,
            scalarize_trophic=scalarize_trophic,
            diffusion_enabled=diffusion_enabled,
            turnover_enabled=turnover_enabled,
        )
        # Replace SOMA-1's base tissue without changing the already-created
        # world RNG or body state.
        self.brain = AuditedCausalTissue(seed=self.seed, **self._brain_settings)
        self.auditor = CausalAuditor(
            seed=self.seed,
            enabled=audit_enabled,
            group_size=5,
        )
        self.morphology = EscrowMorphology(
            seed=self.seed,
            enabled=morphogenesis_enabled,
            require_audit=require_audit,
            escrow_enabled=escrow_enabled,
            pareto_veto_enabled=pareto_veto_enabled,
        )
        self.last_body_debt = self.body_debt()

    # ------------------------------------------------------------------
    # Morphology-dependent sensing
    # ------------------------------------------------------------------

    def _chemical_concentrations_at(self, points, sources, scale):
        """Vectorized toroidal concentration for one or many receptor tips."""
        points = np.atleast_2d(np.asarray(points, dtype=float))
        sources = np.asarray(sources, dtype=float)
        deltas = sources[None, :, :] - points[:, None, :]
        deltas = (deltas + 0.5) % 1.0 - 0.5
        distances = np.linalg.norm(deltas, axis=2)
        concentration_sum = np.sum(
            np.exp(-distances / float(scale)), axis=1
        )
        values = 1.0 - np.exp(-0.65 * concentration_sum)
        return np.clip(values, 0.0, 1.0)

    def _chemical_concentration_at(self, position, sources, scale):
        return float(
            self._chemical_concentrations_at(position, sources, scale)[0]
        )

    def _chemical_true_gradient_at(self, position, sources, scale):
        position = np.asarray(position, dtype=float)
        sources = np.asarray(sources, dtype=float)
        deltas = sources - position[None, :]
        deltas = (deltas + 0.5) % 1.0 - 0.5
        distances = np.linalg.norm(deltas, axis=1)
        concentration = np.exp(-distances / float(scale))
        total = float(np.sum(concentration))
        if total <= 1e-10:
            return np.zeros(2, dtype=float)
        vector = np.sum(
            deltas / (distances[:, None] + 0.03)
            * concentration[:, None],
            axis=0,
        ) / total
        return np.clip(vector, -1.0, 1.0)

    def _organ_chemical(self, sources, scale, modality):
        sensor, _, _ = self.morphology.effective_arrays()
        strengths = sensor[:, modality]
        center = self._chemical_concentration_at(self.pos, sources, scale)
        reach = 0.014 + 0.060 * strengths
        points = (
            self.pos[None, :]
            + self.morphology.directions * reach[:, None]
        ) % 1.0
        samples = self._chemical_concentrations_at(points, sources, scale)

        weights = 0.04 + strengths
        centered = samples - center
        moment = np.sum(
            weights[:, None]
            * centered[:, None]
            * self.morphology.directions,
            axis=0,
        )
        moment *= 7.5 / max(float(np.sum(weights)), 1e-9)
        true_gradient = self._chemical_true_gradient_at(
            self.pos, sources, scale
        )
        gradient = 0.16 * true_gradient + 0.84 * moment

        density = float(np.sum(weights * samples) / np.sum(weights))
        sensor_quality = clamp(float(np.mean(strengths)), 0.02, 1.0)
        noise_scale = 0.010 + 0.020 * (1.0 - sensor_quality)
        gradient += self.rng.normal(0.0, noise_scale, 2)
        density += float(self.rng.normal(0.0, 0.5 * noise_scale))
        return np.clip(gradient, -1.0, 1.0), clamp(density, 0.0, 1.0)

    def _organ_temperature(self):
        sensor, _, _ = self.morphology.effective_arrays()
        strengths = sensor[:, 3]
        center, true_gradient = self.temperature_field(self.pos)
        samples = np.zeros(MORPH_SLOT_COUNT, dtype=float)
        for index, direction in enumerate(self.morphology.directions):
            reach = 0.014 + 0.060 * float(strengths[index])
            point = (self.pos + direction * reach) % 1.0
            samples[index], _ = self.temperature_field(point)
        weights = 0.04 + strengths
        moment = np.sum(
            weights[:, None]
            * (samples - center)[:, None]
            * self.morphology.directions,
            axis=0,
        )
        moment *= 8.2 / max(float(np.sum(weights)), 1e-9)
        gradient = 0.15 * true_gradient + 0.85 * moment
        quality = clamp(float(np.mean(strengths)), 0.02, 1.0)
        gradient += self.rng.normal(0.0, 0.012 + 0.018 * (1.0 - quality), 2)
        return center, np.clip(gradient, -1.0, 1.0)

    def make_sensor(self):
        nutrient_gradient, nutrient_concentration = self._organ_chemical(
            self.nutrient_positions, 0.17, 0
        )
        toxin_gradient, toxin_concentration = self._organ_chemical(
            self.toxin_positions, 0.15, 1
        )
        shelter_gradient, shelter_concentration = self._organ_chemical(
            self.shelter_positions, 0.20, 2
        )
        ambient, thermal_gradient = self._organ_temperature()

        tissue_distress = 1.0 - float(np.mean(self.brain.vitality))
        prediction_uncertainty = float(np.mean(self.brain.prediction_error))

        sensor = np.array([
            nutrient_gradient[0],
            nutrient_gradient[1],
            nutrient_concentration * 2.0 - 1.0,
            toxin_gradient[0],
            toxin_gradient[1],
            toxin_concentration * 2.0 - 1.0,
            shelter_gradient[0],
            shelter_gradient[1],
            shelter_concentration * 2.0 - 1.0,
            ambient * 2.0 - 1.0,
            thermal_gradient[0],
            thermal_gradient[1],
            self.energy * 2.0 - 1.0,
            (self.temperature - 0.50) * 2.0,
            self.integrity * 2.0 - 1.0,
            self.fatigue * 2.0 - 1.0,
            self.vel[0] / MAX_SPEED,
            self.vel[1] / MAX_SPEED,
            self.last_action[0],
            self.last_action[1],
            self.pain * 2.0 - 1.0,
            tissue_distress * 2.0 - 1.0,
            clamp(prediction_uncertainty, 0.0, 1.0) * 2.0 - 1.0,
            1.0,
        ], dtype=float)
        return np.clip(sensor, -1.0, 1.0)

    # ------------------------------------------------------------------
    # Life cycle with mutually exclusive audits and organ trials
    # ------------------------------------------------------------------

    def step(self, dt=1.0 / 30.0):
        dt = clamp(float(dt), 1.0 / 240.0, 0.10)
        if not self.alive:
            return

        debt_before = self.body_debt()

        # Two types of experiments never overlap: otherwise a failed organ and a
        # neuronal knockout could be incorrectly blamed on one another.
        if not self.auditor.busy and not self.morphology.busy:
            priority_audit = (
                self.auditor.enabled
                and (
                    self.auditor.completed < 2
                    or self.auditor.cooldown <= 0.0
                    and self.morphology.cooldown > 3.0
                )
            )
            started = False
            if priority_audit:
                started = self.auditor.maybe_start(
                    self.age,
                    debt_before,
                    self.brain,
                    morphology_busy=False,
                )
            if not started:
                started = self.morphology.maybe_start(
                    self.age,
                    debt_before,
                    self.brain,
                    self.auditor,
                    audit_busy=False,
                )
            if not started and self.auditor.enabled:
                self.auditor.maybe_start(
                    self.age,
                    debt_before,
                    self.brain,
                    morphology_busy=False,
                )

        self.brain.set_audit_gate(
            self.auditor.gate()
            if self.auditor.enabled
            else np.ones((CELL_COUNT, TROPHIC_COUNT), dtype=float)
        )
        self.brain.set_efferent_knockout(
            self.auditor.current_knockout_mask()
        )

        sensor = self.make_sensor()
        action = self.brain.act(sensor, debt_before, dt)
        eaten_before = self.eaten
        self._apply_body_and_world(action, dt)
        if self.eaten > eaten_before:
            self.morphology.add_material(0.070 * (self.eaten - eaten_before))

        next_sensor = self.make_sensor()
        debt_after = self.body_debt()

        # During a causal audit, sensorimotor parameters are frozen and the
        # correlational claim itself is restored afterward. The body still pays
        # the metabolic consequences of the intervention.
        was_learning = self.brain.learning_enabled
        causal_snapshot = None
        if self.auditor.busy:
            self.brain.learning_enabled = False
            causal_snapshot = self.brain.causal_estimate.copy()
        self.brain.learn(next_sensor, debt_after, dt)
        if causal_snapshot is not None:
            self.brain.causal_estimate = causal_snapshot
        self.brain.learning_enabled = was_learning
        self.brain.set_efferent_knockout(None)

        self.auditor.observe(debt_after, dt, self.age + dt)
        self.morphology.observe(debt_before, debt_after, dt)

        self.last_action = np.array(action, dtype=float)
        self.age += dt
        self.last_body_debt = debt_after
        self.viability_integral += dt * (1.0 - float(np.mean(debt_after)))

        if self.energy <= 0.0 or self.integrity <= 0.0:
            self.energy = max(0.0, self.energy)
            self.integrity = max(0.0, self.integrity)
            self.vel[:] = 0.0
            self.alive = False

    # ------------------------------------------------------------------
    # Morphology-dependent body mechanics
    # ------------------------------------------------------------------

    def _apply_body_and_world(self, action, dt):
        action = np.clip(np.asarray(action, dtype=float), -1.0, 1.0)
        shaped_action = self.morphology.transform_action(action)
        target_velocity = shaped_action * MAX_SPEED
        response = 1.0 - math.exp(-4.0 * dt)
        self.vel += (target_velocity - self.vel) * response

        displacement = self.vel * dt
        self.pos = (self.pos + displacement) % 1.0
        self.distance_travelled += float(np.linalg.norm(displacement))

        movement = float(np.dot(shaped_action, shaped_action))
        neural = self.brain.neural_cost()
        shelter = self.shelter_level()
        ambient, _ = self.temperature_field()
        self.last_ambient = ambient
        self.last_shelter = shelter

        sensor_mean, fin_mean, shell_mean = self.morphology.organ_means()
        insulation = clamp(0.44 * shell_mean, 0.0, 0.38)
        thermal_coupling = (0.16 + 0.95 * shelter) * (1.0 - insulation)
        self.temperature += (
            (ambient - self.temperature) * thermal_coupling * dt
            + 0.022 * movement * dt
        )
        self.temperature = clamp(self.temperature, 0.0, 1.0)

        thermal_stress = clamp(
            abs(self.temperature - 0.50) / 0.42, 0.0, 1.0
        )
        locomotor_efficiency = 1.0 + 0.90 * fin_mean
        structural_mass = 1.0 + 0.30 * shell_mean + 0.10 * sensor_mean

        self.fatigue += (
            0.075 * movement * structural_mass / locomotor_efficiency
            + 0.020 * neural
        ) * dt
        rest_fraction = max(0.0, 1.0 - math.sqrt(min(1.0, movement)))
        recovery = (0.008 + 0.160 * shelter) * rest_fraction
        self.fatigue -= recovery * dt
        self.fatigue = clamp(self.fatigue, 0.0, 1.0)

        structure_cost = self.morphology.construction_and_maintenance_cost()
        energy_cost = (
            0.0019
            + 0.0026 * movement * structural_mass / locomotor_efficiency
            + 0.0010 * neural
            + 0.0014 * thermal_stress
            + 0.0010 * self.fatigue
            + structure_cost
        ) * dt
        self.energy -= energy_cost

        if thermal_stress > 0.70:
            damage = (
                0.010
                * (thermal_stress - 0.70)
                / 0.30
                * (1.0 - 0.24 * shell_mean)
                * dt
            )
            self.integrity -= damage
            self.pain = min(1.0, self.pain + damage * 20.0)

        if self.fatigue > 0.90:
            damage = 0.006 * (self.fatigue - 0.90) / 0.10 * dt
            self.integrity -= damage
            self.pain = min(1.0, self.pain + damage * 20.0)

        if (
            self.energy > 0.52
            and self.fatigue < 0.58
            and thermal_stress < 0.55
        ):
            heal_rate = (
                0.0018
                * (self.energy - 0.52)
                / 0.48
                * (1.0 - self.fatigue)
            )
            healing = min(heal_rate * dt, 1.0 - self.integrity)
            self.integrity += healing
            self.energy -= healing * 0.35

        for index, nutrient in enumerate(self.nutrient_positions):
            delta = wrapped_delta(self.pos, nutrient)
            if float(np.linalg.norm(delta)) < (
                self.morphology.local_radius(delta) + NUTRIENT_RADIUS
            ):
                self.energy = min(1.0, self.energy + 0.17)
                self.eaten += 1
                self.nutrient_positions[index] = self.rng.random(2)

        for index, toxin in enumerate(self.toxin_positions):
            delta = wrapped_delta(self.pos, toxin)
            if float(np.linalg.norm(delta)) < (
                self.morphology.local_radius(delta) + TOXIN_RADIUS
            ):
                local_shell = self.morphology.local_shell(delta)
                protection = clamp(0.62 * local_shell, 0.0, 0.56)
                self.integrity = max(
                    0.0, self.integrity - 0.16 * (1.0 - protection)
                )
                self.energy = max(0.0, self.energy - 0.035)
                self.pain = 1.0
                self.poisoned += 1
                self.toxin_positions[index] = self.rng.random(2)

        self.pain *= math.exp(-2.3 * dt)
        self.energy = clamp(self.energy, 0.0, 1.0)
        self.integrity = clamp(self.integrity, 0.0, 1.0)

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def state_dict(self):
        state = super().state_dict()
        state['save_version'] = scalar_array(SAVE_VERSION, np.int64)
        state.update(self.auditor.state_dict())
        state.update(self.morphology.state_dict())
        return state

    def load_state(self, data):
        if int(data['save_version']) != SAVE_VERSION:
            raise ValueError('unsupported SOMA-2 save version')
        # SOMA-1 loader validates all inherited body and brain arrays. Give it a
        # shallow mapping with its own version number, then restore SOMA-2 state.
        keys = list(data.files) if hasattr(data, 'files') else list(data.keys())
        base = {key: data[key] for key in keys}
        base['save_version'] = scalar_array(1, np.int64)
        super().load_state(base)
        self.auditor.load_state(data)
        self.morphology.load_state(data)
        self.brain.set_audit_gate(
            self.auditor.gate()
            if self.auditor.enabled
            else np.ones((CELL_COUNT, TROPHIC_COUNT), dtype=float)
        )
        self.brain.set_efferent_knockout(None)


# =============================================================================
# Pythonista scene
# =============================================================================


if IN_PYTHONISTA:

    def circle_node(radius, fill_color, stroke_color='clear', parent=None):
        path = ui.Path.oval(-radius, -radius, radius * 2.0, radius * 2.0)
        path.line_width = 1.0
        return ShapeNode(
            path=path,
            fill_color=fill_color,
            stroke_color=stroke_color,
            parent=parent,
        )


    def diamond_node(radius, fill_color, stroke_color='clear', parent=None):
        path = ui.Path()
        path.move_to(0.0, radius)
        path.line_to(radius, 0.0)
        path.line_to(0.0, -radius)
        path.line_to(-radius, 0.0)
        path.close()
        path.line_width = 1.0
        return ShapeNode(
            path=path,
            fill_color=fill_color,
            stroke_color=stroke_color,
            parent=parent,
        )


    def temperature_color(value):
        value = clamp(float(value), 0.0, 1.0)
        if value < 0.5:
            t = value / 0.5
            r = int(18 + 20 * t)
            g = int(42 + 22 * t)
            b = int(67 + 5 * t)
        else:
            t = (value - 0.5) / 0.5
            r = int(38 + 57 * t)
            g = int(64 - 22 * t)
            b = int(72 - 40 * t)
        return '#{:02X}{:02X}{:02X}'.format(r, g, b)


    class SomaTwoScene(Scene):
        def setup(self):
            self.background_color = '#071014'
            self.core = SomaTwoCore()

            self.temperature_tiles = []
            self.tile_columns = 12
            self.tile_rows = 6
            for _ in range(self.tile_columns * self.tile_rows):
                tile = SpriteNode(
                    texture=None,
                    color='#162A3A',
                    size=(10.0, 10.0),
                    parent=self,
                )
                tile.alpha = 0.62
                tile.z_position = -20
                self.temperature_tiles.append(tile)

            self.shelter_nodes = []
            for _ in range(SHELTER_COUNT):
                node = circle_node(20.0, '#355D76', '#73A6C4', parent=self)
                node.alpha = 0.34
                node.z_position = -5
                self.shelter_nodes.append(node)

            self.nutrient_nodes = [
                circle_node(8.0, '#FFD15A', '#FFF1B0', parent=self)
                for _ in range(NUTRIENT_COUNT)
            ]
            self.toxin_nodes = [
                diamond_node(8.5, '#E45B68', '#FFC0C6', parent=self)
                for _ in range(TOXIN_COUNT)
            ]

            self.body = circle_node(18.0, '#54E3BD', '#C5FFF1', parent=self)
            self.body.z_position = 10
            self.core_node = circle_node(6.0, '#F2FFFB', 'clear', parent=self.body)

            self.cell_nodes = []
            for index in range(20):
                angle = 2.0 * math.pi * index / 20.0
                node = circle_node(1.55, '#DFFFF7', 'clear', parent=self.body)
                node.position = (10.0 * math.cos(angle), 10.0 * math.sin(angle))
                self.cell_nodes.append(node)

            self.sensor_nodes = []
            self.fin_nodes = []
            self.shell_nodes = []
            for index, angle in enumerate(self.core.morphology.slot_angles):
                direction = np.array([math.cos(angle), math.sin(angle)])
                shell = circle_node(3.0, '#74E6C2', 'clear', parent=self.body)
                shell.position = tuple(14.0 * direction)
                shell.z_position = 1
                self.shell_nodes.append(shell)

                fin = diamond_node(3.2, '#C9A7FF', 'clear', parent=self.body)
                fin.position = tuple(19.0 * direction)
                fin.z_rotation = angle - math.pi / 2.0
                fin.z_position = 0
                self.fin_nodes.append(fin)

                sensor = circle_node(2.4, '#FFD15A', '#FFFFFF', parent=self.body)
                sensor.position = tuple(24.0 * direction)
                sensor.z_position = 2
                self.sensor_nodes.append(sensor)

            self.bar_backgrounds = []
            self.bar_foregrounds = []
            bar_colors = ('#FFD15A', '#7CC8FF', '#69E5BE', '#C9A7FF')
            for color in bar_colors:
                bg = SpriteNode(
                    texture=None,
                    color='#26383E',
                    size=(116.0, 7.0),
                    parent=self,
                )
                fg = SpriteNode(
                    texture=None,
                    color=color,
                    size=(116.0, 7.0),
                    parent=self,
                )
                bg.anchor_point = (0.0, 0.5)
                fg.anchor_point = (0.0, 0.5)
                self.bar_backgrounds.append(bg)
                self.bar_foregrounds.append(fg)

            self.info_label = LabelNode('', font=('Menlo', 9), parent=self)
            self.info_label.anchor_point = (0.0, 1.0)
            self.info_label.color = '#DCEAEC'

            self.help_label = LabelNode(
                'tap: relocate nutrient   autosave: 20 s',
                font=('Menlo', 9),
                parent=self,
            )
            self.help_label.anchor_point = (1.0, 1.0)
            self.help_label.color = '#7F9AA1'

            self.death_label = LabelNode(
                'DORMANT — tap to regenerate the body',
                font=('Menlo-Bold', 15),
                parent=self,
            )
            self.death_label.color = '#FF8D96'
            self.death_label.alpha = 0.0
            self.death_label.z_position = 30

            self.last_save_time = 0.0
            self.last_tile_update = -100.0
            self._layout()
            self._load_life_if_possible()
            self._sync_nodes(force_tiles=True)

        @property
        def arena_top(self):
            return max(ARENA_BOTTOM + 90.0, float(self.size.h) - HUD_HEIGHT)

        @property
        def play_height(self):
            return self.arena_top - ARENA_BOTTOM

        def did_change_size(self):
            if hasattr(self, 'info_label'):
                self._layout()
                self._sync_nodes(force_tiles=True)

        def _layout(self):
            width = float(self.size.w)
            height = float(self.size.h)
            top = height - 7.0
            self.info_label.position = (9.0, top)
            self.help_label.position = (width - 9.0, top)
            self.death_label.position = (
                width * 0.5,
                ARENA_BOTTOM + self.play_height * 0.5,
            )

            bar_y = height - 66.0
            for index, (bg, fg) in enumerate(zip(
                self.bar_backgrounds, self.bar_foregrounds
            )):
                x = 9.0 + index * 126.0
                bg.position = (x, bar_y)
                fg.position = (x, bar_y)

            tile_width = width / self.tile_columns
            tile_height = self.play_height / self.tile_rows
            for row in range(self.tile_rows):
                for column in range(self.tile_columns):
                    index = row * self.tile_columns + column
                    tile = self.temperature_tiles[index]
                    tile.size = (tile_width + 1.0, tile_height + 1.0)
                    tile.position = (
                        (column + 0.5) * tile_width,
                        ARENA_BOTTOM + (row + 0.5) * tile_height,
                    )

            body_radius_pixels = max(
                15.0, BODY_RADIUS * min(width, self.play_height)
            )
            self.body.scale = body_radius_pixels / 18.0
            shelter_radius_pixels = SHELTER_RADIUS * min(width, self.play_height)
            for node in self.shelter_nodes:
                node.scale = shelter_radius_pixels / 20.0

        def update(self):
            dt = clamp(float(self.dt), 1.0 / 120.0, 1.0 / 15.0)
            self.core.step(dt)
            self._sync_nodes(force_tiles=False)
            if self.t - self.last_save_time >= 20.0:
                self._save_life()
                self.last_save_time = self.t

        def _screen_position(self, normalized):
            return (
                float(normalized[0]) * float(self.size.w),
                ARENA_BOTTOM + float(normalized[1]) * self.play_height,
            )

        def _sync_nodes(self, force_tiles=False):
            if force_tiles or self.t - self.last_tile_update >= 1.0:
                for row in range(self.tile_rows):
                    for column in range(self.tile_columns):
                        index = row * self.tile_columns + column
                        normalized = np.array([
                            (column + 0.5) / self.tile_columns,
                            (row + 0.5) / self.tile_rows,
                        ])
                        value, _ = self.core.temperature_field(normalized)
                        self.temperature_tiles[index].color = temperature_color(value)
                self.last_tile_update = self.t

            for node, position in zip(
                self.nutrient_nodes, self.core.nutrient_positions
            ):
                node.position = self._screen_position(position)
            for node, position in zip(
                self.toxin_nodes, self.core.toxin_positions
            ):
                node.position = self._screen_position(position)
            for node, position in zip(
                self.shelter_nodes, self.core.shelter_positions
            ):
                node.position = self._screen_position(position)

            self.body.position = self._screen_position(self.core.pos)
            self.body.alpha = 1.0 if self.core.alive else 0.25
            self.core_node.alpha = (
                0.18 + 0.42 * self.core.energy + 0.40 * self.core.integrity
            )
            self.death_label.alpha = 0.0 if self.core.alive else 1.0

            for index, node in enumerate(self.cell_nodes):
                activity = abs(float(self.core.brain.hidden[index]))
                vitality = float(self.core.brain.vitality[index])
                node.alpha = 0.12 + 0.50 * activity + 0.38 * vitality
                node.scale = 0.68 + 0.42 * activity + 0.22 * vitality

            sensor, fin, shell = self.core.morphology.effective_arrays()
            modality_colors = ('#FFD15A', '#FF7D89', '#75BFFF', '#A8F3FF')
            candidate_on = self.core.morphology.treatment_on
            for index in range(MORPH_SLOT_COUNT):
                modality = int(np.argmax(sensor[index]))
                sensor_strength = float(np.max(sensor[index]))
                self.sensor_nodes[index].color = modality_colors[modality]
                self.sensor_nodes[index].alpha = 0.18 + 0.82 * sensor_strength
                highlight = (
                    1.25
                    if self.core.morphology.active
                    and index == self.core.morphology.slot
                    and candidate_on
                    else 1.0
                )
                self.sensor_nodes[index].scale = (
                    0.55 + 0.95 * sensor_strength
                ) * highlight
                direction = self.core.morphology.directions[index]
                reach = 21.0 + 12.0 * sensor_strength
                self.sensor_nodes[index].position = tuple(reach * direction)

                self.fin_nodes[index].alpha = 0.10 + 0.90 * float(fin[index])
                self.fin_nodes[index].scale = 0.55 + 1.15 * float(fin[index])
                self.shell_nodes[index].alpha = 0.10 + 0.90 * float(shell[index])
                self.shell_nodes[index].scale = 0.55 + 1.25 * float(shell[index])

                self.sensor_nodes[index].stroke_color = (
                    '#FFFFFF' if highlight > 1.0 else '#D5E9E5'
                )

            values = (
                self.core.energy,
                1.0 - abs(self.core.temperature - 0.50) / 0.50,
                self.core.integrity,
                1.0 - self.core.fatigue,
            )
            for foreground, value in zip(self.bar_foregrounds, values):
                foreground.size = (
                    max(1.0, 116.0 * clamp(value, 0.0, 1.0)), 7.0
                )

            diagnostic = self.core.brain.diagnostics()
            audit = self.core.auditor
            morph = self.core.morphology
            organ_means = morph.organ_means()
            vote_text = ''.join(
                '+' if vote > 0 else '-' if vote < 0 else '0'
                for vote in morph.last_votes
            )
            self.info_label.text = (
                'SOMA-2 age {:6.1f}s E {:.3f} T {:.3f} I {:.3f} F {:.3f} food {} toxin {} material {:.2f}\n'
                'AUDIT {:18s} n {} pass {} fail {} effect {:+.5f} verified {:.4f}\n'
                'MORPH {:29s} P/A/R {}/{}/{} votes {} S/F/H {:.2f}/{:.2f}/{:.2f}\n'
                'tissue V {:.3f} pred {:.3f} causal {:.4f} edges {} born {} rewired {}'
            ).format(
                self.core.age,
                self.core.energy,
                self.core.temperature,
                self.core.integrity,
                self.core.fatigue,
                self.core.eaten,
                self.core.poisoned,
                morph.material,
                audit.status_text(),
                audit.completed,
                audit.passed,
                audit.failed,
                audit.last_target_effect,
                diagnostic['verified_strength'],
                morph.status_text(),
                morph.proposals,
                morph.accepted,
                morph.rejected,
                vote_text,
                organ_means[0], organ_means[1], organ_means[2],
                diagnostic['mean_vitality'],
                diagnostic['prediction_error'],
                diagnostic['causal_strength'],
                diagnostic['edges'],
                diagnostic['births'],
                diagnostic['rewires'],
            )

        def touch_began(self, touch):
            x = clamp(float(touch.location.x), 0.0, float(self.size.w))
            y = clamp(float(touch.location.y), ARENA_BOTTOM, self.arena_top)
            normalized = np.array([
                x / max(1.0, float(self.size.w)),
                (y - ARENA_BOTTOM) / max(1.0, self.play_height),
            ])
            if self.core.alive:
                self.core.relocate_nearest_nutrient(normalized)
            else:
                self.core.regenerate_body(normalized)
            self._save_life()

        def _save_life(self):
            try:
                np.savez(SAVE_FILE, **self.core.state_dict())
            except Exception as exc:
                print('SOMA-2 save failed:', exc)

        def _load_life_if_possible(self):
            if not os.path.exists(SAVE_FILE):
                return
            try:
                with np.load(SAVE_FILE, allow_pickle=False) as data:
                    self.core.load_state(data)
            except Exception as exc:
                print('SOMA-2 load ignored:', exc)

        def pause(self):
            self._save_life()

        def stop(self):
            self._save_life()


# =============================================================================
# Headless helpers
# =============================================================================


def run_headless_trial(
    seed=0,
    seconds=300.0,
    learning_enabled=True,
    scalarize_trophic=False,
    diffusion_enabled=True,
    turnover_enabled=True,
    audit_enabled=True,
    morphogenesis_enabled=True,
    require_audit=True,
    escrow_enabled=True,
    pareto_veto_enabled=True,
    dt=1.0 / 30.0,
):
    core = SomaTwoCore(
        seed=seed,
        learning_enabled=learning_enabled,
        scalarize_trophic=scalarize_trophic,
        diffusion_enabled=diffusion_enabled,
        turnover_enabled=turnover_enabled,
        audit_enabled=audit_enabled,
        morphogenesis_enabled=morphogenesis_enabled,
        require_audit=require_audit,
        escrow_enabled=escrow_enabled,
        pareto_veto_enabled=pareto_veto_enabled,
    )
    maximum_steps = int(max(0.0, float(seconds)) / float(dt))
    for _ in range(maximum_steps):
        core.step(dt)
        if not core.alive:
            break

    diagnostic = core.brain.diagnostics()
    lived = max(core.age, 1e-9)
    sensor_mean, fin_mean, shell_mean = core.morphology.organ_means()
    audit_rate = (
        core.auditor.passed / core.auditor.completed
        if core.auditor.completed else 0.0
    )
    return {
        'seed': int(seed),
        'age': float(core.age),
        'survived': bool(core.alive),
        'food': int(core.eaten),
        'toxin': int(core.poisoned),
        'energy': float(core.energy),
        'temperature': float(core.temperature),
        'integrity': float(core.integrity),
        'fatigue': float(core.fatigue),
        'mean_health': float(core.viability_integral / lived),
        'distance': float(core.distance_travelled),
        'tissue_vitality': diagnostic['mean_vitality'],
        'prediction_error': diagnostic['prediction_error'],
        'verified_strength': diagnostic['verified_strength'],
        'audits': int(core.auditor.completed),
        'audit_passes': int(core.auditor.passed),
        'audit_failures': int(core.auditor.failed),
        'audit_pass_rate': float(audit_rate),
        'audit_last_effect': float(core.auditor.last_target_effect),
        'morph_proposals': int(core.morphology.proposals),
        'morph_accepted': int(core.morphology.accepted),
        'morph_rejected': int(core.morphology.rejected),
        'morph_complexity': float(core.morphology.complexity()),
        'sensor_mean': sensor_mean,
        'fin_mean': fin_mean,
        'shell_mean': shell_mean,
        'material': float(core.morphology.material),
        'births': diagnostic['births'],
        'rewires': diagnostic['rewires'],
    }


def _print_smoke_test():
    result = run_headless_trial(seed=7, seconds=40.0)
    print('SOMA-2 headless smoke test')
    for key in sorted(result):
        print('{:>20}: {}'.format(key, result[key]))


if __name__ == '__main__':
    if IN_PYTHONISTA:
        run(
            SomaTwoScene(),
            orientation=LANDSCAPE,
            frame_interval=2,
            anti_alias=True,
            show_fps=False,
            multi_touch=True,
        )
    else:
        _print_smoke_test()
