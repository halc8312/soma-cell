# coding: utf-8
"""Generate SOMA-CELL 0.4 long-run report from the Scene CSV."""
import SOMA_CELL_0_4_pythonista as soma

if __name__ == '__main__':
    print(soma.generate_report())
