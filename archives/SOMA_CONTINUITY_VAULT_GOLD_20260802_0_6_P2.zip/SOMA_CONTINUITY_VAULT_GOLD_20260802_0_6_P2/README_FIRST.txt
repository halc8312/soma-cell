SOMA CONTINUITY VAULT — GOLD 20260802 / SOMA-CELL 0.6-P2
================================================================
現在の凍結基準: SOMA-CELL 0.6-P2.0
P2組織契約: 0.6-P2.2
身体ポート契約: 0.6-P0.2
次のマイルストーン: 正式SOMA-CELL 0.6

このVaultの目的
----------------
会話の記憶や一時sandboxに依存せず、0.5化学身体、P0身体ポート、
P1一物質神経、P2八細胞物質再帰組織、旧SOMA因果監査系を復元し、
正式0.6の物質的ABBA/BAAB監査・校正・変化ゲートを正しく続ける。

最初に読むもの
--------------
1. governance/00_MANDATORY_STARTUP_GATE_JA.md
2. governance/PROJECT_STATE.json
3. docs/SOMA_CONTEXT_HANDOFF_JA.md
4. docs/SOMA_CELL_0_6_INTEGRATION_CONTRACT.md
5. docs/SOMA_CELL_0_6_P2_TISSUE_CONTRACT.md
6. results/SOMA_CELL_0_6_P2_VALIDATION_RESULTS.txt
7. results/SOMA_CELL_0_6_P2_EXPERIMENT_REPORT.txt

凍結する科学的限定
------------------
- holdout全機構対固定は5/6正、平均AUC +1.872678だがn=6。
- 開発seedは試験環境の校正に使った。
- 予測器の正味身体価値は未証明。
- 再帰の追加価値は極小で未証明。
- 正式0.6でもno-prediction/no-recurrenceを外さない。
- 生命、意識、オープンエンド進化を宣言しない。
