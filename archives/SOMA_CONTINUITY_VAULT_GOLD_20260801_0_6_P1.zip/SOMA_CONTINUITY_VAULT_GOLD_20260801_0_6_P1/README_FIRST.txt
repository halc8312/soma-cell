SOMA CONTINUITY VAULT — GOLD 20260801 / SOMA-CELL 0.6-P1
================================================================
現在の凍結基準: SOMA-CELL 0.6-P1.0
身体ポート契約: 0.6-P0.2
神経組織契約: 0.6-P1.1
次のマイルストーン: SOMA-CELL 0.6-P2

このVaultの目的
----------------
会話コンテキスト、sandboxリンク、一時添付に依存せず、P1の検証済み
1物質神経区画、P0化学身体ポート、SOMA-0〜0.5の系譜を復元し、
P2の8細胞物質神経組織を正しい物質境界上で実装できる状態を保存する。

新しい会話で再開するとき
------------------------
1. このZIP全体を添付する。
2. governance/00_MANDATORY_STARTUP_GATE_JA.mdを最初に読む。
3. governance/PROJECT_STATE.json、docs/SOMA_CONTEXT_HANDOFF_JA.md、
   docs/SOMA_CELL_0_6_INTEGRATION_CONTRACT.md、
   docs/SOMA_CELL_0_6_P0_BODY_PORT_CONTRACT.md、
   docs/SOMA_CELL_0_6_P1_TISSUE_CONTRACT.mdを正本として扱う。
4. SHA256SUMS.txtを照合する。
5. P2実装前にP1本体、18項目検証、24試行レポートを再読し、
   最新Git HEADで新しいP2プリフライト証跡を発行する。

凍結ルール
----------
- P1は1区画の情報処理価値を限定的に示した。
- P1予測器の純身体利益は未証明である。
- P2はP0公開APIとP1組織契約以外から身体へアクセスしない。
- ATP・材料・信号・損傷・死体化学・eDNA・HGTを無料化しない。
- P0 22/22、P1 18/18、等費用ダミー比較を回帰試験として維持する。
- 旧SOMA-5〜7（Rなし）は統合元にしない。

重要
----
ChatGPTの会話コンテキストやsandboxは永久保管を保証しない。このZIPを
ユーザー自身のGoogle Drive、iCloud Drive、Filesアプリ、PC等にも保存する。
